import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

/* --------------------------------------------------------------------------
   秋日田庄 · 微缩三维丰收景   A single-file, procedural Three.js diorama. No external assets, no UI.
   Visual goals: warm low sun, golden wheat, teal water, crimson maples,
   thatched farmhouses and a lived-in courtyard.
   -------------------------------------------------------------------------- */

export function initAutumnScene(container) {
  const host = typeof container === 'string' ? document.querySelector(container) : container;
  if (!host) throw new Error('initAutumnScene: container not found');

  if (window.__HARVEST__ && typeof window.__HARVEST__.destroy === 'function') {
    try { window.__HARVEST__.destroy(); } catch (error) { /* previous scene already gone */ }
  }

  host.replaceChildren();
  host.classList.add('is-autumn-scene');

  const readHostSize = () => {
    const rect = host.getBoundingClientRect();
    return {
      width: Math.max(1, Math.round(rect.width || host.clientWidth || window.innerWidth)),
      height: Math.max(1, Math.round(rect.height || host.clientHeight || window.innerHeight)),
    };
  };

  let viewport = readHostSize();
  const IS_SMALL = viewport.width < 760;
  const SHADOW_SIZE = IS_SMALL ? 1024 : 2048;

  function pixelRatioForViewport() {
    const raw = window.devicePixelRatio || 1;
    const cap = IS_SMALL ? 1.35 : 1.8;
    const budget = IS_SMALL ? 1900000 : 3300000;
    const pixels = Math.max(1, viewport.width * viewport.height);
    return Math.max(1, Math.min(raw, cap, Math.sqrt(budget / pixels)));
  }

  const canvas = document.createElement('canvas');
  canvas.className = 'autumn-scene-canvas';
  canvas.setAttribute('aria-label', '秋日田园丰收微缩三维场景');
  host.appendChild(canvas);

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: 'high-performance',
    stencil: false,
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.98;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.shadowMap.autoUpdate = false;
  renderer.setPixelRatio(pixelRatioForViewport());
  renderer.setSize(viewport.width, viewport.height, false);

  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.display = 'block';

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0xf0d4a4, 36, 88);

const TARGET = new THREE.Vector3(0, 1.15, 0.15);
const camera = new THREE.PerspectiveCamera(36, viewport.width / viewport.height, 0.3, 180);

function setHomeCamera() {
  const aspect = viewport.width / viewport.height;
  TARGET.set(0, 1.15, 0.15);
  if (aspect < 0.82) {
    // Tall frame: keep the entire square farm plate in view from above.
    camera.position.set(0.8, 36.0, 13.0);
    camera.fov = 52;
  } else if (aspect < 1.12) {
    camera.position.set(0.6, 30.0, 11.5);
    camera.fov = 42;
  } else {
    // High-angle opening: the harvested field reads as a square diorama.
    camera.position.set(0.6, 29.0, 11.0);
    camera.fov = 40;
  }
  camera.lookAt(TARGET);
  camera.updateProjectionMatrix();
}
setHomeCamera();

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.copy(TARGET);
controls.enableDamping = true;
controls.dampingFactor = 0.055;
controls.enablePan = false;
controls.minDistance = 11.5;
controls.maxDistance = 45;
controls.minPolarAngle = 0.34;
controls.maxPolarAngle = 1.34;
controls.rotateSpeed = 0.56;
controls.zoomSpeed = 0.72;
controls.update();

/* --------------------------------------------------------------------------
   Cinematic post stack
   RenderPass keeps the scene in linear HDR, UnrealBloom adds a soft warm halo,
   and OutputPass performs the single final ACES tone map + sRGB conversion.
   -------------------------------------------------------------------------- */

const composer = new EffectComposer(renderer);
const renderPass = new RenderPass(scene, camera);
const bloomPass = new UnrealBloomPass(
  new THREE.Vector2(viewport.width, viewport.height),
  0.8,
  0.5,
  0.8,
);
bloomPass.threshold = 0.8;
bloomPass.strength = 0.8;
bloomPass.radius = 0.5;
// A warm tint keeps the bloom from looking like a cold camera haze.
const bloomTints = [
  [1.0, 0.90, 0.76],
  [1.0, 0.88, 0.72],
  [1.0, 0.86, 0.68],
  [1.0, 0.84, 0.65],
  [1.0, 0.82, 0.62],
];
bloomPass.bloomTintColors = bloomTints.map(([r, g, b]) => new THREE.Vector3(r, g, b));
const outputPass = new OutputPass();
composer.addPass(renderPass);
composer.addPass(bloomPass);
composer.addPass(outputPass);
composer.setPixelRatio(renderer.getPixelRatio());
composer.setSize(viewport.width, viewport.height);

const clock = new THREE.Clock();
const timeUniforms = {
  uTime: { value: 0 },
};

/* --------------------------------------------------------------------------
   Deterministic helpers
   -------------------------------------------------------------------------- */

function mulberry32(seed) {
  let a = seed >>> 0;
  return function random() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rng = mulberry32(0x9e3779b9);
const rand = (a = 0, b = 1) => a + (b - a) * rng();
const choose = (list) => list[Math.floor(rng() * list.length)];

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lerp = (a, b, t) => a + (b - a) * t;
function smooth(a, b, x) {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
}
const V3 = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const C = (hex) => new THREE.Color(hex);

function offsetColor(hex, h = 0, s = 0, l = 0) {
  return new THREE.Color(hex).offsetHSL(h, s, l);
}

/* --------------------------------------------------------------------------
   Procedural texture atelier
   -------------------------------------------------------------------------- */

const maxAnisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());

function makeTexture(w, h, painter, options = {}) {
  const { repeat = [1, 1], srgb = true, wrap = true } = options;
  const surface = document.createElement('canvas');
  surface.width = w;
  surface.height = h;
  const ctx = surface.getContext('2d');
  painter(ctx, w, h);
  const texture = new THREE.CanvasTexture(surface);
  texture.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  if (wrap) {
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
  } else {
    texture.wrapS = THREE.ClampToEdgeWrapping;
    texture.wrapT = THREE.ClampToEdgeWrapping;
  }
  texture.repeat.set(repeat[0], repeat[1]);
  texture.anisotropy = maxAnisotropy;
  texture.needsUpdate = true;
  return texture;
}

function speckle(ctx, w, h, count, colors, sizeMin, sizeMax, localRng) {
  for (let i = 0; i < count; i += 1) {
    const r = localRng();
    ctx.globalAlpha = 0.08 + localRng() * 0.28;
    ctx.fillStyle = colors[Math.floor(localRng() * colors.length)];
    const s = sizeMin + localRng() * (sizeMax - sizeMin);
    ctx.beginPath();
    ctx.ellipse(localRng() * w, localRng() * h, s, s * (0.45 + r * 0.8), localRng() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

const groundDetail = makeTexture(256, 256, (ctx, w, h) => {
  const rr = mulberry32(73);
  ctx.fillStyle = '#f5ecd8';
  ctx.fillRect(0, 0, w, h);
  for (let i = 0; i < 5200; i += 1) {
    const light = rr() > 0.52;
    ctx.strokeStyle = light ? 'rgba(255,248,218,0.22)' : 'rgba(83,66,34,0.14)';
    ctx.lineWidth = 0.7 + rr() * 1.1;
    const x = rr() * w;
    const y = rr() * h;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (rr() - 0.5) * 4, y - 1 - rr() * 4);
    ctx.stroke();
  }
  speckle(ctx, w, h, 520, ['#73552f', '#c7a75f', '#f9e8b9'], 0.6, 2.1, rr);
}, { repeat: [7, 7] });

const soilTexture = makeTexture(256, 256, (ctx, w, h) => {
  const rr = mulberry32(19);
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#9c7138');
  grad.addColorStop(1, '#76502b');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
  speckle(ctx, w, h, 2200, ['#66431f', '#c09755', '#d2ac68', '#4f371e'], 0.8, 3.8, rr);
  for (let i = 0; i < 36; i += 1) {
    ctx.strokeStyle = 'rgba(75,49,23,0.20)';
    ctx.lineWidth = 1 + rr() * 2;
    ctx.beginPath();
    const y = rr() * h;
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(w * 0.3, y + 6, w * 0.65, y - 7, w, y + 2);
    ctx.stroke();
  }
}, { repeat: [3, 3] });

// A brighter straw mat sits on top of each field bed and furrow. This keeps
// the fields luminous gold even when the sun rakes across them at a low angle.
const stubbleTexture = makeTexture(256, 256, (ctx, w, h) => {
  const rr = mulberry32(29);
  ctx.fillStyle = '#d8a849';
  ctx.fillRect(0, 0, w, h);
  for (let i = 0; i < 3600; i += 1) {
    const light = rr() > 0.34;
    ctx.strokeStyle = light ? 'rgba(255,231,156,0.42)' : 'rgba(133,83,28,0.24)';
    ctx.lineWidth = 0.6 + rr() * 1.2;
    const x = rr() * w;
    const y = rr() * h;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (rr() - 0.5) * 9, y - 2 - rr() * 10);
    ctx.stroke();
  }
  speckle(ctx, w, h, 450, ['#f5d27c', '#b0772d', '#e5b75b'], 1, 2.6, rr);
}, { repeat: [3, 3] });

const thatchTexture = makeTexture(256, 256, (ctx, w, h) => {
  const rr = mulberry32(37);
  ctx.fillStyle = '#b2834a';
  ctx.fillRect(0, 0, w, h);
  const straws = ['#f2d69a', '#e3bc74', '#fae6b8', '#d0a45a', '#c18d47', '#edc983', '#b07b3c', '#f8e2ad'];
  // Long, slightly wandering strands run down the roof slope. On the roof's
  // top UVs this reads as thatch rather than timber boards.
  for (let i = 0; i < 2150; i += 1) {
    const x = rr() * w;
    const y = rr() * h - 25;
    const length = 8 + rr() * 58;
    const drift = (rr() - 0.5) * 7;
    ctx.strokeStyle = straws[Math.floor(rr() * straws.length)];
    ctx.globalAlpha = 0.15 + rr() * 0.44;
    ctx.lineWidth = 0.55 + rr() * 2.3;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + drift * 0.5, y + length * 0.45, x + drift, y + length);
    ctx.stroke();
  }
  // Soft compressed courses add depth without turning into plank lines.
  for (let y = -10; y < h; y += 38 + rr() * 26) {
    ctx.strokeStyle = 'rgba(105,68,31,0.12)';
    ctx.lineWidth = 3 + rr() * 4;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y + (rr() - 0.5) * 7);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,238,190,0.16)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(0, y + 5);
    ctx.lineTo(w, y + 5 + (rr() - 0.5) * 5);
    ctx.stroke();
  }
  // Occasional darker packed clumps.
  for (let i = 0; i < 130; i += 1) {
    ctx.fillStyle = rr() > 0.5 ? 'rgba(112,72,33,0.20)' : 'rgba(255,231,172,0.20)';
    ctx.beginPath();
    ctx.ellipse(rr() * w, rr() * h, 3 + rr() * 13, 1.5 + rr() * 4, (rr() - 0.5) * 0.4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  for (let x = 10; x < w; x += 52 + rr() * 38) {
    ctx.strokeStyle = 'rgba(76,48,20,0.12)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x - 8, h);
    ctx.stroke();
  }
  speckle(ctx, w, h, 400, ['#64421e', '#ffe8b5', '#8a5c2a'], 0.8, 2.2, rr);
}, { repeat: [2.2, 1.5] });

const tileTexture = makeTexture(256, 256, (ctx, w, h) => {
  const rr = mulberry32(83);
  ctx.fillStyle = '#43565a';
  ctx.fillRect(0, 0, w, h);
  const rowH = 30;
  for (let row = -1; row < h / rowH + 1; row += 1) {
    const offset = row % 2 ? 17 : 0;
    for (let col = -1; col < w / 34 + 2; col += 1) {
      const x = col * 34 + offset;
      const y = row * rowH;
      const grad = ctx.createLinearGradient(x, y, x + 28, y);
      grad.addColorStop(0, '#60777a');
      grad.addColorStop(0.5, '#7f9694');
      grad.addColorStop(1, '#384b4e');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.roundRect(x + 1, y + 2, 30, rowH - 4, [0, 0, 12, 12]);
      ctx.fill();
      ctx.strokeStyle = 'rgba(30,43,45,0.55)';
      ctx.lineWidth = 1.2;
      ctx.stroke();
    }
  }
  speckle(ctx, w, h, 280, ['#a9bbb4', '#2e3f42'], 0.5, 1.8, rr);
}, { repeat: [2, 2] });

const plasterTexture = makeTexture(256, 256, (ctx, w, h) => {
  const rr = mulberry32(91);
  ctx.fillStyle = '#e7d5ad';
  ctx.fillRect(0, 0, w, h);
  speckle(ctx, w, h, 1800, ['#cbb58c', '#f7eccf', '#ae946c', '#d7c39a'], 0.8, 3.5, rr);
  for (let i = 0; i < 20; i += 1) {
    ctx.strokeStyle = 'rgba(116,95,65,0.10)';
    ctx.lineWidth = 1 + rr() * 2;
    const x = rr() * w;
    const y = rr() * h;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (rr() - 0.5) * 60, y + 10 + rr() * 45);
    ctx.stroke();
  }
}, { repeat: [2, 2] });

const woodTexture = makeTexture(256, 256, (ctx, w, h) => {
  const rr = mulberry32(41);
  ctx.fillStyle = '#65432a';
  ctx.fillRect(0, 0, w, h);
  const tones = ['#7c5637', '#4e3220', '#8d6744', '#5a3a23', '#9f7850'];
  for (let i = 0; i < 220; i += 1) {
    ctx.strokeStyle = tones[Math.floor(rr() * tones.length)];
    ctx.globalAlpha = 0.16 + rr() * 0.3;
    ctx.lineWidth = 0.6 + rr() * 2.3;
    const x = rr() * w;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.bezierCurveTo(x + (rr() - 0.5) * 15, h * 0.33, x + (rr() - 0.5) * 14, h * 0.68, x + (rr() - 0.5) * 9, h);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  for (let i = 0; i < 7; i += 1) {
    const x = rr() * w;
    const y = rr() * h;
    ctx.strokeStyle = 'rgba(38,22,12,0.45)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(x, y, 3 + rr() * 7, 8 + rr() * 13, rr() * Math.PI, 0, Math.PI * 2);
    ctx.stroke();
  }
}, { repeat: [1, 2] });

const barkTexture = makeTexture(128, 256, (ctx, w, h) => {
  const rr = mulberry32(511);
  ctx.fillStyle = '#533826';
  ctx.fillRect(0, 0, w, h);
  const tones = ['#2f2016', '#74503a', '#8c6a4e', '#3d2a1d', '#6a4831'];
  for (let i = 0; i < 120; i += 1) {
    ctx.strokeStyle = tones[Math.floor(rr() * tones.length)];
    ctx.globalAlpha = 0.22 + rr() * 0.42;
    ctx.lineWidth = 0.6 + rr() * 2.8;
    const x = rr() * w;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    for (let y = 0; y < h; y += 24) {
      ctx.lineTo(x + Math.sin(y * 0.06 + rr() * 2) * 3 + (rr() - 0.5) * 3, y);
    }
    ctx.stroke();
  }
  for (let i = 0; i < 80; i += 1) {
    ctx.fillStyle = rr() > 0.45 ? 'rgba(148,155,117,0.24)' : 'rgba(206,186,139,0.15)';
    ctx.beginPath();
    ctx.ellipse(rr() * w, rr() * h, 1 + rr() * 4, 1 + rr() * 2, rr() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}, { repeat: [1, 1] });

const wheatTexture = makeTexture(128, 256, (ctx, w, h) => {
  const rr = mulberry32(311);
  ctx.clearRect(0, 0, w, h);
  const stems = 12;
  for (let i = 0; i < stems; i += 1) {
    const baseX = 8 + (i / stems) * (w - 16) + (rr() - 0.5) * 9;
    const tipX = baseX + (rr() - 0.5) * 24;
    const tipY = 12 + rr() * 26;
    const shade = rr();
    ctx.strokeStyle = shade > 0.6 ? 'rgba(255,242,204,0.98)' : shade > 0.3 ? 'rgba(245,217,153,0.98)' : 'rgba(229,197,128,0.97)';
    ctx.lineWidth = 1.7 + rr() * 1.7;
    ctx.beginPath();
    ctx.moveTo(baseX, h);
    ctx.quadraticCurveTo(baseX + (rr() - 0.5) * 10, h * 0.58, tipX, tipY + 42);
    ctx.stroke();
    // grain head
    const headAngle = -0.35 - rr() * 0.18;
    for (let k = 0; k < 10; k += 1) {
      const t = k / 9;
      const gx = lerp(tipX, tipX + Math.cos(headAngle) * 24, t);
      const gy = lerp(tipY + 42, tipY + 1, t);
      ctx.fillStyle = k % 2 ? 'rgba(255,246,208,1)' : 'rgba(239,207,137,0.98)';
      ctx.beginPath();
      ctx.ellipse(gx + (k % 2 ? 2.6 : -2.6), gy, 2.8, 4.8, -0.45, 0, Math.PI * 2);
      ctx.fill();
    }
    // slender leaves
    ctx.strokeStyle = 'rgba(236,207,142,0.72)';
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.moveTo(baseX, h * 0.67);
    ctx.quadraticCurveTo(baseX + (rr() - 0.5) * 35, h * 0.5, baseX + (rr() - 0.5) * 48, h * 0.38);
    ctx.stroke();
  }
  // A few extra golden glints keep distant fields from reading as bare stems.
  for (let i = 0; i < 30; i += 1) {
    ctx.fillStyle = 'rgba(255,230,161,0.40)';
    ctx.beginPath();
    ctx.ellipse(rr() * w, 20 + rr() * (h - 35), 1 + rr() * 2.2, 3 + rr() * 4.5, -0.4, 0, Math.PI * 2);
    ctx.fill();
  }
}, { repeat: [1, 1], wrap: false });

const smokeTexture = makeTexture(128, 128, (ctx, w, h) => {
  const grad = ctx.createRadialGradient(w / 2, h / 2, 3, w / 2, h / 2, w / 2);
  grad.addColorStop(0, 'rgba(255,248,226,0.85)');
  grad.addColorStop(0.35, 'rgba(255,242,216,0.45)');
  grad.addColorStop(0.75, 'rgba(255,238,210,0.12)');
  grad.addColorStop(1, 'rgba(255,238,210,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}, { wrap: false });

const glowTexture = makeTexture(64, 64, (ctx, w, h) => {
  const grad = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
  grad.addColorStop(0, 'rgba(255,255,238,1)');
  grad.addColorStop(0.22, 'rgba(255,236,177,0.85)');
  grad.addColorStop(0.6, 'rgba(255,198,119,0.15)');
  grad.addColorStop(1, 'rgba(255,188,98,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}, { wrap: false });

const shadowTexture = makeTexture(128, 128, (ctx, w, h) => {
  const grad = ctx.createRadialGradient(w / 2, h / 2, 2, w / 2, h / 2, w / 2);
  grad.addColorStop(0, 'rgba(8,24,22,0.82)');
  grad.addColorStop(0.45, 'rgba(8,24,22,0.50)');
  grad.addColorStop(0.8, 'rgba(8,24,22,0.12)');
  grad.addColorStop(1, 'rgba(8,24,22,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
}, { wrap: false });

const waterNormalTexture = makeTexture(256, 256, (ctx, w, h) => {
  const image = ctx.createImageData(w, h);
  const data = image.data;
  const strength = 2.7;
  const twoPi = Math.PI * 2;
  const heightAt = (u, v) => (
    Math.sin(twoPi * (3 * u + 5 * v)) * 0.42
    + Math.sin(twoPi * (7 * u - 2 * v + 0.17)) * 0.1
    + Math.cos(twoPi * (4 * u + 9 * v + 0.31)) * 0.2
    + Math.sin(twoPi * (11 * u - 6 * v + 0.73)) * 0.08
    + Math.cos(twoPi * (2 * u + 13 * v + 0.48)) * 0.14
  );
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const u = x / w;
      const v = y / h;
      const eps = 0.0015;
      const du = (heightAt(u + eps, v) - heightAt(u - eps, v)) / (eps * 2);
      const dv = (heightAt(u, v + eps) - heightAt(u, v - eps)) / (eps * 2);
      let nx = -du * strength;
      let ny = -dv * strength;
      let nz = 1;
      const len = Math.hypot(nx, ny, nz);
      nx /= len;
      ny /= len;
      nz /= len;
      const index = (y * w + x) * 4;
      data[index] = Math.round((nx * 0.5 + 0.5) * 255);
      data[index + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      data[index + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      data[index + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
}, { repeat: [2.0, 16.0], srgb: false });

const cloudTexture = makeTexture(256, 128, (ctx, w, h) => {
  const rr = mulberry32(199);
  ctx.clearRect(0, 0, w, h);
  for (let i = 0; i < 40; i += 1) {
    const x = 35 + rr() * (w - 70);
    const y = 35 + rr() * (h - 70);
    const r = 12 + rr() * 35;
    const grad = ctx.createRadialGradient(x, y, 0, x, y, r);
    grad.addColorStop(0, 'rgba(255,247,224,0.18)');
    grad.addColorStop(0.6, 'rgba(255,241,210,0.07)');
    grad.addColorStop(1, 'rgba(255,241,210,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);
  }
}, { wrap: false });

/* --------------------------------------------------------------------------
   Materials / toon ramp
   -------------------------------------------------------------------------- */

const toonGradient = new THREE.DataTexture(
  new Uint8Array([46, 104, 166, 222, 255]),
  5,
  1,
  THREE.RedFormat,
);
toonGradient.minFilter = THREE.NearestFilter;
toonGradient.magFilter = THREE.NearestFilter;
toonGradient.generateMipmaps = false;
toonGradient.needsUpdate = true;

function toon(color = 0xffffff, options = {}) {
  const { flatShading, ...materialOptions } = options;
  return new THREE.MeshToonMaterial({
    color,
    gradientMap: toonGradient,
    ...materialOptions,
  });
}

const matTerrain = toon(0xffffff, { map: groundDetail, vertexColors: true });
const matSoil = toon(0xffffff, { map: soilTexture });
const matSoilDark = toon(0xffffff, { map: soilTexture, color: 0xb89058 });
const matStubble = toon(0xfff0b5, { map: stubbleTexture, emissive: 0x2b1a02, emissiveIntensity: 0.24 });
const matWood = toon(0xffffff, { map: woodTexture });
const matWoodLight = toon(0xc08a50, { map: woodTexture });
const matWoodDark = toon(0x4b2c1a);
const matThatch = toon(0xfff0cc, { map: thatchTexture });
const matThatchDark = toon(0xffffff, { map: thatchTexture, color: 0xc09a62 });
const matTile = toon(0xffffff, { map: tileTexture });
const matPlaster = toon(0xffffff, { map: plasterTexture });
const matBark = toon(0xffffff, { map: barkTexture });
const matStone = toon(0x898b83);
const matStoneDark = toon(0x5e6865);
const matStoneWarm = toon(0xa49b88);
const matMetal = toon(0x6c5a43, { emissive: 0x151006, emissiveIntensity: 0.2 });
const matLeafBase = toon(0xffffff, {
  side: THREE.DoubleSide,
  emissive: 0x160401,
  emissiveIntensity: 0.18,
});
const matWheat = toon(0xfff0c4, {
  map: wheatTexture,
  alphaTest: 0.26,
  side: THREE.DoubleSide,
  emissive: 0x352004,
  emissiveIntensity: 0.34,
});
matWheat.customProgramCacheKey = () => 'autumn-wheat-wind-v1';
matWheat.onBeforeCompile = (shader) => {
  shader.uniforms.uTime = timeUniforms.uTime;
  shader.vertexShader = shader.vertexShader
    .replace('#include <common>', '#include <common>\nuniform float uTime;')
    .replace(
      '#include <begin_vertex>',
      /* glsl */ `
        vec3 transformed = vec3( position );
        #ifdef USE_INSTANCING
          vec4 wheatOrigin = instanceMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
          float bend = pow( max( position.y / 0.78, 0.0 ), 1.35 );
          float broad = sin( uTime * 0.85 + wheatOrigin.x * 0.22 + wheatOrigin.z * 0.16 );
          float flutter = sin( uTime * 2.05 + wheatOrigin.x * 1.3 + wheatOrigin.z * 1.7 );
          float gust = sin( uTime * 1.15 + wheatOrigin.x * 0.7 - wheatOrigin.z * 0.55 );
          float sway = broad * 0.075 + flutter * 0.022 + gust * 0.032;
          transformed.x += sway * bend;
          transformed.z += ( gust * 0.026 + broad * 0.015 ) * bend;
        #endif
      `,
    );
};
matWheat.needsUpdate = true;

const matGrass = toon(0xffffff, { vertexColors: true, side: THREE.DoubleSide });

/* --------------------------------------------------------------------------
   Sky, haze and warm sunset light
   -------------------------------------------------------------------------- */

const sky = new THREE.Mesh(
  new THREE.SphereGeometry(105, 32, 20),
  new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    toneMapped: false,
    uniforms: {
      uSunDir: { value: new THREE.Vector3(0.53, 0.055, -0.846).normalize() },
      uTime: { value: 0 },
      uDusk: { value: 0 },
      uNight: { value: 0 },
    },
    vertexShader: /* glsl */ `
      varying vec3 vWorld;
      void main() {
        vec4 world = modelMatrix * vec4(position, 1.0);
        vWorld = world.xyz;
        gl_Position = projectionMatrix * viewMatrix * world;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uSunDir;
      uniform float uTime;
      uniform float uDusk;
      uniform float uNight;
      varying vec3 vWorld;

      float hash21(vec2 p) {
        p = fract(p * vec2(123.34, 456.21));
        p += dot(p, p + 45.32);
        return fract(p.x * p.y);
      }
      float noise21(vec2 p) {
        vec2 i = floor(p);
        vec2 f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        float a = hash21(i);
        float b = hash21(i + vec2(1.0, 0.0));
        float c = hash21(i + vec2(0.0, 1.0));
        float d = hash21(i + vec2(1.0, 1.0));
        return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
      }
      float fbm21(vec2 p) {
        float v = 0.0;
        float a = 0.5;
        mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
        for (int i = 0; i < 4; i++) {
          v += a * noise21(p);
          p = rot * p * 2.03 + 11.7;
          a *= 0.5;
        }
        return v;
      }

      void main() {
        vec3 dir = normalize(vWorld - cameraPosition);
        float h = clamp(dir.y * 0.5 + 0.5, 0.0, 1.0);
        vec3 low = mix(vec3(0.985, 0.760, 0.485), vec3(0.960, 0.360, 0.150), uDusk);
        low = mix(low, vec3(0.30, 0.18, 0.34), uNight);
        vec3 horizon = mix(vec3(1.000, 0.890, 0.690), vec3(0.920, 0.250, 0.180), uDusk);
        horizon = mix(horizon, vec3(0.26, 0.16, 0.38), uNight);
        vec3 zenith = mix(vec3(0.635, 0.775, 0.765), vec3(0.300, 0.120, 0.360), uDusk);
        zenith = mix(zenith, vec3(0.035, 0.045, 0.120), uNight);
        vec3 col = mix(low, horizon, smoothstep(0.18, 0.355, h));
        col = mix(col, zenith, smoothstep(0.365, 0.465, h));
        float solar = max(dot(dir, normalize(uSunDir)), 0.0);
        vec3 glowA = mix(vec3(1.00, 0.55, 0.18), vec3(1.00, 0.24, 0.08), uDusk);
        glowA = mix(glowA, vec3(0.55, 0.68, 0.96), uNight);
        vec3 glowB = mix(vec3(1.00, 0.74, 0.38), vec3(1.00, 0.40, 0.18), uDusk);
        glowB = mix(glowB, vec3(0.64, 0.76, 0.98), uNight);
        vec3 glowC = mix(vec3(1.00, 0.88, 0.60), vec3(1.00, 0.62, 0.36), uDusk);
        glowC = mix(glowC, vec3(0.76, 0.86, 1.00), uNight);
        vec3 glowD = mix(vec3(1.00, 0.92, 0.70), vec3(1.00, 0.78, 0.48), uDusk);
        glowD = mix(glowD, vec3(0.84, 0.92, 1.00), uNight);
        float duskGlow = (1.0 + uDusk * 0.35) * (1.0 - uNight * 0.48);
        col += glowA * pow(solar, 14.0) * 0.08 * duskGlow;
        col += glowB * pow(solar, 55.0) * 0.08 * duskGlow;
        col += glowC * pow(solar, 240.0) * 0.12 * duskGlow;
        col += glowD * smoothstep(0.9992, 0.9998, solar) * 0.2 * duskGlow;
        float band = sin(dir.x * 18.0 + dir.z * 12.0) * 0.0025;
        float wisps = sin(dir.x * 11.0 + dir.z * 6.0 + 0.8) + 0.62 * sin(dir.x * 23.0 - dir.z * 17.0 + 2.1);
        wisps = smoothstep(0.12, 1.12, wisps) * smoothstep(0.345, 0.405, h) * (1.0 - smoothstep(0.46, 0.54, h));
        vec3 wispTint = mix(vec3(1.0, 0.962, 0.865), vec3(0.96, 0.48, 0.42), uDusk);
        wispTint = mix(wispTint, vec3(0.38, 0.32, 0.56), uNight);
        col = mix(col, wispTint, wisps * mix(mix(0.12, 0.18, uDusk), 0.1, uNight));
        vec2 cloudUv = vec2(dir.x * 3.4 + dir.z * 1.6, dir.z * 4.8 - dir.x * 1.2);
        cloudUv += vec2(uTime * 0.0045, uTime * 0.0018);
        float cloud = fbm21(cloudUv);
        cloud = smoothstep(0.51, 0.75, cloud) * smoothstep(0.355, 0.408, h) * (1.0 - smoothstep(0.455, 0.505, h));
        vec3 cloudTint = mix(vec3(1.0, 0.968, 0.885), vec3(0.92, 0.46, 0.44), uDusk);
        cloudTint = mix(cloudTint, vec3(0.28, 0.25, 0.46), uNight);
        col = mix(col, cloudTint, cloud * mix(mix(0.23, 0.33, uDusk), 0.22, uNight));
        col = max(col + band, 0.0);
        // The scene is rendered into a linear HDR composer target. Convert the
        // painted sky from display-space values so OutputPass can apply ACES
        // once, instead of double tone-mapping a bright background. Keeping
        // the sky below the bloom threshold lets only real scene highlights
        // halo, rather than the entire upper half of the frame.
        col = pow(col, vec3(2.2)) * 0.58;
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  }),
);
sky.frustumCulled = false;
sky.renderOrder = -20;
scene.add(sky);

const hemi = new THREE.HemisphereLight(0xffe2c2, 0x413c30, 0.52);
scene.add(hemi);

const sun = new THREE.DirectionalLight(0xfff4df, 3.0);
// Lower, more lateral sunset angle: longer raking shadows and a clear
// shadowed side on the cottage instead of flat frontal illumination.
sun.position.set(-21.5, 7.8, 4.8);
sun.target.position.set(0.4, 0.2, 0.2);
sun.castShadow = true;
sun.shadow.mapSize.set(SHADOW_SIZE, SHADOW_SIZE);
sun.shadow.camera.left = -15;
sun.shadow.camera.right = 15;
sun.shadow.camera.top = 15;
sun.shadow.camera.bottom = -15;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 52;
sun.shadow.bias = -0.00035;
sun.shadow.normalBias = 0.028;
sun.shadow.radius = 2.1;
sun.shadow.camera.updateProjectionMatrix();
scene.add(sun);
scene.add(sun.target);

const coolFill = new THREE.DirectionalLight(0x9dbfb4, 0.16);
coolFill.position.set(9, 8, -12);
scene.add(coolFill);

const frontFill = new THREE.DirectionalLight(0xffd9a9, 0.11);
frontFill.position.set(-5, 5.5, 15);
scene.add(frontFill);

// A small warm bounce that keeps the shaded side of the cottage alive.
const warmBounce = new THREE.PointLight(0xffa155, 5.5, 9, 2);
warmBounce.position.set(5.2, 1.7, 4.4);
scene.add(warmBounce);

const mistSprites = [];
for (let i = 0; i < 4; i += 1) {
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: cloudTexture,
      color: 0xfff1d2,
      transparent: true,
      opacity: 0.16 - i * 0.018,
      depthWrite: false,
      toneMapped: false,
    }),
  );
  sprite.position.set(-5.5 + i * 3.6, 2.0 + i * 0.35, -4.8 - i * 0.7);
  sprite.scale.set(10.5, 3.4, 1);
  sprite.userData.phase = i * 1.7;
  scene.add(sprite);
  mistSprites.push(sprite);
}

const airyClouds = [];
const cloudPlacements = [
  [-9.5, 10.5, -17.0, 24, 7.4, 0.14],
  [4.5, 13.2, -19.0, 27, 8.2, 0.11],
  [12.0, 8.8, -14.0, 17, 5.2, 0.12],
  [-16.0, 7.6, -13.5, 15, 4.2, 0.09],
];
for (let i = 0; i < cloudPlacements.length; i += 1) {
  const [x, y, z, sx, sy, opacity] = cloudPlacements[i];
  const cloud = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: cloudTexture,
      color: 0xfff3d7,
      transparent: true,
      opacity,
      depthWrite: false,
      toneMapped: false,
    }),
  );
  cloud.position.set(x, y, z);
  cloud.scale.set(sx, sy, 1);
  cloud.renderOrder = -6;
  cloud.userData = { baseX: x, phase: i * 2.3, drift: 0.09 + i * 0.025 };
  scene.add(cloud);
  airyClouds.push(cloud);
}

/* --------------------------------------------------------------------------
   World groups and river geometry
   -------------------------------------------------------------------------- */

const world = new THREE.Group();
scene.add(world);

const riverCurve = new THREE.CatmullRomCurve3(
  [
    V3(-6.55, 0, -7.05),
    V3(-5.62, 0, -4.55),
    V3(-4.92, 0, -2.10),
    V3(-3.10, 0, 0.82),
    V3(-0.72, 0, 3.28),
    V3(1.10, 0, 5.08),
    V3(2.92, 0, 7.30),
  ],
  false,
  'catmullrom',
  0.34,
);

const RIVER_SEGMENTS = 200;
const riverSamples = [];
for (let i = 0; i <= RIVER_SEGMENTS; i += 1) {
  const t = i / RIVER_SEGMENTS;
  const p = riverCurve.getPointAt(t);
  const tangent = riverCurve.getTangentAt(t).normalize();
  const normal = V3(-tangent.z, 0, tangent.x).normalize();
  const width = lerp(1.05, 1.9, smooth(0.08, 0.98, t)) * (0.94 + Math.sin(t * 11.2 + 0.8) * 0.06);
  riverSamples.push({ t, p, tangent, normal, width });
}

// Keep the original riverCurve untouched so the bridge and all of its
// surrounding rocks stay exactly where they are. The visual water is extended
// only to an inner square edge; a stone culvert frames each mouth. This keeps
// every water vertex safely inside the 8.66-unit plinth radius and avoids the
// water sheet appearing to hang over the wooden base.
const WATER_EDGE = 7.55;

function distanceToSquareEdge(point, direction, half = WATER_EDGE) {
  const hits = [];
  if (Math.abs(direction.x) > 1e-6) {
    for (const boundary of [-half, half]) {
      const t = (boundary - point.x) / direction.x;
      if (t > 0) hits.push(t);
    }
  }
  if (Math.abs(direction.z) > 1e-6) {
    for (const boundary of [-half, half]) {
      const t = (boundary - point.z) / direction.z;
      if (t > 0) hits.push(t);
    }
  }
  return hits.length ? Math.min(...hits) : 0;
}

function buildWaterSamples() {
  const downstream = [];
  const upstream = [];

  let p = riverSamples[0].p.clone();
  let direction = riverSamples[0].tangent.clone().multiplyScalar(-1).normalize();
  const upstreamNormal = riverSamples[0].normal.clone();
  const upstreamEdgeDistance = distanceToSquareEdge(p, direction);
  const upstreamSteps = Math.max(1, Math.ceil(upstreamEdgeDistance / 0.06));
  for (let i = 1; i <= upstreamSteps; i += 1) {
    const t = i / upstreamSteps;
    const point = p.clone().addScaledVector(direction, upstreamEdgeDistance * t);
    const width = lerp(riverSamples[0].width, riverSamples[0].width * 1.12, t);
    upstream.push({
      p: point,
      tangent: direction.clone(),
      normal: upstreamNormal.clone(),
      width,
      t: 0,
      edge: t >= 1 - 1e-5,
    });
  }
  upstream.reverse();

  p = riverSamples[riverSamples.length - 1].p.clone();
  direction = riverSamples[riverSamples.length - 1].tangent.clone().normalize();
  const downstreamNormal = riverSamples[riverSamples.length - 1].normal.clone();
  const downstreamEdgeDistance = distanceToSquareEdge(p, direction);
  const downstreamSteps = Math.max(1, Math.ceil(downstreamEdgeDistance / 0.06));
  for (let i = 1; i <= downstreamSteps; i += 1) {
    const t = i / downstreamSteps;
    const point = p.clone().addScaledVector(direction, downstreamEdgeDistance * t);
    const width = lerp(
      riverSamples[riverSamples.length - 1].width,
      riverSamples[riverSamples.length - 1].width * 1.08,
      t,
    );
    downstream.push({
      p: point,
      tangent: direction.clone(),
      normal: downstreamNormal.clone(),
      width,
      t: 1,
      edge: t >= 1 - 1e-5,
    });
  }

  const all = [
    ...upstream,
    ...riverSamples.map((sample) => ({ ...sample, edge: false })),
    ...downstream,
  ];

  let distance = 0;
  all[0].v = 0;
  for (let i = 1; i < all.length; i += 1) {
    distance += all[i].p.distanceTo(all[i - 1].p);
    all[i].v = distance;
  }
  for (const sample of all) sample.v /= Math.max(1e-6, distance);
  return all;
}

const waterSamples = buildWaterSamples();

function distanceToWater(x, z) {
  let best = Infinity;
  for (let i = 0; i < waterSamples.length - 1; i += 1) {
    const a = waterSamples[i].p;
    const b = waterSamples[i + 1].p;
    const abx = b.x - a.x;
    const abz = b.z - a.z;
    const denom = abx * abx + abz * abz || 1;
    let t = ((x - a.x) * abx + (z - a.z) * abz) / denom;
    t = clamp(t, 0, 1);
    const dx = x - (a.x + abx * t);
    const dz = z - (a.z + abz * t);
    const d = dx * dx + dz * dz;
    if (d < best) best = d;
  }
  return Math.sqrt(best);
}

function waterWidthNear(x, z) {
  let best = Infinity;
  let width = 1.2;
  for (const sample of waterSamples) {
    const d = Math.hypot(x - sample.p.x, z - sample.p.z);
    if (d < best) {
      best = d;
      width = sample.width;
    }
  }
  return width;
}

function distanceToRiver(x, z) {
  let best = Infinity;
  for (let i = 0; i < riverSamples.length - 1; i += 1) {
    const a = riverSamples[i].p;
    const b = riverSamples[i + 1].p;
    const abx = b.x - a.x;
    const abz = b.z - a.z;
    const denom = abx * abx + abz * abz || 1;
    let t = ((x - a.x) * abx + (z - a.z) * abz) / denom;
    t = clamp(t, 0, 1);
    const dx = x - (a.x + abx * t);
    const dz = z - (a.z + abz * t);
    const d = Math.sqrt(dx * dx + dz * dz);
    if (d < best) best = d;
  }
  return best;
}

function riverWidthAt(x, z) {
  let best = Infinity;
  let width = 1.2;
  for (const sample of riverSamples) {
    const d = Math.hypot(x - sample.p.x, z - sample.p.z);
    if (d < best) {
      best = d;
      width = sample.width;
    }
  }
  return width;
}

const WATER_Y = 0.095;

function terrainHeight(x, z) {
  let h = 0.11;
  h += Math.sin(x * 0.42 + 0.6) * Math.cos(z * 0.36 - 0.45) * 0.052;
  h += Math.sin(x * 0.95 - z * 0.61 + 1.2) * 0.025;
  h += Math.cos(x * 0.62 + z * 0.78 - 0.9) * 0.018;

  // A very gentle rise toward the back edge gives the field a sense of depth.
  h += smooth(-2.4, -7.9, z) * 0.15;
  h += smooth(-4.9, -7.5, z) * 0.05;

  // The river sits in a shallow, readable channel.
  const distance = distanceToRiver(x, z);
  const channel = 1 - smooth(0.44, 1.92, distance);
  h -= channel * 0.235;
  h += smooth(1.45, 3.0, distance) * 0.02;

  // Slight hollow around the farmyard, then edge erosion back to the plinth.
  const yard = Math.hypot((x - 3.6) / 4.1, (z - 0.75) / 3.35);
  h = lerp(h, 0.105, (1 - smooth(0.82, 1.22, yard)) * 0.7);

  const edge = smooth(8.32, 7.45, Math.max(Math.abs(x), Math.abs(z)));
  h *= edge;
  return Math.max(0.018, h);
}

const FIELD_PLOTS = [
  { cx: -6.25, cz: 2.65, len: 5.0, wid: 2.5, rot: -0.12, seed: 110, density: 1.0 },
  { cx: -6.72, cz: -5.55, len: 2.8, wid: 1.7, rot: 0.06, seed: 111, density: 0.9 },
  { cx: -0.90, cz: -5.45, len: 4.6, wid: 3.0, rot: -0.04, seed: 112, density: 1.0 },
  { cx: 5.20, cz: -5.40, len: 3.4, wid: 2.5, rot: -0.28, seed: 113, density: 0.95 },
  { cx: -4.85, cz: 5.35, len: 4.4, wid: 3.5, rot: 0.10, seed: 114, density: 1.05 },
];

const WORK_CLEARINGS = [
  { x: -3.30, z: 4.52, r: 0.92 },
  { x: -0.25, z: -5.15, r: 0.42 },
];

function inWorkClearing(x, z) {
  for (const spot of WORK_CLEARINGS) {
    if (Math.hypot(x - spot.x, z - spot.z) < spot.r) return true;
  }
  return false;
}

function plotLocal(x, z, plot) {
  const dx = x - plot.cx;
  const dz = z - plot.cz;
  const cos = Math.cos(plot.rot);
  const sin = Math.sin(plot.rot);
  return {
    x: dx * cos - dz * sin,
    z: dx * sin + dz * cos,
  };
}

function fieldInfluenceAt(x, z) {
  let best = 0;
  for (const plot of FIELD_PLOTS) {
    const local = plotLocal(x, z, plot);
    const fx = 1 - smooth(plot.wid * 0.5 - 0.22, plot.wid * 0.5 + 0.55, Math.abs(local.x));
    const fz = 1 - smooth(plot.len * 0.5 - 0.22, plot.len * 0.5 + 0.55, Math.abs(local.z));
    best = Math.max(best, fx * fz);
  }
  return best;
}

function isInsideAnyField(x, z, margin = 0) {
  for (const plot of FIELD_PLOTS) {
    const local = plotLocal(x, z, plot);
    if (Math.abs(local.x) < plot.wid * 0.5 + margin && Math.abs(local.z) < plot.len * 0.5 + margin) {
      return true;
    }
  }
  return false;
}

function buildTerrain() {
  const size = 16.8;
  const segments = IS_SMALL ? 80 : 116;
  const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
  geometry.rotateX(-Math.PI / 2);

  const position = geometry.attributes.position;
  const colors = new Float32Array(position.count * 3);
  const meadow = C(0x7d8d49);
  const dryMeadow = C(0xa7924f);
  const deepGrass = C(0x647b43);
  const goldField = C(0xc2993f);
  const bankSoil = C(0x8d6b3b);
  const wetSoil = C(0x64705a);
  const courtyard = C(0xae8353);
  const color = new THREE.Color();

  for (let i = 0; i < position.count; i += 1) {
    const x = position.getX(i);
    const z = position.getZ(i);
    const y = terrainHeight(x, z);
    position.setY(i, y);

    const field = fieldInfluenceAt(x, z);
    const distance = distanceToRiver(x, z);
    const yard = Math.hypot((x - 3.7) / 4.3, (z - 0.9) / 3.4);

    color.copy(meadow).lerp(dryMeadow, 0.35 + 0.28 * Math.sin(x * 0.55 + z * 0.33));
    color.lerp(deepGrass, smooth(-7.5, -2.0, z) * 0.12);
    color.lerp(goldField, field * 0.62);
    color.lerp(courtyard, (1 - smooth(0.86, 1.1, yard)) * 0.42);
    color.lerp(bankSoil, (1 - smooth(1.2, 2.1, distance)) * 0.5);
    color.lerp(wetSoil, (1 - smooth(0.5, 1.02, distance)) * 0.65);

    const grain = Math.sin(x * 12.7 + z * 9.3) * 0.5 + Math.cos(x * 7.1 - z * 14.6) * 0.5;
    color.offsetHSL(0, 0, grain * 0.018);
    colors[i * 3] = color.r;
    colors[i * 3 + 1] = color.g;
    colors[i * 3 + 2] = color.b;
  }

  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geometry.computeVertexNormals();

  const mesh = new THREE.Mesh(geometry, matTerrain);
  mesh.receiveShadow = true;
  world.add(mesh);
  return mesh;
}

const terrain = buildTerrain();

/* --------------------------------------------------------------------------
   Display plinth: a layered wooden base with a mossy earth cap
   -------------------------------------------------------------------------- */

function roundedRectShape(width, depth, radius) {
  const shape = new THREE.Shape();
  const x = -width / 2;
  const y = -depth / 2;
  const r = Math.min(radius, Math.min(width, depth) / 2 - 0.001);
  shape.moveTo(x + r, y);
  shape.lineTo(x + width - r, y);
  shape.quadraticCurveTo(x + width, y, x + width, y + r);
  shape.lineTo(x + width, y + depth - r);
  shape.quadraticCurveTo(x + width, y + depth, x + width - r, y + depth);
  shape.lineTo(x + r, y + depth);
  shape.quadraticCurveTo(x, y + depth, x, y + depth - r);
  shape.lineTo(x, y + r);
  shape.quadraticCurveTo(x, y, x + r, y);
  return shape;
}

function roundedSlabGeometry(width, depth, height, radius = 0.3) {
  const geometry = new THREE.ExtrudeGeometry(roundedRectShape(width, depth, radius), {
    depth: height,
    bevelEnabled: true,
    bevelThickness: 0.055,
    bevelSize: 0.055,
    bevelSegments: 2,
    curveSegments: 4,
    steps: 1,
  });
  geometry.rotateX(-Math.PI / 2);
  geometry.translate(0, -height / 2, 0);
  geometry.computeVertexNormals();
  return geometry;
}

function buildBase() {
  const group = new THREE.Group();

  const foot = new THREE.Mesh(
    roundedSlabGeometry(16.95, 16.95, 0.15, 0.34),
    [toon(0x4b3524), toon(0x62462f)],
  );
  foot.position.y = -1.36;
  foot.castShadow = true;
  foot.receiveShadow = true;
  group.add(foot);

  const woodSide = toon(0xffffff, {
    map: woodTexture,
    color: 0xc69a72,
    emissive: 0x3a2417,
    emissiveIntensity: 0.58,
  });
  const woodTop = toon(0x4a3221);
  const body = new THREE.Mesh(
    roundedSlabGeometry(17.1, 17.1, 1.02, 0.38),
    [woodTop, woodSide],
  );
  body.position.y = -0.79;
  body.castShadow = true;
  body.receiveShadow = true;
  group.add(body);

  const lipTop = toon(0x8d7448, { emissive: 0x1c1406, emissiveIntensity: 0.3 });
  const lipSide = toon(0xffffff, {
    map: woodTexture,
    color: 0xb08258,
    emissive: 0x2a170c,
    emissiveIntensity: 0.44,
  });
  const lip = new THREE.Mesh(
    roundedSlabGeometry(17.32, 17.32, 0.3, 0.4),
    [lipTop, lipSide],
  );
  lip.position.y = -0.13;
  lip.castShadow = true;
  lip.receiveShadow = true;
  group.add(lip);

  // A warm, visible inlay catches the low sun and gives the plinth a crafted edge.
  const inlay = toon(0xd2a461, { emissive: 0x3e250e, emissiveIntensity: 0.45 });
  const inlayGeom = new THREE.BoxGeometry(17.02, 0.055, 0.055);
  for (const z of [-8.5, 8.5]) {
    const strip = new THREE.Mesh(inlayGeom, inlay);
    strip.position.set(0, -0.43, z);
    group.add(strip);
  }
  const inlaySideGeom = new THREE.BoxGeometry(0.055, 0.055, 17.02);
  for (const x of [-8.5, 8.5]) {
    const strip = new THREE.Mesh(inlaySideGeom, inlay);
    strip.position.set(x, -0.43, 0);
    group.add(strip);
  }

  const brass = toon(0xb68b48);
  const trimGeom = new THREE.BoxGeometry(17.18, 0.035, 0.035);
  for (const z of [-8.55, 8.55]) {
    const trim = new THREE.Mesh(trimGeom, brass);
    trim.position.set(0, -0.31, z);
    group.add(trim);
  }
  const trimSideGeom = new THREE.BoxGeometry(0.035, 0.035, 17.18);
  for (const x of [-8.55, 8.55]) {
    const trim = new THREE.Mesh(trimSideGeom, brass);
    trim.position.set(x, -0.31, 0);
    group.add(trim);
  }

  // Subtle corner blocks make the square plinth feel crafted.
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const block = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.34, 0.22), toon(0x4d3824));
      block.position.set(sx * 8.48, -0.31, sz * 8.48);
      group.add(block);
    }
  }

  group.position.y = 0;
  world.add(group);
}

buildBase();

/* --------------------------------------------------------------------------
   Wheat fields
   -------------------------------------------------------------------------- */

const wheatInstances = [];
const ridgeInstances = [];
const grassInstances = [];
const rockInstances = [];
const reedStems = [];
const reedHeads = [];
const fallenLeafInstances = [];
const thatchFringeInstances = [];
const fencePostInstances = [];
const fenceRailInstances = [];
const pathStoneInstances = [];

function makeWheatTuftGeometry() {
  const planes = 3;
  const w = 0.46;
  const h = 0.78;
  const positions = [];
  const uvs = [];
  const indices = [];
  for (let p = 0; p < planes; p += 1) {
    const a = (p / planes) * Math.PI;
    const cos = Math.cos(a);
    const sin = Math.sin(a);
    const base = positions.length / 3;
    const corners = [
      [-w / 2, 0],
      [w / 2, 0],
      [w / 2, h],
      [-w / 2, h],
    ];
    for (const [x, y] of corners) {
      positions.push(x * cos, y, x * sin);
      uvs.push((x / w) + 0.5, y / h);
    }
    indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

const wheatGeometry = makeWheatTuftGeometry();

function addWheatClump(x, y, z, yaw, scale, colorHex, rngLocal) {
  wheatInstances.push({
    x,
    y,
    z,
    yaw,
    sx: scale * (0.9 + rngLocal() * 0.28),
    sy: scale * (0.82 + rngLocal() * 0.34),
    tx: (rngLocal() - 0.5) * 0.11,
    tz: (rngLocal() - 0.5) * 0.11,
    color: colorHex,
  });
}

const WHEAT_COLORS = [
  '#eab541',
  '#f4ca5f',
  '#dfa32f',
  '#f8d777',
  '#d7972b',
  '#ffdf8a',
  '#edbc4b',
  '#dcab3b',
];

function addWheatField(plot) {
  const localRng = mulberry32(plot.seed);
  const centerHeight = terrainHeight(plot.cx, plot.cz);
  const baseY = centerHeight + 0.075;
  const group = new THREE.Group();
  group.position.set(plot.cx, baseY, plot.cz);
  group.rotation.y = plot.rot;

  const bedShape = roundedRectShape(plot.wid + 0.24, plot.len + 0.18, 0.34);
  const bedGeometry = new THREE.ExtrudeGeometry(bedShape, {
    depth: 0.2,
    bevelEnabled: true,
    bevelThickness: 0.04,
    bevelSize: 0.035,
    bevelSegments: 2,
    curveSegments: 3,
    steps: 1,
  });
  bedGeometry.rotateX(-Math.PI / 2);
  bedGeometry.translate(0, -0.1, 0);
  const bed = new THREE.Mesh(bedGeometry, [matStubble, matSoilDark]);
  bed.receiveShadow = true;
  bed.castShadow = true;
  group.add(bed);

  const rowCount = Math.max(4, Math.round(plot.wid / 0.29));
  const rowWidth = (plot.wid / rowCount) * 0.72;
  for (let row = 0; row < rowCount; row += 1) {
    const localX = -plot.wid / 2 + (row + 0.5) * (plot.wid / rowCount);
    const localZ = 0;
    const cos = Math.cos(plot.rot);
    const sin = Math.sin(plot.rot);
    const wx = plot.cx + localX * cos + localZ * sin;
    const wz = plot.cz - localX * sin + localZ * cos;
    ridgeInstances.push({
      x: wx,
      y: baseY + 0.045,
      z: wz,
      ry: plot.rot,
      sx: rowWidth,
      sy: 0.09,
      sz: plot.len - 0.2,
      color: row % 2 ? '#e6bf72' : '#f0ce84',
    });

    const count = Math.floor((plot.len - 0.22) / 0.097);
    for (let i = 0; i < count; i += 1) {
      if (localRng() > 0.94) continue;
      const lx = localX + (localRng() - 0.5) * rowWidth * 0.8;
      const lz = -plot.len / 2 + 0.14 + (i + 0.5) * ((plot.len - 0.26) / count) + (localRng() - 0.5) * 0.06;
      const wx2 = plot.cx + lx * cos + lz * sin;
      const wz2 = plot.cz - lx * sin + lz * cos;
      if (inWorkClearing(wx2, wz2)) continue;
      addWheatClump(
        wx2,
        baseY + 0.082,
        wz2,
        plot.rot + (localRng() - 0.5) * 0.9,
        (0.82 + localRng() * 0.3) * plot.density,
        WHEAT_COLORS[Math.floor(localRng() * WHEAT_COLORS.length)],
        localRng,
      );
    }
  }

  // A few wild stalks at the edge soften the rectangular field beds.
  const fringeCount = Math.floor(plot.len * 4);
  for (let i = 0; i < fringeCount; i += 1) {
    const side = localRng() > 0.5 ? 1 : -1;
    const lx = side * (plot.wid / 2 + localRng() * 0.28);
    const lz = (localRng() - 0.5) * plot.len;
    const cos = Math.cos(plot.rot);
    const sin = Math.sin(plot.rot);
    const wx = plot.cx + lx * cos + lz * sin;
    const wz = plot.cz - lx * sin + lz * cos;
    addWheatClump(
      wx,
      terrainHeight(wx, wz) + 0.055,
      wz,
      localRng() * Math.PI,
      0.65 + localRng() * 0.32,
      WHEAT_COLORS[Math.floor(localRng() * WHEAT_COLORS.length)],
      localRng,
    );
  }

  world.add(group);

  for (let i = 0; i < 18; i += 1) {
    const lx = (localRng() - 0.5) * plot.wid;
    const lz = (localRng() > 0.5 ? 1 : -1) * (plot.len / 2 + 0.1 + localRng() * 0.28);
    const cos = Math.cos(plot.rot);
    const sin = Math.sin(plot.rot);
    const wx = plot.cx + lx * cos + lz * sin;
    const wz = plot.cz - lx * sin + lz * cos;
    addGrassTuft(wx, terrainHeight(wx, wz) + 0.02, wz, 0.7 + localRng() * 0.6, localRng);
  }

  return { ...plot, baseY };
}

FIELD_PLOTS.forEach(addWheatField);

/* --------------------------------------------------------------------------
   Continuous field carpet
   The original raised beds stay intact, but a terrain-following golden mat and
   a dense filler crop now bridge the alleys between them. The alpha mask lets
   the field flow around the stream, courtyard, bridge and the square rim.
   -------------------------------------------------------------------------- */

const FIELD_MASK_SIZE = IS_SMALL ? 768 : 1024;
const FIELD_MASK_HALF = 8.4;
const continuousFieldCanvas = document.createElement('canvas');
continuousFieldCanvas.width = FIELD_MASK_SIZE;
continuousFieldCanvas.height = FIELD_MASK_SIZE;
const fieldMaskCtx = continuousFieldCanvas.getContext('2d', { willReadFrequently: true });
const fieldMaskX = (x) => ((x + FIELD_MASK_HALF) / (FIELD_MASK_HALF * 2)) * FIELD_MASK_SIZE;
const fieldMaskY = (z) => ((z + FIELD_MASK_HALF) / (FIELD_MASK_HALF * 2)) * FIELD_MASK_SIZE;

function paintContinuousFieldMask() {
  const ctx = fieldMaskCtx;
  const S = FIELD_MASK_SIZE;
  ctx.clearRect(0, 0, S, S);
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, S, S);
  ctx.save();

  // Keep a narrow grassy rim around the square display base.
  ctx.beginPath();
  ctx.rect(fieldMaskX(-8.08), fieldMaskY(-8.08), fieldMaskX(8.08) - fieldMaskX(-8.08), fieldMaskY(8.08) - fieldMaskY(-8.08));
  ctx.clip();

  ctx.fillStyle = '#fff';
  const blob = (cx, cz, rx, rz, rot = 0) => {
    ctx.beginPath();
    ctx.ellipse(fieldMaskX(cx), fieldMaskY(cz), (rx / 16.8) * S, (rz / 16.8) * S, rot, 0, Math.PI * 2);
    ctx.fill();
  };

  // West-bank field: one continuous sweep from the back-left corner through
  // the mid-left and foreground plots.
  blob(-6.15, 1.2, 2.9, 4.5, -0.08);
  blob(-5.15, 4.6, 3.6, 3.2, 0.08);
  blob(-6.25, -2.9, 2.5, 3.7, 0.12);
  blob(-6.55, -6.2, 2.0, 2.5, 0.04);
  blob(-4.2, 1.85, 2.4, 3.0, -0.2);
  // Center and east rear fields around the farmhouse.
  blob(-0.6, -5.0, 4.2, 3.2, -0.04);
  blob(2.8, -5.3, 2.7, 2.7, -0.22);
  blob(5.3, -4.9, 2.3, 2.9, -0.24);
  blob(-2.8, -3.4, 2.0, 2.1, 0.05);
  // Small, irregular lobes break up the overall silhouette.
  blob(-7.25, 3.85, 1.0, 1.7, 0.2);
  blob(-4.4, -1.2, 1.3, 2.0, 0.1);
  blob(0.6, -2.9, 1.6, 1.4, -0.2);
  blob(4.2, -6.8, 1.5, 1.1, 0.06);

  // Erase the water corridor, using the actual extended river samples so the
  // golden mat reaches the banks but never enters the stream.
  ctx.strokeStyle = '#000';
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  for (let i = 0; i < waterSamples.length - 1; i += 1) {
    const a = waterSamples[i];
    const b = waterSamples[i + 1];
    ctx.lineWidth = (((a.width + b.width) * 0.5 + 0.86) / 16.8) * S;
    ctx.beginPath();
    ctx.moveTo(fieldMaskX(a.p.x), fieldMaskY(a.p.z));
    ctx.lineTo(fieldMaskX(b.p.x), fieldMaskY(b.p.z));
    ctx.stroke();
  }

  // Courtyard/barn clearing. The house and fence keep their own ground.
  ctx.fillStyle = '#000';
  const yardX0 = fieldMaskX(0.55);
  const yardY0 = fieldMaskY(-1.95);
  const yardX1 = fieldMaskX(6.95);
  const yardY1 = fieldMaskY(3.6);
  ctx.beginPath();
  ctx.roundRect(yardX0, yardY0, yardX1 - yardX0, yardY1 - yardY0, 0.38 * (S / 16.8));
  ctx.fill();

  // Keep the bridge and its stony approaches clear.
  ctx.beginPath();
  ctx.ellipse(fieldMaskX(1.26), fieldMaskY(5.26), (2.35 / 16.8) * S, (2.05 / 16.8) * S, 0, 0, Math.PI * 2);
  ctx.fill();

  const path = [
    [2.83, 3.92],
    [3.02, 3.56],
    [3.08, 3.12],
    [3.03, 2.62],
  ];
  ctx.strokeStyle = '#000';
  ctx.lineCap = 'round';
  ctx.lineWidth = 0.72 * (S / 16.8);
  ctx.beginPath();
  ctx.moveTo(fieldMaskX(path[0][0]), fieldMaskY(path[0][1]));
  for (let i = 1; i < path.length; i += 1) {
    ctx.lineTo(fieldMaskX(path[i][0]), fieldMaskY(path[i][1]));
  }
  ctx.stroke();

  ctx.restore();
}

paintContinuousFieldMask();

const continuousFieldTexture = new THREE.CanvasTexture(continuousFieldCanvas);
continuousFieldTexture.flipY = false;
continuousFieldTexture.wrapS = THREE.ClampToEdgeWrapping;
continuousFieldTexture.wrapT = THREE.ClampToEdgeWrapping;
continuousFieldTexture.colorSpace = THREE.NoColorSpace;
continuousFieldTexture.minFilter = THREE.LinearFilter;
continuousFieldTexture.magFilter = THREE.LinearFilter;
continuousFieldTexture.anisotropy = maxAnisotropy;
continuousFieldTexture.needsUpdate = true;

const fieldMaskData = fieldMaskCtx.getImageData(0, 0, FIELD_MASK_SIZE, FIELD_MASK_SIZE).data;

function isInContinuousField(x, z) {
  if (Math.abs(x) > FIELD_MASK_HALF || Math.abs(z) > FIELD_MASK_HALF) return false;
  const px = clamp(Math.floor(fieldMaskX(x)), 0, FIELD_MASK_SIZE - 1);
  const py = clamp(Math.floor(fieldMaskY(z)), 0, FIELD_MASK_SIZE - 1);
  return fieldMaskData[(py * FIELD_MASK_SIZE + px) * 4] > 128;
}

function buildContinuousFieldCarpet() {
  const segments = IS_SMALL ? 84 : 120;
  const geometry = new THREE.PlaneGeometry(16.8, 16.8, segments, segments);
  geometry.rotateX(-Math.PI / 2);
  const position = geometry.attributes.position;
  const uvs = geometry.attributes.uv;
  const colors = new Float32Array(position.count * 3);
  const color = new THREE.Color();
  const darkGold = C(0xd1a351);
  const lightGold = C(0xf0cd83);
  const wetEdge = C(0xb58b4c);

  for (let i = 0; i < position.count; i += 1) {
    const x = position.getX(i);
    const z = position.getZ(i);
    position.setY(i, terrainHeight(x, z) + 0.052);
    uvs.setXY(i, (x + FIELD_MASK_HALF) / (FIELD_MASK_HALF * 2), (z + FIELD_MASK_HALF) / (FIELD_MASK_HALF * 2));
    const grain = 0.5 + 0.5 * Math.sin(x * 2.7 + z * 1.9);
    color.copy(darkGold).lerp(lightGold, grain * 0.65);
    const waterDistance = distanceToWater(x, z);
    if (waterDistance < waterWidthNear(x, z) * 0.5 + 0.7) color.lerp(wetEdge, 0.4);
    colors[i * 3] = color.r;
    colors[i * 3 + 1] = color.g;
    colors[i * 3 + 2] = color.b;
  }
  uvs.needsUpdate = true;
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geometry.computeVertexNormals();

  const material = toon(0xffffff, {
    map: stubbleTexture,
    alphaMap: continuousFieldTexture,
    alphaTest: 0.48,
    side: THREE.DoubleSide,
    vertexColors: true,
    emissive: 0x1b1002,
    emissiveIntensity: 0.17,
  });
  const mat = new THREE.Mesh(geometry, material);
  mat.receiveShadow = true;
  mat.castShadow = false;
  mat.userData.noBatch = true;
  world.add(mat);

  return mat;
}

buildContinuousFieldCarpet();

function fillContinuousWheat() {
  const fillRng = mulberry32(8821);
  const target = 2000;
  let added = 0;
  let attempts = 0;
  while (added < target && attempts < 50000) {
    attempts += 1;
    const x = (fillRng() - 0.5) * 16.0;
    const z = (fillRng() - 0.5) * 16.0;
    if (!isInContinuousField(x, z)) continue;
    if (isInsideAnyField(x, z, 0.02)) continue;
    if (inWorkClearing(x, z)) continue;
    const riverDistance = distanceToWater(x, z);
    if (riverDistance < waterWidthNear(x, z) * 0.5 + 0.24) continue;
    // Do not grow wheat through the courtyard, the bridge or its path.
    if (x > 0.85 && x < 6.7 && z > -1.7 && z < 3.7) continue;
    if (Math.hypot(x - 1.26, z - 5.26) < 2.2) continue;
    const scale = 0.72 + fillRng() * 0.4;
    addWheatClump(
      x,
      terrainHeight(x, z) + 0.066,
      z,
      fillRng() * Math.PI,
      scale,
      WHEAT_COLORS[Math.floor(fillRng() * WHEAT_COLORS.length)],
      fillRng,
    );
    added += 1;
  }
}

fillContinuousWheat();

function buildWheatInstances() {
  const geometry = wheatGeometry;
  const mesh = new THREE.InstancedMesh(geometry, matWheat, wheatInstances.length);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  wheatInstances.forEach((item, i) => {
    dummy.position.set(item.x, item.y, item.z);
    dummy.rotation.set(item.tx, item.yaw, item.tz, 'YXZ');
    dummy.scale.set(item.sx, item.sy, item.sx);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    color.set(item.color);
    mesh.setColorAt(i, color);
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = false;
  mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  mesh.computeBoundingSphere?.();
  world.add(mesh);
}

buildWheatInstances();

/* --------------------------------------------------------------------------
   Shared instancing batchers
   -------------------------------------------------------------------------- */

function buildBoxInstances(parent, entries, material, castShadow = true, receiveShadow = true) {
  if (!entries.length) return null;
  const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), material, entries.length);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  let hasColor = false;
  entries.forEach((entry, i) => {
    dummy.position.set(entry.x, entry.y, entry.z);
    dummy.rotation.set(entry.rx || 0, entry.ry || 0, entry.rz || 0);
    dummy.scale.set(entry.sx, entry.sy, entry.sz);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    if (entry.color) {
      hasColor = true;
      mesh.setColorAt(i, color.set(entry.color));
    }
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (hasColor && mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = castShadow;
  mesh.receiveShadow = receiveShadow;
  mesh.frustumCulled = false;
  mesh.computeBoundingSphere?.();
  parent.add(mesh);
  return mesh;
}

buildBoxInstances(world, ridgeInstances, matStubble, true, true);

/* --------------------------------------------------------------------------
   River water, banks, stones and reeds
   -------------------------------------------------------------------------- */

function makeWaterStripGeometry(samples, y) {
  const acrossCount = 5;
  const positions = [];
  const uvs = [];
  const colors = [];
  const indices = [];
  const centerColor = C(0x0b3033);
  const edgeColor = C(0x347b70);
  const bankTint = C(0x75a992);
  for (let i = 0; i < samples.length; i += 1) {
    const sample = samples[i];
    for (let a = 0; a < acrossCount; a += 1) {
      const across = a / (acrossCount - 1);
      const offset = (across - 0.5) * sample.width;
      positions.push(
        sample.p.x + sample.normal.x * offset,
        y,
        sample.p.z + sample.normal.z * offset,
      );
      uvs.push(across, sample.v);
      const edge = Math.abs(across - 0.5) * 2;
      const color = centerColor.clone()
        .lerp(edgeColor, Math.pow(edge, 1.15) * 0.82)
        .lerp(bankTint, Math.pow(edge, 5) * 0.15);
      colors.push(color.r, color.g, color.b);
    }
  }
  for (let i = 0; i < samples.length - 1; i += 1) {
    for (let a = 0; a < acrossCount - 1; a += 1) {
      const i0 = i * acrossCount + a;
      const i1 = i0 + 1;
      const i2 = i0 + acrossCount;
      const i3 = i2 + 1;
      indices.push(i0, i2, i1, i1, i2, i3);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

function makeWaterEnvironmentTexture() {
  const canvasEnv = document.createElement('canvas');
  canvasEnv.width = 512;
  canvasEnv.height = 256;
  const ctx = canvasEnv.getContext('2d');
  const gradient = ctx.createLinearGradient(0, 0, 0, 256);
  gradient.addColorStop(0, '#c8d9d1');
  gradient.addColorStop(0.34, '#f5e3bf');
  gradient.addColorStop(0.52, '#ffe5b2');
  gradient.addColorStop(0.6, '#b6a06f');
  gradient.addColorStop(1, '#3a372c');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 512, 256);

  const glow = ctx.createRadialGradient(310, 128, 2, 310, 128, 90);
  glow.addColorStop(0, 'rgba(255,246,208,0.95)');
  glow.addColorStop(0.18, 'rgba(255,225,165,0.62)');
  glow.addColorStop(0.55, 'rgba(255,196,120,0.16)');
  glow.addColorStop(1, 'rgba(255,190,110,0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, 512, 256);

  const cloudRng = mulberry32(7711);
  for (let i = 0; i < 16; i += 1) {
    const x = 40 + cloudRng() * 430;
    const y = 40 + cloudRng() * 58;
    const r = 18 + cloudRng() * 35;
    const cloud = ctx.createRadialGradient(x, y, 0, x, y, r);
    cloud.addColorStop(0, 'rgba(255,251,232,0.20)');
    cloud.addColorStop(1, 'rgba(255,251,232,0)');
    ctx.fillStyle = cloud;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  const texture = new THREE.CanvasTexture(canvasEnv);
  texture.mapping = THREE.EquirectangularReflectionMapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

const waterEnvSource = makeWaterEnvironmentTexture();
const pmremGenerator = new THREE.PMREMGenerator(renderer);
pmremGenerator.compileEquirectangularShader();
const waterEnvTarget = pmremGenerator.fromEquirectangular(waterEnvSource);
const waterEnvMap = waterEnvTarget.texture;
waterEnvSource.dispose();
pmremGenerator.dispose();

const waterMaterial = new THREE.MeshPhysicalMaterial({
  color: 0xffffff,
  vertexColors: true,
  roughness: 0.15,
  metalness: 0,
  reflectivity: 0.82,
  envMap: waterEnvMap,
  envMapIntensity: 0.94,
  ior: 1.333,
  specularIntensity: 1.02,
  specularColor: 0xffe3af,
  clearcoat: 0.58,
  clearcoatRoughness: 0.11,
  normalMap: waterNormalTexture,
  normalScale: new THREE.Vector2(0.43, 0.43),
  side: THREE.DoubleSide,
  transparent: false,
  depthWrite: true,
});
waterNormalTexture.repeat.set(2.0, 16.0);

const waterMesh = new THREE.Mesh(makeWaterStripGeometry(waterSamples, WATER_Y), waterMaterial);
waterMesh.name = 'river-water';
waterMesh.receiveShadow = true;
waterMesh.castShadow = false;
waterMesh.renderOrder = 2;
waterMesh.userData.noBatch = true;
world.add(waterMesh);

// A dark wet bed extends just beyond the visible banks and over the plinth rim.
const bedSamples = waterSamples.map((s) => ({ ...s, width: s.width + 0.2 }));
const riverBed = new THREE.Mesh(
  makeWaterStripGeometry(bedSamples, WATER_Y - 0.032),
  toon(0x3d5b4d),
);
riverBed.name = 'river-bed';
riverBed.receiveShadow = true;
world.add(riverBed);

/* --------------------------------------------------------------------------
   Culvert mouths
   The water stops 0.6 units inside the plinth rim. These stone portals sit at
   each end, sealing the channel and making the stream appear to emerge from
   (or disappear into) a culvert in the edge of the diorama.
   -------------------------------------------------------------------------- */

const culvertStone = toon(0x69756f, { flatShading: true });
const culvertStoneLight = toon(0x858e86, { flatShading: true });
const culvertStoneDark = toon(0x4f5d59, { flatShading: true });
const culvertMouth = new THREE.MeshBasicMaterial({ color: 0x101512, toneMapped: false });
const culvertStoneGeometry = new THREE.DodecahedronGeometry(1, 0);
const culvertBounds = [];

function buildCulvert(sample, endName) {
  const width = sample.width;
  const outward = sample.tangent.clone().normalize();
  const group = new THREE.Group();
  group.position.copy(sample.p);
  group.rotation.y = Math.atan2(outward.x, outward.z);
  group.name = `culvert-${endName}`;
  world.add(group);

  // Dark throat behind the water end. From above it reads as a recessed tunnel.
  const throat = new THREE.Mesh(
    new THREE.BoxGeometry(width * 0.9, 0.3, 0.04),
    culvertMouth,
  );
  throat.position.set(0, 0.245, 0.012);
  group.add(throat);

  // Stone jambs and a heavy lintel, kept deliberately compact so the whole
  // portal remains inside the 8.66-unit plinth silhouette.
  for (const side of [-1, 1]) {
    const jamb = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.5, 0.32), culvertStone);
    jamb.position.set(side * (width * 0.5 + 0.12), 0.25, 0.07);
    jamb.rotation.z = side * 0.045;
    jamb.castShadow = true;
    jamb.receiveShadow = true;
    group.add(jamb);

    const footing = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.15, 0.4), culvertStoneDark);
    footing.position.set(side * (width * 0.5 + 0.16), 0.075, 0.12);
    footing.castShadow = true;
    footing.receiveShadow = true;
    group.add(footing);

    // A low retaining stone blends the portal into the earth bank.
    const wing = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.17, 0.26), culvertStoneLight);
    wing.position.set(side * (width * 0.5 + 0.3), 0.09, 0.16);
    wing.rotation.y = side * 0.12;
    wing.castShadow = true;
    wing.receiveShadow = true;
    group.add(wing);

    // Irregular cap stones make the edge feel built from field stone.
    const cap = new THREE.Mesh(culvertStoneGeometry, side > 0 ? culvertStoneLight : culvertStone);
    cap.position.set(side * (width * 0.5 + 0.08), 0.54, 0.15);
    cap.scale.set(0.17, 0.13, 0.19);
    cap.rotation.set(side * 0.4, side * 0.8, side * 0.3);
    cap.castShadow = true;
    group.add(cap);
  }

  const lintel = new THREE.Mesh(new THREE.BoxGeometry(width + 0.36, 0.15, 0.38), culvertStone);
  lintel.position.set(0, 0.45, 0.09);
  lintel.rotation.x = -0.035;
  lintel.castShadow = true;
  lintel.receiveShadow = true;
  group.add(lintel);

  // A low stone apron reaches toward the square rim without crossing it.
  const apron = new THREE.Mesh(new THREE.BoxGeometry(width + 0.22, 0.06, 0.24), culvertStoneDark);
  apron.position.set(0, 0.03, 0.22);
  apron.rotation.x = 0.015;
  apron.castShadow = true;
  apron.receiveShadow = true;
  group.add(apron);

  // Loose stones around the mouth.
  const culvertRng = mulberry32(endName === 'outlet' ? 7719 : 7721);
  for (let i = 0; i < 9; i += 1) {
    const stone = new THREE.Mesh(
      culvertStoneGeometry,
      culvertRng() > 0.5 ? culvertStone : culvertStoneLight,
    );
    const side = culvertRng() > 0.5 ? 1 : -1;
    const s = 0.07 + culvertRng() * 0.085;
    stone.position.set(
      side * (width * 0.5 + 0.1 + culvertRng() * 0.18),
      0.045 + s * 0.3,
      0.05 + culvertRng() * 0.22,
    );
    stone.scale.set(s, s * 0.7, s * 0.9);
    stone.rotation.set(culvertRng() * 2, culvertRng() * 3, culvertRng() * 2);
    stone.castShadow = true;
    stone.receiveShadow = true;
    group.add(stone);
  }

  group.updateMatrixWorld(true);
  const bounds = new THREE.Box3().setFromObject(group);
  culvertBounds.push({
    name: endName,
    min: bounds.min.toArray(),
    max: bounds.max.toArray(),
  });
  return group;
}

buildCulvert(waterSamples[0], 'inlet');
buildCulvert(waterSamples[waterSamples.length - 1], 'outlet');

// Twinkling white sun glints on the water surface.
const sparkleCount = 145;
const sparklePositions = new Float32Array(sparkleCount * 3);
const sparklePhases = new Float32Array(sparkleCount);
const sparkleSizes = new Float32Array(sparkleCount);
const sparkleRng = mulberry32(7801);
for (let i = 0; i < sparkleCount; i += 1) {
  const sample = waterSamples[Math.floor(sparkleRng() * waterSamples.length)];
  const lateral = (sparkleRng() - 0.5) * sample.width * 0.82;
  sparklePositions[i * 3] = sample.p.x + sample.normal.x * lateral;
  sparklePositions[i * 3 + 1] = WATER_Y + 0.018;
  sparklePositions[i * 3 + 2] = sample.p.z + sample.normal.z * lateral;
  sparklePhases[i] = sparkleRng() * Math.PI * 2;
  sparkleSizes[i] = 0.36 + sparkleRng() * 0.74;
}
const sparkleGeometry = new THREE.BufferGeometry();
sparkleGeometry.setAttribute('position', new THREE.BufferAttribute(sparklePositions, 3));
sparkleGeometry.setAttribute('aPhase', new THREE.BufferAttribute(sparklePhases, 1));
sparkleGeometry.setAttribute('aSize', new THREE.BufferAttribute(sparkleSizes, 1));
const sparkleMaterial = new THREE.ShaderMaterial({
  uniforms: {
    uTime: { value: 0 },
    uPixelRatio: { value: renderer.getPixelRatio() },
  },
  transparent: true,
  depthWrite: false,
  depthTest: true,
  blending: THREE.AdditiveBlending,
  toneMapped: false,
  vertexShader: /* glsl */ `
    uniform float uTime;
    uniform float uPixelRatio;
    attribute float aPhase;
    attribute float aSize;
    varying float vAlpha;
    void main() {
      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      float primary = pow(max(0.0, sin(uTime * 2.1 + aPhase)), 12.0);
      float secondary = pow(max(0.0, sin(uTime * 5.4 + aPhase * 2.7)), 8.0);
      float pulse = max(primary, secondary * 0.55);
      vAlpha = 0.08 + pulse * 0.92;
      gl_PointSize = aSize * uPixelRatio * (1.0 + pulse * 1.7) * (170.0 / max(1.0, -mvPosition.z));
      gl_Position = projectionMatrix * mvPosition;
    }
  `,
  fragmentShader: /* glsl */ `
    varying float vAlpha;
    void main() {
      vec2 p = gl_PointCoord - 0.5;
      float alpha = smoothstep(0.5, 0.035, length(p));
      gl_FragColor = vec4(1.0, 0.94, 0.72, alpha * vAlpha);
    }
  `,
});
const waterSparkles = new THREE.Points(sparkleGeometry, sparkleMaterial);
waterSparkles.frustumCulled = false;
waterSparkles.renderOrder = 4;
world.add(waterSparkles);

// Stones along the channel.
function addRockCluster(sampleIndex, side, count, localRng, scaleBias = 1) {
  const sample = riverSamples[clamp(sampleIndex, 0, riverSamples.length - 1)];
  for (let i = 0; i < count; i += 1) {
    const t = sample.t;
    const along = (localRng() - 0.5) * 0.4;
    const p = riverCurve.getPointAt(clamp(t + along * 0.008, 0, 1));
    const tangent = riverCurve.getTangentAt(clamp(t + along * 0.008, 0, 1)).normalize();
    const normal = V3(-tangent.z, 0, tangent.x);
    const offset = sample.width / 2 + 0.14 + localRng() * 0.42;
    const x = p.x + normal.x * offset * side;
    const z = p.z + normal.z * offset * side;
    const size = (0.115 + localRng() * 0.21) * scaleBias;
    rockInstances.push({
      x,
      y: terrainHeight(x, z) + size * 0.35,
      z,
      sx: size * (0.8 + localRng() * 0.8),
      sy: size * (0.55 + localRng() * 0.65),
      sz: size * (0.8 + localRng() * 0.8),
      rx: localRng() * Math.PI,
      ry: localRng() * Math.PI,
      rz: localRng() * Math.PI,
      color: choose(['#596669', '#687372', '#4f5d5f', '#70736a', '#5c6960']),
    });
  }
}

const rockRng = mulberry32(505);
for (let i = 4; i < riverSamples.length - 5; i += 3) {
  addRockCluster(i, 1, 1 + (rockRng() > 0.64 ? 1 : 0), rockRng);
  addRockCluster(i + 1, -1, 1 + (rockRng() > 0.7 ? 1 : 0), rockRng);
}
addRockCluster(6, 1, 3, rockRng, 1.15);
addRockCluster(6, -1, 2, rockRng, 1.22);

// Stone lips at both rim outlets frame the extended water and hide the
// transition where the stream meets the edge of the plinth.
const edgeRockRng = mulberry32(7913);
for (const sample of [waterSamples[3], waterSamples[waterSamples.length - 4]]) {
  for (const side of [-1, 1]) {
    for (let i = 0; i < 4; i += 1) {
      const offset = sample.width * 0.5 + 0.1 + edgeRockRng() * 0.32;
      const x = sample.p.x + sample.normal.x * offset * side;
      const z = sample.p.z + sample.normal.z * offset * side;
      const size = 0.16 + edgeRockRng() * 0.25;
      rockInstances.push({
        x,
        y: terrainHeight(x, z) + size * 0.4,
        z,
        sx: size * (0.9 + edgeRockRng() * 0.7),
        sy: size * (0.6 + edgeRockRng() * 0.5),
        sz: size * (0.9 + edgeRockRng() * 0.7),
        rx: edgeRockRng() * Math.PI,
        ry: edgeRockRng() * Math.PI,
        rz: edgeRockRng() * Math.PI,
        color: choose(['#596669', '#687372', '#4f5d5f', '#70736a']),
      });
    }
  }
}

function buildRockInstances() {
  const geometry = new THREE.DodecahedronGeometry(1, 0);
  const material = toon(0xffffff, { flatShading: true });
  const mesh = new THREE.InstancedMesh(geometry, material, rockInstances.length);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  rockInstances.forEach((item, i) => {
    dummy.position.set(item.x, item.y, item.z);
    dummy.rotation.set(item.rx, item.ry, item.rz);
    dummy.scale.set(item.sx, item.sy, item.sz);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    mesh.setColorAt(i, color.set(item.color));
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  mesh.computeBoundingSphere?.();
  world.add(mesh);
}
buildRockInstances();

// Cattails and reeds at the water's edge.
function addReedsAt(sample, side, count, localRng) {
  for (let i = 0; i < count; i += 1) {
    const angle = localRng() * 0.9 - 0.45;
    const offset = sample.width / 2 - 0.03 + localRng() * 0.32;
    const x = sample.p.x + sample.normal.x * offset * side + (localRng() - 0.5) * 0.15;
    const z = sample.p.z + sample.normal.z * offset * side + (localRng() - 0.5) * 0.15;
    const baseY = terrainHeight(x, z);
    const height = 0.48 + localRng() * 0.48;
    reedStems.push({
      x, y: baseY + height / 2, z,
      sx: 0.018 + localRng() * 0.012,
      sy: height,
      sz: 0.018 + localRng() * 0.012,
      rx: Math.sin(angle) * 0.24,
      rz: Math.cos(angle) * 0.24,
    });
    if (localRng() > 0.38) {
      reedHeads.push({
        x: x + Math.sin(angle) * 0.2,
        y: baseY + height + 0.035,
        z: z + Math.cos(angle) * 0.12,
        sx: 0.052,
        sy: 0.13,
        sz: 0.052,
        rx: Math.sin(angle) * 0.24,
        rz: Math.cos(angle) * 0.24,
      });
    }
  }
}
const reedRng = mulberry32(707);
addReedsAt(riverSamples[26], -1, 7, reedRng);
addReedsAt(riverSamples[58], 1, 8, reedRng);
addReedsAt(riverSamples[112], -1, 10, reedRng);
addReedsAt(riverSamples[155], 1, 9, reedRng);
addReedsAt(riverSamples[186], -1, 12, reedRng);
addReedsAt(waterSamples[7], -1, 5, reedRng);
addReedsAt(waterSamples[waterSamples.length - 8], 1, 6, reedRng);

function buildReeds() {
  if (reedStems.length) {
    const stems = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(1, 1, 1, 5),
      toon(0x6b713c),
      reedStems.length,
    );
    const dummy = new THREE.Object3D();
    reedStems.forEach((item, i) => {
      dummy.position.set(item.x, item.y, item.z);
      dummy.rotation.set(item.rx, 0, item.rz);
      dummy.scale.set(item.sx, item.sy, item.sz);
      dummy.updateMatrix();
      stems.setMatrixAt(i, dummy.matrix);
    });
    stems.instanceMatrix.needsUpdate = true;
    stems.castShadow = true;
    stems.receiveShadow = true;
    stems.frustumCulled = false;
    world.add(stems);

    const heads = new THREE.InstancedMesh(
      new THREE.CapsuleGeometry(1, 1.2, 3, 5),
      toon(0x6e4523),
      reedHeads.length,
    );
    reedHeads.forEach((item, i) => {
      dummy.position.set(item.x, item.y, item.z);
      dummy.rotation.set(item.rx, 0, item.rz);
      dummy.scale.set(item.sx, item.sy, item.sz);
      dummy.updateMatrix();
      heads.setMatrixAt(i, dummy.matrix);
    });
    heads.instanceMatrix.needsUpdate = true;
    heads.castShadow = true;
    heads.frustumCulled = false;
    world.add(heads);
  }
}
buildReeds();

/* --------------------------------------------------------------------------
   Small stony path, stepping stones
   -------------------------------------------------------------------------- */

function buildPathStones() {
  const stoneGeom = new THREE.CylinderGeometry(0.5, 0.58, 1, 7);
  const mesh = new THREE.InstancedMesh(stoneGeom, toon(0xffffff, { flatShading: true }), pathStoneInstances.length);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  pathStoneInstances.forEach((item, i) => {
    dummy.position.set(item.x, item.y, item.z);
    dummy.rotation.set(item.rx || 0, item.ry || 0, item.rz || 0);
    dummy.scale.set(item.sx, item.sy, item.sz);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    mesh.setColorAt(i, color.set(item.color));
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  world.add(mesh);
}

/* --------------------------------------------------------------------------
   Courtyard, cottage, fence and harvest props
   -------------------------------------------------------------------------- */

const houseGroup = new THREE.Group();
houseGroup.position.set(3.65, 0.2, 0.12);
houseGroup.rotation.y = -0.055;
world.add(houseGroup);

const courtyardGroup = new THREE.Group();
world.add(courtyardGroup);

const smokeSources = [];
const warmLights = [];
const nightGlowMaterials = [];
const nightGlowSprites = [];

function addMesh(parent, geometry, material, x = 0, y = 0, z = 0, cast = true, receive = true) {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(x, y, z);
  mesh.castShadow = cast;
  mesh.receiveShadow = receive;
  parent.add(mesh);
  return mesh;
}

function addBox(parent, w, h, d, material, x = 0, y = 0, z = 0, cast = true, receive = true) {
  return addMesh(parent, new THREE.BoxGeometry(w, h, d), material, x, y, z, cast, receive);
}

function addCylinder(parent, rTop, rBottom, height, material, x = 0, y = 0, z = 0, segments = 8, cast = true, receive = true) {
  return addMesh(parent, new THREE.CylinderGeometry(rTop, rBottom, height, segments), material, x, y, z, cast, receive);
}

function addBeam(parent, a, b, thickness, material, cast = true, receive = true) {
  const direction = new THREE.Vector3().subVectors(b, a);
  const length = direction.length();
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(thickness, thickness, length), material);
  mesh.position.copy(a).add(b).multiplyScalar(0.5);
  mesh.quaternion.setFromUnitVectors(V3(0, 0, 1), direction.normalize());
  mesh.castShadow = cast;
  mesh.receiveShadow = receive;
  parent.add(mesh);
  return mesh;
}

function buildCourtyard() {
  const padShape = roundedRectShape(5.8, 4.15, 0.55);
  const padGeometry = new THREE.ExtrudeGeometry(padShape, {
    depth: 0.22,
    bevelEnabled: true,
    bevelThickness: 0.04,
    bevelSize: 0.04,
    bevelSegments: 2,
    curveSegments: 4,
    steps: 1,
  });
  padGeometry.rotateX(-Math.PI / 2);
  padGeometry.translate(0, -0.11, 0);
  const pad = new THREE.Mesh(padGeometry, [matSoil, matSoilDark]);
  pad.position.set(3.72, 0.155, 1.02);
  pad.castShadow = true;
  pad.receiveShadow = true;
  courtyardGroup.add(pad);

  // Irregular flat stones across the yard.
  const yardRng = mulberry32(603);
  for (let i = 0; i < 19; i += 1) {
    const x = 2.1 + yardRng() * 4.7;
    const z = 0.95 + yardRng() * 2.2;
    pathStoneInstances.push({
      x,
      y: 0.278 + yardRng() * 0.006,
      z,
      sx: 0.18 + yardRng() * 0.22,
      sy: 0.022 + yardRng() * 0.018,
      sz: 0.16 + yardRng() * 0.2,
      ry: yardRng() * Math.PI,
      color: choose(['#b5ab97', '#c4b9a3', '#96988e', '#b8a087']),
    });
  }
}

buildCourtyard();

function buildWindow(parent, x, y, z, width, height, rotationY = 0) {
  const windowGroup = new THREE.Group();
  windowGroup.position.set(x, y, z);
  windowGroup.rotation.y = rotationY;
  parent.add(windowGroup);

  const glowColor = new THREE.Color(0xffd39a).multiplyScalar(1.12);
  const glowMaterial = new THREE.MeshBasicMaterial({ color: glowColor, toneMapped: false });
  nightGlowMaterials.push({
    material: glowMaterial,
    base: glowColor.clone(),
    day: 1,
    dusk: 1.16,
    night: 1.55,
  });
  const glow = new THREE.Mesh(
    new THREE.PlaneGeometry(width * 0.86, height * 0.82),
    glowMaterial,
  );
  glow.position.z = 0.014;
  windowGroup.add(glow);

  const frameMat = matWoodDark;
  addBox(windowGroup, width + 0.1, 0.065, 0.05, frameMat, 0, height / 2, 0.038, false, false);
  addBox(windowGroup, width + 0.1, 0.065, 0.05, frameMat, 0, -height / 2, 0.038, false, false);
  addBox(windowGroup, 0.065, height + 0.05, 0.05, frameMat, -width / 2, 0, 0.038, false, false);
  addBox(windowGroup, 0.065, height + 0.05, 0.05, frameMat, width / 2, 0, 0.038, false, false);
  for (let i = -1; i <= 1; i += 1) {
    addBox(windowGroup, 0.025, height * 0.84, 0.025, frameMat, i * width * 0.25, 0, 0.05, false, false);
  }
  for (let i = -1; i <= 1; i += 1) {
    addBox(windowGroup, width * 0.84, 0.025, 0.025, frameMat, 0, i * height * 0.25, 0.05, false, false);
  }

  const sill = addBox(windowGroup, width + 0.18, 0.07, 0.18, matWoodDark, 0, -height / 2 - 0.05, 0.065, true, true);
  sill.rotation.z = 0.005;
  return windowGroup;
}

function addThatchFringe(parent, x0, x1, y, z, localRng, count) {
  // This function is called in the parent's local space; convert later via parent.localToWorld.
  for (let i = 0; i < count; i += 1) {
    const x = lerp(x0, x1, (i + 0.5) / count) + (localRng() - 0.5) * 0.04;
    thatchFringeInstances.push({
      parent,
      x,
      y: y - localRng() * 0.085,
      z: z + (localRng() - 0.5) * 0.05,
      sx: 0.026 + localRng() * 0.022,
      sy: 0.16 + localRng() * 0.105,
      sz: 0.026 + localRng() * 0.022,
      rx: Math.PI + (localRng() - 0.5) * 0.16,
      rz: (localRng() - 0.5) * 0.22,
    });
  }
}

function buildGableRoof(parent, options) {
  const {
    width,
    depth,
    wallTop,
    rise,
    overhang = 0.35,
    material = matThatch,
    fringe = true,
    gableMaterial = matPlaster,
    localRng,
  } = options;
  const run = depth / 2 + overhang;
  const angle = Math.atan2(rise, run);
  const slope = Math.hypot(run, rise);
  const roofWidth = width + overhang * 2;

  for (const side of [1, -1]) {
    const slab = new THREE.Mesh(new THREE.BoxGeometry(roofWidth, 0.16, slope), material);
    slab.position.set(0, wallTop + rise / 2 - 0.025, (side * run) / 2);
    slab.rotation.x = side * angle;
    slab.castShadow = true;
    slab.receiveShadow = true;
    parent.add(slab);
  }

  const ridge = new THREE.Mesh(new THREE.BoxGeometry(roofWidth + 0.1, 0.16, 0.23), matThatchDark);
  ridge.position.set(0, wallTop + rise + 0.045, 0);
  ridge.castShadow = true;
  ridge.receiveShadow = true;
  parent.add(ridge);

  // A dark timber fascia under the straw edge makes the silhouette read cleanly.
  for (const side of [1, -1]) {
    addBox(parent, roofWidth, 0.095, 0.11, matWoodDark, 0, wallTop - 0.07, side * (run + 0.02), true, true);
  }

  // A jagged, hanging straw skirt breaks the ruler-straight roof edge. The
  // uneven lower silhouette is the detail that reads as thatch instead of tile.
  const skirtRng = localRng || mulberry32(830);
  for (const side of [1, -1]) {
    const segments = 38;
    const positions = [];
    const colors = [];
    const indices = [];
    const low = new THREE.Color(0x9f7136);
    const high = new THREE.Color(0xe2bc7a);
    for (let i = 0; i <= segments; i += 1) {
      const x = lerp(-roofWidth / 2, roofWidth / 2, i / segments);
      const top = wallTop - 0.015 + (skirtRng() - 0.5) * 0.025;
      const bottom = wallTop - 0.105 - skirtRng() * 0.11;
      const z = side * (run + 0.035) + (skirtRng() - 0.5) * 0.025;
      positions.push(x, top, z, x + (skirtRng() - 0.5) * 0.025, bottom, z + side * 0.012);
      const shade = 0.3 + skirtRng() * 0.5;
      const c = low.clone().lerp(high, shade);
      colors.push(low.r, low.g, low.b, c.r, c.g, c.b);
    }
    for (let i = 0; i < segments; i += 1) {
      const a = i * 2;
      indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
    const skirtGeometry = new THREE.BufferGeometry();
    skirtGeometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    skirtGeometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    skirtGeometry.setIndex(indices);
    skirtGeometry.computeVertexNormals();
    const skirt = new THREE.Mesh(
      skirtGeometry,
      toon(0xffffff, { vertexColors: true, side: THREE.DoubleSide }),
    );
    skirt.castShadow = true;
    skirt.receiveShadow = true;
    parent.add(skirt);
  }

  // A rounded straw ridge cap, slightly uneven, sits above the timber ridge.
  const ridgeCap = new THREE.Mesh(
    new THREE.CylinderGeometry(0.115, 0.14, roofWidth + 0.06, 7, 1),
    toon(0xd8b26e),
  );
  ridgeCap.rotation.z = Math.PI / 2;
  ridgeCap.rotation.x = (skirtRng() - 0.5) * 0.03;
  ridgeCap.position.y = wallTop + rise + 0.12;
  ridgeCap.castShadow = true;
  ridgeCap.receiveShadow = true;
  parent.add(ridgeCap);
  for (let i = 0; i < 5; i += 1) {
    const binding = new THREE.Mesh(
      new THREE.TorusGeometry(0.135, 0.014, 4, 8),
      matWoodDark,
    );
    binding.rotation.y = Math.PI / 2;
    binding.position.set(-roofWidth / 2 + ((i + 0.5) / 5) * roofWidth, wallTop + rise + 0.12, 0);
    parent.add(binding);
  }

  // Triangular gable walls and their timber trim.
  const shape = new THREE.Shape();
  shape.moveTo(-depth / 2, 0);
  shape.lineTo(depth / 2, 0);
  shape.lineTo(0, rise);
  shape.closePath();
  const gableGeometry = new THREE.ShapeGeometry(shape);
  gableGeometry.rotateY(Math.PI / 2);
  for (const side of [1, -1]) {
    const gable = new THREE.Mesh(gableGeometry, gableMaterial);
    gable.position.set(side * (width / 2 - 0.01), wallTop, 0);
    gable.rotation.y = side > 0 ? 0 : Math.PI;
    gable.castShadow = true;
    gable.receiveShadow = true;
    parent.add(gable);

    addBeam(
      parent,
      V3(side * (width / 2 + 0.015), wallTop, -depth / 2),
      V3(side * (width / 2 + 0.015), wallTop + rise, 0),
      0.075,
      matWoodDark,
    );
    addBeam(
      parent,
      V3(side * (width / 2 + 0.015), wallTop, depth / 2),
      V3(side * (width / 2 + 0.015), wallTop + rise, 0),
      0.075,
      matWoodDark,
    );
    addBeam(
      parent,
      V3(side * (width / 2 + 0.018), wallTop + rise * 0.52, -depth * 0.24),
      V3(side * (width / 2 + 0.018), wallTop + rise * 0.52, depth * 0.24),
      0.055,
      matWoodDark,
      false,
      false,
    );
  }

  if (fringe) {
    const rngLocal = localRng || mulberry32(801);
    const count = Math.max(36, Math.floor(roofWidth / 0.062));
    addThatchFringe(parent, -roofWidth / 2, roofWidth / 2, wallTop - 0.06, run + 0.015, rngLocal, count);
    addThatchFringe(parent, -roofWidth / 2, roofWidth / 2, wallTop - 0.06, -run - 0.015, rngLocal, count);
  }

  return { run, angle, roofWidth };
}

function buildCottage() {
  const rngHouse = mulberry32(912);

  // Stone platform and plaster walls.
  addBox(houseGroup, 3.92, 0.2, 2.72, matStoneDark, 0, 0.1, 0);
  const walls = addBox(houseGroup, 3.4, 1.55, 2.28, matPlaster, 0, 0.96, 0);
  walls.receiveShadow = true;

  // Wooden sill and structural frame.
  addBox(houseGroup, 3.58, 0.12, 2.42, matWoodDark, 0, 0.22, 0);
  addBox(houseGroup, 3.55, 0.13, 2.41, matWoodDark, 0, 1.73, 0);
  for (const x of [-1.66, 1.66]) {
    for (const z of [-1.12, 1.12]) {
      addBox(houseGroup, 0.12, 1.6, 0.12, matWoodDark, x, 1.0, z);
    }
    addBox(houseGroup, 0.095, 3.5, 0.1, matWoodDark, 0, 1.2, 0);
  }
  addBeam(houseGroup, V3(-1.66, 0.45, 1.17), V3(-0.55, 1.55, 1.17), 0.075, matWoodDark);
  addBeam(houseGroup, V3(1.66, 0.45, 1.17), V3(0.55, 1.55, 1.17), 0.075, matWoodDark);

  // Front door, recessed and warm.
  const door = addBox(houseGroup, 0.63, 1.25, 0.08, matWoodDark, -0.62, 0.91, 1.155);
  const doorInset = addBox(houseGroup, 0.47, 1.05, 0.035, toon(0x3a2012), -0.62, 0.91, 1.2);
  doorInset.castShadow = false;
  for (let i = -1; i <= 1; i += 1) {
    addBox(houseGroup, 0.018, 0.98, 0.02, matWoodLight, -0.62 + i * 0.14, 0.9, 1.222, false, false);
  }
  addBox(houseGroup, 0.1, 0.1, 0.035, matMetal, -0.37, 0.92, 1.24, false, false);
  const step = addBox(houseGroup, 0.95, 0.16, 0.58, matStone, -0.62, 0.16, 1.48);
  step.rotation.x = -0.03;

  // Faded red door papers; a very small human trace.
  const paperMat = toon(0x9f3e2c);
  addBox(houseGroup, 0.075, 0.92, 0.012, paperMat, -1.02, 0.98, 1.203, false, false);
  addBox(houseGroup, 0.075, 0.92, 0.012, paperMat, -0.22, 0.98, 1.203, false, false);
  addBox(houseGroup, 0.75, 0.075, 0.012, paperMat, -0.62, 1.56, 1.203, false, false);

  buildWindow(houseGroup, 0.82, 1.12, 1.165, 0.68, 0.56);
  const sideWindow = buildWindow(houseGroup, 1.705, 1.12, -0.28, 0.55, 0.52, Math.PI / 2);
  sideWindow.position.x = 1.705;

  // Roof.
  buildGableRoof(houseGroup, {
    width: 3.4,
    depth: 2.28,
    wallTop: 1.73,
    rise: 1.14,
    overhang: 0.38,
    material: matThatch,
    fringe: true,
    localRng: rngHouse,
  });

  // Chimney with a stone cap. It sits on the near roof slope so the wood smoke
  // is visible from the default three-quarter view.
  addBox(houseGroup, 0.32, 1.12, 0.32, matStone, -0.86, 2.45, 0.33);
  addBox(houseGroup, 0.43, 0.1, 0.41, matStoneDark, -0.86, 3.03, 0.33);
  addBox(houseGroup, 0.17, 0.18, 0.17, matStoneDark, -0.86, 3.15, 0.33);
  smokeSources.push({ parent: houseGroup, local: V3(-0.86, 3.24, 0.33), drift: V3(0.16, 0, -0.08), rate: 0.18 });

  // Small warm interior lights around the front door.
  const doorLight = new THREE.PointLight(0xff9f58, 4.5, 3.1, 2);
  doorLight.position.set(-0.5, 1.35, 1.45);
  doorLight.userData = { day: 4.5, dusk: 6.5, night: 9.5 };
  houseGroup.add(doorLight);
  warmLights.push(doorLight);
  const glowSprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      color: 0xffb35d,
      transparent: true,
      opacity: 0.24,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      toneMapped: false,
    }),
  );
  glowSprite.position.set(-0.62, 1.12, 1.31);
  glowSprite.scale.set(1.0, 0.9, 1);
  nightGlowSprites.push({ material: glowSprite.material, day: 0.24, dusk: 0.32, night: 0.42 });
  houseGroup.add(glowSprite);

  // A little red lantern beside the door.
  const lanternGroup = new THREE.Group();
  lanternGroup.position.set(-1.27, 1.43, 1.31);
  houseGroup.add(lanternGroup);
  addCylinder(lanternGroup, 0.025, 0.025, 0.22, matWoodDark, 0, 0.24, 0, 5, false, false);
  const lanternColor = new THREE.Color(0xff7a44).multiplyScalar(1.2);
  const lanternMaterial = new THREE.MeshBasicMaterial({
    color: lanternColor,
    toneMapped: false,
  });
  nightGlowMaterials.push({
    material: lanternMaterial,
    base: lanternColor.clone(),
    day: 1,
    dusk: 1.18,
    night: 1.75,
  });
  const lantern = addMesh(
    lanternGroup,
    new THREE.SphereGeometry(0.13, 12, 8),
    lanternMaterial,
    0,
    0.12,
    0,
    false,
    false,
  );
  lantern.scale.y = 0.82;
  addCylinder(lanternGroup, 0.075, 0.075, 0.025, matWoodDark, 0, 0.245, 0, 8, false, false);
  addCylinder(lanternGroup, 0.075, 0.075, 0.025, matWoodDark, 0, -0.005, 0, 8, false, false);
  addCylinder(lanternGroup, 0.007, 0.007, 0.14, toon(0xa62d1d), 0, -0.075, 0, 4, false, false);
  const lanternLight = new THREE.PointLight(0xffb15e, 0, 3.4, 2);
  lanternLight.position.set(0, 0.12, 0.1);
  lanternLight.userData = { day: 0, dusk: 1.4, night: 4.0 };
  lanternGroup.add(lanternLight);
  warmLights.push(lanternLight);

  // Attached woodshed with a gray tiled roof.
  const shed = new THREE.Group();
  shed.position.set(2.42, 0.02, -0.58);
  houseGroup.add(shed);
  addBox(shed, 1.32, 0.16, 1.74, matStoneDark, 0, 0.09, 0);
  for (const z of [-0.76, 0.76]) {
    addBox(shed, 0.1, 1.48, 0.1, matWood, -0.56, 0.77, z);
    addBox(shed, 0.085, 1.36, 0.085, matWood, 0.55, 0.71, z);
  }
  addBox(shed, 1.4, 0.08, 1.85, matWoodDark, 0, 1.48, 0);
  const leanTo = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.12, 2.05), matTile);
  leanTo.position.set(0.05, 1.72, -0.1);
  leanTo.rotation.x = 0.2;
  leanTo.castShadow = true;
  leanTo.receiveShadow = true;
  shed.add(leanTo);
  // roof lip
  addBox(shed, 1.65, 0.08, 0.12, matTile, 0.05, 1.6, 0.92);
  // Firewood under the shed.
  const fireRng = mulberry32(918);
  for (let i = 0; i < 10; i += 1) {
    const log = addCylinder(
      shed,
      0.055 + fireRng() * 0.025,
      0.06 + fireRng() * 0.025,
      0.62,
      matWood,
      -0.33 + (i % 3) * 0.13,
      0.12 + Math.floor(i / 3) * 0.1,
      -0.2 + fireRng() * 0.4,
      6,
      true,
      true,
    );
    log.rotation.z = Math.PI / 2;
    log.rotation.y = fireRng() * 0.22;
  }
  smokeSources.push({ parent: shed, local: V3(0.66, 1.9, 0.1), drift: V3(-0.15, 0, -0.2), rate: 0.1 });

  // Drying corn and peppers under the eaves.
  const cropRng = mulberry32(920);
  addCropBundle(houseGroup, -1.44, 1.34, 1.31, 'corn', cropRng);
  addCropBundle(houseGroup, 1.36, 1.26, -0.9, 'chili', cropRng);
  addCropBundle(houseGroup, 0.05, 1.3, 1.315, 'chili', cropRng);

  // A broom leaning by the door.
  const broom = new THREE.Group();
  broom.position.set(1.43, 0.33, 1.35);
  broom.rotation.z = -0.14;
  broom.rotation.x = 0.03;
  houseGroup.add(broom);
  addCylinder(broom, 0.015, 0.019, 1.0, matWood, 0, 0.5, 0, 5);
  const bristles = addCylinder(broom, 0.11, 0.035, 0.35, matThatchDark, 0, 0.08, 0, 7);
  bristles.rotation.z = 0.02;

  return houseGroup;
}

function addCropBundle(parent, x, y, z, kind, localRng) {
  const rope = addCylinder(parent, 0.008, 0.008, 0.38, matWoodDark, x, y, z, 4, false, false);
  rope.rotation.z = 0.04;
  if (kind === 'corn') {
    for (let i = 0; i < 3; i += 1) {
      const cob = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.045, 0.24, 4, 6),
        toon(i % 2 ? 0xd6a03c : 0xe2b34c),
      );
      cob.position.set(x - 0.08 + i * 0.08, y - 0.1 - i * 0.04, z);
      cob.rotation.z = 0.24 + (localRng() - 0.5) * 0.2;
      cob.castShadow = true;
      parent.add(cob);
      const husk = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.25, 5), toon(0x7c8b45));
      husk.position.copy(cob.position);
      husk.position.y -= 0.1;
      husk.rotation.z = cob.rotation.z;
      parent.add(husk);
    }
  } else {
    for (let i = 0; i < 9; i += 1) {
      const chili = new THREE.Mesh(
        new THREE.ConeGeometry(0.035, 0.16, 5),
        toon(i % 3 ? 0xb73923 : 0xd9532d),
      );
      chili.position.set(x + (localRng() - 0.5) * 0.22, y - 0.1 - i * 0.058, z + (localRng() - 0.5) * 0.06);
      chili.rotation.z = Math.PI + (localRng() - 0.5) * 0.3;
      chili.castShadow = true;
      parent.add(chili);
    }
  }
}

buildCottage();

/* --------------------------------------------------------------------------
   Fences, gate and garden
   -------------------------------------------------------------------------- */

function addFenceSegment(x1, z1, x2, z2, y, rngLocal, fenceHeight = 0.72) {
  const length = Math.hypot(x2 - x1, z2 - z1);
  const count = Math.max(2, Math.ceil(length / 0.62));
  const yaw = Math.atan2(-(z2 - z1), x2 - x1);
  for (let i = 0; i <= count; i += 1) {
    const t = i / count;
    const x = lerp(x1, x2, t) + (rngLocal() - 0.5) * 0.035;
    const z = lerp(z1, z2, t) + (rngLocal() - 0.5) * 0.035;
    const height = fenceHeight * (0.86 + rngLocal() * 0.18);
    fencePostInstances.push({
      x,
      y: y + height / 2,
      z,
      ry: yaw + (rngLocal() - 0.5) * 0.11,
      sx: 0.09 + rngLocal() * 0.025,
      sy: height,
      sz: 0.09 + rngLocal() * 0.025,
    });
    // A little pointed cap, built from a separate tiny box rather than a cone
    // so it remains visually part of the timber fence.
    fencePostInstances.push({
      x,
      y: y + height + 0.035,
      z,
      ry: yaw,
      sx: 0.07,
      sy: 0.07,
      sz: 0.07,
    });
  }
  for (const level of [0.26, 0.55]) {
    fenceRailInstances.push({
      x: (x1 + x2) / 2,
      y: y + fenceHeight * level,
      z: (z1 + z2) / 2,
      ry: yaw,
      sx: length,
      sy: 0.07,
      sz: 0.055,
    });
  }
}

function buildFenceAndGate() {
  const fenceRng = mulberry32(1004);
  const padY = 0.255;
  addFenceSegment(1.55, 2.82, 2.63, 2.82, padY, fenceRng);
  addFenceSegment(3.48, 2.82, 6.48, 2.82, padY, fenceRng);
  addFenceSegment(1.55, 2.82, 1.55, -0.72, padY, fenceRng, 0.68);
  addFenceSegment(6.48, 2.82, 6.48, -0.72, padY, fenceRng, 0.68);
  addFenceSegment(1.55, -0.72, 2.1, -0.72, padY, fenceRng, 0.64);
  addFenceSegment(5.9, -0.72, 6.48, -0.72, padY, fenceRng, 0.64);

  // Gate posts.
  for (const x of [2.62, 3.48]) {
    fencePostInstances.push({
      x,
      y: padY + 0.47,
      z: 2.82,
      sx: 0.14,
      sy: 0.94,
      sz: 0.14,
    });
    fencePostInstances.push({
      x,
      y: padY + 0.98,
      z: 2.82,
      sx: 0.17,
      sy: 0.08,
      sz: 0.17,
    });
  }

  // One gate leaf, swung inward. The X brace is what sells it as a gate.
  const gate = new THREE.Group();
  gate.position.set(2.68, padY + 0.12, 2.8);
  gate.rotation.y = 0.9;
  courtyardGroup.add(gate);
  addBox(gate, 0.07, 0.74, 0.07, matWoodDark, 0, 0.37, -0.38);
  addBox(gate, 0.07, 0.74, 0.07, matWoodDark, 0, 0.37, 0.38);
  addBox(gate, 0.065, 0.07, 0.82, matWoodDark, 0, 0.68, 0);
  addBox(gate, 0.055, 0.06, 0.76, matWoodDark, 0, 0.28, 0);
  addBeam(gate, V3(0, 0.26, -0.36), V3(0, 0.7, 0.36), 0.045, matWoodDark, false, false);
  addBeam(gate, V3(0, 0.7, -0.36), V3(0, 0.26, 0.36), 0.045, matWoodDark, false, false);

  // Small stepping-stone trail from the bridge up to the gate and door.
  const pathRng = mulberry32(1009);
  const path = new THREE.CatmullRomCurve3([
    V3(2.83, 0.25, 3.92),
    V3(3.02, 0.27, 3.56),
    V3(3.08, 0.28, 3.12),
    V3(3.03, 0.3, 2.62),
    V3(2.94, 0.31, 2.18),
    V3(2.99, 0.32, 1.72),
  ]);
  // Packed earth under the stones makes the route legible from a distance.
  const pathSamples = 26;
  const ribbonPositions = [];
  const ribbonUvs = [];
  const ribbonIndices = [];
  for (let i = 0; i < pathSamples; i += 1) {
    const t = i / (pathSamples - 1);
    const p = path.getPointAt(t);
    const tangent = path.getTangentAt(t).normalize();
    const normal = V3(-tangent.z, 0, tangent.x);
    const width = 0.62;
    for (let side = -1; side <= 1; side += 1) {
      const x = p.x + normal.x * width * 0.5 * side;
      const z = p.z + normal.z * width * 0.5 * side;
      const onPad = z < 3.06 && x > 1.62;
      const y = (onPad ? 0.272 : terrainHeight(x, z) + 0.032) + 0.008;
      ribbonPositions.push(x, y, z);
      ribbonUvs.push(side > 0 ? 1 : 0, t);
    }
  }
  for (let i = 0; i < pathSamples - 1; i += 1) {
    const a = i * 2;
    ribbonIndices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
  }
  const ribbonGeom = new THREE.BufferGeometry();
  ribbonGeom.setAttribute('position', new THREE.Float32BufferAttribute(ribbonPositions, 3));
  ribbonGeom.setAttribute('uv', new THREE.Float32BufferAttribute(ribbonUvs, 2));
  ribbonGeom.setIndex(ribbonIndices);
  ribbonGeom.computeVertexNormals();
  const ribbon = new THREE.Mesh(ribbonGeom, toon(0xa77943));
  ribbon.receiveShadow = true;
  courtyardGroup.add(ribbon);

  for (let i = 0; i < 16; i += 1) {
    const t = (i + 0.45) / 16;
    const p = path.getPointAt(t);
    const tangent = path.getTangentAt(t);
    const angle = Math.atan2(tangent.x, tangent.z);
    const x = p.x + (pathRng() - 0.5) * 0.13;
    const z = p.z + (pathRng() - 0.5) * 0.13;
    const onPad = z < 3.06 && x > 1.62;
    const ground = (onPad ? 0.272 : terrainHeight(x, z) + 0.035) + 0.016;
    pathStoneInstances.push({
      x,
      y: ground,
      z,
      sx: 0.27 + pathRng() * 0.14,
      sy: 0.032 + pathRng() * 0.013,
      sz: 0.22 + pathRng() * 0.12,
      ry: angle + pathRng() * 0.5,
      color: choose(['#b8ae98', '#a69d8b', '#c7bca4', '#ad9f88']),
    });
  }
}

buildFenceAndGate();

/* --------------------------------------------------------------------------
   Courtyard props: pumpkins, corn, trays, jars, haystack, bench
   -------------------------------------------------------------------------- */

function makePumpkin(radius, colorHex, seed) {
  const localRng = mulberry32(seed);
  const geometry = new THREE.SphereGeometry(radius, 14, 9);
  const position = geometry.attributes.position;
  for (let i = 0; i < position.count; i += 1) {
    const x = position.getX(i);
    const y = position.getY(i);
    const z = position.getZ(i);
    const angle = Math.atan2(z, x);
    const lobe = 1 + Math.cos(angle * 8) * 0.09;
    position.setXYZ(i, x * lobe, y * 0.72, z * lobe);
  }
  geometry.computeVertexNormals();
  const group = new THREE.Group();
  const pumpkin = new THREE.Mesh(geometry, toon(colorHex));
  pumpkin.castShadow = true;
  pumpkin.receiveShadow = true;
  group.add(pumpkin);
  const stem = new THREE.Mesh(
    new THREE.CylinderGeometry(0.024, 0.035, 0.14, 5),
    toon(0x66703c),
  );
  stem.position.y = radius * 0.68 + 0.055;
  stem.rotation.z = 0.2;
  stem.castShadow = true;
  group.add(stem);
  group.rotation.y = localRng() * Math.PI;
  return group;
}

function addPumpkinPatch() {
  const positions = [
    [2.2, 2.34, 0.28, 0xd96a26],
    [2.54, 2.16, 0.21, 0xe1882f],
    [5.38, 2.48, 0.24, 0xc65a21],
    [5.76, 2.3, 0.3, 0xe29235],
    [6.08, 2.52, 0.18, 0xcf7b45],
    [4.93, 2.76, 0.19, 0x9c9a4a],
    [1.16, 2.22, 0.3, 0xd86524],
    [1.42, 2.43, 0.21, 0xe7a13a],
    [1.02, 1.95, 0.18, 0xc45121],
    [1.36, 1.82, 0.24, 0x9d9a48],
  ];
  for (let i = 0; i < positions.length; i += 1) {
    const [x, z, r, color] = positions[i];
    const pumpkin = makePumpkin(r, color, 1200 + i);
    const ground = x < 1.55 ? terrainHeight(x, z) + 0.025 : 0.292;
    pumpkin.position.set(x, ground + r * 0.3, z);
    world.add(pumpkin);
    // vine curl
    const vine = new THREE.Mesh(
      new THREE.TorusGeometry(0.15 + r * 0.2, 0.013, 4, 9, Math.PI * 1.4),
      toon(0x6f7e3c),
    );
    vine.position.set(x + 0.25, 0.34, z + 0.12);
    vine.rotation.set(Math.PI / 2, 0.4, 0);
    vine.castShadow = true;
    world.add(vine);
  }
}

function addCornPatch() {
  const cornRng = mulberry32(1309);
  const positions = [
    [5.82, 1.82, 1.0],
    [6.13, 1.96, 0.92],
    [5.66, 2.08, 0.85],
    [2.02, 2.52, 0.82],
  ];
  for (let n = 0; n < positions.length; n += 1) {
    const [x, z, scale] = positions[n];
    const group = new THREE.Group();
    group.position.set(x, 0.3, z);
    group.rotation.y = cornRng() * Math.PI;
    world.add(group);
    for (let i = 0; i < 3; i += 1) {
      const h = (1.42 + cornRng() * 0.25) * scale;
      const stem = addCylinder(group, 0.018, 0.027, h, toon(0x728141), (i - 1) * 0.11, h / 2, (cornRng() - 0.5) * 0.12, 5);
      stem.rotation.z = (i - 1) * 0.075;
      for (let l = 0; l < 3; l += 1) {
        const leaf = addMesh(
          group,
          new THREE.PlaneGeometry(0.15, 0.7),
          toon(0x768b45, { side: THREE.DoubleSide }),
          (i - 1) * 0.13 + (cornRng() - 0.5) * 0.1,
          h * (0.35 + l * 0.15),
          (cornRng() - 0.5) * 0.15,
        );
        leaf.rotation.set(0.12 + cornRng() * 0.2, cornRng() * Math.PI, (cornRng() - 0.5) * 0.9);
        leaf.scale.set(1, 0.8 + cornRng() * 0.3, 1);
      }
      if (i < 2) {
        const cob = new THREE.Mesh(
          new THREE.CapsuleGeometry(0.045, 0.2, 4, 6),
          toon(0xd8a63e, { emissive: 0x231405, emissiveIntensity: 0.16 }),
        );
        cob.position.set((i - 1) * 0.11 + 0.07, h * 0.55, 0.07);
        cob.rotation.z = -0.35;
        cob.castShadow = true;
        group.add(cob);
        const husk = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.23, 5), toon(0x788044));
        husk.position.copy(cob.position);
        husk.position.y -= 0.11;
        husk.rotation.z = cob.rotation.z + 0.1;
        group.add(husk);
      }
    }
  }
}

function addDryingTrays() {
  const trayMat = toon(0xffffff, { map: thatchTexture, color: 0xc49a5a });
  const produceRng = mulberry32(1401);
  const spots = [
    [4.42, 1.68, 0.48],
    [5.47, 2.04, 0.4],
    [2.18, 1.56, 0.36],
  ];
  for (const [x, z, radius] of spots) {
    const group = new THREE.Group();
    group.position.set(x, 0.33, z);
    world.add(group);
    addCylinder(group, radius, radius * 0.92, 0.045, trayMat, 0, 0.025, 0, 16, true, true);
    for (let i = 0; i < 18; i += 1) {
      const angle = produceRng() * Math.PI * 2;
      const r = Math.sqrt(produceRng()) * radius * 0.72;
      const color = produceRng() > 0.48 ? 0xb53a23 : 0xd39a35;
      const item = new THREE.Mesh(
        produceRng() > 0.45
          ? new THREE.SphereGeometry(0.032 + produceRng() * 0.02, 6, 4)
          : new THREE.ConeGeometry(0.027, 0.08, 4),
        toon(color),
      );
      item.position.set(Math.cos(angle) * r, 0.07, Math.sin(angle) * r);
      item.castShadow = true;
      group.add(item);
    }
    // simple bamboo legs
    for (const sx of [-1, 1]) {
      const leg = addCylinder(group, 0.025, 0.025, 0.18, matWood, sx * radius * 0.5, -0.09, 0, 4, false, false);
      leg.rotation.z = sx * 0.08;
    }
  }
}

function makeJar(scale, colorHex) {
  const points = [];
  points.push(new THREE.Vector2(0.01, 0));
  points.push(new THREE.Vector2(0.2, 0.02));
  points.push(new THREE.Vector2(0.25, 0.12));
  points.push(new THREE.Vector2(0.24, 0.34));
  points.push(new THREE.Vector2(0.15, 0.47));
  points.push(new THREE.Vector2(0.17, 0.55));
  const jarGeometry = new THREE.LatheGeometry(points, 12);
  const jar = new THREE.Mesh(jarGeometry, toon(colorHex, { side: THREE.DoubleSide }));
  jar.scale.setScalar(scale);
  jar.castShadow = true;
  jar.receiveShadow = true;
  return jar;
}

function addBench(x, z, rotation) {
  const group = new THREE.Group();
  group.position.set(x, 0.32, z);
  group.rotation.y = rotation;
  world.add(group);
  addBox(group, 0.95, 0.08, 0.26, matWood, 0, 0.24, 0);
  addBox(group, 0.95, 0.06, 0.22, matWood, 0, 0.52, -0.14);
  for (const sx of [-0.35, 0.35]) {
    addBox(group, 0.08, 0.24, 0.08, matWoodDark, sx, 0.12, -0.08);
    addBox(group, 0.08, 0.24, 0.08, matWoodDark, sx, 0.12, 0.08);
  }
}

function addHaystack(x, z, scale) {
  const group = new THREE.Group();
  group.position.set(x, terrainHeight(x, z) + 0.04, z);
  group.rotation.y = rand(-0.3, 0.3);
  world.add(group);
  const base = new THREE.Mesh(new THREE.ConeGeometry(0.8 * scale, 1.5 * scale, 12, 1), matThatchDark);
  base.position.y = 0.75 * scale;
  base.castShadow = true;
  base.receiveShadow = true;
  group.add(base);
  const top = new THREE.Mesh(new THREE.ConeGeometry(0.48 * scale, 0.65 * scale, 10), matThatch);
  top.position.y = 1.5 * scale;
  top.castShadow = true;
  group.add(top);
  const pole = addCylinder(group, 0.025, 0.03, 0.9, matWoodDark, 0, 1.65 * scale, 0, 4, true, true);
  pole.rotation.z = 0.12;
}

addPumpkinPatch();
addCornPatch();
addDryingTrays();
addBench(5.12, 1.24, -0.35);
addBench(2.28, 0.98, 1.5);

for (const [x, z, scale, color] of [
  [1.98, 1.44, 0.95, 0x607678],
  [2.24, 1.34, 0.7, 0x75554a],
  [4.25, 0.85, 0.78, 0x4f696b],
]) {
  const jar = makeJar(scale, color);
  jar.position.set(x, 0.34, z);
  world.add(jar);
}

addHaystack(-0.4, -2.5, 0.9);
addHaystack(-5.55, -0.8, 0.62);

/* --------------------------------------------------------------------------
   Bridge
   -------------------------------------------------------------------------- */

const bridgeGroup = new THREE.Group();
world.add(bridgeGroup);
const bridgeInfo = (() => {
  const t = 0.85;
  const p = riverCurve.getPointAt(t);
  const tangent = riverCurve.getTangentAt(t).normalize();
  const normal = V3(-tangent.z, 0, tangent.x).normalize();
  const eastNormal = normal.clone().multiplyScalar(-1);
  const yaw = Math.atan2(-eastNormal.z, eastNormal.x);
  bridgeGroup.position.set(p.x, 0, p.z);
  bridgeGroup.rotation.y = yaw;

  const deckLength = riverWidthAt(p.x, p.z) + 2.35;
  const deckWidth = 1.65;
  const deckBase = WATER_Y + 0.22;
  const plankCount = 21;
  const rngBridge = mulberry32(1500);

  // A soft painted shadow sits on the water so the bridge feels grounded.
  // The water uses a custom shader and does not receive the real shadow map.
  const bridgeShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(1, 1),
    new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
      toneMapped: false,
    }),
  );
  bridgeShadow.rotation.x = -Math.PI / 2;
  bridgeShadow.position.set(0, WATER_Y + 0.006, 0);
  bridgeShadow.scale.set(deckLength * 0.72, deckWidth * 1.5, 1);
  bridgeShadow.renderOrder = 3;
  bridgeGroup.add(bridgeShadow);
  for (let i = 0; i < plankCount; i += 1) {
    const u = (i + 0.5) / plankCount;
    const x = (u - 0.5) * deckLength;
    const arch = 0.17 * (1 - Math.pow((u - 0.5) * 2, 2));
    const slope = -0.34 * ((u - 0.5) * 2) * 0.35;
    const plank = addBox(
      bridgeGroup,
      0.145,
      0.062,
      deckWidth + (rngBridge() - 0.5) * 0.09,
      i % 4 === 0 ? matWoodLight : matWood,
      x,
      deckBase + arch,
      (rngBridge() - 0.5) * 0.025,
    );
    plank.rotation.z = slope;
    plank.rotation.y = (rngBridge() - 0.5) * 0.008;
    if (i % 4 === 0) plank.material = matWoodLight;
  }

  // Stringers under the deck.
  for (const side of [-1, 1]) {
    for (let i = 0; i < 4; i += 1) {
      const x0 = -deckLength / 2 + (i / 4) * deckLength;
      const x1 = -deckLength / 2 + ((i + 1) / 4) * deckLength;
      const y0 = deckBase + 0.12 - 0.22;
      const y1 = deckBase + 0.12 + 0.17 * (1 - Math.pow(((i + 1) / 4 - 0.5) * 2, 2)) - 0.22;
      addBeam(
        bridgeGroup,
        V3(x0, y0, side * deckWidth * 0.34),
        V3(x1, y1, side * deckWidth * 0.34),
        0.12,
        matWoodDark,
      );
    }
  }

  // A pair of low steps on each bank make the bridge feel walkable.
  for (const side of [-1, 1]) {
    addBox(
      bridgeGroup,
      0.38,
      0.13,
      deckWidth * 0.9,
      matWood,
      side * (deckLength / 2 + 0.18),
      deckBase - 0.07,
      0,
    );
    addBox(
      bridgeGroup,
      0.34,
      0.11,
      deckWidth * 0.78,
      matStoneWarm,
      side * (deckLength / 2 + 0.36),
      deckBase - 0.19,
      0,
    );
  }

  // Small, low abutment stones tucked beneath the deck ends. They should not
  // read as boulders or block the path.
  for (const side of [-1, 1]) {
    const geo = new THREE.DodecahedronGeometry(0.24, 0);
    for (let i = 0; i < 3; i += 1) {
      const rock = new THREE.Mesh(geo, matStoneWarm);
      rock.position.set(
        side * (deckLength / 2 + 0.05 + rand(0, 0.12)),
        deckBase - 0.23 + rand(-0.02, 0.02),
        (i - 1) * 0.47,
      );
      rock.scale.set(0.85 + rand(0, 0.35), 0.5 + rand(0, 0.15), 0.9 + rand(0, 0.4));
      rock.rotation.set(rand(0, 1), rand(0, 3), rand(0, 1));
      rock.castShadow = true;
      rock.receiveShadow = true;
      bridgeGroup.add(rock);
    }
  }

  // Railings: modest, hand-built and not symmetrical.
  for (const side of [-1, 1]) {
    const zRail = side * (deckWidth / 2 + 0.04);
    for (const u of [-0.42, -0.14, 0.14, 0.42]) {
      const x = u * deckLength;
      const arch = 0.17 * (1 - Math.pow(u * 2, 2));
      const post = addBox(bridgeGroup, 0.09, 0.74, 0.09, matWoodDark, x, deckBase + arch + 0.38, zRail);
      post.rotation.z = -0.02;
    }
    for (let i = 0; i < 4; i += 1) {
      const u0 = -0.46 + i * 0.23;
      const u1 = -0.46 + (i + 1) * 0.23;
      const arch0 = 0.17 * (1 - Math.pow(u0 * 2, 2));
      const arch1 = 0.17 * (1 - Math.pow(u1 * 2, 2));
      addBeam(
        bridgeGroup,
        V3(u0 * deckLength, deckBase + arch0 + 0.69, zRail),
        V3(u1 * deckLength, deckBase + arch1 + 0.69, zRail),
        0.065,
        matWood,
      );
      addBeam(
        bridgeGroup,
        V3(u0 * deckLength, deckBase + arch0 + 0.4, zRail),
        V3(u1 * deckLength, deckBase + arch1 + 0.4, zRail),
        0.045,
        matWood,
        false,
        false,
      );
    }
  }

  // Rope-ish ends and small post caps.
  for (const side of [-1, 1]) {
    for (const u of [-0.46, 0.46]) {
      const x = u * deckLength;
      addBox(bridgeGroup, 0.13, 0.06, 0.13, matWoodDark, x, deckBase + 0.11, side * (deckWidth / 2 + 0.04));
    }
  }

  bridgeGroup.updateMatrixWorld(true);
  const eastEnd = bridgeGroup.localToWorld(V3(deckLength / 2 + 0.18, 0, 0));
  const westEnd = bridgeGroup.localToWorld(V3(-deckLength / 2 - 0.18, 0, 0));
  return { p, yaw, deckLength, deckWidth, deckBase, eastEnd, westEnd };
})();

/* --------------------------------------------------------------------------
   Trees: branching trunks, real leaf-shaped instanced foliage
   -------------------------------------------------------------------------- */

const branchInstances = [];
const leafInstances = [];
const shrubLeafInstances = [];

function makeMapleLeafGeometry() {
  const points = [
    [0, -0.58],
    [-0.07, -0.28],
    [-0.25, -0.22],
    [-0.63, -0.31],
    [-0.34, -0.01],
    [-0.69, 0.18],
    [-0.31, 0.18],
    [-0.37, 0.49],
    [-0.10, 0.30],
    [0, 0.83],
    [0.10, 0.30],
    [0.37, 0.49],
    [0.31, 0.18],
    [0.69, 0.18],
    [0.34, -0.01],
    [0.63, -0.31],
    [0.25, -0.22],
    [0.07, -0.28],
  ];
  const shape = new THREE.Shape();
  shape.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i += 1) {
    shape.lineTo(points[i][0], points[i][1]);
  }
  shape.closePath();
  const geometry = new THREE.ShapeGeometry(shape, 1);
  const position = geometry.attributes.position;
  for (let i = 0; i < position.count; i += 1) {
    const x = position.getX(i);
    const y = position.getY(i);
    position.setZ(i, Math.abs(x) * 0.08 - y * 0.022);
  }
  geometry.computeVertexNormals();
  return geometry;
}

const mapleLeafGeometry = makeMapleLeafGeometry();

const MAPLE_PALETTES = {
  crimson: ['#9e2c1c', '#b43a21', '#8a271c', '#c34a26', '#d05b28', '#a62f1f', '#d97829', '#b74b22'],
  ember: ['#b73b1e', '#cf5223', '#df6a27', '#e2862f', '#c44821', '#a93820', '#ef9b39'],
  amber: ['#c85123', '#db6c25', '#e7812b', '#efa643', '#d36425', '#bd4b20', '#f2b34c'],
};

function branchBetween(parentless, start, end, radiusStart, radiusEnd, color) {
  const direction = new THREE.Vector3().subVectors(end, start);
  const length = direction.length();
  if (length < 0.002) return;
  const quaternion = new THREE.Quaternion().setFromUnitVectors(V3(0, 1, 0), direction.clone().normalize());
  branchInstances.push({
    x: (start.x + end.x) * 0.5,
    y: (start.y + end.y) * 0.5,
    z: (start.z + end.z) * 0.5,
    quaternion,
    radius: radiusStart,
    length,
    color,
  });
}

function addLeafAt(x, y, z, quaternion, scale, colorHex) {
  leafInstances.push({ x, y, z, quaternion, scale, color: colorHex });
}

const leafQuat = new THREE.Quaternion();
const leafEuler = new THREE.Euler();

function randomLeafQuaternion(rngLeaf) {
  leafEuler.set(
    (rngLeaf() - 0.5) * Math.PI * 1.2,
    rngLeaf() * Math.PI * 2,
    (rngLeaf() - 0.5) * Math.PI * 1.2,
    'YXZ',
  );
  return new THREE.Quaternion().setFromEuler(leafEuler);
}

function addLeafCluster(center, radius, count, leafScale, palette, rngLeaf) {
  for (let i = 0; i < count; i += 1) {
    const theta = rngLeaf() * Math.PI * 2;
    const phi = Math.acos(2 * rngLeaf() - 1);
    const r = radius * Math.cbrt(rngLeaf());
    const x = center.x + Math.sin(phi) * Math.cos(theta) * r;
    const y = center.y + Math.cos(phi) * r * 0.85;
    const z = center.z + Math.sin(phi) * Math.sin(theta) * r;
    const scale = leafScale * (0.76 + rngLeaf() * 0.48);
    const color = palette[Math.floor(rngLeaf() * palette.length)];
    addLeafAt(x, y, z, randomLeafQuaternion(rngLeaf), scale, color);
  }
}

function createMapleTree(spec) {
  const localRng = mulberry32(spec.seed);
  const base = V3(spec.x, terrainHeight(spec.x, spec.z) + 0.015, spec.z);
  const scale = spec.scale;
  const trunkHeight = spec.height * 0.34;
  const trunkPoints = [base.clone()];
  for (let i = 1; i <= 4; i += 1) {
    const t = i / 4;
    const p = base.clone();
    p.x += Math.sin(t * 2.4 + spec.seed * 0.04) * 0.18 * scale + t * spec.leanX * scale;
    p.z += Math.cos(t * 1.7 + spec.seed * 0.07) * 0.12 * scale + t * spec.leanZ * scale;
    p.y += t * trunkHeight;
    trunkPoints.push(p);
  }

  // surface roots
  for (let i = 0; i < 5; i += 1) {
    const angle = (i / 5) * Math.PI * 2 + localRng() * 0.45;
    const end = base.clone().add(V3(Math.cos(angle) * (0.52 + localRng() * 0.4) * scale, -0.05, Math.sin(angle) * (0.52 + localRng() * 0.4) * scale));
    branchBetween(null, base.clone().add(V3(0, 0.48 * scale, 0)), end, 0.11 * scale, 0.035 * scale, '#4c3424');
  }

  for (let i = 0; i < trunkPoints.length - 1; i += 1) {
    const r0 = lerp(0.31, 0.17, i / (trunkPoints.length - 1)) * scale;
    const r1 = lerp(0.31, 0.17, (i + 1) / (trunkPoints.length - 1)) * scale;
    branchBetween(null, trunkPoints[i], trunkPoints[i + 1], r0, r1, '#5c3d29');
  }

  const terminals = [];
  const maxDepth = 3;

  function grow(start, direction, length, radius, depth) {
    let p = start.clone();
    let dir = direction.clone().normalize();
    const steps = depth === 0 ? 3 : 2;
    let currentRadius = radius;
    for (let s = 0; s < steps; s += 1) {
      dir.x += (localRng() - 0.5) * 0.24;
      dir.z += (localRng() - 0.5) * 0.24;
      dir.y += (localRng() - 0.5) * 0.11 + 0.015;
      dir.normalize();
      const segLength = length / steps;
      const next = p.clone().addScaledVector(dir, segLength);
      const nextRadius = currentRadius * 0.77;
      branchBetween(null, p, next, currentRadius, nextRadius, depth < 2 ? '#60412b' : '#6b4b33');
      p = next;
      currentRadius = nextRadius;
    }

    if (depth >= maxDepth) {
      terminals.push({ pos: p.clone(), radius: currentRadius, depth });
      return;
    }

    const childCount = depth === 0 ? 3 : localRng() > 0.56 ? 3 : 2;
    const up = V3(0, 1, 0);
    const arbitrary = Math.abs(dir.dot(up)) > 0.92 ? V3(1, 0, 0) : up;
    const u = new THREE.Vector3().crossVectors(dir, arbitrary).normalize();
    const v = new THREE.Vector3().crossVectors(dir, u).normalize();
    for (let c = 0; c < childCount; c += 1) {
      const angle = (c / childCount) * Math.PI * 2 + localRng() * 0.65;
      const outward = u.clone().multiplyScalar(Math.cos(angle)).add(v.clone().multiplyScalar(Math.sin(angle)));
      const childDir = dir.clone().multiplyScalar(0.46).add(outward.multiplyScalar(0.86)).add(V3(0, 0.28, 0)).normalize();
      grow(
        p,
        childDir,
        length * (0.58 + localRng() * 0.12),
        currentRadius * (0.7 + localRng() * 0.1),
        depth + 1,
      );
    }
  }

  // Four main limbs, each with a slightly different reach.
  const limbCount = 4;
  for (let i = 0; i < limbCount; i += 1) {
    const angle = (i / limbCount) * Math.PI * 2 + 0.45 + localRng() * 0.35;
    const start = trunkPoints[2].clone().lerp(trunkPoints[3], localRng() * 0.5);
    const reach = 0.72 + localRng() * 0.25;
    const upward = 0.72 + localRng() * 0.3;
    const dir = V3(Math.cos(angle) * reach, upward, Math.sin(angle) * reach).normalize();
    grow(start, dir, spec.height * (0.34 + localRng() * 0.06), 0.16 * scale, 0);
  }
  // A central leader gives the silhouette a crown instead of a lollipop.
  grow(trunkPoints[3], V3(0.08, 1, -0.03), spec.height * 0.31, 0.14 * scale, 0);

  const palette = MAPLE_PALETTES[spec.palette];
  const crownCenter = base.clone().add(V3(0, trunkHeight + spec.height * 0.26, 0));
  const terminalLeaves = Math.max(12, Math.round(spec.leaves / Math.max(1, terminals.length)));

  for (const terminal of terminals) {
    const clusterRadius = 0.42 * scale + (1 - terminal.depth / maxDepth) * 0.18;
    addLeafCluster(
      terminal.pos,
      clusterRadius,
      terminalLeaves,
      spec.leafSize,
      palette,
      localRng,
    );
  }

  // Fill the middle of the crown with airy sprays so the silhouette is not hollow.
  const fillCount = Math.max(10, Math.round(spec.leaves * 0.16 / 8));
  for (let i = 0; i < fillCount; i += 1) {
    const p = crownCenter.clone().add(
      V3(
        (localRng() - 0.5) * spec.crown * 1.55,
        (localRng() - 0.25) * spec.height * 0.28,
        (localRng() - 0.5) * spec.crown * 1.55,
      ),
    );
    addLeafCluster(p, 0.45 * scale, 7, spec.leafSize * 0.94, palette, localRng);
  }

  // A scattering of fallen leaves around the trunk.
  for (let i = 0; i < 42; i += 1) {
    const angle = localRng() * Math.PI * 2;
    const radius = 0.35 + localRng() * 2.2 * scale;
    const x = spec.x + Math.cos(angle) * radius;
    const z = spec.z + Math.sin(angle) * radius;
    if (isInsideAnyField(x, z, 0.08)) continue;
    const y = terrainHeight(x, z) + 0.025;
    leafEuler.set(-Math.PI / 2 + (localRng() - 0.5) * 0.3, localRng() * Math.PI * 2, (localRng() - 0.5) * 0.25, 'YXZ');
    fallenLeafInstances.push({
      x, y, z,
      quaternion: new THREE.Quaternion().setFromEuler(leafEuler),
      scale: spec.leafSize * (0.48 + localRng() * 0.22),
      color: palette[Math.floor(localRng() * palette.length)],
    });
  }

  // Root mound.
  const mound = new THREE.Mesh(
    new THREE.CylinderGeometry(0.55 * scale, 0.72 * scale, 0.16, 12),
    toon(0x6c5534),
  );
  mound.position.set(spec.x, terrainHeight(spec.x, spec.z) + 0.005, spec.z);
  mound.receiveShadow = true;
  world.add(mound);

  return terminals.length;
}

const TREE_SPECS = [
  {
    x: 7.05, z: 4.48, scale: 1.09, height: 5.9, crown: 2.95, seed: 2401,
    leaves: 2480, leafSize: 0.245, palette: 'crimson', leanX: -0.2, leanZ: -0.12,
  },
  {
    x: 6.86, z: -2.56, scale: 0.86, height: 4.5, crown: 2.3, seed: 2402,
    leaves: 1540, leafSize: 0.225, palette: 'ember', leanX: -0.22, leanZ: 0.13,
  },
  {
    x: -7.7, z: 7.12, scale: 0.36, height: 2.25, crown: 1.15, seed: 2403,
    leaves: 280, leafSize: 0.17, palette: 'amber', leanX: 0.1, leanZ: -0.08,
  },
  {
    x: -6.86, z: -3.04, scale: 0.68, height: 3.55, crown: 1.85, seed: 2404,
    leaves: 930, leafSize: 0.205, palette: 'crimson', leanX: 0.18, leanZ: 0.2,
  },
  {
    x: 2.62, z: -7.1, scale: 0.5, height: 2.8, crown: 1.5, seed: 2405,
    leaves: 540, leafSize: 0.185, palette: 'ember', leanX: -0.14, leanZ: 0.07,
  },
];

const treeTerminals = [];
for (const spec of TREE_SPECS) {
  treeTerminals.push(createMapleTree(spec));
}

function addShrub(x, z, scale, paletteName, leafCount, seed) {
  const localRng = mulberry32(seed);
  const baseY = terrainHeight(x, z) + 0.01;
  const palette = MAPLE_PALETTES[paletteName];
  for (let s = 0; s < 4; s += 1) {
    const angle = (s / 4) * Math.PI * 2 + localRng();
    const p0 = V3(x, baseY, z);
    const p1 = V3(x + Math.cos(angle) * 0.28 * scale, baseY + 0.38 * scale, z + Math.sin(angle) * 0.28 * scale);
    const p2 = V3(p1.x + Math.cos(angle) * 0.2 * scale, baseY + 0.7 * scale, p1.z + Math.sin(angle) * 0.2 * scale);
    branchBetween(null, p0, p1, 0.03 * scale, 0.022 * scale, '#5d4029');
    branchBetween(null, p1, p2, 0.022 * scale, 0.01 * scale, '#6a4c33');
  }
  for (let i = 0; i < leafCount; i += 1) {
    const angle = localRng() * Math.PI * 2;
    const radius = Math.sqrt(localRng()) * 0.66 * scale;
    const y = baseY + 0.18 * scale + localRng() * 0.78 * scale;
    const color = palette[Math.floor(localRng() * palette.length)];
    leafEuler.set(
      (localRng() - 0.5) * Math.PI,
      localRng() * Math.PI * 2,
      (localRng() - 0.5) * Math.PI,
      'YXZ',
    );
    shrubLeafInstances.push({
      x: x + Math.cos(angle) * radius,
      y,
      z: z + Math.sin(angle) * radius,
      quaternion: new THREE.Quaternion().setFromEuler(leafEuler),
      scale: 0.24 * (0.7 + localRng() * 0.6),
      color,
    });
  }
}

addShrub(6.1, 2.55, 1.0, 'amber', 120, 3001);
addShrub(1.72, 2.28, 0.8, 'ember', 88, 3002);
addShrub(6.7, 5.55, 1.1, 'crimson', 110, 3003);
addShrub(-0.4, 6.62, 0.85, 'amber', 76, 3004);
addShrub(-2.1, -2.82, 0.9, 'crimson', 85, 3005);
addShrub(4.8, -3.25, 0.8, 'ember', 70, 3006);

/* --------------------------------------------------------------------------
   Ground-leaf carpet
   A dense layer of separate maple leaves covers the banks, the courtyard and
   the ground under the maples. It is one InstancedMesh, so the density is cheap.
   -------------------------------------------------------------------------- */

const GROUND_LEAF_COLORS = [
  '#a32c1b', '#b93b20', '#ca4e23', '#d96327', '#e57c2a',
  '#ec9636', '#f0b347', '#c84421', '#933025', '#d9a144',
];

function addGroundLeaf(x, z, scale, rngLeaf, colorHex = null, surfaceY = null) {
  if (Math.abs(x) > 8.12 || Math.abs(z) > 8.12) return false;
  const waterDistance = distanceToWater(x, z);
  if (waterDistance < waterWidthNear(x, z) * 0.5 + 0.055) return false;
  let y = surfaceY;
  if (y == null) {
    const onPad = x > 0.75 && x < 6.62 && z > -1.02 && z < 3.1;
    y = onPad ? 0.283 : terrainHeight(x, z) + 0.032;
  }
  leafEuler.set(
    -Math.PI / 2 + (rngLeaf() - 0.5) * 0.22,
    rngLeaf() * Math.PI * 2,
    (rngLeaf() - 0.5) * 0.18,
    'YXZ',
  );
  fallenLeafInstances.push({
    x,
    y: y + rngLeaf() * 0.015,
    z,
    quaternion: new THREE.Quaternion().setFromEuler(leafEuler),
    scale: scale * (0.82 + rngLeaf() * 0.36),
    color: colorHex || GROUND_LEAF_COLORS[Math.floor(rngLeaf() * GROUND_LEAF_COLORS.length)],
  });
  return true;
}

function scatterGroundLeaves() {
  const leafRng = mulberry32(9601);

  // Thick rings beneath every maple canopy.
  for (const tree of TREE_SPECS) {
    const count = Math.round(310 + tree.scale * 235);
    const radius = tree.crown * (1.35 + tree.scale * 0.28);
    for (let i = 0; i < count; i += 1) {
      const angle = leafRng() * Math.PI * 2;
      const distance = Math.sqrt(leafRng()) * radius;
      const x = tree.x + Math.cos(angle) * distance;
      const z = tree.z + Math.sin(angle) * distance;
      if (isInsideAnyField(x, z, 0.05)) continue;
      addGroundLeaf(x, z, 0.105 + leafRng() * 0.145, leafRng);
    }
  }

  // A heavy litter line along both banks, following the extended water.
  for (let i = 0; i < 1650; i += 1) {
    const sample = waterSamples[Math.floor(leafRng() * waterSamples.length)];
    const side = leafRng() > 0.5 ? 1 : -1;
    const offset = sample.width * 0.5 + 0.1 + leafRng() * 0.92;
    const x = sample.p.x + sample.normal.x * offset * side + (leafRng() - 0.5) * 0.18;
    const z = sample.p.z + sample.normal.z * offset * side + (leafRng() - 0.5) * 0.18;
    addGroundLeaf(x, z, 0.09 + leafRng() * 0.13, leafRng);
  }

  // Courtyard and the open strip in front of the fence.
  for (let i = 0; i < 760; i += 1) {
    const x = 0.95 + leafRng() * 5.85;
    const z = 0.65 + leafRng() * 3.05;
    if (x > 1.0 && x < 6.4 && z < 2.95) {
      addGroundLeaf(x, z, 0.095 + leafRng() * 0.13, leafRng, null, 0.286);
    } else {
      addGroundLeaf(x, z, 0.095 + leafRng() * 0.13, leafRng);
    }
  }
  for (let i = 0; i < 360; i += 1) {
    const x = 0.9 + leafRng() * 5.9;
    const z = 1.45 + leafRng() * 6.1;
    addGroundLeaf(x, z, 0.085 + leafRng() * 0.14, leafRng);
  }

  // Scattered litter through the continuous field gaps and around the rim.
  for (let i = 0; i < 1450; i += 1) {
    const x = (leafRng() - 0.5) * 15.8;
    const z = (leafRng() - 0.5) * 15.8;
    if (!isInContinuousField(x, z)) continue;
    if (isInsideAnyField(x, z, 0.03)) continue;
    addGroundLeaf(x, z, 0.075 + leafRng() * 0.12, leafRng, null, terrainHeight(x, z) + 0.066);
  }
  for (let i = 0; i < 480; i += 1) {
    const x = (leafRng() - 0.5) * 15.7;
    const z = (leafRng() - 0.5) * 15.7;
    addGroundLeaf(x, z, 0.08 + leafRng() * 0.13, leafRng);
  }

  // Concentrated wind-drifts read as actual leaf piles.
  const driftSpots = [
    [-7.7, 2.3, 0.5], [-5.45, 6.2, 0.58], [1.15, 2.7, 0.48],
    [6.35, 2.6, 0.42], [5.5, -2.7, 0.5], [-1.9, -2.7, 0.44],
    [3.55, 4.65, 0.4], [7.0, 0.8, 0.45], [-3.7, -0.8, 0.4],
    [0.7, 4.55, 0.32],
  ];
  for (const [cx, cz, spread] of driftSpots) {
    for (let i = 0; i < 52; i += 1) {
      const angle = (i / 52) * Math.PI * 2 + leafRng() * 0.35;
      const r = Math.sqrt(leafRng()) * spread;
      addGroundLeaf(
        cx + Math.cos(angle) * r,
        cz + Math.sin(angle) * r,
        0.095 + leafRng() * 0.13,
        leafRng,
      );
    }
  }

  // The hero maple and the open grass by the bridge deserve a genuinely thick
  // carpet, not just isolated flecks.
  for (let i = 0; i < 1450; i += 1) {
    const angle = leafRng() * Math.PI * 2;
    const distance = Math.sqrt(leafRng()) * 4.7;
    const x = 7.05 + Math.cos(angle) * distance;
    const z = 4.48 + Math.sin(angle) * distance;
    addGroundLeaf(x, z, 0.11 + leafRng() * 0.15, leafRng);
  }
  for (let i = 0; i < 760; i += 1) {
    const x = 1.9 + leafRng() * 6.1;
    const z = 2.7 + leafRng() * 4.6;
    addGroundLeaf(x, z, 0.105 + leafRng() * 0.14, leafRng);
  }

  // A broad, low-density scatter fills remaining grass gaps so no single area
  // reads as a bare green panel.
  for (let i = 0; i < 2600; i += 1) {
    const x = (leafRng() - 0.5) * 16.0;
    const z = (leafRng() - 0.5) * 16.0;
    if (isInsideAnyField(x, z, 0.02)) continue;
    const surface = isInContinuousField(x, z) ? terrainHeight(x, z) + 0.066 : null;
    addGroundLeaf(x, z, 0.08 + leafRng() * 0.12, leafRng, null, surface);
  }
}

scatterGroundLeaves();

function buildBranchGeometry() {
  if (!branchInstances.length) return;
  const geometry = new THREE.CylinderGeometry(0.64, 1, 1, 6, 1, false);
  const mesh = new THREE.InstancedMesh(geometry, matBark, branchInstances.length);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  const palette = ['#8f7054', '#6f543d', '#9b7b5f', '#7e6148', '#b19272'];
  branchInstances.forEach((branch, i) => {
    dummy.position.set(branch.x, branch.y, branch.z);
    dummy.quaternion.copy(branch.quaternion);
    dummy.scale.set(branch.radius, branch.length, branch.radius);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    mesh.setColorAt(i, color.set(palette[i % palette.length]));
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  mesh.computeBoundingSphere?.();
  world.add(mesh);
}
buildBranchGeometry();

function buildLeafInstances(entries, material, castShadow) {
  if (!entries.length) return null;
  const mesh = new THREE.InstancedMesh(mapleLeafGeometry, material, entries.length);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  entries.forEach((leaf, i) => {
    dummy.position.set(leaf.x, leaf.y, leaf.z);
    dummy.quaternion.copy(leaf.quaternion);
    dummy.scale.setScalar(leaf.scale);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    mesh.setColorAt(i, color.set(leaf.color));
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = castShadow;
  mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  mesh.computeBoundingSphere?.();
  world.add(mesh);
  return mesh;
}

const leafMesh = buildLeafInstances(leafInstances, matLeafBase, true);
buildLeafInstances(shrubLeafInstances, matLeafBase, true);
buildLeafInstances(fallenLeafInstances, matLeafBase, false);

/* --------------------------------------------------------------------------
   Grass tufts and reeds
   -------------------------------------------------------------------------- */

function makeGrassGeometry() {
  const localRng = mulberry32(441);
  const positions = [];
  const colors = [];
  const indices = [];
  const blades = 8;
  const dark = C(0x53642f);
  const light = C(0xcdb35b);
  for (let i = 0; i < blades; i += 1) {
    const angle = localRng() * Math.PI * 2;
    const baseRadius = localRng() * 0.08;
    const height = 0.16 + localRng() * 0.28;
    const width = 0.012 + localRng() * 0.01;
    const lean = (localRng() - 0.5) * 0.22;
    const x0 = Math.cos(angle) * baseRadius;
    const z0 = Math.sin(angle) * baseRadius;
    const dx = Math.cos(angle) * width;
    const dz = Math.sin(angle) * width;
    const base = positions.length / 3;
    positions.push(x0 - dx, 0, z0 - dz, x0 + dx, 0, z0 + dz, x0 + lean, height, z0 + lean * 0.4);
    const c = dark.clone().lerp(light, 0.2 + localRng() * 0.55);
    colors.push(dark.r, dark.g, dark.b, dark.r, dark.g, dark.b, c.r, c.g, c.b);
    indices.push(base, base + 1, base + 2);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

const grassGeometry = makeGrassGeometry();

function addGrassTuft(x, y, z, scale, localRng) {
  grassInstances.push({
    x, y, z,
    ry: localRng() * Math.PI * 2,
    sx: scale,
    sy: scale * (0.8 + localRng() * 0.45),
    sz: scale,
    color: choose(['#8a934d', '#a59c54', '#b5a35c', '#7b8a4b', '#c1a958']),
  });
}

// A soft fringe along the base edge and around field borders.
const grassRng = mulberry32(3301);
for (let i = 0; i < 150; i += 1) {
  const side = Math.floor(grassRng() * 4);
  const offset = 7.75 + grassRng() * 0.55;
  let x;
  let z;
  if (side === 0) { x = (grassRng() - 0.5) * 15.6; z = -offset; }
  else if (side === 1) { x = (grassRng() - 0.5) * 15.6; z = offset; }
  else if (side === 2) { x = -offset; z = (grassRng() - 0.5) * 15.6; }
  else { x = offset; z = (grassRng() - 0.5) * 15.6; }
  addGrassTuft(x, terrainHeight(x, z) + 0.01, z, 0.55 + grassRng() * 0.75, grassRng);
}
for (const plot of FIELD_PLOTS) {
  for (let i = 0; i < 12; i += 1) {
    const angle = grassRng() * Math.PI;
    const side = grassRng() > 0.5 ? 1 : -1;
    const localX = side * (plot.wid / 2 + 0.2 + grassRng() * 0.5);
    const localZ = (grassRng() - 0.5) * (plot.len + 0.4);
    const cos = Math.cos(plot.rot);
    const sin = Math.sin(plot.rot);
    const x = plot.cx + localX * cos + localZ * sin;
    const z = plot.cz - localX * sin + localZ * cos;
    addGrassTuft(x, terrainHeight(x, z) + 0.015, z, 0.5 + grassRng() * 0.8, grassRng);
  }
}
for (let i = 0; i < 80; i += 1) {
  const sample = riverSamples[Math.floor(grassRng() * (riverSamples.length - 1))];
  const side = grassRng() > 0.5 ? 1 : -1;
  const offset = sample.width / 2 + 0.12 + grassRng() * 0.7;
  const x = sample.p.x + sample.normal.x * offset * side;
  const z = sample.p.z + sample.normal.z * offset * side;
  addGrassTuft(x, terrainHeight(x, z) + 0.015, z, 0.5 + grassRng() * 0.7, grassRng);
}

function buildGrassInstances() {
  if (!grassInstances.length) return;
  const mesh = new THREE.InstancedMesh(grassGeometry, matGrass, grassInstances.length);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  grassInstances.forEach((item, i) => {
    dummy.position.set(item.x, item.y, item.z);
    dummy.rotation.y = item.ry;
    dummy.scale.set(item.sx, item.sy, item.sz);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    mesh.setColorAt(i, color.set(item.color));
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = false;
  mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  mesh.computeBoundingSphere?.();
  world.add(mesh);
}
buildGrassInstances();

/* --------------------------------------------------------------------------
   Thatched eave fringe conversion (local -> world)
   -------------------------------------------------------------------------- */

function buildThatchFringe() {
  if (!thatchFringeInstances.length) return;
  const geometry = new THREE.ConeGeometry(1, 1, 4);
  const material = toon(0x9c6f34);
  const mesh = new THREE.InstancedMesh(geometry, material, thatchFringeInstances.length);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  thatchFringeInstances.forEach((item, i) => {
    if (!item.parent) return;
    item.parent.updateWorldMatrix(true, false);
    const worldPos = item.parent.localToWorld(V3(item.x, item.y, item.z));
    dummy.position.copy(worldPos);
    dummy.rotation.set(item.rx, item.parent.rotation.y, item.rz);
    dummy.scale.set(item.sx, item.sy, item.sz);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    mesh.setColorAt(i, color.set(choose(['#bd8b43', '#d0a45b', '#a87634'])));
  });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = false;
  mesh.frustumCulled = false;
  world.add(mesh);
}
buildThatchFringe();

/* --------------------------------------------------------------------------
   Fence batchers + path stones (collected from courtyard/field builders)
   -------------------------------------------------------------------------- */

buildBoxInstances(world, fencePostInstances, matWood, true, true);
buildBoxInstances(world, fenceRailInstances, matWood, true, true);
buildPathStones();

/* --------------------------------------------------------------------------
   Farmers at work in the wheat
   -------------------------------------------------------------------------- */

function createFarmer(scale = 1) {
  const group = new THREE.Group();
  const skin = toon(0xc48c62);
  const shirt = toon(0x3e6173);
  const trousers = toon(0x3e4142);
  const straw = toon(0xd5ad68);
  const darkStraw = toon(0xb88643);

  // Legs planted in the field.
  for (const side of [-1, 1]) {
    const leg = addCylinder(group, 0.05, 0.06, 0.43, trousers, side * 0.095, 0.215, 0, 6);
    leg.rotation.z = side * 0.08;
    const foot = addBox(group, 0.12, 0.07, 0.2, toon(0x3b2a1d), side * 0.1, 0.055, 0.04);
    foot.rotation.x = 0.08;
  }

  const body = new THREE.Group();
  body.position.set(0, 0.45, 0);
  body.rotation.x = 0.82; // bent over the sheaves
  group.add(body);
  addCylinder(body, 0.13, 0.17, 0.55, shirt, 0, 0.27, 0, 7);
  addBox(body, 0.27, 0.46, 0.17, shirt, 0, 0.24, 0.02);
  addBox(body, 0.31, 0.075, 0.2, toon(0x9b3d26), 0, 0.04, 0.015, false, false);

  // Arms reaching down to the sickle.
  const armA = addCylinder(body, 0.035, 0.045, 0.46, skin, -0.14, 0.28, 0.02, 5);
  armA.rotation.z = -0.55;
  armA.rotation.x = 0.6;
  const armB = addCylinder(body, 0.035, 0.045, 0.42, skin, 0.13, 0.26, 0.08, 5);
  armB.rotation.z = 0.52;
  armB.rotation.x = 0.48;

  const head = new THREE.Group();
  head.position.set(0, 0.56, 0.025);
  body.add(head);
  addMesh(head, new THREE.SphereGeometry(0.11, 12, 8), skin, 0, 0, 0);
  const hat = new THREE.Mesh(new THREE.ConeGeometry(0.235, 0.115, 14), straw);
  hat.position.y = 0.105;
  hat.castShadow = true;
  head.add(hat);
  const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.02, 16), darkStraw);
  brim.position.y = 0.043;
  brim.castShadow = true;
  head.add(brim);

  // Sickle: a small curved hook of metal.
  const sickle = new THREE.Group();
  sickle.position.set(0.22, 0.07, 0.42);
  sickle.rotation.z = -0.35;
  body.add(sickle);
  addCylinder(sickle, 0.018, 0.02, 0.24, matWoodDark, 0, -0.04, 0, 5);
  const blade = new THREE.Mesh(
    new THREE.TorusGeometry(0.095, 0.009, 4, 12, Math.PI * 0.95),
    toon(0x7c827d, { emissive: 0x121310, emissiveIntensity: 0.18 }),
  );
  blade.rotation.set(0.7, 0.45, 0.8);
  sickle.add(blade);

  // A sheaf at the feet.
  const sheaf = new THREE.Group();
  sheaf.position.set(-0.34, 0.1, 0.18);
  sheaf.rotation.z = 0.24;
  group.add(sheaf);
  for (let i = 0; i < 7; i += 1) {
    const stalk = addCylinder(sheaf, 0.007, 0.009, 0.4, toon(0xbf913d), (i - 3) * 0.018, 0.2, 0, 3, false, false);
    stalk.rotation.z = (i - 3) * 0.055;
  }
  addBox(sheaf, 0.2, 0.04, 0.16, toon(0x9b6e30), 0, 0.24, 0);

  group.scale.setScalar(scale);
  return group;
}

const farmerA = createFarmer(1.3);
farmerA.position.set(-3.30, 0.33, 4.52);
farmerA.rotation.y = 1.04;
world.add(farmerA);

// A trampled patch and a little red sash make the nearest farmer readable
// against the dense gold stalks.
const trampled = new THREE.Mesh(
  new THREE.CylinderGeometry(0.6, 0.7, 0.026, 14),
  toon(0x8a612f),
);
trampled.position.set(-3.30, 0.305, 4.52);
trampled.receiveShadow = true;
world.add(trampled);


const farmerB = createFarmer(0.8);
farmerB.position.set(-0.25, 0.36, -5.15);
farmerB.rotation.y = -2.2;
world.add(farmerB);

function addHarvestSheaf(x, z, scale, rotation) {
  const group = new THREE.Group();
  group.position.set(x, terrainHeight(x, z) + 0.04, z);
  group.rotation.y = rotation;
  group.rotation.z = (rand(0, 1) - 0.5) * 0.14;
  world.add(group);
  const bundle = new THREE.Mesh(new THREE.ConeGeometry(0.29 * scale, 0.8 * scale, 9), matThatch);
  bundle.position.y = 0.4 * scale;
  bundle.castShadow = true;
  bundle.receiveShadow = true;
  group.add(bundle);
  const tie = new THREE.Mesh(new THREE.CylinderGeometry(0.125 * scale, 0.14 * scale, 0.08 * scale, 8), matWoodDark);
  tie.position.y = 0.34 * scale;
  tie.castShadow = true;
  group.add(tie);
}

addHarvestSheaf(-3.05, 5.86, 0.78, 0.6);
addHarvestSheaf(-2.86, 4.92, 0.66, -0.4);
addHarvestSheaf(-5.72, 4.4, 0.74, 1.1);
addHarvestSheaf(-0.1, -3.58, 0.7, 0.2);

/* --------------------------------------------------------------------------
   Two simple scarecrows
   -------------------------------------------------------------------------- */

function fieldSurfaceAt(x, z) {
  let y = terrainHeight(x, z) + 0.06;
  for (const plot of FIELD_PLOTS) {
    const local = plotLocal(x, z, plot);
    if (
      Math.abs(local.x) < plot.wid * 0.5 + 0.1
      && Math.abs(local.z) < plot.len * 0.5 + 0.1
    ) {
      y = Math.max(y, terrainHeight(plot.cx, plot.cz) + 0.075 + 0.1);
    }
  }
  return y;
}

function createScarecrow(options) {
  const {
    x, z, rotation = 0, lean = 0.055, scale = 1,
    coatColor = 0xc85a32, accentColor = 0x3f7f86,
    patchColor = 0xe0a13a, seed = 8100,
  } = options;
  const localRng = mulberry32(seed);
  const group = new THREE.Group();
  group.position.set(x, fieldSurfaceAt(x, z) + 0.008, z);
  group.rotation.y = rotation;
  group.rotation.z = lean;
  group.scale.setScalar(scale);
  world.add(group);

  const coatBase = new THREE.Color(coatColor);
  const coat = toon(coatColor, { emissive: coatColor, emissiveIntensity: 0.09 });
  const coatDark = toon(coatBase.clone().offsetHSL(0, -0.03, -0.17), {
    emissive: coatBase.clone().multiplyScalar(0.35),
    emissiveIntensity: 0.12,
  });
  const accent = toon(accentColor, { emissive: accentColor, emissiveIntensity: 0.08 });
  const burlap = toon(0xe4c48b, { emissive: 0x3a2812, emissiveIntensity: 0.12 });
  const straw = toon(0xf1d17d, { emissive: 0x3f2b0c, emissiveIntensity: 0.12 });
  const strawDark = toon(0xd5a84f, { emissive: 0x3d2808, emissiveIntensity: 0.1 });

  // Wooden spine and shoulder crossbar.
  addCylinder(group, 0.035, 0.052, 1.45, matWoodDark, 0, 0.725, 0, 6);
  addBox(group, 1.18, 0.072, 0.072, matWoodDark, 0, 1.12, 0);

  // Ragged coat, bright waist sash and pieced patches.
  addCylinder(group, 0.22, 0.31, 0.7, coat, 0, 0.92, 0, 7);
  addCylinder(group, 0.25, 0.27, 0.075, coatDark, 0, 0.71, 0, 7);
  addCylinder(group, 0.265, 0.285, 0.055, accent, 0, 0.74, 0, 7);
  addBox(group, 0.3, 0.2, 0.24, toon(patchColor, { emissive: patchColor, emissiveIntensity: 0.08 }), 0.1, 0.95, 0.02);
  addBox(group, 0.22, 0.16, 0.22, coatDark, -0.12, 0.84, -0.01);

  // Sleeves hanging from the crossbar.
  for (const side of [-1, 1]) {
    const sleeve = addBox(group, 0.34, 0.11, 0.16, coatDark, side * 0.44, 1.06, 0);
    sleeve.rotation.z = side * 0.34;
    const cuff = addCylinder(group, 0.022, 0.028, 0.2, accent, side * 0.62, 0.95, 0, 4, false, false);
    cuff.rotation.z = side * 0.42;
    const strawCuff = addCylinder(group, 0.018, 0.024, 0.2, strawDark, side * 0.64, 0.95, 0, 4, false, false);
    strawCuff.rotation.z = side * 0.42;
  }

  // Burlap head and button eyes.
  addMesh(group, new THREE.SphereGeometry(0.155, 12, 9), burlap, 0, 1.53, 0);
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x1b1812, toneMapped: false });
  for (const side of [-1, 1]) {
    addMesh(group, new THREE.SphereGeometry(0.018, 6, 5), eyeMat, side * 0.052, 1.56, 0.137, false, false);
  }
  addBox(group, 0.07, 0.012, 0.012, toon(0x4d2e20), 0, 1.49, 0.146, false, false);

  // Wide, brighter straw hat: brim plus shallow crown.
  const brim = addCylinder(group, 0.28, 0.28, 0.022, strawDark, 0, 1.67, 0, 16);
  brim.rotation.z = (localRng() - 0.5) * 0.06;
  addMesh(group, new THREE.ConeGeometry(0.235, 0.19, 13), straw, 0, 1.755, 0);

  // A few loose straw tufts make the silhouette read instantly as a scarecrow.
  for (let i = 0; i < 8; i += 1) {
    const angle = localRng() * Math.PI * 2;
    const tuft = addCylinder(
      group,
      0.006,
      0.012,
      0.13 + localRng() * 0.12,
      i % 2 ? straw : strawDark,
      Math.cos(angle) * (0.2 + localRng() * 0.16),
      0.7 + localRng() * 0.32,
      Math.sin(angle) * (0.16 + localRng() * 0.12),
      3,
      false,
      false,
    );
    tuft.rotation.z = (localRng() - 0.5) * 1.1;
    tuft.rotation.x = (localRng() - 0.5) * 0.8;
  }

  // Bright scarf at the neck, with one tail hanging down the chest.
  addCylinder(group, 0.16, 0.16, 0.085, accent, 0, 1.37, 0, 9);
  addBox(group, 0.075, 0.24, 0.045, accent, 0.07, 1.23, 0.12);
  return group;
}

createScarecrow({
  x: -5.72,
  z: 5.72,
  rotation: -0.5,
  lean: 0.065,
  scale: 1.0,
  coatColor: 0xc95c33,
  accentColor: 0x3f7f86,
  patchColor: 0xe5ad3f,
  seed: 8101,
});
createScarecrow({
  x: -1.62,
  z: -4.72,
  rotation: 2.45,
  lean: -0.055,
  scale: 1.06,
  coatColor: 0x3f7f86,
  accentColor: 0xcf5a32,
  patchColor: 0xe3a438,
  seed: 8102,
});

/* --------------------------------------------------------------------------
   Egrets / cranes
   -------------------------------------------------------------------------- */

const cranes = [];
function createCrane(scale, phase) {
  const group = new THREE.Group();
  const white = toon(0xf7f0de, { emissive: 0x6b5a3f, emissiveIntensity: 0.08 });
  const warmWhite = toon(0xfff6e4);
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 7), white);
  body.scale.set(0.9, 0.68, 2.2);
  body.castShadow = false;
  group.add(body);
  const neck = addCylinder(group, 0.028, 0.05, 0.48, warmWhite, 0, 0.03, 0.28, 5, false, false);
  neck.rotation.x = 0.84;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 6), warmWhite);
  head.position.set(0, 0.15, 0.55);
  group.add(head);
  const beak = new THREE.Mesh(new THREE.ConeGeometry(0.027, 0.18, 5), toon(0xd0a147));
  beak.position.set(0, 0.14, 0.67);
  beak.rotation.x = Math.PI / 2;
  group.add(beak);
  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.3, 5), white);
  tail.position.set(0, 0, -0.38);
  tail.rotation.x = -Math.PI / 2 - 0.15;
  group.add(tail);

  const wings = [];
  for (const side of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(side * 0.11, 0.02, 0.02);
    group.add(pivot);
    const shape = new THREE.Shape();
    shape.moveTo(0, -0.12);
    shape.lineTo(side * 0.58, 0.12);
    shape.lineTo(side * 0.87, -0.02);
    shape.lineTo(side * 0.33, -0.2);
    shape.closePath();
    const wingGeo = new THREE.ShapeGeometry(shape);
    wingGeo.rotateX(-Math.PI / 2);
    const wing = new THREE.Mesh(wingGeo, new THREE.MeshToonMaterial({
      color: 0xf8f1df,
      gradientMap: toonGradient,
      side: THREE.DoubleSide,
    }));
    wing.castShadow = false;
    pivot.add(wing);
    wings.push({ pivot, side });
  }

  group.scale.setScalar(scale);
  group.userData = { phase, wings };
  return group;
}

const craneOrbits = [
  { radius: 6.0, height: 6.9, phase: 2.55, speed: 0.048, scale: 0.78, centerX: 0, centerZ: -1.1 },
  { radius: 6.8, height: 7.15, phase: 3.15, speed: 0.045, scale: 0.84, centerX: 0, centerZ: -1.1 },
  { radius: 7.6, height: 7.4, phase: 3.9, speed: 0.041, scale: 0.9, centerX: 0, centerZ: -1.1 },
  { radius: 8.3, height: 7.65, phase: 4.8, speed: 0.037, scale: 0.45, centerX: 0, centerZ: -1.1 },
  { radius: 7.2, height: 7.5, phase: 5.6, speed: 0.043, scale: 0.5, centerX: 0, centerZ: -1.1 },
];
craneOrbits.forEach((orbit, i) => {
  const crane = createCrane(orbit.scale, i * 2.1);
  crane.name = `crane-${i}`;
  crane.rotation.order = 'YXZ';
  crane.userData.orbit = orbit;
  crane.userData.dynamic = true;
  world.add(crane);
  cranes.push(crane);
});

/* --------------------------------------------------------------------------
   Chimney smoke, dust motes, water leaves
   -------------------------------------------------------------------------- */

const smokeParticles = [];
function initSmoke() {
  const smokeRng = mulberry32(5001);
  for (const source of smokeSources) {
    source.parent.updateWorldMatrix(true, false);
    const origin = source.parent.localToWorld(source.local.clone());
    for (let i = 0; i < 12; i += 1) {
      const material = new THREE.SpriteMaterial({
        map: smokeTexture,
        color: 0xe4ded1,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        toneMapped: false,
      });
      const sprite = new THREE.Sprite(material);
      sprite.position.copy(origin);
      sprite.scale.setScalar(0.26);
      world.add(sprite);
      smokeParticles.push({
        sprite,
        origin,
        phase: i / 9 + smokeRng() * 0.08,
        speed: source.rate * (0.75 + smokeRng() * 0.6),
        drift: source.drift.clone(),
        size: 0.45 + smokeRng() * 0.35,
      });
    }
  }
}
initSmoke();

const moteCount = IS_SMALL ? 70 : 130;
const motePositions = new Float32Array(moteCount * 3);
const moteSeeds = new Float32Array(moteCount * 2);
const moteRng = mulberry32(5100);
for (let i = 0; i < moteCount; i += 1) {
  motePositions[i * 3] = (moteRng() - 0.5) * 15.1;
  motePositions[i * 3 + 1] = 0.3 + moteRng() * 4.1;
  motePositions[i * 3 + 2] = (moteRng() - 0.5) * 15.1;
  moteSeeds[i * 2] = moteRng() * Math.PI * 2;
  moteSeeds[i * 2 + 1] = 0.25 + moteRng() * 0.55;
}
const moteGeometry = new THREE.BufferGeometry();
moteGeometry.setAttribute('position', new THREE.BufferAttribute(motePositions, 3));
const moteMaterial = new THREE.PointsMaterial({
  size: IS_SMALL ? 0.045 : 0.055,
  map: glowTexture,
  color: 0xffd78f,
  transparent: true,
  opacity: 0.52,
  depthWrite: false,
  blending: THREE.AdditiveBlending,
  sizeAttenuation: true,
  toneMapped: false,
});
const motes = new THREE.Points(moteGeometry, moteMaterial);
motes.frustumCulled = false;
world.add(motes);

const waterLeafCount = 12;
const waterLeafMesh = new THREE.InstancedMesh(mapleLeafGeometry, matLeafBase, waterLeafCount);
waterLeafMesh.castShadow = false;
waterLeafMesh.receiveShadow = false;
waterLeafMesh.frustumCulled = false;
world.add(waterLeafMesh);
const waterLeaves = [];
const waterLeafRng = mulberry32(5200);
const waterLeafColors = ['#b73922', '#d16229', '#9d2b1d', '#df8a31'];
for (let i = 0; i < waterLeafCount; i += 1) {
  waterLeaves.push({
    t: waterLeafRng(),
    offset: (waterLeafRng() - 0.5) * 0.75,
    speed: 0.006 + waterLeafRng() * 0.005,
    rotation: waterLeafRng() * Math.PI * 2,
    spin: (waterLeafRng() - 0.5) * 0.9,
    scale: 0.055 + waterLeafRng() * 0.04,
    phase: waterLeafRng() * Math.PI * 2,
  });
  waterLeafMesh.setColorAt(i, new THREE.Color(waterLeafColors[i % waterLeafColors.length]));
}
if (waterLeafMesh.instanceColor) waterLeafMesh.instanceColor.needsUpdate = true;

// A handful of loose maple leaves drift down through the grove. They are
// deliberately sparse, just enough to make the still frame feel alive.
const fallingLeafCount = IS_SMALL ? 18 : 32;
const fallingLeafMesh = new THREE.InstancedMesh(mapleLeafGeometry, matLeafBase, fallingLeafCount);
fallingLeafMesh.castShadow = false;
fallingLeafMesh.receiveShadow = false;
fallingLeafMesh.frustumCulled = false;
fallingLeafMesh.renderOrder = 1;
world.add(fallingLeafMesh);
const fallDummy = new THREE.Object3D();
const fallLeaves = [];
const fallRng = mulberry32(5300);
const fallSources = TREE_SPECS.map((tree) => ({ x: tree.x, z: tree.z, crown: tree.crown }));
const fallColors = ['#b74422', '#d36a2a', '#e39433', '#982e1d', '#c95625', '#eda23d'];
for (let i = 0; i < fallingLeafCount; i += 1) {
  const source = fallSources[Math.floor(fallRng() * fallSources.length)];
  fallLeaves.push({
    x: source.x + (fallRng() - 0.5) * source.crown * 1.8,
    z: source.z + (fallRng() - 0.5) * source.crown * 1.8,
    y: 1.2 + fallRng() * 4.2,
    speed: 0.12 + fallRng() * 0.18,
    sway: 0.12 + fallRng() * 0.25,
    phase: fallRng() * Math.PI * 2,
    spin: (fallRng() - 0.5) * 1.4,
    spinSpeed: 0.35 + fallRng() * 0.7,
    scale: 0.095 + fallRng() * 0.075,
    color: fallColors[i % fallColors.length],
  });
  fallingLeafMesh.setColorAt(i, new THREE.Color(fallLeaves[i].color));
}
if (fallingLeafMesh.instanceColor) fallingLeafMesh.instanceColor.needsUpdate = true;

/* --------------------------------------------------------------------------
   Animation
   -------------------------------------------------------------------------- */

const dummy = new THREE.Object3D();

const floatingColor = new THREE.Color();

function updateSmoke(dt) {
  for (const particle of smokeParticles) {
    particle.phase += dt * particle.speed;
    if (particle.phase > 1) particle.phase -= 1;
    const t = particle.phase;
    const ease = t * t * (3 - 2 * t);
    particle.sprite.position.set(
      particle.origin.x + particle.drift.x * ease * 2.6 + Math.sin(t * 9 + particle.origin.z) * 0.12,
      particle.origin.y + ease * 2.5,
      particle.origin.z + particle.drift.z * ease * 2.6 + Math.cos(t * 7 + particle.origin.x) * 0.1,
    );
    const scale = particle.size * (0.55 + ease * 2.1);
    particle.sprite.scale.setScalar(scale);
    particle.sprite.material.opacity = 0.63 * Math.sin(t * Math.PI) * (1 - t * 0.2);
  }
}

function updateMotes(time, dt) {
  const positions = moteGeometry.attributes.position.array;
  for (let i = 0; i < moteCount; i += 1) {
    const phase = moteSeeds[i * 2];
    const speed = moteSeeds[i * 2 + 1];
    positions[i * 3] += Math.sin(time * 0.11 + phase) * 0.0009 + Math.sin(time * 0.31 + phase * 2) * 0.0003;
    positions[i * 3 + 1] += dt * speed * 0.035;
    positions[i * 3 + 2] += Math.cos(time * 0.09 + phase) * 0.0007;
    if (positions[i * 3 + 1] > 4.8) positions[i * 3 + 1] = 0.25;
  }
  moteGeometry.attributes.position.needsUpdate = true;
}

function updateWaterLeaves(time, dt) {
  for (let i = 0; i < waterLeaves.length; i += 1) {
    const leaf = waterLeaves[i];
    leaf.t += leaf.speed * dt;
    leaf.rotation += leaf.spin * dt * 0.08;
    if (leaf.t > 1) leaf.t -= 1;
    const p = riverCurve.getPointAt(leaf.t);
    const tangent = riverCurve.getTangentAt(leaf.t).normalize();
    const normal = V3(-tangent.z, 0, tangent.x);
    dummy.position.set(
      p.x + normal.x * leaf.offset,
      WATER_Y + 0.018 + Math.sin(time * 1.1 + leaf.phase) * 0.008,
      p.z + normal.z * leaf.offset,
    );
    dummy.rotation.set(-Math.PI / 2, leaf.rotation, Math.sin(time * 0.7 + leaf.phase) * 0.08, 'YXZ');
    dummy.scale.setScalar(leaf.scale);
    dummy.updateMatrix();
    waterLeafMesh.setMatrixAt(i, dummy.matrix);
    floatingColor.set(waterLeafColors[i % waterLeafColors.length]);
    waterLeafMesh.setColorAt(i, floatingColor);
  }
  waterLeafMesh.instanceMatrix.needsUpdate = true;
  if (waterLeafMesh.instanceColor) waterLeafMesh.instanceColor.needsUpdate = true;
}

function updateFallingLeaves(time, dt) {
  for (let i = 0; i < fallLeaves.length; i += 1) {
    const leaf = fallLeaves[i];
    leaf.y -= leaf.speed * dt;
    leaf.spin += leaf.spinSpeed * dt;
    const x = leaf.x + Math.sin(time * 0.72 + leaf.phase) * leaf.sway;
    const z = leaf.z + Math.cos(time * 0.51 + leaf.phase * 1.7) * leaf.sway * 0.7;
    if (leaf.y < terrainHeight(x, z) + 0.08) {
      const source = fallSources[Math.floor(fallRng() * fallSources.length)];
      leaf.x = source.x + (fallRng() - 0.5) * source.crown * 1.8;
      leaf.z = source.z + (fallRng() - 0.5) * source.crown * 1.8;
      leaf.y = 3.2 + fallRng() * 2.4;
      leaf.phase = fallRng() * Math.PI * 2;
    }
    fallDummy.position.set(x, leaf.y, z);
    fallDummy.rotation.set(
      leaf.spin,
      time * 0.23 + leaf.phase,
      Math.sin(time * 0.9 + leaf.phase) * 0.7,
      'YXZ',
    );
    fallDummy.scale.setScalar(leaf.scale);
    fallDummy.updateMatrix();
    fallingLeafMesh.setMatrixAt(i, fallDummy.matrix);
  }
  fallingLeafMesh.instanceMatrix.needsUpdate = true;
}

function updateCranes(time) {
  cranes.forEach((crane) => {
    const orbit = crane.userData.orbit;
    const phase = crane.userData.phase;
    const angle = orbit.phase + time * orbit.speed;

    // Large, slow circular migration across the sky. The heading is the
    // tangent to the circle, so the birds always face where they are going.
    const x = orbit.centerX + Math.cos(angle) * orbit.radius;
    const z = orbit.centerZ + Math.sin(angle) * orbit.radius;
    const y = orbit.height + Math.sin(time * 0.36 + phase * 1.9) * 0.18;
    const tangentX = -Math.sin(angle);
    const tangentZ = Math.cos(angle);

    crane.position.set(x, y, z);
    crane.rotation.y = Math.atan2(tangentX, tangentZ);
    crane.rotation.x = Math.sin(time * 0.51 + phase) * 0.025;
    crane.rotation.z = -0.065 + Math.sin(time * 0.8 + phase) * 0.022;

    for (const wing of crane.userData.wings) {
      const flapCycle = Math.sin(time * 3.05 + phase * 1.4);
      const glide = 0.72 + Math.sin(time * 0.41 + phase) * 0.16;
      const flap = flapCycle * 0.4 * glide;
      wing.pivot.rotation.z = wing.side * (0.13 + flap);
      wing.pivot.rotation.x = Math.sin(time * 1.8 + phase + 0.6) * 0.055;
    }
  });
}

function updateMist(time) {
  for (let i = 0; i < mistSprites.length; i += 1) {
    const sprite = mistSprites[i];
    sprite.position.x += Math.sin(time * 0.035 + sprite.userData.phase) * 0.0006;
    sprite.position.y += Math.cos(time * 0.04 + sprite.userData.phase) * 0.0004;
  }
  for (let i = 0; i < airyClouds.length; i += 1) {
    const cloud = airyClouds[i];
    cloud.position.x = cloud.userData.baseX + Math.sin(time * cloud.userData.drift * 0.08 + cloud.userData.phase) * 0.7;
  }
}

/* --------------------------------------------------------------------------
   Sunset transition
   The day values match the existing grading exactly. uDusk drives the sky
   palette inside the shader; lights, fog, exposure and bloom are interpolated
   in the same smooth three-second envelope.
   -------------------------------------------------------------------------- */

const ui = document.createElement('div');
ui.className = 'autumn-scene-ui';
ui.setAttribute('role', 'group');
ui.setAttribute('aria-label', '秋季场景互动');
ui.innerHTML = `
  <button class="autumn-scene-btn" type="button" data-action="dusk" aria-pressed="false">
    <span class="autumn-scene-btn__mark" aria-hidden="true"></span>落日黄昏
  </button>
  <button class="autumn-scene-btn" type="button" data-action="duck">
    <span class="autumn-scene-btn__mark" aria-hidden="true"></span>小鸭入河
  </button>
`;
host.appendChild(ui);
const duskButton = ui.querySelector('[data-action="dusk"]');
const duckButton = ui.querySelector('[data-action="duck"]');
// Two distinct three-second stages: sunset, then deep blue-purple night.
const sunsetDuration = 6.0;
const daySunDir = new THREE.Vector3(0.53, 0.055, -0.846).normalize();
const duskSunDir = new THREE.Vector3(0.53, 0.012, -0.846).normalize();
const nightSunDir = new THREE.Vector3(0.53, 0.025, -0.846).normalize();

const dayLook = {
  sunColor: new THREE.Color(0xfff4df),
  sunIntensity: 3.0,
  sunY: 7.8,
  hemiSky: new THREE.Color(0xffe2c2),
  hemiGround: new THREE.Color(0x413c30),
  hemiIntensity: 0.52,
  coolFill: 0.16,
  frontFill: 0.11,
  warmBounce: 5.5,
  exposure: 0.98,
  bloom: 0.8,
  fog: new THREE.Color(0xf0d4a4),
};

const duskLook = {
  sunColor: new THREE.Color(0xff7e5f),
  sunIntensity: 2.4,
  sunY: 5.0,
  hemiSky: new THREE.Color(0x8a4f6c),
  hemiGround: new THREE.Color(0x2b1724),
  hemiIntensity: 0.34,
  coolFill: 0.06,
  frontFill: 0.04,
  warmBounce: 7.5,
  exposure: 0.95,
  bloom: 1.0,
  fog: new THREE.Color(0xb85c61),
};

const nightLook = {
  sunColor: new THREE.Color(0x9db7e6),
  sunIntensity: 0.55,
  sunY: 4.4,
  hemiSky: new THREE.Color(0x3b3f6a),
  hemiGround: new THREE.Color(0x14131f),
  hemiIntensity: 0.16,
  coolFill: 0.025,
  frontFill: 0.015,
  warmBounce: 10.5,
  exposure: 0.76,
  bloom: 0.95,
  fog: new THREE.Color(0x1b1b33),
};

let sunsetProgress = 0;
let sunsetTarget = 0;
let sunsetTransitionActive = false;
let sunsetShadowFrames = 0;

function applySunset(progress) {
  const stage1 = clamp(progress / 0.5, 0, 1);
  const stage2 = clamp((progress - 0.5) / 0.5, 0, 1);
  const a = stage1 * stage1 * (3 - 2 * stage1);
  const b = stage2 * stage2 * (3 - 2 * stage2);
  const mix3 = (day, dusk, night) => lerp(lerp(day, dusk, a), night, b);

  sun.color.copy(dayLook.sunColor).lerp(duskLook.sunColor, a).lerp(nightLook.sunColor, b);
  sun.intensity = mix3(dayLook.sunIntensity, duskLook.sunIntensity, nightLook.sunIntensity);
  sun.position.y = mix3(dayLook.sunY, duskLook.sunY, nightLook.sunY);

  hemi.color.copy(dayLook.hemiSky).lerp(duskLook.hemiSky, a).lerp(nightLook.hemiSky, b);
  hemi.groundColor.copy(dayLook.hemiGround).lerp(duskLook.hemiGround, a).lerp(nightLook.hemiGround, b);
  hemi.intensity = mix3(dayLook.hemiIntensity, duskLook.hemiIntensity, nightLook.hemiIntensity);
  coolFill.intensity = mix3(dayLook.coolFill, duskLook.coolFill, nightLook.coolFill);
  frontFill.intensity = mix3(dayLook.frontFill, duskLook.frontFill, nightLook.frontFill);
  warmBounce.intensity = mix3(dayLook.warmBounce, duskLook.warmBounce, nightLook.warmBounce);

  for (const light of warmLights) {
    if (!light.userData) continue;
    light.intensity = mix3(light.userData.day, light.userData.dusk, light.userData.night);
  }
  for (const entry of nightGlowMaterials) {
    const factor = mix3(entry.day, entry.dusk, entry.night);
    entry.material.color.copy(entry.base).multiplyScalar(factor);
  }
  for (const entry of nightGlowSprites) {
    entry.material.opacity = mix3(entry.day, entry.dusk, entry.night);
  }

  renderer.toneMappingExposure = mix3(dayLook.exposure, duskLook.exposure, nightLook.exposure);
  bloomPass.strength = mix3(dayLook.bloom, duskLook.bloom, nightLook.bloom);
  scene.fog.color.copy(dayLook.fog).lerp(duskLook.fog, a).lerp(nightLook.fog, b);

  sky.material.uniforms.uDusk.value = a;
  sky.material.uniforms.uNight.value = b;
  sky.material.uniforms.uSunDir.value
    .copy(daySunDir)
    .lerp(duskSunDir, a)
    .lerp(nightSunDir, b)
    .normalize();
}

function toggleSunset() {
  const nextTarget = sunsetTarget > 0.5 ? 0 : 1;
  sunsetTarget = nextTarget;
  sunsetTransitionActive = true;
  sunsetShadowFrames = 2;
  if (duskButton) {
    duskButton.classList.toggle('is-active', nextTarget === 1);
    duskButton.setAttribute('aria-pressed', nextTarget === 1 ? 'true' : 'false');
    duskButton.title = nextTarget === 1 ? '切回日间光照' : '切换至晚霞';
  }
}

function updateSunset(dt) {
  if (!sunsetTransitionActive) return;
  const step = dt / sunsetDuration;
  if (sunsetProgress < sunsetTarget) {
    sunsetProgress = Math.min(sunsetTarget, sunsetProgress + step);
  } else if (sunsetProgress > sunsetTarget) {
    sunsetProgress = Math.max(sunsetTarget, sunsetProgress - step);
  }
  applySunset(sunsetProgress);
  sunsetShadowFrames = 2;
  if (Math.abs(sunsetProgress - sunsetTarget) < 1e-5) {
    sunsetProgress = sunsetTarget;
    applySunset(sunsetProgress);
    sunsetTransitionActive = false;
  }
}

applySunset(0);
if (duskButton) {
  duskButton.title = '切换至晚霞';
  duskButton.addEventListener('click', toggleSunset);
}

let shadowPrepared = false;
let animationFrameId = 0;
let running = true;
let frameCount = 0;

function animate() {
  if (!running) return;
  animationFrameId = requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  timeUniforms.uTime.value += dt;
  const time = timeUniforms.uTime.value;
  if (sky.material.uniforms.uTime) sky.material.uniforms.uTime.value = time;

  waterNormalTexture.offset.y -= dt * 0.022;
  if (waterNormalTexture.offset.y < -1) waterNormalTexture.offset.y += 1;
  sparkleMaterial.uniforms.uTime.value = time;

  controls.update();
  updateSunset(dt);
  updateDucks(time);
  updateSmoke(dt);
  updateMotes(time, dt);
  updateWaterLeaves(time, dt);
  updateFallingLeaves(time, dt);
  updateCranes(time);
  updateMist(time);

  if (!shadowPrepared) {
    renderer.shadowMap.needsUpdate = true;
    shadowPrepared = true;
  }
  if (sunsetShadowFrames > 0) {
    renderer.shadowMap.needsUpdate = true;
    sunsetShadowFrames -= 1;
  }
  renderer.info.autoReset = false;
  renderer.info.reset();
  composer.render(dt);
  if (window.__HARVEST__ && window.__HARVEST__.scene === scene) {
    window.__HARVEST__.sceneStats = {
      calls: renderer.info.render.calls,
      triangles: renderer.info.render.triangles,
      points: renderer.info.render.points,
      lines: renderer.info.render.lines,
    };
  }
  frameCount += 1;
  if (frameCount === 3) host.dataset.sceneReady = '1';
}

function onResize() {
  viewport = readHostSize();
  const aspect = viewport.width / viewport.height;
  camera.aspect = aspect;
  camera.fov = aspect < 0.82 ? 52 : aspect < 1.12 ? 42 : 40;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(pixelRatioForViewport());
  renderer.setSize(viewport.width, viewport.height, false);
  composer.setPixelRatio(renderer.getPixelRatio());
  composer.setSize(viewport.width, viewport.height);
  if (sparkleMaterial && sparkleMaterial.uniforms.uPixelRatio) {
    sparkleMaterial.uniforms.uPixelRatio.value = renderer.getPixelRatio();
  }
  renderer.shadowMap.needsUpdate = true;
}

window.addEventListener('resize', onResize);

/* --------------------------------------------------------------------------
   Static draw-call batching
   The diorama is visually dense but almost entirely static. Grouping opaque
   meshes that share the same material keeps the scene at a low draw-call count
   without touching instanced wheat, foliage, animated birds or particles.
   -------------------------------------------------------------------------- */

function materialSignature(material) {
  const colorHex = (value) => (value && value.isColor ? value.getHexString() : '');
  return [
    material.type,
    colorHex(material.color),
    colorHex(material.emissive),
    material.emissiveIntensity ?? '',
    material.vertexColors ? 1 : 0,
    material.side,
    material.map?.uuid || '',
    material.alphaMap?.uuid || '',
    material.normalMap?.uuid || '',
    material.roughnessMap?.uuid || '',
    material.metalnessMap?.uuid || '',
    material.emissiveMap?.uuid || '',
    material.aoMap?.uuid || '',
    material.clearcoatNormalMap?.uuid || '',
    material.gradientMap?.uuid || '',
    material.transparent ? 1 : 0,
    material.opacity ?? 1,
    material.alphaTest ?? 0,
    material.depthWrite === false ? 0 : 1,
    material.depthTest === false ? 0 : 1,
    material.blending,
    material.toneMapped === false ? 0 : 1,
    material.flatShading ? 1 : 0,
    material.fog === false ? 0 : 1,
    material.polygonOffset ? 1 : 0,
  ].join('|');
}

function batchStaticMeshes(root) {
  const dynamicNodes = new Set();
  root.traverse((node) => {
    if (node.userData && node.userData.dynamic) {
      node.traverse((child) => dynamicNodes.add(child));
    }
  });

  root.updateMatrixWorld(true);
  const groups = new Map();
  root.traverse((mesh) => {
    if (!mesh.isMesh || mesh.isInstancedMesh || mesh.isSkinnedMesh) return;
    if (dynamicNodes.has(mesh)) return;
    if (mesh.userData.noBatch) return;
    if (!mesh.geometry || !mesh.material) return;
    if (Array.isArray(mesh.material)) return;
    if (mesh.material.isShaderMaterial || mesh.material.transparent) return;
    if (mesh.material.onBeforeCompile && mesh.material.onBeforeCompile.length > 0) return;
    if (mesh.geometry.morphAttributes && Object.keys(mesh.geometry.morphAttributes).length) return;
    const key = `${materialSignature(mesh.material)}|${mesh.castShadow ? 1 : 0}${mesh.receiveShadow ? 1 : 0}`;
    let group = groups.get(key);
    if (!group) {
      group = {
        material: mesh.material,
        castShadow: mesh.castShadow,
        receiveShadow: mesh.receiveShadow,
        meshes: [],
      };
      groups.set(key, group);
    }
    group.meshes.push(mesh);
  });

  let mergedGroups = 0;
  let removedMeshes = 0;
  for (const group of groups.values()) {
    if (group.meshes.length < 2) continue;
    const geometries = [];
    let failed = false;
    for (const mesh of group.meshes) {
      try {
        const source = mesh.geometry;
        const geometry = source.index ? source.toNonIndexed() : source.clone();
        geometry.applyMatrix4(mesh.matrixWorld);
        const vertexCount = geometry.attributes.position.count;

        for (const attributeName of Object.keys(geometry.attributes)) {
          if (!['position', 'normal', 'uv', 'color'].includes(attributeName)) {
            geometry.deleteAttribute(attributeName);
          }
        }
        if (!geometry.attributes.normal) geometry.computeVertexNormals();
        if (!geometry.attributes.uv) {
          geometry.setAttribute(
            'uv',
            new THREE.Float32BufferAttribute(new Float32Array(vertexCount * 2), 2),
          );
        }
        if (group.material.vertexColors) {
          if (!geometry.attributes.color) {
            const colors = new Float32Array(vertexCount * 3);
            colors.fill(1);
            geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
          }
        } else if (geometry.attributes.color) {
          geometry.deleteAttribute('color');
        }
        geometry.clearGroups();
        geometry.morphAttributes = {};
        geometries.push(geometry);
      } catch {
        failed = true;
        break;
      }
    }
    if (failed) continue;

    let merged = null;
    try {
      merged = mergeGeometries(geometries, false);
    } catch {
      merged = null;
    }
    if (!merged) continue;

    merged.computeBoundingSphere();
    const batch = new THREE.Mesh(merged, group.material);
    batch.castShadow = group.castShadow;
    batch.receiveShadow = group.receiveShadow;
    batch.frustumCulled = true;
    world.add(batch);
    for (const mesh of group.meshes) {
      if (mesh.parent) mesh.parent.remove(mesh);
      removedMeshes += 1;
    }
    mergedGroups += 1;
  }

  if (new URLSearchParams(window.location.search).has('debug')) {
    console.info(`[autumn] batched ${removedMeshes} static meshes into ${mergedGroups} draw groups`);
  }
}

batchStaticMeshes(world);

/* --------------------------------------------------------------------------
   Little duck procession
   Four procedural ducklings start at the field edge, waddle down the bank,
   settle exactly onto the water plane, then follow the real river centerline
   downstream. Their bodies fade out before reaching the stone culvert.
   -------------------------------------------------------------------------- */

// duckButton is created with the local scene UI above.
const duckFlock = new THREE.Group();
duckFlock.visible = false;
world.add(duckFlock);

const DUCK_COUNT = 4;
const DUCK_DELAY = 1.15;
const DUCK_FADE_IN = 0.4;
const DUCK_WALK_START = 0.14;
const DUCK_WALK_DURATION = 2.7;
const DUCK_SINK_DURATION = 0.85;
const DUCK_SWIM_DURATION = 12.5;
const DUCK_FADE_OUT = 1.2;
const DUCK_TOTAL = DUCK_WALK_START + DUCK_WALK_DURATION
  + DUCK_SINK_DURATION + DUCK_SWIM_DURATION + DUCK_FADE_OUT;
const DUCK_SWIM_END_T = 0.965;

// The story starts at the near wheat-field edge beside the stream, where the
// default camera can read the waddling line before it reaches the water.
const duckStart = new THREE.Vector3(-3.4, 0, 4.4);
duckStart.y = terrainHeight(duckStart.x, duckStart.z) + 0.012;

function nearestRiverT(x, z) {
  let bestDistance = Infinity;
  let bestT = 0.5;
  for (let i = 0; i <= 400; i += 1) {
    const t = i / 400;
    const point = riverCurve.getPointAt(t);
    const distance = (point.x - x) ** 2 + (point.z - z) ** 2;
    if (distance < bestDistance) {
      bestDistance = distance;
      bestT = t;
    }
  }
  return bestT;
}

const duckEntryT = nearestRiverT(duckStart.x, duckStart.z);
const duckEntry = riverCurve.getPointAt(duckEntryT);
const duckEntryTangent = riverCurve.getTangentAt(duckEntryT).normalize();
const duckEntryNormal = V3(-duckEntryTangent.z, 0, duckEntryTangent.x).normalize();
const duckEntryWidth = waterWidthNear(duckEntry.x, duckEntry.z);
const duckSide = Math.sign(
  (duckStart.x - duckEntry.x) * duckEntryNormal.x
  + (duckStart.z - duckEntry.z) * duckEntryNormal.z,
) || 1;
const duckBank = duckEntry.clone().addScaledVector(
  duckEntryNormal,
  duckSide * (duckEntryWidth * 0.5 + 0.34),
);
duckBank.y = Math.max(terrainHeight(duckBank.x, duckBank.z) + 0.012, WATER_Y + 0.012);

const duckWalkMid = duckStart.clone().lerp(duckBank, 0.56);
duckWalkMid.y = 0;
const duckWalkCurve = new THREE.CatmullRomCurve3(
  [
    new THREE.Vector3(duckStart.x, 0, duckStart.z),
    duckWalkMid,
    new THREE.Vector3(duckBank.x, 0, duckBank.z),
  ],
  false,
  'catmullrom',
  0.22,
);

function makeDuck(index) {
  const group = new THREE.Group();
  const feather = toon(0xffd12b, { emissive: 0x4c3000, emissiveIntensity: 0.2 });
  const bill = toon(0xf18a2e, { emissive: 0x3b1604, emissiveIntensity: 0.06 });
  const eye = new THREE.MeshBasicMaterial({ color: 0x1d1710, toneMapped: false });
  for (const material of [feather, bill, eye]) {
    material.transparent = true;
    material.opacity = 0;
  }

  const body = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), feather);
  body.scale.set(0.105, 0.075, 0.16);
  body.position.set(0, 0.075, 0);
  body.receiveShadow = true;
  group.add(body);

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.052, 0.085, 8), feather);
  neck.position.set(0, 0.137, 0.115);
  neck.rotation.x = -0.5;
  group.add(neck);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.062, 12, 9), feather);
  head.position.set(0, 0.18, 0.15);
  head.receiveShadow = true;
  group.add(head);

  const beak = new THREE.Mesh(new THREE.ConeGeometry(0.031, 0.078, 7), bill);
  beak.rotation.x = Math.PI / 2;
  beak.position.set(0, 0.178, 0.207);
  group.add(beak);

  for (const side of [-1, 1]) {
    const eyeMesh = new THREE.Mesh(new THREE.SphereGeometry(0.0105, 6, 5), eye);
    eyeMesh.position.set(side * 0.033, 0.197, 0.183);
    group.add(eyeMesh);

    const wing = new THREE.Mesh(new THREE.SphereGeometry(1, 10, 8), feather);
    wing.scale.set(0.024, 0.043, 0.086);
    wing.position.set(side * 0.093, 0.079, -0.005);
    group.add(wing);
  }

  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.042, 0.115, 6), feather);
  tail.rotation.x = -Math.PI / 2;
  tail.position.set(0, 0.085, -0.172);
  group.add(tail);

  const legs = new THREE.Group();
  for (const side of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.010, 0.060, 5), bill);
    leg.position.set(side * 0.045, 0.035, 0.015);
    leg.rotation.z = side * 0.06;
    legs.add(leg);
    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.009, 0.055), bill);
    foot.position.set(side * 0.045, 0.008, 0.040);
    legs.add(foot);
  }
  group.add(legs);

  group.scale.setScalar(0.85);
  group.userData = {
    materials: [feather, bill, eye],
    legs,
    index,
    phase: index * 1.7,
  };
  group.visible = false;
  group.position.copy(duckStart);
  group.rotation.y = Math.atan2(
    duckBank.x - duckStart.x,
    duckBank.z - duckStart.z,
  );
  return group;
}

const duckWakeTexture = (() => {
  const wakeCanvas = document.createElement('canvas');
  wakeCanvas.width = 128;
  wakeCanvas.height = 256;
  const ctx = wakeCanvas.getContext('2d');
  ctx.clearRect(0, 0, 128, 256);
  const fade = ctx.createLinearGradient(0, 0, 0, 256);
  fade.addColorStop(0, 'rgba(255, 245, 215, 0)');
  fade.addColorStop(0.16, 'rgba(255, 245, 215, .68)');
  fade.addColorStop(0.72, 'rgba(255, 245, 215, .26)');
  fade.addColorStop(1, 'rgba(255, 245, 215, 0)');
  ctx.strokeStyle = fade;
  ctx.lineCap = 'round';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(64, 10);
  ctx.bezierCurveTo(57, 74, 30, 172, 8, 246);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(64, 10);
  ctx.bezierCurveTo(71, 74, 98, 172, 120, 246);
  ctx.stroke();
  ctx.lineWidth = 2.2;
  ctx.strokeStyle = 'rgba(255, 245, 215, .22)';
  ctx.beginPath();
  ctx.moveTo(64, 22);
  ctx.bezierCurveTo(59, 86, 42, 174, 27, 232);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(64, 22);
  ctx.bezierCurveTo(69, 86, 86, 174, 101, 232);
  ctx.stroke();
  const texture = new THREE.CanvasTexture(wakeCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
})();

const ducks = [];
for (let i = 0; i < DUCK_COUNT; i += 1) {
  const duck = makeDuck(i);
  ducks.push(duck);
  duckFlock.add(duck);
}

const duckWakes = [];
for (let i = 0; i < DUCK_COUNT; i += 1) {
  const material = new THREE.MeshBasicMaterial({
    map: duckWakeTexture,
    color: 0xffefcf,
    transparent: true,
    opacity: 0,
    depthWrite: false,
    side: THREE.DoubleSide,
    toneMapped: false,
  });
  const wakeGeometry = new THREE.PlaneGeometry(0.58, 0.72);
  wakeGeometry.rotateX(Math.PI / 2);
  const wake = new THREE.Mesh(wakeGeometry, material);
  wake.visible = false;
  wake.renderOrder = 2;
  duckWakes.push(wake);
  duckFlock.add(wake);
}

let duckSequenceActive = false;
let duckSequenceStart = 0;

function setDuckOpacity(duck, alpha) {
  const clamped = clamp(alpha, 0, 1);
  for (const material of duck.userData.materials) material.opacity = clamped;
  duck.visible = clamped > 0.015;
}

function startDuckSequence() {
  if (duckSequenceActive) return;
  duckSequenceActive = true;
  duckSequenceStart = timeUniforms.uTime.value;
  duckFlock.visible = true;
  for (const duck of ducks) {
    duck.visible = false;
    duck.position.copy(duckStart);
    for (const material of duck.userData.materials) material.opacity = 0;
  }
  for (const wake of duckWakes) {
    wake.visible = false;
    wake.material.opacity = 0;
  }
  if (duckButton) {
    duckButton.disabled = true;
    duckButton.classList.add('is-active');
    duckButton.setAttribute('aria-busy', 'true');
  }
}

function finishDuckSequence() {
  duckSequenceActive = false;
  duckFlock.visible = false;
  for (const duck of ducks) {
    setDuckOpacity(duck, 0);
    duck.userData.legs.visible = true;
  }
  for (const wake of duckWakes) {
    wake.visible = false;
    wake.material.opacity = 0;
  }
  if (duckButton) {
    duckButton.disabled = false;
    duckButton.classList.remove('is-active');
    duckButton.setAttribute('aria-busy', 'false');
  }
}

function updateDucks(time) {
  if (!duckSequenceActive) return;
  const elapsed = time - duckSequenceStart;
  const walkEnd = DUCK_WALK_START + DUCK_WALK_DURATION;
  const sinkEnd = walkEnd + DUCK_SINK_DURATION;
  const swimEnd = sinkEnd + DUCK_SWIM_DURATION;

  for (let i = 0; i < ducks.length; i += 1) {
    const duck = ducks[i];
    const wake = duckWakes[i];
    const local = elapsed - i * DUCK_DELAY;
    if (local < 0 || local > DUCK_TOTAL) {
      duck.visible = false;
      wake.visible = false;
      continue;
    }

    duck.visible = true;
    duck.userData.legs.visible = local < sinkEnd;
    let wakeActive = false;
    const fadeIn = smooth(0, DUCK_FADE_IN, local);
    const fadeOut = 1 - smooth(swimEnd, DUCK_TOTAL, local);
    const alpha = Math.min(fadeIn, fadeOut);
    setDuckOpacity(duck, alpha);

    let x;
    let z;
    let y;
    let yaw;
    let roll = 0;

    if (local < walkEnd) {
      const p = clamp((local - DUCK_WALK_START) / DUCK_WALK_DURATION, 0, 1);
      const point = duckWalkCurve.getPointAt(p);
      const tangent = duckWalkCurve.getTangentAt(p).normalize();
      const pathNormal = V3(-tangent.z, 0, tangent.x).normalize();
      const lane = (i - (DUCK_COUNT - 1) * 0.5) * 0.025;
      x = point.x + pathNormal.x * lane;
      z = point.z + pathNormal.z * lane;
      const groundY = terrainHeight(x, z) + 0.014;
      const bankBlend = smooth(0.82, 1, p);
      y = lerp(groundY, duckBank.y, bankBlend)
        + Math.abs(Math.sin(local * 10.5 + i * 1.7)) * 0.007;
      yaw = Math.atan2(tangent.x, tangent.z);
      roll = Math.sin(local * 10.5 + i * 1.7) * 0.035;
    } else if (local < sinkEnd) {
      const p = clamp((local - walkEnd) / DUCK_SINK_DURATION, 0, 1);
      const eased = p * p * (3 - 2 * p);
      x = lerp(duckBank.x, duckEntry.x, eased);
      z = lerp(duckBank.z, duckEntry.z, eased);
      y = lerp(duckBank.y, WATER_Y - 0.066, eased);
      yaw = Math.atan2(duckEntryTangent.x, duckEntryTangent.z);
      roll = Math.sin(p * Math.PI) * 0.025;
    } else if (local <= swimEnd) {
      wakeActive = true;
      const p = clamp((local - sinkEnd) / DUCK_SWIM_DURATION, 0, 1);
      const swimT = lerp(duckEntryT, DUCK_SWIM_END_T, p);
      const point = riverCurve.getPointAt(swimT);
      const tangent = riverCurve.getTangentAt(swimT).normalize();
      const normal = V3(-tangent.z, 0, tangent.x).normalize();
      const lane = (i - (DUCK_COUNT - 1) * 0.5) * 0.065;
      x = point.x + normal.x * lane;
      z = point.z + normal.z * lane;
      y = WATER_Y - 0.066 + Math.sin(time * 1.6 + i * 1.9) * 0.0045;
      yaw = Math.atan2(tangent.x, tangent.z) + Math.sin(time * 1.3 + i * 1.2) * 0.045;
      roll = Math.sin(time * 1.8 + i * 1.4) * 0.04;
    } else {
      wakeActive = true;
      const point = riverCurve.getPointAt(DUCK_SWIM_END_T);
      const tangent = riverCurve.getTangentAt(DUCK_SWIM_END_T).normalize();
      const normal = V3(-tangent.z, 0, tangent.x).normalize();
      const lane = (i - (DUCK_COUNT - 1) * 0.5) * 0.065;
      x = point.x + normal.x * lane;
      z = point.z + normal.z * lane;
      y = WATER_Y - 0.066;
      yaw = Math.atan2(tangent.x, tangent.z);
      roll = Math.sin(time * 1.8 + i * 1.4) * 0.02;
    }

    duck.position.set(x, y, z);
    duck.rotation.y = yaw;
    duck.rotation.z = roll;

    if (wakeActive && alpha > 0.015) {
      wake.visible = true;
      wake.position.set(
        x - Math.sin(yaw) * 0.34,
        WATER_Y + 0.006,
        z - Math.cos(yaw) * 0.34,
      );
      wake.rotation.y = yaw;
      wake.material.opacity = alpha * 0.42;
    } else {
      wake.visible = false;
      wake.material.opacity = 0;
    }
  }

  const lastEnd = (DUCK_COUNT - 1) * DUCK_DELAY + DUCK_TOTAL;
  if (elapsed >= lastEnd) finishDuckSequence();
}

if (duckButton) duckButton.addEventListener('click', startDuckSequence);

let disposed = false;

function disposeScene() {
  if (disposed) return;
  disposed = true;

  running = false;
  if (animationFrameId) cancelAnimationFrame(animationFrameId);
  animationFrameId = 0;
  renderer.setAnimationLoop(null);
  window.removeEventListener('resize', onResize);
  controls.dispose();

  if (waterEnvTarget) {
    try { waterEnvTarget.dispose(); } catch (error) { /* already released */ }
  }

  if (composer) {
    for (let i = 0; i < composer.passes.length; i += 1) {
      const pass = composer.passes[i];
      if (pass && typeof pass.dispose === 'function') {
        try { pass.dispose(); } catch (error) { /* pass already released */ }
      }
    }
    try { composer.dispose(); } catch (error) { /* targets already released */ }
  }

  const textures = new Set();
  const materials = new Set();
  const geometries = new Set();
  const textureSlots = [
    'map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'emissiveMap',
    'alphaMap', 'bumpMap', 'displacementMap', 'clearcoatMap', 'clearcoatNormalMap',
    'clearcoatRoughnessMap', 'sheenColorMap', 'sheenRoughnessMap', 'specularMap',
    'transmissionMap', 'thicknessMap', 'lightMap', 'envMap', 'gradientMap',
  ];

  const collectMaterial = (material) => {
    if (!material || materials.has(material)) return;
    materials.add(material);
    for (let i = 0; i < textureSlots.length; i += 1) {
      const texture = material[textureSlots[i]];
      if (texture && texture.isTexture) textures.add(texture);
    }
    if (material.uniforms) {
      Object.keys(material.uniforms).forEach((key) => {
        const value = material.uniforms[key] && material.uniforms[key].value;
        if (value && value.isTexture) textures.add(value);
      });
    }
  };

  scene.traverse((object) => {
    if (object.geometry) geometries.add(object.geometry);
    if (object.material) {
      if (Array.isArray(object.material)) object.material.forEach(collectMaterial);
      else collectMaterial(object.material);
    }
  });

  textures.forEach((texture) => {
    try { texture.dispose(); } catch (error) { /* texture already released */ }
  });
  materials.forEach((material) => {
    try { material.dispose(); } catch (error) { /* material already released */ }
  });
  geometries.forEach((geometry) => {
    try { geometry.dispose(); } catch (error) { /* geometry already released */ }
  });

  scene.clear();
  if (host.dataset.sceneReady) delete host.dataset.sceneReady;
  host.classList.remove('is-autumn-scene');
  host.replaceChildren();

  if (window.__HARVEST__ && window.__HARVEST__.scene === scene) {
    window.__HARVEST__ = null;
  }

  renderer.dispose();
  try { renderer.forceContextLoss(); } catch (error) { /* best effort */ }
}

const api = {
  scene,
  camera,
  renderer,
  controls,
  composer,
  bloomPass,
  outputPass,
  startDuckSequence,
  toggleSunset,
  destroy: disposeScene,
  get disposed() { return disposed; },
};

window.__HARVEST__ = api;
renderer.compileAsync(scene, camera).catch(() => {});
animate();
return api;
}
