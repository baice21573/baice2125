// Builds one shared Three.js runtime containing the Spring, Summer, Autumn and Winter factories.
// Output: four-seasons-3d.bundle.js, exposing window.initSpringScene, initSummerScene, initAutumnScene and initWinterScene.
import { readFileSync, writeFileSync } from 'node:fs';

const vendorRoot = 'taohuayuan-source/vendor';
const threePath = `${vendorRoot}/three.module.js`;
const orbitPath = `${vendorRoot}/examples/jsm/controls/OrbitControls.js`;
const addonPaths = [
  `${vendorRoot}/examples/jsm/shaders/CopyShader.js`,
  `${vendorRoot}/examples/jsm/shaders/LuminosityHighPassShader.js`,
  `${vendorRoot}/examples/jsm/postprocessing/Pass.js`,
  `${vendorRoot}/examples/jsm/postprocessing/ShaderPass.js`,
  `${vendorRoot}/examples/jsm/postprocessing/MaskPass.js`,
  `${vendorRoot}/examples/jsm/postprocessing/EffectComposer.js`,
  `${vendorRoot}/examples/jsm/postprocessing/RenderPass.js`,
  `${vendorRoot}/examples/jsm/postprocessing/UnrealBloomPass.js`,
  `${vendorRoot}/examples/jsm/shaders/OutputShader.js`,
  `${vendorRoot}/examples/jsm/postprocessing/OutputPass.js`,
  `${vendorRoot}/examples/jsm/objects/Reflector.js`,
  `${vendorRoot}/examples/jsm/utils/BufferGeometryUtils.js`,
];

let threeSource = readFileSync(threePath, 'utf8');
const exportMatch = threeSource.match(/export \{([\s\S]*?)\};?\s*$/);
if (!exportMatch) throw new Error('Could not find Three.js export list');

const exportNames = exportMatch[1]
  .split(',')
  .map((name) => name.trim())
  .filter(Boolean);

if (exportNames.some((name) => name.includes(' as '))) {
  throw new Error('Aliased Three.js exports are not supported by this build script');
}

threeSource = threeSource.slice(0, exportMatch.index);

let orbitSource = readFileSync(orbitPath, 'utf8')
  .replace(/^import[\s\S]*?from\s+['"][^'"]+['"];\s*/gm, '')
  .replace(/^export\s*\{[\s\S]*?\};?\s*$/gm, '')
  .replace(/^export\s+(?=(?:function|class|const|let|var)\s)/gm, '');

function bundleAddon(path) {
  return readFileSync(path, 'utf8')
    .replace(/^import[\s\S]*?from\s+['"][^'"]+['"];\s*/gm, '')
    .replace(/^export\s*\{[\s\S]*?\};?\s*$/gm, '')
    .replace(/^export\s+(?=(?:function|class|const|let|var)\s)/gm, '')
    .trim();
}

const addonSource = addonPaths.map(bundleAddon).join('\n\n');
const addonBundle = `const FourSeasonsAddons = (function () {
${addonSource}
return {
  EffectComposer,
  RenderPass,
  UnrealBloomPass,
  OutputPass,
  ShaderPass,
  Pass,
  FullScreenQuad,
  Reflector,
  mergeGeometries,
};
})();
const {
  EffectComposer,
  RenderPass,
  UnrealBloomPass,
  OutputPass,
  ShaderPass,
  Pass,
  FullScreenQuad,
  Reflector,
  mergeGeometries,
} = FourSeasonsAddons;`;

const springSource = readFileSync('spring-scene.js', 'utf8')
  .replace(/^import[^\n]*\n/gm, '')
  .replace(/^export\s+function\s+initSpringScene/m, 'function initSpringScene');

const summerSource = readFileSync('summer-scene.js', 'utf8')
  .replace(/^import[^\n]*\n/gm, '')
  .replace(/^export\s+function\s+initSummerScene/m, 'function initSummerScene');

const autumnSource = readFileSync('autumn-scene.js', 'utf8')
  .replace(/^import[^\n]*\n/gm, '')
  .replace(/^export\s+function\s+initAutumnScene/m, 'function initAutumnScene');

const winterSource = readFileSync('winter-scene.js', 'utf8')
  .replace(/^import[^\n]*\n/gm, '')
  .replace(/^export\s+function\s+initWinterScene/m, 'function initWinterScene');

const bundled = `(function () {
'use strict';

${threeSource}

const THREE = { ${exportNames.join(', ')} };

const OrbitControls = (function () {
${orbitSource}
return OrbitControls;
})();

${addonBundle}

const SpringSceneFactory = (function (THREE, OrbitControls, EffectComposer, RenderPass, UnrealBloomPass, OutputPass, ShaderPass, Pass, FullScreenQuad) {
${springSource}
return initSpringScene;
})(THREE, OrbitControls, EffectComposer, RenderPass, UnrealBloomPass, OutputPass, ShaderPass, Pass, FullScreenQuad);

const SummerSceneFactory = (function (THREE, OrbitControls, EffectComposer, RenderPass, UnrealBloomPass, OutputPass, Reflector, mergeGeometries) {
${summerSource}
return initSummerScene;
})(THREE, OrbitControls, EffectComposer, RenderPass, UnrealBloomPass, OutputPass, Reflector, mergeGeometries);

const AutumnSceneFactory = (function (THREE, OrbitControls, EffectComposer, RenderPass, UnrealBloomPass, OutputPass, mergeGeometries) {
${autumnSource}
return initAutumnScene;
})(THREE, OrbitControls, EffectComposer, RenderPass, UnrealBloomPass, OutputPass, mergeGeometries);

const WinterSceneFactory = (function (THREE, OrbitControls, EffectComposer, RenderPass, UnrealBloomPass, OutputPass, mergeGeometries) {
${winterSource}
return initWinterScene;
})(THREE, OrbitControls, EffectComposer, RenderPass, UnrealBloomPass, OutputPass, mergeGeometries);

window.initSpringScene = SpringSceneFactory;
window.initSummerScene = SummerSceneFactory;
window.initAutumnScene = AutumnSceneFactory;
window.initWinterScene = WinterSceneFactory;
})();`;

writeFileSync('four-seasons-3d.bundle.js', bundled, 'utf8');
console.log(`Wrote four-seasons-3d.bundle.js (${(Buffer.byteLength(bundled) / 1024 / 1024).toFixed(2)} MB)`);
