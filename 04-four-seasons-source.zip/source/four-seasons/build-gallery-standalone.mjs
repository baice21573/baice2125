// Builds a single-file gallery with the shared Spring + Summer + Autumn Three.js bundle inlined.
// Usage: node build-gallery-standalone.mjs
import { readFileSync, writeFileSync } from 'node:fs';

const gallery = readFileSync('four-seasons-gallery.html', 'utf8');
const marker = '<script src="./four-seasons-3d.bundle.js?v=6"></script>';
if (!gallery.includes(marker)) throw new Error('4-seasons 3D bundle script marker not found');

const bundle = readFileSync('four-seasons-3d.bundle.js', 'utf8');
const safeBundle = bundle.replace(/<\/script/gi, '<\\/script');
const standalone = gallery.replace(marker, () => `<script>\n${safeBundle}\n</script>`);
writeFileSync('four-seasons-gallery-standalone.html', standalone, 'utf8');
console.log(`Wrote four-seasons-gallery-standalone.html (${(Buffer.byteLength(standalone) / 1024 / 1024).toFixed(2)} MB)`);
