import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

// ---------------------------------------------------------------------------
// 上元灯会 · 微缩夜街
// A hand-built, toon-shaded miniature Shangyuan festival street.
// ---------------------------------------------------------------------------

export function initWinterScene(container) {
  const host = typeof container === 'string' ? document.querySelector(container) : container;
  if (!host) throw new Error('initWinterScene: container not found');

  if (window.__WINTER__ && typeof window.__WINTER__.destroy === 'function') {
    try { window.__WINTER__.destroy(); } catch (error) { /* previous scene already gone */ }
  }

  host.replaceChildren();
  host.classList.add('is-winter-scene');

  const readHostSize = () => {
    const rect = host.getBoundingClientRect();
    return {
      width: Math.max(1, Math.round(rect.width || host.clientWidth || window.innerWidth)),
      height: Math.max(1, Math.round(rect.height || host.clientHeight || window.innerHeight)),
    };
  };

  let viewport = readHostSize();

  const canvas = document.createElement('canvas');
  canvas.className = 'winter-scene-canvas';
  canvas.setAttribute('aria-label', '上元灯会微缩三维街景');
  host.appendChild(canvas);

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: 'high-performance',
    stencil: false,
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.45));
  renderer.setSize(viewport.width, viewport.height, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.display = 'block';
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x040a14);
scene.fog = new THREE.FogExp2(0x081726, 0.0032);

const TARGET = new THREE.Vector3(0, 2.7, -1.8);
const camera = new THREE.PerspectiveCamera(45, viewport.width / viewport.height, 0.4, 420);

function placeInitialCamera() {
  const aspect = viewport.width / viewport.height;
  if (aspect < 1.08) {
    // Tall mobile frame: a high-angle top view keeps the square night street intact.
    camera.position.copy(TARGET).add(new THREE.Vector3(1.8, 58.0, 24.0));
    camera.fov = 54;
  } else {
    // High opening view: the lantern street reads as a square diorama.
    camera.position.copy(TARGET).add(new THREE.Vector3(1.4, 50.0, 20.0));
    camera.fov = 42;
  }
  camera.updateProjectionMatrix();
}
placeInitialCamera();

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.copy(TARGET);
controls.enableDamping = true;
controls.dampingFactor = 0.055;
controls.enablePan = false;
controls.rotateSpeed = 0.56;
controls.zoomSpeed = 0.82;
controls.minDistance = 15;
controls.maxDistance = 128;
controls.minPolarAngle = 0.08;
controls.maxPolarAngle = Math.PI * 0.485;
controls.update();

const debugParams = new URLSearchParams(window.location.search);
const composer = new EffectComposer(renderer);
composer.renderTarget1.samples = 2;
composer.renderTarget2.samples = 2;
const renderPass = new RenderPass(scene, camera);
const bloomPass = new UnrealBloomPass(
  new THREE.Vector2(viewport.width, viewport.height),
  0.38,
  0.58,
  0.95
);
const outputPass = new OutputPass();
composer.addPass(renderPass);
if (!debugParams.has('nobloom')) composer.addPass(bloomPass);
composer.addPass(outputPass);

// ---------------------------------------------------------------------------
// Deterministic helpers
// ---------------------------------------------------------------------------

function mulberry32(seed) {
  let a = seed >>> 0;
  return function random() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rng = mulberry32(0x20260212);
const trng = mulberry32(0x7f1a33);

const rand = (a = 0, b = 1) => a + (b - a) * rng();
const trand = (a = 0, b = 1) => a + (b - a) * trng();
const choose = (list) => list[Math.floor(rng() * list.length)];
const clamp01 = (v) => Math.max(0, Math.min(1, v));

const V3 = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const col = (v) => new THREE.Color(v);

function makeCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return [c, c.getContext('2d')];
}

function makeTexture(canvas, { repeat = false, anisotropy = 8 } = {}) {
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  if (repeat) {
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
  }
  texture.anisotropy = Math.min(anisotropy, renderer.capabilities.getMaxAnisotropy());
  texture.needsUpdate = true;
  return texture;
}

function drawRoundedRect(ctx, x, y, w, h, r) {
  const radius = Math.min(r, w * 0.5, h * 0.5);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function drawHanziLine(ctx, text, cx, cy, fontSize, spacing = 2) {
  const chars = Array.from(text);
  ctx.font = `600 ${fontSize}px "STKaiti","KaiTi","FangSong","Microsoft YaHei",serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const widths = chars.map((c) => ctx.measureText(c).width);
  const total = widths.reduce((a, b) => a + b, 0) + spacing * (chars.length - 1);
  let x = cx - total * 0.5;
  for (let i = 0; i < chars.length; i++) {
    ctx.fillText(chars[i], x + widths[i] * 0.5, cy);
    x += widths[i] + spacing;
  }
}

// ---------------------------------------------------------------------------
// Painted textures
// ---------------------------------------------------------------------------

function makeStoneTexture() {
  const S = 1024;
  const [c, ctx] = makeCanvas(S, S);
  ctx.fillStyle = '#506173';
  ctx.fillRect(0, 0, S, S);

  const r = mulberry32(0x51a7c3);
  const cols = 7;
  const rows = 7;
  const xs = [0];
  const ys = [0];
  for (let i = 1; i < cols; i++) xs.push((i / cols) * S + (r() - 0.5) * 34);
  for (let i = 1; i < rows; i++) ys.push((i / rows) * S + (r() - 0.5) * 30);
  xs.push(S);
  ys.push(S);

  const palette = ['#586a7c', '#4c5f72', '#667280', '#45586b', '#5f6c79', '#526579', '#6b7278'];
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      const x0 = xs[i] + (r() - 0.5) * 5;
      const x1 = xs[i + 1] + (r() - 0.5) * 5;
      const y0 = ys[j] + (r() - 0.5) * 4;
      const y1 = ys[j + 1] + (r() - 0.5) * 4;
      const inset = 4 + r() * 3;
      const c1 = palette[Math.floor(r() * palette.length)];
      const c2 = palette[Math.floor(r() * palette.length)];
      const grad = ctx.createLinearGradient(x0, y0, x1, y1);
      grad.addColorStop(0, c1);
      grad.addColorStop(1, c2);
      ctx.fillStyle = grad;
      ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.moveTo(x0 + inset + (r() - 0.5) * 7, y0 + inset);
      ctx.lineTo(x1 - inset + (r() - 0.5) * 7, y0 + inset + (r() - 0.5) * 5);
      ctx.lineTo(x1 - inset, y1 - inset + (r() - 0.5) * 5);
      ctx.lineTo(x0 + inset - (r() - 0.5) * 7, y1 - inset);
      ctx.closePath();
      ctx.fill();
      ctx.globalAlpha = 1;

      ctx.strokeStyle = 'rgba(27,38,50,.75)';
      ctx.lineWidth = 5;
      ctx.stroke();

      ctx.strokeStyle = 'rgba(177,194,202,.12)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x0 + inset + 10, y0 + inset + 7);
      ctx.lineTo(x1 - inset - 12, y0 + inset + 6);
      ctx.stroke();
    }
  }

  // soft damp patches, grime and a few hairline cracks
  for (let i = 0; i < 55; i++) {
    const x = r() * S;
    const y = r() * S;
    const rad = 18 + r() * 95;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    const warm = r() > 0.7;
    g.addColorStop(0, warm ? 'rgba(130,112,87,.10)' : 'rgba(20,37,49,.13)');
    g.addColorStop(1, 'rgba(20,37,49,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
  for (let i = 0; i < 2800; i++) {
    const light = r() > 0.65;
    ctx.fillStyle = light ? 'rgba(208,211,191,.075)' : 'rgba(10,18,27,.10)';
    const s = 0.5 + r() * 1.8;
    ctx.fillRect(r() * S, r() * S, s, s);
  }
  for (let i = 0; i < 9; i++) {
    let x = r() * S;
    let y = r() * S;
    ctx.strokeStyle = 'rgba(18,28,38,.45)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    for (let k = 0; k < 7; k++) {
      x += (r() - 0.5) * 60;
      y += 10 + r() * 30;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  return makeTexture(c, { repeat: true, anisotropy: 16 });
}

function makeRoofTexture() {
  const S = 512;
  const [c, ctx] = makeCanvas(S, S);
  ctx.fillStyle = '#c5d0c7';
  ctx.fillRect(0, 0, S, S);

  const r = mulberry32(0x0921ff);
  const rowH = 42;
  const tileW = 27;
  for (let y = 0; y < S + rowH; y += rowH) {
    const g = ctx.createLinearGradient(0, y, 0, y + rowH);
    g.addColorStop(0, 'rgba(244,248,235,.35)');
    g.addColorStop(0.5, 'rgba(181,196,184,.18)');
    g.addColorStop(1, 'rgba(78,96,92,.22)');
    ctx.fillStyle = g;
    ctx.fillRect(0, y, S, rowH);

    ctx.strokeStyle = 'rgba(77,94,89,.55)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, y + rowH - 1);
    ctx.lineTo(S, y + rowH - 1);
    ctx.stroke();

    for (let x = ((y / rowH) % 2) * (tileW * 0.5); x < S + tileW; x += tileW) {
      const jitter = (r() - 0.5) * 2.4;
      ctx.strokeStyle = 'rgba(68,85,82,.40)';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(x + jitter, y + 4);
      ctx.quadraticCurveTo(x + jitter + 5, y + rowH * 0.5, x + jitter - 1, y + rowH - 3);
      ctx.stroke();
      ctx.strokeStyle = 'rgba(239,244,231,.27)';
      ctx.lineWidth = 1.3;
      ctx.beginPath();
      ctx.moveTo(x + jitter + 3, y + 5);
      ctx.quadraticCurveTo(x + jitter + 8, y + rowH * 0.5, x + jitter + 2, y + rowH - 4);
      ctx.stroke();
    }
  }
  for (let i = 0; i < 700; i++) {
    ctx.fillStyle = r() > 0.5 ? 'rgba(255,255,240,.08)' : 'rgba(44,60,57,.10)';
    ctx.fillRect(r() * S, r() * S, 1 + r() * 2, 1 + r() * 2);
  }
  return makeTexture(c, { repeat: true, anisotropy: 16 });
}

function makeLanternPaperTexture() {
  const W = 512;
  const H = 512;
  const [c, ctx] = makeCanvas(W, H);
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, '#fff4d6');
  g.addColorStop(0.42, '#fffdf2');
  g.addColorStop(0.78, '#ffe7b8');
  g.addColorStop(1, '#f6cf92');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  const r = mulberry32(0x55a2d0);
  for (let i = 0; i < 800; i++) {
    ctx.fillStyle = r() > 0.5 ? 'rgba(133,91,46,.055)' : 'rgba(255,255,255,.08)';
    ctx.fillRect(r() * W, r() * H, 1 + r() * 2, 1 + r() * 3);
  }
  for (let x = 12; x < W; x += 31) {
    const lineGrad = ctx.createLinearGradient(x - 3, 0, x + 4, 0);
    lineGrad.addColorStop(0, 'rgba(168,113,54,.02)');
    lineGrad.addColorStop(0.45, 'rgba(122,68,30,.52)');
    lineGrad.addColorStop(1, 'rgba(255,250,224,.22)');
    ctx.strokeStyle = lineGrad;
    ctx.lineWidth = 3.0;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, H);
    ctx.stroke();
  }
  ctx.fillStyle = 'rgba(115,53,26,.20)';
  ctx.fillRect(0, 0, W, 23);
  ctx.fillRect(0, H - 23, W, 23);
  // tiny hand-painted gold clouds
  ctx.strokeStyle = 'rgba(172,113,49,.30)';
  ctx.lineWidth = 3;
  for (let i = 0; i < 7; i++) {
    const x = r() * W;
    const y = 60 + r() * (H - 120);
    ctx.beginPath();
    ctx.arc(x, y, 16, 0.2, Math.PI * 1.4);
    ctx.arc(x + 24, y + 6, 12, Math.PI * 0.7, Math.PI * 1.65);
    ctx.stroke();
  }
  return makeTexture(c, { repeat: true, anisotropy: 8 });
}

function makeWindowTexture() {
  const S = 512;
  const [c, ctx] = makeCanvas(S, S);
  const g = ctx.createRadialGradient(S * 0.5, S * 0.45, S * 0.06, S * 0.5, S * 0.55, S * 0.74);
  g.addColorStop(0, '#fff6d3');
  g.addColorStop(0.34, '#ffdda0');
  g.addColorStop(0.78, '#ffad58');
  g.addColorStop(1, '#dc7435');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);

  const r = mulberry32(0x1488aa);
  for (let i = 0; i < 900; i++) {
    ctx.fillStyle = r() > 0.5 ? 'rgba(122,63,24,.045)' : 'rgba(255,255,240,.09)';
    ctx.fillRect(r() * S, r() * S, 1 + r() * 2, 1 + r() * 2);
  }

  // warm interior silhouettes behind the lattice
  ctx.fillStyle = 'rgba(99,43,21,.17)';
  ctx.beginPath();
  ctx.ellipse(168, 378, 64, 26, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(365, 400, 48, 18, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(99,43,21,.14)';
  ctx.fillRect(285, 318, 18, 98);
  ctx.fillRect(306, 330, 9, 83);

  ctx.strokeStyle = '#4a2618';
  ctx.lineWidth = 27;
  ctx.strokeRect(13, 13, S - 26, S - 26);
  ctx.lineWidth = 11;
  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo((S / 4) * i, 15);
    ctx.lineTo((S / 4) * i, S - 15);
    ctx.stroke();
  }
  for (let i = 1; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(15, (S / 3) * i);
    ctx.lineTo(S - 15, (S / 3) * i);
    ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(255,215,142,.38)';
  ctx.lineWidth = 3;
  ctx.strokeRect(30, 30, S - 60, S - 60);
  return makeTexture(c, { anisotropy: 8 });
}

const SIGN_ENTRIES = [
  { text: '上元灯会', size: 54, seal: '元' },
  { text: '桂花酿', size: 66, seal: '酒' },
  { text: '茶', size: 126, seal: '香' },
  { text: '酒', size: 126, seal: '醇' },
  { text: '面具', size: 82, seal: '彩' },
  { text: '糖葫芦', size: 58, seal: '甜' },
  { text: '汤圆', size: 82, seal: '糯' },
  { text: '香囊', size: 82, seal: '安' },
];

function makeSignAtlas() {
  const W = 1024;
  const H = 256;
  const CW = 256;
  const CH = 128;
  const [c, ctx] = makeCanvas(W, H);
  const r = mulberry32(0x5e2711);
  ctx.fillStyle = '#26150f';
  ctx.fillRect(0, 0, W, H);

  for (let row = 0; row < 2; row++) {
    for (let col = 0; col < 4; col++) {
      const x = col * CW;
      const y = row * CH;
      const entry = SIGN_ENTRIES[row * 4 + col];
      const pad = 6;

      const wood = ctx.createLinearGradient(x, y, x + CW, y + CH);
      wood.addColorStop(0, '#351d13');
      wood.addColorStop(0.55, '#24120d');
      wood.addColorStop(1, '#3d2115');
      ctx.fillStyle = wood;
      ctx.fillRect(x + pad, y + pad, CW - pad * 2, CH - pad * 2);

      ctx.strokeStyle = '#ab7736';
      ctx.lineWidth = 7;
      ctx.strokeRect(x + 15, y + 15, CW - 30, CH - 30);
      ctx.strokeStyle = 'rgba(230,183,95,.46)';
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 26, y + 26, CW - 52, CH - 52);

      for (let i = 0; i < 34; i++) {
        ctx.strokeStyle = `rgba(226,176,89,${0.015 + r() * 0.035})`;
        ctx.lineWidth = 1;
        const yy = y + 24 + r() * (CH - 48);
        ctx.beginPath();
        ctx.moveTo(x + 24, yy);
        ctx.lineTo(x + CW - 24, yy);
        ctx.stroke();
      }

      ctx.shadowColor = 'rgba(255,179,71,.55)';
      ctx.shadowBlur = 9;
      ctx.fillStyle = '#e9bd6c';
      const chars = Array.from(entry.text).length;
      const fontSize = chars >= 4 ? 38 : chars === 3 ? 46 : chars === 2 ? 62 : 82;
      drawHanziLine(ctx, entry.text, x + CW * 0.5, y + CH * 0.5, fontSize, 2);
      ctx.shadowBlur = 0;

      // small vermilion seal
      ctx.fillStyle = '#963329';
      ctx.fillRect(x + CW - 48, y + CH - 48, 25, 25);
      ctx.strokeStyle = 'rgba(255,215,157,.75)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x + CW - 46, y + CH - 46, 21, 21);
      ctx.fillStyle = '#f6d8a4';
      ctx.font = '600 14px "STKaiti","KaiTi",serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(entry.seal, x + CW - 35, y + CH - 35);

      // tiny corner studs
      ctx.fillStyle = 'rgba(231,187,109,.55)';
      for (const [sx, sy] of [
        [31, 31],
        [CW - 31, 31],
        [31, CH - 31],
        [CW - 31, CH - 31],
      ]) {
        ctx.beginPath();
        ctx.arc(x + sx, y + sy, 2.8, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
  return makeTexture(c, { anisotropy: 8 });
}

const BANNER_ENTRIES = [
  { text: '上元夜', colors: ['#bd3a2d', '#7e1716'] },
  { text: '花灯', colors: ['#b52e27', '#6f1213'] },
  { text: '祈平安', colors: ['#b74a2d', '#7d2115'] },
  { text: '福满门', colors: ['#a92b2c', '#6f1419'] },
];

function makeBannerAtlas() {
  const W = 512;
  const H = 1024;
  const [c, ctx] = makeCanvas(W, H);
  const r = mulberry32(0x8ab117);

  for (let row = 0; row < 2; row++) {
    for (let col = 0; col < 2; col++) {
      const x = col * 256;
      const y = row * 512;
      const entry = BANNER_ENTRIES[row * 2 + col];
      const g = ctx.createLinearGradient(x, y, x + 80, y + 512);
      g.addColorStop(0, entry.colors[0]);
      g.addColorStop(0.55, entry.colors[1]);
      g.addColorStop(1, '#5b1113');
      ctx.fillStyle = g;
      ctx.fillRect(x + 8, y + 8, 240, 496);

      ctx.strokeStyle = '#d3a252';
      ctx.lineWidth = 6;
      ctx.strokeRect(x + 19, y + 18, 218, 476);
      ctx.strokeStyle = 'rgba(255,219,150,.40)';
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 31, y + 30, 194, 452);

      // woven cloth texture
      for (let i = 0; i < 150; i++) {
        ctx.strokeStyle = r() > 0.5 ? 'rgba(255,209,142,.035)' : 'rgba(44,4,3,.08)';
        ctx.beginPath();
        ctx.moveTo(x + 15 + r() * 226, y + 15);
        ctx.lineTo(x + 15 + r() * 226, y + 497);
        ctx.stroke();
      }

      // cloud scroll motifs
      ctx.strokeStyle = 'rgba(246,200,120,.42)';
      ctx.lineWidth = 3.5;
      for (let i = 0; i < 3; i++) {
        const cy = y + 82 + i * 34;
        ctx.beginPath();
        ctx.arc(x + 128, cy, 38 + i * 7, Math.PI * 1.05, Math.PI * 1.95);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.arc(x + 128, y + 420, 44, Math.PI * 0.05, Math.PI * 0.95);
      ctx.stroke();

      ctx.fillStyle = '#f7d590';
      ctx.shadowColor = 'rgba(255,174,77,.45)';
      ctx.shadowBlur = 8;
      const chars = Array.from(entry.text);
      const step = 82;
      const startY = y + 256 - ((chars.length - 1) * step) / 2;
      ctx.font = '600 72px "STKaiti","KaiTi",serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      for (let i = 0; i < chars.length; i++) {
        ctx.fillText(chars[i], x + 128, startY + i * step);
      }
      ctx.shadowBlur = 0;

      // bottom fringe
      ctx.fillStyle = '#d9a250';
      for (let i = 0; i < 8; i++) {
        ctx.fillRect(x + 33 + i * 25, y + 493, 13, 10);
      }
    }
  }
  return makeTexture(c, { anisotropy: 8 });
}

function makeArtworkTexture() {
  const S = 1024;
  const [c, ctx] = makeCanvas(S, S);
  const bg = ctx.createRadialGradient(S * 0.52, S * 0.48, S * 0.02, S * 0.5, S * 0.5, S * 0.72);
  bg.addColorStop(0, '#fff3c0');
  bg.addColorStop(0.23, '#ffdb8a');
  bg.addColorStop(0.58, '#f8b55e');
  bg.addColorStop(0.82, '#d97c38');
  bg.addColorStop(1, '#8e4527');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, S, S);

  const r = mulberry32(0x3a44bd);
  // translucent vermilion sun disc
  ctx.globalAlpha = 0.55;
  ctx.fillStyle = '#d34f29';
  ctx.beginPath();
  ctx.arc(735, 265, 100, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  // distant painted mountains
  ctx.globalAlpha = 0.18;
  ctx.fillStyle = '#7d3e2e';
  ctx.beginPath();
  ctx.moveTo(0, 820);
  ctx.bezierCurveTo(130, 650, 210, 760, 320, 640);
  ctx.bezierCurveTo(420, 530, 500, 710, 620, 600);
  ctx.bezierCurveTo(720, 505, 820, 690, 1024, 560);
  ctx.lineTo(1024, 1024);
  ctx.lineTo(0, 1024);
  ctx.closePath();
  ctx.fill();
  ctx.globalAlpha = 1;

  // ornate golden clouds and flowing silk
  ctx.lineCap = 'round';
  for (let i = 0; i < 13; i++) {
    const x = r() * S;
    const y = r() * S;
    const scale = 0.5 + r() * 1.5;
    ctx.strokeStyle = `rgba(255,240,180,${0.16 + r() * 0.35})`;
    ctx.lineWidth = 2 + r() * 4;
    ctx.beginPath();
    ctx.moveTo(x - 90 * scale, y);
    ctx.bezierCurveTo(x - 40 * scale, y - 42 * scale, x + 30 * scale, y + 38 * scale, x + 82 * scale, y - 2 * scale);
    ctx.stroke();
    ctx.strokeStyle = `rgba(144,70,38,${0.18 + r() * 0.2})`;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x - 84 * scale, y + 7);
    ctx.bezierCurveTo(x - 30 * scale, y - 32 * scale, x + 28 * scale, y + 45 * scale, x + 77 * scale, y + 4);
    ctx.stroke();
  }

  // six painted medallions, one per lantern panel
  for (let panel = 0; panel < 6; panel++) {
    const cx = (panel + 0.5) * (S / 6);
    const cy = 500;
    ctx.save();
    ctx.translate(cx, cy);
    const disc = ctx.createRadialGradient(0, 0, 10, 0, 0, 135);
    disc.addColorStop(0, 'rgba(255,248,207,.24)');
    disc.addColorStop(0.72, 'rgba(255,227,157,.08)');
    disc.addColorStop(1, 'rgba(188,86,42,0)');
    ctx.fillStyle = disc;
    ctx.beginPath();
    ctx.arc(0, 0, 138, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = 'rgba(255,241,190,.58)';
    ctx.lineWidth = 2.3;
    ctx.beginPath();
    ctx.arc(0, 0, 122, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(128,53,27,.25)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(0, 0, 112, 0, Math.PI * 2);
    ctx.stroke();

    // golden clouds
    ctx.strokeStyle = 'rgba(255,242,188,.48)';
    ctx.lineWidth = 3;
    for (let k = 0; k < 3; k++) {
      ctx.beginPath();
      ctx.arc(-34 + k * 34, -18 + k * 13, 24 + k * 7, Math.PI * 0.2, Math.PI * 1.35);
      ctx.stroke();
    }
    // distant mountain and a little tower silhouette
    ctx.fillStyle = 'rgba(127,58,32,.22)';
    ctx.beginPath();
    ctx.moveTo(-104, 70);
    ctx.bezierCurveTo(-65, -12, -32, 35, -2, 4);
    ctx.bezierCurveTo(30, -24, 60, 30, 105, 62);
    ctx.lineTo(105, 105);
    ctx.lineTo(-104, 105);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = 'rgba(95,45,28,.38)';
    ctx.fillRect(14, 26, 4, 45);
    ctx.beginPath();
    ctx.moveTo(2, 30);
    ctx.lineTo(30, 30);
    ctx.lineTo(23, 20);
    ctx.lineTo(9, 20);
    ctx.closePath();
    ctx.fill();

    // tiny crane-like brush accent
    ctx.strokeStyle = 'rgba(255,245,196,.58)';
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(-45, -48);
    ctx.bezierCurveTo(-15, -70, 16, -65, 44, -52);
    ctx.bezierCurveTo(18, -45, -8, -49, -45, -48);
    ctx.stroke();

    ctx.restore();
  }

  // stylized koi, one rising, one falling
  drawKoi(ctx, 455, 640, 1.32, -0.4, '#d96933', '#ffe7ac');
  drawKoi(ctx, 655, 455, 0.92, Math.PI * 0.72, '#e48d45', '#fff0c8');

  // lotus at the base
  ctx.globalAlpha = 0.75;
  for (let i = 0; i < 7; i++) {
    const a = -Math.PI + (i / 6) * Math.PI;
    ctx.save();
    ctx.translate(520, 842);
    ctx.rotate(a + Math.PI * 0.5);
    const petal = ctx.createLinearGradient(0, 0, 0, -90);
    petal.addColorStop(0, 'rgba(255,224,164,.55)');
    petal.addColorStop(1, 'rgba(233,137,75,.1)');
    ctx.fillStyle = petal;
    ctx.beginPath();
    ctx.ellipse(0, -45, 28, 65, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  ctx.globalAlpha = 1;

  // border bands with tiny characters
  ctx.strokeStyle = 'rgba(255,226,157,.6)';
  ctx.lineWidth = 6;
  ctx.strokeRect(22, 22, S - 44, S - 44);
  ctx.strokeStyle = 'rgba(112,49,29,.4)';
  ctx.lineWidth = 2;
  ctx.strokeRect(44, 44, S - 88, S - 88);
  ctx.fillStyle = 'rgba(255,235,178,.74)';
  ctx.font = '600 34px "STKaiti","KaiTi",serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('上 元 灯 影', S * 0.5, 86);
  ctx.fillText('花 好 月 圆', S * 0.5, S - 82);

  // paper fibres
  for (let i = 0; i < 1800; i++) {
    ctx.fillStyle = r() > 0.5 ? 'rgba(255,255,230,.05)' : 'rgba(109,50,25,.04)';
    ctx.fillRect(r() * S, r() * S, 1 + r() * 2, 1 + r() * 2);
  }
  return makeTexture(c, { anisotropy: 8 });
}

function drawKoi(ctx, x, y, scale, rot, bodyColor, finColor) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(scale, scale);

  ctx.globalAlpha = 0.2;
  ctx.fillStyle = finColor;
  ctx.beginPath();
  ctx.ellipse(12, 0, 84, 36, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 0.88;

  const body = ctx.createLinearGradient(-60, 0, 90, 0);
  body.addColorStop(0, finColor);
  body.addColorStop(0.62, bodyColor);
  body.addColorStop(1, '#8d351f');
  ctx.fillStyle = body;
  ctx.beginPath();
  ctx.moveTo(-85, 4);
  ctx.bezierCurveTo(-38, -34, 46, -36, 88, -4);
  ctx.bezierCurveTo(49, 34, -37, 34, -85, 4);
  ctx.fill();

  ctx.fillStyle = finColor;
  ctx.globalAlpha = 0.6;
  ctx.beginPath();
  ctx.moveTo(-77, 0);
  ctx.bezierCurveTo(-135, -42, -150, -14, -166, -38);
  ctx.bezierCurveTo(-138, 18, -118, 31, -77, 8);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-25, -24);
  ctx.quadraticCurveTo(12, -67, 44, -21);
  ctx.quadraticCurveTo(11, -27, -19, -9);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(38, 19);
  ctx.quadraticCurveTo(63, 61, 88, 27);
  ctx.quadraticCurveTo(56, 31, 34, 10);
  ctx.fill();

  ctx.globalAlpha = 0.92;
  ctx.strokeStyle = 'rgba(255,246,208,.8)';
  ctx.lineWidth = 2.4;
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.arc(20 + i * 14, 0, 9 - i, 0.2, Math.PI * 1.25);
    ctx.stroke();
  }
  ctx.fillStyle = '#33201a';
  ctx.beginPath();
  ctx.arc(64, -8, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function makeGlowTexture(inner = '255,251,232', outer = '255,164,74') {
  const S = 256;
  const [c, ctx] = makeCanvas(S, S);
  const g = ctx.createRadialGradient(S * 0.5, S * 0.5, 0, S * 0.5, S * 0.5, S * 0.5);
  g.addColorStop(0, `rgba(${inner},1)`);
  g.addColorStop(0.16, `rgba(${inner},.92)`);
  g.addColorStop(0.42, `rgba(${outer},.34)`);
  g.addColorStop(0.72, `rgba(${outer},.08)`);
  g.addColorStop(1, `rgba(${outer},0)`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  return makeTexture(c, { anisotropy: 2 });
}

function makeMoonTexture() {
  const S = 512;
  const [c, ctx] = makeCanvas(S, S);
  ctx.clearRect(0, 0, S, S);
  let g = ctx.createRadialGradient(256, 256, 40, 256, 256, 256);
  g.addColorStop(0, 'rgba(255,247,217,.82)');
  g.addColorStop(0.22, 'rgba(255,239,196,.34)');
  g.addColorStop(0.55, 'rgba(255,217,144,.09)');
  g.addColorStop(1, 'rgba(255,196,110,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);

  ctx.save();
  ctx.beginPath();
  ctx.arc(256, 256, 105, 0, Math.PI * 2);
  ctx.clip();
  g = ctx.createRadialGradient(224, 224, 10, 256, 256, 110);
  g.addColorStop(0, '#fffae8');
  g.addColorStop(0.58, '#ffeec8');
  g.addColorStop(1, '#efca8e');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  const r = mulberry32(0x0be1e5);
  for (let i = 0; i < 16; i++) {
    const x = 170 + r() * 175;
    const y = 172 + r() * 165;
    const rad = 4 + r() * 18;
    ctx.fillStyle = `rgba(189,150,100,${0.035 + r() * 0.055})`;
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
  ctx.strokeStyle = 'rgba(255,246,214,.34)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(256, 256, 108, 0, Math.PI * 2);
  ctx.stroke();
  return makeTexture(c, { anisotropy: 4 });
}

function makeSnowBumpTexture() {
  const S = 256;
  const [c, ctx] = makeCanvas(S, S);
  ctx.fillStyle = '#7f7f7f';
  ctx.fillRect(0, 0, S, S);
  const r = mulberry32(0x9c41d2);
  for (let i = 0; i < 950; i++) {
    const x = r() * S;
    const y = r() * S;
    const rad = 1 + Math.pow(r(), 2.2) * 10;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    const light = r() > 0.46;
    g.addColorStop(0, light ? 'rgba(255,255,255,.34)' : 'rgba(34,42,52,.24)');
    g.addColorStop(1, 'rgba(127,127,127,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
  for (let i = 0; i < 1600; i++) {
    ctx.fillStyle = r() > 0.5 ? 'rgba(255,255,255,.10)' : 'rgba(24,30,38,.08)';
    ctx.fillRect(r() * S, r() * S, 1 + r() * 2, 1 + r() * 2);
  }
  const texture = makeTexture(c, { repeat: true, anisotropy: 4 });
  texture.colorSpace = THREE.NoColorSpace;
  texture.repeat.set(3, 3);
  return texture;
}

const snowBumpTexture = makeSnowBumpTexture();

function makeSteamTexture() {
  const W = 256;
  const H = 256;
  const [c, ctx] = makeCanvas(W, H);
  ctx.clearRect(0, 0, W, H);
  const r = mulberry32(0xcc3133);
  for (let i = 0; i < 20; i++) {
    const x = 45 + r() * 166;
    const y = 60 + r() * 135;
    const rad = 22 + r() * 55;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    g.addColorStop(0, `rgba(255,244,226,${0.07 + r() * 0.08})`);
    g.addColorStop(0.55, `rgba(241,228,214,${0.04 + r() * 0.045})`);
    g.addColorStop(1, 'rgba(235,221,209,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
  return makeTexture(c, { anisotropy: 2 });
}

// ---------------------------------------------------------------------------
// Materials
// ---------------------------------------------------------------------------

function makeToonRamp() {
  const data = new Uint8Array([42, 42, 42, 255, 112, 112, 112, 255, 196, 196, 196, 255, 255, 255, 255, 255]);
  const tex = new THREE.DataTexture(data, 4, 1, THREE.RGBAFormat);
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

const gradientMap = makeToonRamp();
const stoneTexture = makeStoneTexture();
const roofTexture = makeRoofTexture();
const lanternTexture = makeLanternPaperTexture();
const windowTexture = makeWindowTexture();
const signAtlas = makeSignAtlas();
const bannerAtlas = makeBannerAtlas();
const artworkTexture = makeArtworkTexture();
const glowTexture = makeGlowTexture();
const moonTexture = makeMoonTexture();
const steamTexture = makeSteamTexture();

function makeShadowTexture() {
  const S = 512;
  const [c, ctx] = makeCanvas(S, S);
  const g = ctx.createRadialGradient(S * 0.5, S * 0.5, S * 0.08, S * 0.5, S * 0.5, S * 0.5);
  g.addColorStop(0, 'rgba(0,0,0,.72)');
  g.addColorStop(0.45, 'rgba(0,0,0,.48)');
  g.addColorStop(0.72, 'rgba(0,0,0,.17)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  return makeTexture(c, { anisotropy: 4 });
}

const shadowTexture = makeShadowTexture();

const toonCache = new Map();
function toon(color) {
  const key = String(color);
  if (!toonCache.has(key)) {
    const material = new THREE.MeshToonMaterial({
      color: new THREE.Color(color),
      gradientMap,
    });
    material.userData.batch = 'toon';
    toonCache.set(key, material);
  }
  return toonCache.get(key);
}

const clothCache = new Map();
function cloth(color) {
  const key = String(color);
  if (!clothCache.has(key)) {
    const material = new THREE.MeshToonMaterial({
      color: new THREE.Color(color),
      gradientMap,
      side: THREE.DoubleSide,
    });
    material.userData.batch = 'cloth';
    clothCache.set(key, material);
  }
  return clothCache.get(key);
}

const roofCache = new Map();
function roofMat(color) {
  const key = String(color);
  if (!roofCache.has(key)) {
    const material = new THREE.MeshToonMaterial({
      color: new THREE.Color(color),
      map: roofTexture,
      gradientMap,
    });
    material.userData.batch = 'roof';
    roofCache.set(key, material);
  }
  return roofCache.get(key);
}

const windowCache = new Map();
function windowMat(color = 0xffd49a, bright = 1.28) {
  const key = `${color}-${bright}`;
  if (!windowCache.has(key)) {
    const material = new THREE.MeshBasicMaterial({
      color: new THREE.Color(color).multiplyScalar(bright),
      map: windowTexture,
      toneMapped: false,
    });
    material.userData.batch = 'window';
    windowCache.set(key, material);
  }
  return windowCache.get(key);
}

function glowMat(color = 0xffc06a, bright = 1.38) {
  const material = new THREE.MeshBasicMaterial({
    color: new THREE.Color(color).multiplyScalar(bright),
    toneMapped: false,
  });
  material.userData.batch = 'glow';
  return material;
}

const signMaterial = new THREE.MeshBasicMaterial({
  map: signAtlas,
  color: 0xffffff,
  toneMapped: false,
  side: THREE.DoubleSide,
});
signMaterial.userData.batch = 'sign';

const bannerMaterial = new THREE.MeshBasicMaterial({
  map: bannerAtlas,
  color: 0xffffff,
  toneMapped: false,
  side: THREE.DoubleSide,
});
bannerMaterial.userData.batch = 'banner';

// stone paving
const groundMaterialBase = new THREE.MeshStandardMaterial({
  map: stoneTexture,
  color: 0xd2d9dd,
  roughness: 0.39,
  metalness: 0.08,
  envMapIntensity: 0.2,
});
const groundMaterialStreet = new THREE.MeshStandardMaterial({
  map: stoneTexture,
  color: 0xffe0b8,
  roughness: 0.31,
  metalness: 0.12,
  envMapIntensity: 0.2,
});
const groundMaterialDark = new THREE.MeshStandardMaterial({
  map: stoneTexture,
  color: 0x8d99a2,
  roughness: 0.48,
  metalness: 0.05,
});

// ---------------------------------------------------------------------------
// Sky, stars, moon and light
// ---------------------------------------------------------------------------

const skyUniforms = {
  uTop: { value: new THREE.Color(0x020713) },
  uMid: { value: new THREE.Color(0x07192c) },
  uHorizon: { value: new THREE.Color(0x13283f) },
  uWarm: { value: new THREE.Color(0x602b1f) },
};
const sky = new THREE.Mesh(
  new THREE.SphereGeometry(230, 32, 20),
  new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: skyUniforms,
    vertexShader: /* glsl */ `
      varying vec3 vDir;
      void main() {
        vDir = normalize(position);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      varying vec3 vDir;
      uniform vec3 uTop;
      uniform vec3 uMid;
      uniform vec3 uHorizon;
      uniform vec3 uWarm;
      void main() {
        float h = clamp(vDir.y * 1.35 + 0.34, 0.0, 1.0);
        vec3 color = mix(uHorizon, uMid, smoothstep(0.08, 0.48, h));
        color = mix(color, uTop, smoothstep(0.45, 1.0, h));
        float horizonGlow = pow(clamp(1.0 - abs(vDir.y + 0.015) * 4.2, 0.0, 1.0), 3.0);
        float sideGlow = pow(clamp(-vDir.x * 0.65 + 0.35, 0.0, 1.0), 3.0);
        color += uWarm * horizonGlow * (0.24 + sideGlow * 0.55);
        float haze = sin(vDir.x * 5.0 + vDir.z * 3.3) * 0.5 + 0.5;
        color += vec3(0.012, 0.022, 0.038) * haze * smoothstep(0.0, 0.5, 1.0 - h);
        gl_FragColor = vec4(color, 1.0);
      }
    `,
  })
);
sky.renderOrder = -100;
sky.frustumCulled = false;
scene.add(sky);

function makeStars() {
  const N = 980;
  const positions = new Float32Array(N * 3);
  const phases = new Float32Array(N);
  const sizes = new Float32Array(N);
  const colors = new Float32Array(N * 3);
  const r = mulberry32(0x61d3aa);
  for (let i = 0; i < N; i++) {
    const theta = r() * Math.PI * 2;
    const phi = Math.acos(0.08 + r() * 0.9);
    const radius = 145 + r() * 65;
    const x = Math.sin(phi) * Math.cos(theta) * radius;
    const y = Math.cos(phi) * radius + 16;
    const z = Math.sin(phi) * Math.sin(theta) * radius;
    positions.set([x, y, z], i * 3);
    phases[i] = r() * Math.PI * 2;
    sizes[i] = 0.9 + Math.pow(r(), 2.2) * 3.4;
    const tint = r();
    colors.set(tint > 0.84 ? [1.0, 0.76, 0.52] : tint > 0.5 ? [0.78, 0.87, 1.0] : [0.94, 0.96, 1.0], i * 3);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
  geo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geo.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
  const material = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    uniforms: {
      uTime: { value: 0 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio || 1, 1.45) },
    },
    vertexShader: /* glsl */ `
      attribute float aPhase;
      attribute float aSize;
      attribute vec3 aColor;
      varying vec3 vColor;
      varying float vTwinkle;
      uniform float uTime;
      uniform float uPixelRatio;
      void main() {
        vColor = aColor;
        vTwinkle = 0.55 + 0.45 * sin(uTime * 0.7 + aPhase);
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = aSize * uPixelRatio * (2.5 + 25.0 / max(1.0, -mv.z * 0.06));
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      varying vec3 vColor;
      varying float vTwinkle;
      void main() {
        vec2 p = gl_PointCoord - 0.5;
        float d = length(p) * 2.0;
        float core = smoothstep(0.46, 0.0, d);
        float halo = smoothstep(1.0, 0.2, d) * 0.36;
        float alpha = (core + halo) * vTwinkle * 1.25;
        if (alpha < 0.01) discard;
        gl_FragColor = vec4(vColor * (0.9 + core * 0.75), alpha);
      }
    `,
  });
  const points = new THREE.Points(geo, material);
  points.renderOrder = -90;
  points.frustumCulled = false;
  scene.add(points);
  return points;
}
const stars = makeStars();

const moon = new THREE.Sprite(
  new THREE.SpriteMaterial({
    map: moonTexture,
    color: 0xfff4d1,
    transparent: true,
    depthWrite: false,
    fog: false,
    toneMapped: false,
  })
);
moon.position.set(-12, 19, -158);
moon.scale.set(31, 31, 1);
moon.renderOrder = -80;
scene.add(moon);

const underShadow = new THREE.Mesh(
  new THREE.PlaneGeometry(72, 72),
  new THREE.MeshBasicMaterial({
    map: shadowTexture,
    transparent: true,
    opacity: 0.9,
    depthWrite: false,
    toneMapped: false,
  })
);
underShadow.rotation.x = -Math.PI / 2;
underShadow.position.y = -3.34;
underShadow.renderOrder = -2;
scene.add(underShadow);

const hemi = new THREE.HemisphereLight(0x6484bd, 0x6b3524, 0.96);
scene.add(hemi);

const ambient = new THREE.AmbientLight(0x243758, 0.72);
scene.add(ambient);

const moonLight = new THREE.DirectionalLight(0xafc9ff, 2.3);
moonLight.position.set(-24, 37, 19);
moonLight.castShadow = true;
moonLight.shadow.mapSize.set(2048, 2048);
moonLight.shadow.camera.left = -24;
moonLight.shadow.camera.right = 24;
moonLight.shadow.camera.top = 26;
moonLight.shadow.camera.bottom = -24;
moonLight.shadow.camera.near = 0.5;
moonLight.shadow.camera.far = 100;
moonLight.shadow.bias = -0.0008;
moonLight.shadow.normalBias = 0.025;
moonLight.shadow.radius = 2.2;
scene.add(moonLight);

const warmFill = new THREE.DirectionalLight(0xff9d59, 0.62);
warmFill.position.set(22, 16, 28);
scene.add(warmFill);

const frontFill = new THREE.DirectionalLight(0x91afd7, 1.0);
frontFill.position.set(4, 19, 32);
scene.add(frontFill);

function pointLight(color, intensity, distance, x, y, z) {
  const light = new THREE.PointLight(color, intensity, distance, 1.7);
  light.position.set(x, y, z);
  scene.add(light);
  return light;
}

const floatLight = pointLight(0xffa957, 280, 24, 0, 5.5, -1.7);
const bridgeLight = pointLight(0xff9c51, 86, 13, 0, 3.2, 7.2);
const leftStreetLight = pointLight(0xffad63, 58, 12, -3.3, 3.5, -1.0);
const rightStreetLight = pointLight(0xff9b4c, 64, 13, 3.6, 3.4, 5.0);
const southStreetLight = pointLight(0xffa456, 76, 14, 0.4, 3.8, 11.2);

// ---------------------------------------------------------------------------
// Static geometry batching
// ---------------------------------------------------------------------------

const staticRoot = new THREE.Group();

const UNIT_BOX = new THREE.BoxGeometry(1, 1, 1);
const UNIT_SPHERE = new THREE.SphereGeometry(0.5, 14, 10);
const UNIT_CYL = new THREE.CylinderGeometry(0.5, 0.5, 1, 12);
const UNIT_CONE = new THREE.ConeGeometry(0.5, 1, 12);
const UNIT_TORUS = new THREE.TorusGeometry(0.5, 0.06, 6, 20);
const UNIT_PLANE = new THREE.PlaneGeometry(1, 1);

function meshStatic(parent, geometry, material, opts = {}) {
  const mesh = new THREE.Mesh(geometry, material);
  const {
    x = 0,
    y = 0,
    z = 0,
    rx = 0,
    ry = 0,
    rz = 0,
    sx = 1,
    sy = 1,
    sz = 1,
    outline = false,
    cast = true,
    receive = true,
  } = opts;
  mesh.position.set(x, y, z);
  mesh.rotation.set(rx, ry, rz);
  mesh.scale.set(sx, sy, sz);
  mesh.castShadow = cast;
  mesh.receiveShadow = receive;
  mesh.userData.outline = outline;
  mesh.userData.batch = material.userData.batch || 'toon';
  parent.add(mesh);
  return mesh;
}

function addBox(parent, w, h, d, color, x, y, z, opts = {}) {
  return meshStatic(parent, UNIT_BOX, toon(color), {
    x,
    y,
    z,
    sx: w,
    sy: h,
    sz: d,
    ...opts,
  });
}

function addCylinder(parent, radiusTop, radiusBottom, height, color, x, y, z, opts = {}) {
  const geometry = new THREE.CylinderGeometry(radiusTop, radiusBottom, height, opts.segments || 10);
  const { segments, ...rest } = opts;
  return meshStatic(parent, geometry, toon(color), { x, y, z, ...rest });
}

function addSphere(parent, radius, color, x, y, z, opts = {}) {
  const { segments, sx = 1, sy = 1, sz = 1, ...rest } = opts;
  const geometry = segments
    ? new THREE.SphereGeometry(0.5, segments, Math.max(6, Math.round(segments * 0.7)))
    : UNIT_SPHERE;
  return meshStatic(parent, geometry, toon(color), {
    x,
    y,
    z,
    sx: radius * 2 * sx,
    sy: radius * 2 * sy,
    sz: radius * 2 * sz,
    ...rest,
  });
}

function addTube(parent, curve, radius, color, opts = {}) {
  const geometry = new THREE.TubeGeometry(
    curve,
    opts.segments || Math.max(8, Math.ceil(curve.points.length * 4)),
    radius,
    opts.radialSegments || 5,
    !!opts.closed
  );
  return meshStatic(parent, geometry, toon(color), {
    x: opts.x || 0,
    y: opts.y || 0,
    z: opts.z || 0,
    outline: opts.outline || false,
    cast: opts.cast ?? false,
    receive: opts.receive ?? true,
  });
}

function addPlanePatch(parent, w, h, color, material, x, y, z, opts = {}) {
  return meshStatic(parent, UNIT_PLANE, material, {
    x,
    y,
    z,
    sx: w,
    sy: h,
    sz: 1,
    ...opts,
  });
}

// ---------------------------------------------------------------------------
// Batch baking
// ---------------------------------------------------------------------------

const snowSurfaceMaterial = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  roughness: 0.96,
  metalness: 0.01,
  vertexColors: true,
});
snowSurfaceMaterial.userData.batch = 'snow';
let snowSurfaceMesh = null;

const snowBatchMaterial = new THREE.MeshStandardMaterial({
  color: 0xe9f0f3,
  roughness: 0.94,
  metalness: 0.0,
  vertexColors: true,
  bumpMap: snowBumpTexture,
  bumpScale: 0.045,
  transparent: true,
  opacity: 0,
  depthWrite: false,
});

const batchMaterials = {
  toon: new THREE.MeshToonMaterial({
    color: 0xffffff,
    gradientMap,
    vertexColors: true,
  }),
  cloth: new THREE.MeshToonMaterial({
    color: 0xffffff,
    gradientMap,
    vertexColors: true,
    side: THREE.DoubleSide,
  }),
  roof: new THREE.MeshToonMaterial({
    color: 0xffffff,
    gradientMap,
    map: roofTexture,
    vertexColors: true,
  }),
  window: new THREE.MeshBasicMaterial({
    color: 0xffffff,
    map: windowTexture,
    vertexColors: true,
    toneMapped: false,
  }),
  glow: new THREE.MeshBasicMaterial({
    color: 0xffffff,
    vertexColors: true,
    toneMapped: false,
  }),
  sign: new THREE.MeshBasicMaterial({
    color: 0xffffff,
    map: signAtlas,
    vertexColors: true,
    toneMapped: false,
    side: THREE.DoubleSide,
  }),
  banner: new THREE.MeshBasicMaterial({
    color: 0xffffff,
    map: bannerAtlas,
    vertexColors: true,
    toneMapped: false,
    side: THREE.DoubleSide,
  }),
  snow: snowBatchMaterial,
};

const outlineMaterial = new THREE.ShaderMaterial({
  side: THREE.BackSide,
  depthWrite: true,
  uniforms: {
    uThickness: { value: 0.038 },
    uColor: { value: new THREE.Color(0x201211) },
  },
  vertexShader: /* glsl */ `
    uniform float uThickness;
    void main() {
      vec3 n = normalize(normalMatrix * normal);
      vec4 mv = modelViewMatrix * vec4(position, 1.0);
      mv.xyz += n * uThickness;
      gl_Position = projectionMatrix * mv;
    }
  `,
  fragmentShader: /* glsl */ `
    uniform vec3 uColor;
    void main() {
      gl_FragColor = vec4(uColor, 1.0);
    }
  `,
});

function cleanForBatch(geometry, matrix, color) {
  let g = geometry.index ? geometry.toNonIndexed() : geometry.clone();
  g.applyMatrix4(matrix);
  for (const name of Object.keys(g.attributes)) {
    if (!['position', 'normal', 'uv', 'color'].includes(name)) g.deleteAttribute(name);
  }
  if (!g.attributes.normal) g.computeVertexNormals();
  if (!g.attributes.uv) {
    const count = g.attributes.position.count;
    g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(count * 2), 2));
  }
  const count = g.attributes.position.count;
  const colors = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    colors[i * 3] = color.r;
    colors[i * 3 + 1] = color.g;
    colors[i * 3 + 2] = color.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  return g;
}

function bakeStatic(root) {
  root.updateMatrixWorld(true);
  const buckets = {
    toon: [],
    cloth: [],
    roof: [],
    window: [],
    glow: [],
    sign: [],
    banner: [],
    snow: [],
    outline: [],
  };

  root.traverse((obj) => {
    if (!obj.isMesh || obj.isInstancedMesh) return;
    const batch = obj.userData.batch;
    if (!batch || !batchMaterials[batch]) return;
    const color = obj.material?.color ? obj.material.color.clone() : new THREE.Color(0xffffff);
    const geo = cleanForBatch(obj.geometry, obj.matrixWorld, color);
    buckets[batch].push(geo);
    if (obj.userData.outline) {
      const outlineGeo = cleanForBatch(obj.geometry, obj.matrixWorld, new THREE.Color(0x201211));
      buckets.outline.push(outlineGeo);
    }
  });

  const meshes = [];
  for (const key of Object.keys(batchMaterials)) {
    if (!buckets[key].length) continue;
    const merged = mergeGeometries(buckets[key], false);
    for (const g of buckets[key]) g.dispose();
    if (!merged) {
      console.warn('Failed to merge batch', key);
      continue;
    }
    merged.computeBoundingSphere();
    const mesh = new THREE.Mesh(merged, batchMaterials[key]);
    const casts = key === 'toon' || key === 'cloth' || key === 'roof';
    mesh.castShadow = casts;
    mesh.receiveShadow = key === 'snow' ? true : casts;
    mesh.frustumCulled = true;
    if (key === 'snow') {
      snowSurfaceMesh = mesh;
      mesh.visible = false;
      mesh.renderOrder = -5;
    }
    scene.add(mesh);
    meshes.push(mesh);
  }

  if (buckets.outline.length) {
    const merged = mergeGeometries(buckets.outline, false);
    for (const g of buckets.outline) g.dispose();
    if (merged) {
      merged.computeBoundingSphere();
      const outline = new THREE.Mesh(merged, outlineMaterial);
      outline.castShadow = false;
      outline.receiveShadow = false;
      outline.frustumCulled = true;
      scene.add(outline);
      meshes.push(outline);
    }
  }

  // The authored hierarchy is no longer needed.
  root.traverse((obj) => {
    if (obj.isMesh) obj.geometry.dispose?.();
  });
  root.clear();
  return meshes;
}

// ---------------------------------------------------------------------------
// The miniature itself
// ---------------------------------------------------------------------------

const lanternSpecs = [];
const waterLanternSpecs = [];
const steamSpecs = [];

function addLantern(x, y, z, size = 0.48, color = '#ff9d4b', opts = {}) {
  lanternSpecs.push({
    position: V3(x, y, z),
    size,
    color: new THREE.Color(color),
    tassel: opts.tassel !== false,
    glow: opts.glow ?? 1,
  });
}

function addSteam(x, y, z, opts = {}) {
  steamSpecs.push({ position: V3(x, y, z), size: opts.size || 1.5, phase: rand(0, Math.PI * 2) });
}

// ---------------------------------------------------------------------------
// Square plinth, paving and the little canal
// ---------------------------------------------------------------------------

function addGroundPlane(w, d, x, z, material, y = 0.008, uvScale = 4.6) {
  const geometry = new THREE.PlaneGeometry(w, d);
  const uv = geometry.attributes.uv;
  for (let i = 0; i < uv.count; i++) {
    uv.setXY(i, uv.getX(i) * (w / uvScale), uv.getY(i) * (d / uvScale));
  }
  uv.needsUpdate = true;
  const mesh = new THREE.Mesh(geometry, material);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.set(x, y, z);
  mesh.receiveShadow = true;
  scene.add(mesh);
  return mesh;
}

function buildBase() {
  const B = staticRoot;

  // deep wooden plinth
  addBox(B, 31.4, 1.55, 31.4, '#442a1e', 0, -1.72, 0, { outline: true });
  addBox(B, 31.15, 0.16, 31.15, '#4e2a1d', 0, -2.5, 0, { outline: false });
  addBox(B, 31.75, 0.20, 31.75, '#a8783c', 0, -2.42, 0, { outline: false });
  addBox(B, 31.82, 0.16, 31.82, '#c8994d', 0, -0.95, 0, { outline: false });

  // gold hairlines and side panels
  const plinthGlow = glowMat('#d8aa5c', 1.05);
  for (const side of [-1, 1]) {
    addBox(B, 0.10, 0.08, 31.82, '#e0b669', side * 15.91, -1.03, 0);
    addBox(B, 0.10, 0.08, 31.82, '#d6a554', side * 15.91, -2.36, 0);
    addBox(B, 31.82, 0.08, 0.10, '#e0b669', 0, -1.03, side * 15.91);
    addBox(B, 31.82, 0.08, 0.10, '#d6a554', 0, -2.36, side * 15.91);
    meshStatic(B, UNIT_BOX, plinthGlow, {
      x: side * 15.94,
      y: -0.985,
      z: 0,
      sx: 0.045,
      sy: 0.04,
      sz: 31.8,
      cast: false,
      receive: false,
    });
    meshStatic(B, UNIT_BOX, plinthGlow, {
      x: 0,
      y: -0.985,
      z: side * 15.94,
      sx: 31.8,
      sy: 0.04,
      sz: 0.045,
      cast: false,
      receive: false,
    });
  }

  // carved panels on the visible front and right faces
  for (let i = 0; i < 6; i++) {
    const x = -12.5 + i * 5.0;
    addBox(B, 3.55, 0.82, 0.09, '#2a1712', x, -1.74, 15.74, { outline: false });
    addBox(B, 3.72, 0.06, 0.12, '#a8793e', x, -1.31, 15.80);
    addBox(B, 3.72, 0.06, 0.12, '#a8793e', x, -2.17, 15.80);
    addBox(B, 0.10, 0.90, 0.14, '#7d542f', x - 1.88, -1.74, 15.80);
    addBox(B, 0.10, 0.90, 0.14, '#7d542f', x + 1.88, -1.74, 15.80);
    addSphere(B, 0.10, '#c7984c', x, -1.74, 15.82, { sx: 1, sy: 1, sz: 0.28 });
  }
  for (let i = 0; i < 6; i++) {
    const z = -12.5 + i * 5.0;
    addBox(B, 0.09, 0.82, 3.55, '#2a1712', 15.74, -1.74, z);
    addBox(B, 0.12, 0.06, 3.72, '#a8793e', 15.80, -1.31, z);
    addBox(B, 0.12, 0.06, 3.72, '#a8793e', 15.80, -2.17, z);
    addSphere(B, 0.10, '#c7984c', 15.82, -1.74, z, { sx: 0.28, sy: 1, sz: 1 });
  }

  // gold corner shoes
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      addBox(B, 0.40, 1.55, 0.40, '#b9863e', sx * 15.55, -1.73, sz * 15.55, { outline: true });
      addSphere(B, 0.16, '#e0bb6d', sx * 15.55, -2.33, sz * 15.55, { sx: 0.8, sy: 0.6, sz: 0.8 });
    }
  }

  // carved nameplate on the front of the base
  const plaque = new THREE.Group();
  plaque.position.set(0, -1.38, 15.85);
  B.add(plaque);
  addBox(plaque, 3.35, 1.06, 0.12, '#2a1711', 0, 0, 0, { outline: true });
  addBox(plaque, 3.52, 0.09, 0.16, '#c79a50', 0, 0.53, 0.02);
  addBox(plaque, 3.52, 0.09, 0.16, '#c79a50', 0, -0.53, 0.02);
  addSign(plaque, 0, 2.2, 1.0, 0, 0, 0.08);
  for (const sx of [-1, 1]) {
    addSphere(plaque, 0.09, '#e2bd70', sx * 1.62, 0, 0.10, { sx: 1, sy: 1, sz: 0.4 });
  }

  // a raised square frame around the little world, interrupted by the canal
  addBox(B, 30.6, 0.17, 0.82, '#6e5a46', 0, -0.015, 14.95);
  addBox(B, 30.62, 0.055, 0.10, '#d6aa5c', 0, 0.075, 15.27);
  addBox(B, 30.62, 0.04, 0.07, '#e7c77f', 0, 0.07, 14.62);
  addBox(B, 30.6, 0.17, 0.82, '#6e5a46', 0, -0.015, -14.95);
  addBox(B, 30.62, 0.055, 0.10, '#d6aa5c', 0, 0.075, -15.27);
  addBox(B, 30.62, 0.04, 0.07, '#e7c77f', 0, 0.07, -14.62);
  for (const side of [-1, 1]) {
    addBox(B, 0.82, 0.17, 20.4, '#6e5a46', side * 14.95, -0.015, -4.65);
    addBox(B, 0.82, 0.17, 5.8, '#6e5a46', side * 14.95, -0.015, 12.0);
    addBox(B, 0.10, 0.055, 20.4, '#d6aa5c', side * 15.27, 0.075, -4.65);
    addBox(B, 0.10, 0.055, 5.8, '#d6aa5c', side * 15.27, 0.075, 12.0);
    addBox(B, 0.07, 0.04, 20.4, '#e7c77f', side * 14.62, 0.07, -4.65);
    addBox(B, 0.07, 0.04, 5.8, '#e7c77f', side * 14.62, 0.07, 12.0);
  }
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      addBox(B, 1.25, 0.08, 1.25, '#8a6a47', sx * 14.55, 0.052, sz * 14.55, { outline: false });
      addBox(B, 0.95, 0.035, 0.95, '#c89c53', sx * 14.55, 0.10, sz * 14.55, { outline: false });
      addSphere(B, 0.16, '#e4bd72', sx * 14.55, 0.115, sz * 14.55, { sx: 1, sy: 0.22, sz: 1 });
    }
  }

  // low parapet posts at the corners of the square display base
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      addBox(B, 0.38, 0.72, 0.38, '#665245', sx * 14.45, 0.36, sz * 14.45, { outline: true });
      addBox(B, 0.50, 0.09, 0.50, '#d0a257', sx * 14.45, 0.75, sz * 14.45, { outline: false });
      addSphere(B, 0.11, '#e3bc70', sx * 14.45, 0.84, sz * 14.45, { sx: 1, sy: 1.4, sz: 1 });
      addLantern(sx * 14.45, 1.10, sz * 14.45, 0.34, '#ff9b49');
    }
  }
  // low stone rails, open where the canal leaves the base
  const railColor = '#4e5c66';
  addBox(B, 28.2, 0.16, 0.16, railColor, 0, 0.49, 14.45, { outline: false });
  addBox(B, 28.2, 0.16, 0.16, railColor, 0, 0.49, -14.45, { outline: false });
  for (const side of [-1, 1]) {
    addBox(B, 0.16, 0.16, 18.1, railColor, side * 14.45, 0.49, -4.4, { outline: false });
    addBox(B, 0.16, 0.16, 4.4, railColor, side * 14.45, 0.49, 12.15, { outline: false });
    for (const z of [-13.4, -9.4, -5.0, 10.4, 13.4]) {
      addBox(B, 0.24, 0.55, 0.24, '#6d5a4b', side * 14.45, 0.29, z, { outline: false });
    }
  }
  for (const x of [-12.6, -8.4, -4.2, 0, 4.2, 8.4, 12.6]) {
    addBox(B, 0.24, 0.55, 0.24, '#6d5a4b', x, 0.29, 14.45, { outline: false });
    addBox(B, 0.24, 0.55, 0.24, '#6d5a4b', x, 0.29, -14.45, { outline: false });
  }

  // a warm inlaid square outlining the whole diorama
  const inlay = glowMat('#d6aa5b', 1.1);
  meshStatic(B, UNIT_BOX, inlay, { x: 0, y: 0.095, z: 14.2, sx: 28.5, sy: 0.028, sz: 0.10, cast: false, receive: false });
  meshStatic(B, UNIT_BOX, inlay, { x: 0, y: 0.095, z: -14.2, sx: 28.5, sy: 0.028, sz: 0.10, cast: false, receive: false });
  for (const side of [-1, 1]) {
    meshStatic(B, UNIT_BOX, inlay, {
      x: side * 14.2,
      y: 0.095,
      z: -4.25,
      sx: 0.10,
      sy: 0.028,
      sz: 19.3,
      cast: false,
      receive: false,
    });
    meshStatic(B, UNIT_BOX, inlay, {
      x: side * 14.2,
      y: 0.095,
      z: 12.2,
      sx: 0.10,
      sy: 0.028,
      sz: 4.0,
      cast: false,
      receive: false,
    });
  }

  // supporting stone slabs for the two banks (the canal is a genuine recess)
  addBox(B, 30.0, 0.95, 6.0, '#3c4b58', 0, -0.52, 12.02, { outline: false });
  addBox(B, 30.0, 0.95, 20.9, '#3c4b58', 0, -0.52, -4.55, { outline: false });

  addGroundPlane(30, 6.0, 0, 12.0, groundMaterialDark, 0.006);
  addGroundPlane(30, 20.85, 0, -4.58, groundMaterialBase, 0.006);
  addGroundPlane(6.35, 16.25, 0, -2.18, groundMaterialStreet, 0.013);
  addGroundPlane(6.35, 5.98, 0, 12.0, groundMaterialStreet, 0.013);
  addGroundPlane(11.45, 4.18, -8.86, -8.2, groundMaterialStreet, 0.014);

  // stone curbs
  const curbColor = '#354553';
  for (const side of [-1, 1]) {
    addBox(B, 0.28, 0.11, 5.55, curbColor, side * 3.28, 0.05, 12.2, { outline: false });
    addBox(B, 0.28, 0.11, 11.9, curbColor, side * 3.28, 0.05, 0.02, { outline: false });
  }
  addBox(B, 0.28, 0.11, 4.0, curbColor, -3.28, 0.05, -8.1, { outline: false });
  for (const side of [-1, 1]) {
    addBox(B, 11.3, 0.11, 0.28, curbColor, -8.85, 0.05, side === -1 ? -10.0 : -6.2, { outline: false });
  }

  // round stone medallions at the plaza and bridge head
  for (const [mx, mz, radius] of [
    [0, 1.2, 1.25],
    [0, 10.55, 1.05],
    [-7.6, -8.2, 0.9],
  ]) {
    const disc = new THREE.CylinderGeometry(radius, radius, 0.055, 28);
    meshStatic(B, disc, toon('#596978'), { x: mx, y: 0.04, z: mz, receive: true });
    const ring = new THREE.TorusGeometry(radius * 0.78, 0.035, 5, 28);
    meshStatic(B, ring, toon('#9b7a47'), { x: mx, y: 0.075, z: mz, rx: Math.PI / 2, receive: true });
  }

  // tiny fallen petals and confetti
  for (let i = 0; i < 120; i++) {
    const x = rand(-14, 14);
    const z = rand(-14.5, 14.5);
    if (z > 5.8 && z < 9.1) continue;
    const c = choose(['#b93a2e', '#d88c4a', '#e6b45e', '#7f2b27']);
    addBox(B, rand(0.035, 0.10), 0.012, rand(0.02, 0.06), c, x, 0.035, z, {
      ry: rand(0, Math.PI * 2),
      outline: false,
      cast: false,
    });
  }

  // mossy edge tufts
  for (let i = 0; i < 22; i++) {
    const x = choose([rand(-14.5, -10), rand(10, 14.5)]);
    const z = rand(-14, 14);
    addSphere(B, rand(0.18, 0.4), choose(['#254b42', '#2c5947', '#335f4a']), x, 0.08, z, {
      sx: 1.8,
      sy: 0.32,
      sz: 1.2,
      outline: false,
    });
  }

  // canal retaining walls, laid as separate old stone blocks
  for (const [zc, flip] of [
    [5.88, 1],
    [9.02, -1],
  ]) {
    let x = -15;
    while (x < 15) {
      const bw = rand(1.0, 2.0);
      const bh = rand(0.72, 0.94);
      addBox(B, bw * 0.96, bh, 0.36, choose(['#4a5c69', '#52616b', '#435562', '#5b6368']), x + bw / 2, -0.47, zc, {
        outline: false,
      });
      addBox(B, bw * 0.94, 0.07, 0.48, '#748085', x + bw / 2, -0.015, zc, { outline: false });
      x += bw;
    }
    for (let i = 0; i < 15; i++) {
      const xx = rand(-14, 14);
      addBox(B, rand(0.2, 0.65), 0.035, 0.1, '#2e5a45', xx, 0.03 + rand(0, 0.04), zc + flip * 0.2, {
        outline: false,
        cast: false,
      });
    }
  }

  // canal end caps
  for (const side of [-1, 1]) {
    addBox(B, 0.42, 1.1, 3.35, '#465968', side * 15.02, -0.44, 7.45, { outline: true });
    addBox(B, 0.50, 0.12, 3.55, '#798285', side * 15.02, 0.06, 7.45, { outline: false });
    addBox(B, 0.20, 0.56, 1.2, '#1e2c37', side * 14.80, -0.55, 7.45, { outline: false });
  }

  // waterside steps
  for (const [sx, sz, dir] of [
    [-6.2, 8.96, 1],
    [6.6, 5.94, -1],
  ]) {
    for (let i = 0; i < 3; i++) {
      addBox(B, 1.35, 0.18, 0.42, '#65717a', sx, 0.11 - i * 0.19, sz + dir * (0.22 + i * 0.38), {
        outline: false,
      });
    }
  }
}

const waterUniforms = {
  uTime: { value: 0 },
  uDeep: { value: new THREE.Color(0x09202c) },
  uShallow: { value: new THREE.Color(0x2a6670) },
  uWarm: { value: new THREE.Color(0xffb866) },
};

function buildWater() {
  const geometry = new THREE.PlaneGeometry(29.7, 3.02, 1, 1);
  const material = new THREE.ShaderMaterial({
    uniforms: waterUniforms,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    vertexShader: /* glsl */ `
      varying vec3 vWorld;
      void main() {
        vec4 world = modelMatrix * vec4(position, 1.0);
        vWorld = world.xyz;
        gl_Position = projectionMatrix * viewMatrix * world;
      }
    `,
    fragmentShader: /* glsl */ `
      varying vec3 vWorld;
      uniform float uTime;
      uniform vec3 uDeep;
      uniform vec3 uShallow;
      uniform vec3 uWarm;

      void main() {
        float t = uTime;
        float waveA = sin(vWorld.x * 1.65 + sin(vWorld.z * 3.1 + t * 0.52) * 1.12 + t * 0.85);
        float waveB = sin(vWorld.z * 7.3 - vWorld.x * 0.72 + t * 1.4);
        float waveC = sin(vWorld.x * 4.6 + vWorld.z * 4.1 - t * 1.05);
        float ripples = smoothstep(0.72, 1.0, waveA * 0.52 + waveB * 0.27 + waveC * 0.21);
        float fine = smoothstep(0.86, 1.0, sin(vWorld.x * 8.2 + vWorld.z * 11.2 + t * 2.0)) * 0.16;
        float glowX = exp(-pow((vWorld.x - 0.0) / 9.5, 2.0));
        float glowZ = exp(-pow((vWorld.z - 7.45) / 1.7, 2.0));
        float lanternGlow = glowX * glowZ;

        vec3 color = mix(uDeep, uShallow, 0.34 + 0.18 * sin(vWorld.x * 0.26 + t * 0.23));
        color += uWarm * (ripples * 0.30 + fine * 0.22);
        color += uWarm * lanternGlow * 0.30;
        color += vec3(0.03, 0.09, 0.10) * (1.0 - smoothstep(0.0, 1.1, abs(vWorld.z - 7.45)));
        float alpha = 0.93;
        gl_FragColor = vec4(color, alpha);
      }
    `,
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.set(0, -0.48, 7.45);
  mesh.renderOrder = 2;
  scene.add(mesh);
  return mesh;
}

// ---------------------------------------------------------------------------
// Curved Chinese roofs
// ---------------------------------------------------------------------------

function roofHeightAt(x, z, w, d, rise, upturn) {
  const ax = clamp01(Math.abs(x) / (w * 0.5));
  const az = clamp01(Math.abs(z) / (d * 0.5));
  return (
    rise * (1 - Math.pow(az, 1.55)) * (1 - 0.17 * Math.pow(ax, 2.6)) +
    upturn * Math.pow(ax, 4.1) * Math.pow(az, 4.0)
  );
}

function makeRoofGeometry(w, d, rise, upturn = 0.34, nx = 16, nz = 16) {
  const positions = [];
  const uvs = [];
  const indices = [];
  for (let iz = 0; iz <= nz; iz++) {
    for (let ix = 0; ix <= nx; ix++) {
      const x = -w * 0.5 + (ix / nx) * w;
      const z = -d * 0.5 + (iz / nz) * d;
      const y = roofHeightAt(x, z, w, d, rise, upturn);
      positions.push(x, y, z);
      uvs.push(x / 1.55, z / 1.55);
    }
  }
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const a = iz * (nx + 1) + ix;
      const b = a + 1;
      const c = a + nx + 1;
      const dd = c + 1;
      indices.push(a, c, b, b, c, dd);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

function perimeterRoofPoints(w, d, rise, upturn, n = 8) {
  const points = [];
  const sampleEdge = (x0, z0, x1, z1) => {
    for (let i = 0; i < n; i++) {
      const t = i / n;
      const x = THREE.MathUtils.lerp(x0, x1, t);
      const z = THREE.MathUtils.lerp(z0, z1, t);
      points.push(V3(x, roofHeightAt(x, z, w, d, rise, upturn) + 0.02, z));
    }
  };
  sampleEdge(-w * 0.5, -d * 0.5, w * 0.5, -d * 0.5);
  sampleEdge(w * 0.5, -d * 0.5, w * 0.5, d * 0.5);
  sampleEdge(w * 0.5, d * 0.5, -w * 0.5, d * 0.5);
  sampleEdge(-w * 0.5, d * 0.5, -w * 0.5, -d * 0.5);
  points.push(points[0].clone());
  return points;
}

function addRoof(parent, opts) {
  const {
    x = 0,
    y = 0,
    z = 0,
    ry = 0,
    w,
    d,
    rise = 1.3,
    upturn = 0.36,
    color = '#2c5b58',
    trim = '#c79a50',
    lanternCorners = false,
    lanternY = -0.35,
    snow = true,
  } = opts;
  const group = new THREE.Group();
  group.position.set(x, y, z);
  group.rotation.y = ry;
  parent.add(group);

  const geo = makeRoofGeometry(w, d, rise, upturn);
  meshStatic(group, geo, roofMat(color), { cast: true, receive: true });

  // A continuous curved underside closes the tile slab. Unlike the old flat
  // ceiling plane, it follows both sloped roof faces, so the roof reads as a
  // solid timber-and-tile mass from below instead of an open skeleton.
  const roofThickness = 0.15;
  const underGeo = makeRoofGeometry(w * 0.995, d * 0.995, rise * 0.995, upturn * 0.995, 12, 12);
  const underPos = underGeo.attributes.position;
  for (let i = 0; i < underPos.count; i++) {
    underPos.setY(i, underPos.getY(i) - roofThickness);
  }
  const underIndex = underGeo.index.array;
  for (let i = 0; i < underIndex.length; i += 3) {
    const tmp = underIndex[i + 1];
    underIndex[i + 1] = underIndex[i + 2];
    underIndex[i + 2] = tmp;
  }
  underGeo.index.needsUpdate = true;
  underGeo.computeVertexNormals();
  meshStatic(group, underGeo, toon('#26211b'), {
    cast: false,
    receive: true,
  });

  // gold eave line, backed by a thicker dark-green tile lip so the roof reads
  // as a solid tiled slab instead of a single-sided surface.
  const perimeter = perimeterRoofPoints(w, d, rise, upturn, 7);
  const eaveCurve = new THREE.CatmullRomCurve3(perimeter, true, 'centripetal');
  meshStatic(group, new THREE.TubeGeometry(eaveCurve, 80, 0.052, 5, true), toon(trim), {
    cast: false,
    receive: false,
  });
  const edgeColor = `#${new THREE.Color(color).multiplyScalar(0.48).getHexString()}`;
  const underEavePoints = perimeter.map((p) => V3(p.x, p.y - 0.075, p.z));
  const underEaveCurve = new THREE.CatmullRomCurve3(underEavePoints, true, 'centripetal');
  meshStatic(group, new THREE.TubeGeometry(underEaveCurve, 80, 0.06, 5, true), toon(edgeColor), {
    cast: false,
    receive: true,
  });
  meshStatic(group, new THREE.TubeGeometry(underEaveCurve, 80, 0.028, 4, true), toon('#20352b'), {
    y: -0.055,
    cast: false,
    receive: true,
  });

  // central ridge
  const ridgePoints = [];
  for (let i = 0; i <= 10; i++) {
    const xx = -w * 0.5 + (i / 10) * w;
    ridgePoints.push(V3(xx, roofHeightAt(xx, 0, w, d, rise, upturn) + 0.035, 0));
  }
  meshStatic(group, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(ridgePoints), 20, 0.075, 5, false), toon(trim), {
    cast: false,
  });

  // raised tile runs down the two slopes, catching the moonlight
  const ridgeColor = `#${new THREE.Color(color).multiplyScalar(0.58).getHexString()}`;
  for (const fx of [-0.34, -0.17, 0.17, 0.34]) {
    for (const side of [-1, 1]) {
      const pts = [];
      for (let k = 0; k <= 8; k++) {
        const z = side * (k / 8) * d * 0.5;
        const x = fx * w;
        pts.push(V3(x, roofHeightAt(x, z, w, d, rise, upturn) + 0.023, z));
      }
      const curve = new THREE.CatmullRomCurve3(pts);
      meshStatic(group, new THREE.TubeGeometry(curve, 12, 0.027, 4, false), toon(ridgeColor), {
        cast: false,
        receive: false,
      });
    }
  }

  // upturned corner tips, like little crescent horns
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const cx = sx * w * 0.5;
      const cz = sz * d * 0.5;
      const cy = roofHeightAt(cx, cz, w, d, rise, upturn);
      const tip = V3(cx + sx * 0.37, cy + 0.34, cz + sz * 0.34);
      const curve = new THREE.CatmullRomCurve3([
        V3(cx, cy + 0.03, cz),
        V3(cx + sx * 0.13, cy + 0.18, cz + sz * 0.13),
        tip,
        V3(cx + sx * 0.43, cy + 0.27, cz + sz * 0.43),
      ]);
      meshStatic(group, new THREE.TubeGeometry(curve, 12, 0.052, 5, false), toon(trim), {
        cast: false,
      });
      addSphere(group, 0.055, trim, tip.x, tip.y, tip.z, { sx: 1.1, sy: 1.1, sz: 1.1 });

      if (lanternCorners && sz > 0) {
        const world = new THREE.Vector3(sx * (w * 0.42), lanternY, d * 0.42).applyMatrix4(group.matrixWorld);
        // matrixWorld is refreshed later by the building; store local anchor instead
        group.userData.lanternAnchors = group.userData.lanternAnchors || [];
        group.userData.lanternAnchors.push({ local: V3(sx * (w * 0.42), lanternY, d * 0.42), size: 0.36 });
      }
    }
  }

  // ridge end ornaments
  for (const sx of [-1, 1]) {
    const xr = sx * (w * 0.5 - 0.14);
    const yr = roofHeightAt(xr, 0, w, d, rise, upturn) + 0.06;
    addSphere(group, 0.095, trim, xr, yr + 0.08, 0, { sx: 0.9, sy: 1.35, sz: 0.9 });
    addBox(group, 0.08, 0.18, 0.08, trim, xr, yr + 0.22, 0, { rx: 0.12 });
  }

  // Thick, matte snow blanket on the upward-facing roof surface. It sits just
  // above the tiles and has a soft irregular drift, leaving all eave lanterns
  // and windows below it unobstructed.
  if (snow) {
    const sw = w * 1.012;
    const sd = d * 1.012;
    const sRise = rise * 1.008;
    const sUpturn = upturn * 1.04;
    const snowGeo = makeRoofGeometry(sw, sd, sRise, sUpturn, 12, 12);
    const snowPos = snowGeo.attributes.position;
    for (let i = 0; i < snowPos.count; i++) {
      const px = snowPos.getX(i);
      const pz = snowPos.getZ(i);
      const drift = Math.sin(px * 2.7 + pz * 3.4) * 0.014 + Math.cos(px * 5.1 - pz * 2.2) * 0.008;
      snowPos.setY(i, snowPos.getY(i) + 0.042 + drift);
    }
    snowGeo.computeVertexNormals();
    meshStatic(group, snowGeo, snowSurfaceMaterial, {
      cast: false,
      receive: true,
    });

    const snowPerimeter = perimeterRoofPoints(sw, sd, sRise, sUpturn, 7).map((p) => V3(p.x, p.y + 0.055, p.z));
    const snowEave = new THREE.CatmullRomCurve3(snowPerimeter, true, 'centripetal');
    meshStatic(group, new THREE.TubeGeometry(snowEave, 72, 0.045, 4, true), snowSurfaceMaterial, {
      cast: false,
      receive: true,
    });

    const snowRidgePoints = [];
    for (let i = 0; i <= 10; i++) {
      const xx = -sw * 0.5 + (i / 10) * sw;
      snowRidgePoints.push(V3(xx, roofHeightAt(xx, 0, sw, sd, sRise, sUpturn) + 0.065, 0));
    }
    meshStatic(
      group,
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(snowRidgePoints), 18, 0.05, 4, false),
      snowSurfaceMaterial,
      { cast: false, receive: true }
    );
  }

  return group;
}

// ---------------------------------------------------------------------------
// Buildings
// ---------------------------------------------------------------------------

function atlasCell(index, cols, rows) {
  const c = index % cols;
  const r = Math.floor(index / cols);
  return {
    u0: c / cols,
    u1: (c + 1) / cols,
    v0: 1 - (r + 1) / rows,
    v1: 1 - r / rows,
  };
}

function remapPlaneUV(geometry, cell) {
  const uv = geometry.attributes.uv;
  for (let i = 0; i < uv.count; i++) {
    uv.setXY(
      i,
      cell.u0 + uv.getX(i) * (cell.u1 - cell.u0),
      cell.v0 + uv.getY(i) * (cell.v1 - cell.v0)
    );
  }
  uv.needsUpdate = true;
  return geometry;
}

function addSign(parent, index, w, h, x, y, z, ry = 0) {
  const geo = remapPlaneUV(new THREE.PlaneGeometry(w, h), atlasCell(index, 4, 2));
  const mesh = meshStatic(parent, geo, signMaterial, { x, y, z, ry, cast: false, receive: false });
  // wooden backing and little gold nails
  addBox(parent, w * 1.06, h * 1.08, 0.09, '#29150f', x, y, z - 0.055, { ry });
  for (const sx of [-1, 1]) {
    for (const sy of [-1, 1]) {
      addSphere(parent, 0.032, '#c79a52', x + sx * w * 0.43, y + sy * h * 0.38, z + 0.055, {
        sx: 0.55,
        sy: 0.55,
        sz: 0.55,
      });
    }
  }
  return mesh;
}

function addBanner(parent, index, w, h, x, y, z, ry = 0) {
  const geo = remapPlaneUV(new THREE.PlaneGeometry(w, h, 5, 7), atlasCell(index, 2, 2));
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const localX = pos.getX(i);
    const localY = pos.getY(i);
    pos.setZ(i, Math.sin(localY * 3.6 + localX * 1.7) * 0.055 + Math.sin(localY * 7.4) * 0.02);
  }
  geo.computeVertexNormals();
  meshStatic(parent, geo, bannerMaterial, { x, y, z, ry, cast: false, receive: false });
  addBox(parent, w + 0.08, 0.055, 0.055, '#d3a858', x, y + h * 0.5 + 0.03, z, { ry });
  addBox(parent, w + 0.04, 0.045, 0.045, '#b78541', x, y - h * 0.5 - 0.025, z, { ry });
  for (let i = 0; i < 5; i++) {
    addBox(parent, 0.024, 0.11, 0.024, '#e0b15f', x - w * 0.4 + i * w * 0.2, y - h * 0.5 - 0.09, z, {
      ry,
      cast: false,
    });
  }
}

function addWindow(parent, w, h, x, y, z, ry = 0, tint = 0xffd49a) {
  return meshStatic(parent, UNIT_PLANE, windowMat(tint), {
    x,
    y,
    z,
    ry,
    sx: w,
    sy: h,
    cast: false,
    receive: false,
  });
}

function addWindowFrame(parent, w, h, x, y, z, ry = 0, color = '#3b2016') {
  const frame = 0.055;
  addBox(parent, w + frame * 2, frame, 0.07, color, x, y + h / 2 + frame / 2, z - 0.025, { ry });
  addBox(parent, w + frame * 2, frame, 0.07, color, x, y - h / 2 - frame / 2, z - 0.025, { ry });
  addBox(parent, frame, h + frame * 2, 0.07, color, x - w / 2 - frame / 2, y, z - 0.025, { ry });
  addBox(parent, frame, h + frame * 2, 0.07, color, x + w / 2 + frame / 2, y, z - 0.025, { ry });
}

function addRailing(parent, w, x, y, z, ry = 0, color = '#7a3025', trim = '#c69a50') {
  addBox(parent, w, 0.07, 0.08, color, x, y, z, { ry });
  addBox(parent, w, 0.05, 0.06, trim, x, y + 0.38, z, { ry });
  const posts = Math.max(2, Math.round(w / 0.55));
  for (let i = 0; i <= posts; i++) {
    const px = x - w / 2 + (i / posts) * w;
    addBox(parent, 0.055, 0.48, 0.055, color, px, y + 0.22, z, { ry });
    if (i % 2 === 0) {
      addBox(parent, 0.03, 0.30, 0.03, trim, px, y + 0.18, z + 0.005, { ry });
    }
  }
}

function makeAwningStripGeometry(width, depth, drop = 0.42) {
  const nx = 5;
  const nz = 5;
  const positions = [];
  const uvs = [];
  const indices = [];
  for (let iz = 0; iz <= nz; iz++) {
    const t = iz / nz;
    for (let ix = 0; ix <= nx; ix++) {
      const s = ix / nx;
      const x = -width * 0.5 + s * width;
      const z = t * depth;
      const y = -Math.pow(t, 1.32) * drop - Math.sin(s * Math.PI) * 0.035 * t;
      positions.push(x, y, z);
      uvs.push(s * width / 1.6, t * depth / 1.6);
    }
  }
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const a = iz * (nx + 1) + ix;
      const b = a + 1;
      const c = a + nx + 1;
      const d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function addAwning(parent, width, y, z, depth = 0.9, colorA = '#a43a2a', colorB = '#e6c18a') {
  const strips = 6;
  for (let i = 0; i < strips; i++) {
    const sw = width / strips;
    const geo = makeAwningStripGeometry(sw * 1.01, depth, 0.42);
    const mesh = meshStatic(parent, geo, cloth(i % 2 ? colorA : colorB), {
      x: -width / 2 + sw * (i + 0.5),
      y,
      z,
      cast: false,
      receive: true,
    });
    mesh.userData.batch = 'cloth';
  }
  // scalloped valance along the outer lip
  const geo = new THREE.PlaneGeometry(width, 0.38, 12, 1);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    if (pos.getY(i) < 0) pos.setY(i, -0.38 + 0.085 * Math.sin(pos.getX(i) * 8.0));
  }
  geo.computeVertexNormals();
  const v = meshStatic(parent, geo, cloth(colorA), {
    x: 0,
    y: y - 0.45,
    z: z + depth + 0.025,
    cast: false,
    receive: false,
  });
  v.userData.batch = 'cloth';
  addBox(parent, width, 0.05, 0.065, '#c89a51', 0, y - 0.28, z + depth + 0.01, { cast: false });
  for (const sx of [-1, 1]) {
    addBox(parent, 0.05, 0.64, 0.05, '#47251a', sx * width * 0.46, y - 0.42, z + depth * 0.72, {
      rx: 0.24,
      cast: false,
    });
  }
}

function addValance(parent, width, y, z, ry = 0, color = '#9d3027') {
  const geo = new THREE.PlaneGeometry(width, 0.42, 14, 1);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    if (pos.getY(i) < 0) pos.setY(i, -0.42 + 0.08 * Math.sin(pos.getX(i) * 9.5));
    pos.setZ(i, Math.sin(pos.getX(i) * 3.0) * 0.018);
  }
  geo.computeVertexNormals();
  const mesh = meshStatic(parent, geo, cloth(color), {
    x: 0,
    y,
    z,
    ry,
    cast: false,
    receive: true,
  });
  mesh.userData.batch = 'cloth';
  addBox(parent, width, 0.045, 0.055, '#d0a353', 0, y - 0.215, z + 0.022, { ry, cast: false });
  for (let i = 0; i < 7; i++) {
    addBox(parent, 0.035, 0.14, 0.035, '#d7a758', -width * 0.41 + i * width * 0.137, y - 0.25, z + 0.03, {
      ry,
      cast: false,
    });
  }
}

function addStoneRailSegment(parent, x1, z1, x2, z2, y, stone = '#6f7b7b', light = '#a5a495') {
  const alongX = Math.abs(x2 - x1) > Math.abs(z2 - z1);
  const length = Math.hypot(x2 - x1, z2 - z1);
  const cx = (x1 + x2) * 0.5;
  const cz = (z1 + z2) * 0.5;
  const sw = alongX ? length : 0.08;
  const sd = alongX ? 0.08 : length;
  addBox(parent, sw, 0.07, sd, stone, cx, y, cz, { cast: false, receive: true });
  addBox(parent, alongX ? length : 0.11, 0.075, alongX ? 0.11 : length, light, cx, y + 0.32, cz, {
    cast: false,
    receive: true,
  });
  const posts = Math.max(2, Math.round(length / 0.55));
  for (let i = 0; i <= posts; i++) {
    const t = i / posts;
    const px = alongX ? THREE.MathUtils.lerp(x1, x2, t) : x1;
    const pz = alongX ? z1 : THREE.MathUtils.lerp(z1, z2, t);
    addBox(parent, 0.085, 0.36, 0.085, stone, px, y + 0.16, pz, { cast: false, receive: true });
    addBox(parent, 0.13, 0.045, 0.13, light, px, y + 0.37, pz, { cast: false, receive: true });
    if (i < posts) {
      const t2 = (i + 0.5) / posts;
      const bx = alongX ? THREE.MathUtils.lerp(x1, x2, t2) : x1;
      const bz = alongX ? z1 : THREE.MathUtils.lerp(z1, z2, t2);
      addBox(parent, 0.045, 0.2, 0.045, light, bx, y + 0.14, bz, { cast: false, receive: true });
    }
  }
}

function addStoneTerrace(parent, w, d) {
  const sx = w * 0.5 + 0.42;
  const sz = d * 0.5 + 0.42;
  const y = 0.40;
  const stone = '#697576';
  const light = '#a5a495';
  const stairGap = Math.min(w * 0.31, 1.25);

  // side and rear stone balustrade, with the centre of the front left open for stairs
  for (const side of [-1, 1]) {
    addStoneRailSegment(parent, side * sx, -sz, side * sx, sz, y, stone, light);
    addBox(parent, 0.28, 0.1, 0.28, light, side * sx, y + 0.02, -sz, { cast: false });
    addBox(parent, 0.28, 0.1, 0.28, light, side * sx, y + 0.02, sz, { cast: false });
  }
  addStoneRailSegment(parent, -sx, -sz, sx, -sz, y, stone, light);
  addStoneRailSegment(parent, -sx, sz, -stairGap, sz, y, stone, light);
  addStoneRailSegment(parent, stairGap, sz, sx, sz, y, stone, light);

  // stone stair cheeks and drum stones frame the entrance
  for (const side of [-1, 1]) {
    const x = side * (stairGap + 0.12);
    for (let i = 0; i < 4; i++) {
      addBox(parent, 0.24, 0.11, 0.48 - i * 0.06, stone, x, 0.1 + i * 0.07, d * 0.5 + 0.52 + i * 0.18, {
        cast: false,
        receive: true,
      });
    }
    addCylinder(parent, 0.13, 0.16, 0.24, light, x, 0.2, d * 0.5 + 1.22, {
      segments: 10,
      cast: false,
      receive: true,
    });
    addSphere(parent, 0.14, light, x, 0.35, d * 0.5 + 1.22, { sx: 1.05, sy: 0.55, sz: 1.05, segments: 8 });
  }

  // a modest stone stoop sits behind the three treads, not over them
  addBox(parent, stairGap * 2 + 0.30, 0.09, 0.32, '#7b8580', 0, 0.27, d * 0.5 + 0.30, {
    cast: false,
    receive: true,
  });
  addBox(parent, stairGap * 2 + 0.42, 0.045, 0.14, '#b4ad98', 0, 0.32, d * 0.5 + 0.14, {
    cast: false,
    receive: true,
  });
}

function addLatticeWindow(parent, w, h, x, y, z, ry = 0, tint = 0xffd49a, opts = {}) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = ry;
  parent.add(g);

  addWindow(g, w, h, 0, 0, 0, 0, tint);
  const frame = 0.055;
  addBox(g, w + frame * 2, frame, 0.075, '#3b2016', 0, h / 2 + frame / 2, 0.035, { cast: false });
  addBox(g, w + frame * 2, frame, 0.075, '#3b2016', 0, -h / 2 - frame / 2, 0.035, { cast: false });
  addBox(g, frame, h + frame * 2, 0.075, '#3b2016', -w / 2 - frame / 2, 0, 0.035, { cast: false });
  addBox(g, frame, h + frame * 2, 0.075, '#3b2016', w / 2 + frame / 2, 0, 0.035, { cast: false });

  // fuller lattice: two vertical and two horizontal glazing bars
  for (let k = 1; k < 3; k++) {
    addBox(g, 0.028, h * 0.9, 0.035, '#442417', -w * 0.5 + (w * k) / 3, 0, 0.06, { cast: false });
    addBox(g, w * 0.92, 0.028, 0.035, '#442417', 0, -h * 0.5 + (h * k) / 3, 0.06, { cast: false });
  }

  addBox(g, w * 1.08, 0.06, 0.13, '#4d2a1c', 0, -h * 0.5 - 0.09, 0.055, { cast: false });
  if (opts.hood !== false) {
    addBox(g, w * 1.12, 0.075, 0.22, '#345a50', 0, h * 0.5 + 0.085, 0.06, { cast: false });
    addBox(g, w * 1.16, 0.032, 0.055, '#d0a353', 0, h * 0.5 + 0.045, 0.16, { cast: false });
  }
  return g;
}

function addDoorDetails(parent, w, h, x, y, z, ry = 0) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = ry;
  parent.add(g);

  addBox(g, w + 0.34, 0.1, 0.14, '#3a1f16', 0, h * 0.5 + 0.08, 0.055, { cast: false });
  addBox(g, 0.07, h, 0.1, '#432316', 0, 0, 0.075, { cast: false });
  for (const sx of [-1, 1]) {
    addBox(g, 0.07, h, 0.1, '#432316', sx * (w * 0.5 + 0.02), 0, 0.075, { cast: false });
    for (let row = 0; row < 3; row++) {
      addSphere(g, 0.032, '#d4a557', sx * w * 0.26, -h * 0.25 + row * h * 0.25, 0.12, {
        sx: 1,
        sy: 1,
        sz: 0.5,
        segments: 6,
        cast: false,
      });
    }
  }
  addBox(g, w + 0.44, 0.08, 0.32, '#5d696b', 0, -h * 0.5 - 0.02, 0.12, { cast: false, receive: true });
}

function addBracketSet(parent, x, y, z, ry = 0, scale = 1) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = ry;
  g.scale.setScalar(scale);
  parent.add(g);

  addBox(g, 0.5, 0.08, 0.34, '#c99b50', 0, 0, 0, { cast: false });
  addBox(g, 0.32, 0.09, 0.25, '#6b2e21', 0, 0.08, 0, { cast: false });
  addBox(g, 0.2, 0.11, 0.18, '#315a50', 0, 0.17, 0, { cast: false });
  for (const side of [-1, 1]) {
    addBox(g, 0.07, 0.28, 0.07, '#8b3929', side * 0.25, 0.08, 0.02, {
      rz: side * 0.58,
      cast: false,
    });
    addBox(g, 0.18, 0.05, 0.08, '#d4a75c', side * 0.18, 0.22, 0.03, {
      rz: side * 0.2,
      cast: false,
    });
  }
}

function makeEaveStripGeometry(length, projection, drop, upturn = 0.14) {
  const nx = 6;
  const nz = 9;
  const positions = [];
  const uvs = [];
  const indices = [];
  for (let iz = 0; iz <= nz; iz++) {
    const tz = iz / nz;
    const z = (tz - 0.5) * length;
    const endLift = Math.pow(Math.abs(tz * 2 - 1), 4);
    for (let ix = 0; ix <= nx; ix++) {
      const s = ix / nx;
      const x = s * projection;
      const y = -drop * Math.pow(s, 1.15) + upturn * endLift * Math.pow(s, 1.8);
      positions.push(x, y, z);
      uvs.push(s * projection / 1.5, tz * length / 1.5);
    }
  }
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const a = iz * (nx + 1) + ix;
      const b = a + 1;
      const c = a + nx + 1;
      const d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  if (geo.attributes.normal.getY(0) < 0) {
    const idx = geo.index.array;
    for (let i = 0; i < idx.length; i += 3) {
      const tmp = idx[i + 1];
      idx[i + 1] = idx[i + 2];
      idx[i + 2] = tmp;
    }
    geo.index.needsUpdate = true;
    geo.computeVertexNormals();
  }
  return geo;
}

function addEaveStrip(parent, opts) {
  const {
    x = 0,
    y = 0,
    z = 0,
    ry = 0,
    length,
    projection = 0.62,
    drop = 0.3,
    upturn = 0.14,
    roofColor = '#2b5955',
    trim = '#c99b50',
    snow = true,
  } = opts;
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = ry;
  parent.add(g);

  const geo = makeEaveStripGeometry(length, projection, drop, upturn);
  const edgeColor = `#${new THREE.Color(roofColor).multiplyScalar(0.46).getHexString()}`;
  meshStatic(g, geo, roofMat(roofColor), { cast: true, receive: true });

  // A matching underside shell closes the skirt roof and gives the green
  // eave a believable slab thickness from oblique and low angles.
  const underGeo = geo.clone();
  underGeo.translate(0, -0.065, 0);
  const underIndex = underGeo.index.array;
  for (let i = 0; i < underIndex.length; i += 3) {
    const tmp = underIndex[i + 1];
    underIndex[i + 1] = underIndex[i + 2];
    underIndex[i + 2] = tmp;
  }
  underGeo.index.needsUpdate = true;
  underGeo.computeVertexNormals();
  meshStatic(g, underGeo, toon(edgeColor), { cast: false, receive: true });

  addBox(g, 0.08, 0.08, length, trim, projection - 0.01, -drop + 0.035, 0, { cast: false });
  addBox(g, 0.11, 0.11, length, '#4a2419', 0.02, 0.015, 0, { cast: false });
  addBox(g, 0.045, 0.09, length, '#7c3127', projection - 0.02, -drop - 0.085, 0, { cast: false });

  // thick outer lip and side lips
  const outerLip = [];
  for (let i = 0; i <= 6; i++) {
    const tz = i / 6;
    const zz = (tz - 0.5) * length;
    const endLift = Math.pow(Math.abs(tz * 2 - 1), 4);
    outerLip.push(V3(projection - 0.01, -drop + upturn * endLift + 0.01, zz));
  }
  addTube(g, new THREE.CatmullRomCurve3(outerLip), 0.042, edgeColor, {
    segments: 10,
    radialSegments: 5,
    cast: false,
  });
  for (const sz of [-1, 1]) {
    const sideLip = [];
    for (let i = 0; i <= 4; i++) {
      const s = i / 4;
      sideLip.push(
        V3(
          s * projection * 0.98,
          -drop * Math.pow(s, 1.15) + upturn * Math.pow(s, 1.8) + 0.005,
          sz * length * 0.5
        )
      );
    }
    addTube(g, new THREE.CatmullRomCurve3(sideLip), 0.03, edgeColor, {
      segments: 6,
      radialSegments: 4,
      cast: false,
    });
  }

  // Thin raised tile runs give each skirt roof a tiled slope rather than a
  // flat green shelf when seen from the high camera.
  for (const ridgeT of [-0.3, 0, 0.3]) {
    const zz = ridgeT * length;
    const endLift = Math.pow(Math.abs((zz / length + 0.5) * 2 - 1), 4);
    const pts = [];
    for (let i = 0; i <= 4; i++) {
      const s = i / 4;
      const xx = s * projection * 0.98;
      const yy = -drop * Math.pow(s, 1.15) + upturn * endLift * Math.pow(s, 1.8) + 0.012;
      pts.push(V3(xx, yy, zz));
    }
    addTube(g, new THREE.CatmullRomCurve3(pts), 0.012, '#315048', {
      segments: 7,
      radialSegments: 4,
      cast: false,
    });
  }

  for (const sz of [-1, 1]) {
    addSphere(g, 0.055, trim, projection * 0.96, -drop + upturn * 0.9, sz * length * 0.48, {
      sx: 1.1,
      sy: 0.7,
      sz: 1.1,
      segments: 5,
      cast: false,
    });
    addBox(g, 0.16, 0.1, 0.16, '#6b2e21', projection * 0.5, -drop * 0.28, sz * length * 0.3, {
      cast: false,
    });
    addBox(g, 0.2, 0.05, 0.08, trim, projection * 0.62, -drop * 0.2, sz * length * 0.3, {
      cast: false,
    });
  }

  if (snow) {
    const snowGeo = geo.clone();
    snowGeo.translate(0, 0.035, 0);
    snowGeo.computeVertexNormals();
    meshStatic(g, snowGeo, snowSurfaceMaterial, { cast: false, receive: true });
  }
  return g;
}

function addSurroundEaves(parent, halfW, halfD, y, upperLength, sideLength, roofColor, trim, options = {}) {
  addEaveStrip(parent, {
    x: halfW,
    y,
    z: 0,
    ry: 0,
    length: sideLength,
    roofColor,
    trim,
    ...options,
  });
  addEaveStrip(parent, {
    x: -halfW,
    y,
    z: 0,
    ry: Math.PI,
    length: sideLength,
    roofColor,
    trim,
    ...options,
  });
  addEaveStrip(parent, {
    x: 0,
    y,
    z: -halfD,
    ry: Math.PI / 2,
    length: upperLength,
    roofColor,
    trim,
    ...options,
  });
}

function addRoofFinial(parent, topY, rise, trim) {
  const y = topY + rise + 0.04;
  addCylinder(parent, 0.045, 0.065, 0.22, trim, 0, y + 0.11, 0, { segments: 8, cast: false });
  addSphere(parent, 0.09, trim, 0, y + 0.28, 0, { sx: 1, sy: 0.82, sz: 1, segments: 8, cast: false });
  addSphere(parent, 0.06, '#f1cc87', 0, y + 0.36, 0, { sx: 0.95, sy: 0.72, sz: 0.95, segments: 7, cast: false });
  addCylinder(parent, 0.012, 0.018, 0.2, trim, 0, y + 0.48, 0, { segments: 6, cast: false });
  addSphere(parent, 0.05, trim, 0, y + 0.6, 0, { sx: 0.75, sy: 1.1, sz: 0.75, segments: 6, cast: false });
}

function addAtticFrieze(parent, w, d, topY, levels, trim) {
  // A modelled mezzanine band under the main roof, so the space between the
  // upper skirt eave and the roof is not an empty gap.
  if (levels < 2) return;
  const h = 0.58;
  const cy = topY - 0.31;
  const wood = '#4e2b20';
  const bays = 4;

  // Solid timber attic volume: this closes the pale triangular void between
  // the upper eave and the main roof from every viewing angle.
  addBox(parent, w + 0.08, h, d + 0.08, '#3b241c', 0, cy, 0, {
    outline: true,
    cast: false,
    receive: true,
  });

  addBox(parent, w * 0.92, h * 0.62, 0.065, wood, 0, cy, d * 0.5 + 0.05, {
    cast: false,
    receive: true,
  });
  for (let i = 0; i <= bays; i++) {
    const x = -w * 0.46 + (i / bays) * w * 0.92;
    addBox(parent, 0.032, h * 0.58, 0.04, trim, x, cy, d * 0.5 + 0.09, { cast: false });
    addCylinder(parent, 0.05, 0.06, h * 0.92, '#6b2b21', x, topY - 0.29, d * 0.5 + 0.075, {
      segments: 7,
      outline: false,
      cast: false,
    });
    addSphere(parent, 0.065, trim, x, topY - 0.055, d * 0.5 + 0.075, {
      sx: 1,
      sy: 0.7,
      sz: 1,
      segments: 6,
      cast: false,
    });
  }
  for (const yy of [cy - 0.16, cy + 0.16]) {
    addBox(parent, w * 0.94, 0.035, 0.045, trim, 0, yy, d * 0.5 + 0.09, { cast: false });
  }
  addBox(parent, w * 0.96, 0.06, 0.08, '#713126', 0, topY - 0.06, d * 0.5 + 0.045, {
    cast: false,
    receive: true,
  });

  for (const side of [-1, 1]) {
    addBox(parent, 0.06, h * 0.62, d * 0.9, wood, side * (w * 0.5 + 0.045), cy, 0, {
      cast: false,
      receive: true,
    });
    for (let i = 0; i <= 3; i++) {
      const z = -d * 0.45 + (i / 3) * d * 0.9;
      addBox(parent, 0.04, h * 0.58, 0.035, trim, side * (w * 0.5 + 0.085), cy, z, {
        cast: false,
      });
      addCylinder(parent, 0.045, 0.055, h * 0.9, '#6b2b21', side * (w * 0.5 + 0.075), topY - 0.29, z, {
        segments: 6,
        outline: false,
        cast: false,
      });
    }
    for (const yy of [cy - 0.16, cy + 0.16]) {
      addBox(parent, 0.045, 0.035, d * 0.92, trim, side * (w * 0.5 + 0.085), yy, 0, {
        cast: false,
      });
    }
  }

  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      addCylinder(parent, 0.065, 0.075, h, '#61291f', sx * (w * 0.5 - 0.02), topY - 0.29, sz * (d * 0.5 - 0.02), {
        segments: 8,
        outline: true,
        cast: false,
      });
      addSphere(parent, 0.08, trim, sx * (w * 0.5 - 0.02), topY - 0.045, sz * (d * 0.5 - 0.02), {
        sx: 1,
        sy: 0.7,
        sz: 1,
        segments: 6,
        cast: false,
      });
    }
  }
}

function buildBuilding(opts) {
  const {
    x,
    z,
    w,
    d,
    levels = 1,
    rot = 0,
    sign = 0,
    banner = null,
    roofColor = '#2b5b58',
    wallColor = '#8b664b',
    upperColor = '#b88b62',
    trim = '#c99b50',
    levelHeight = 3.05,
    upperHeight = 2.58,
    seed = 1,
  } = opts;
  const local = new THREE.Group();
  local.position.set(x, 0, z);
  local.rotation.y = rot;
  staticRoot.add(local);

  const r = mulberry32(seed * 9187 + 17);
  const podiumY = 0.28;
  addBox(local, w + 0.58, 0.3, d + 0.58, '#4a5964', 0, 0.15, 0, { outline: true });
  addBox(local, w + 0.24, 0.1, d + 0.24, '#716d64', 0, 0.33, 0, { outline: false });

  // three shallow steps at the entrance
  for (let i = 0; i < 3; i++) {
    addBox(local, w * 0.34, 0.09, 0.38 - i * 0.08, '#5c6a73', 0, 0.05 + i * 0.065, d / 2 + 0.56 + i * 0.20, {
      outline: false,
    });
  }
  addStoneTerrace(local, w, d);

  let bottom = 0.35;
  for (let level = 0; level < levels; level++) {
    const isUpper = level > 0;
    const h = isUpper ? upperHeight : levelHeight;
    const setBack = isUpper ? 0.24 : 0;
    const lw = w - setBack * 2;
    const ld = d - setBack * 2;
    const cy = bottom + h * 0.5;

    addBox(local, lw, h, ld, isUpper ? upperColor : wallColor, 0, cy, 0, { outline: true });

    // dark timber sill and top beams
    addBox(local, lw + 0.16, 0.17, ld + 0.16, '#4a2419', 0, bottom + 0.06, 0, { outline: false });
    addBox(local, lw + 0.13, 0.14, ld + 0.13, '#3c2018', 0, bottom + h - 0.08, 0, { outline: false });

    // columns at the front
    const bays = isUpper ? 3 : 5;
    for (let i = 0; i <= bays; i++) {
      const px = -lw * 0.5 + (i / bays) * lw;
      const radius = i === 0 || i === bays ? 0.15 : 0.105;
      addCylinder(local, radius, radius * 1.08, h, i === 0 || i === bays ? '#6e2b21' : '#7e3828', px, cy, ld * 0.5 + 0.02, {
        outline: i === 0 || i === bays,
        segments: 9,
      });
      addSphere(local, radius * 0.8, trim, px, bottom + 0.12, ld * 0.5 + 0.02, { sx: 1, sy: 1.4, sz: 1 });
      addSphere(local, radius * 0.72, trim, px, bottom + h - 0.16, ld * 0.5 + 0.02, { sx: 1, sy: 1.3, sz: 1 });
    }

    // side and rear windows keep the walls alive from the orbit's main angles
    {
      const rearY = bottom + h * 0.46;
      for (const sx of [-1, 1]) {
        addLatticeWindow(
          local,
          lw * 0.24,
          h * (isUpper ? 0.30 : 0.34),
          sx * lw * 0.24,
          rearY,
          -ld * 0.5 - 0.055,
          Math.PI,
          0xffd09a,
          { hood: false }
        );
      }
      for (const side of [-1, 1]) {
        addLatticeWindow(
          local,
          ld * 0.26,
          h * (isUpper ? 0.28 : 0.33),
          side * (lw * 0.5 + 0.055),
          rearY,
          -ld * 0.18,
          side * Math.PI / 2,
          0xffcb8d,
          { hood: false }
        );
        if (isUpper) {
          addLatticeWindow(
            local,
            ld * 0.22,
            h * 0.25,
            side * (lw * 0.5 + 0.055),
            rearY + h * 0.30,
            ld * 0.18,
            side * Math.PI / 2,
            0xffc07e,
            { hood: false }
          );
        }
      }
    }

    if (!isUpper) {
      // glowing storefront: a wide window either side of a central doorway
      const winW = lw * 0.31;
      const winH = h * 0.40;
      for (const sx of [-1, 1]) {
        const wx = sx * lw * 0.245;
        addLatticeWindow(local, winW, winH, wx, bottom + h * 0.44, ld * 0.5 + 0.045, 0, 0xffd39a);
      }
      const doorW = lw * 0.18;
      const doorH = h * 0.60;
      addWindow(local, doorW, doorH, 0, bottom + h * 0.36, ld * 0.5 + 0.05, 0, 0xffca87);
      addDoorDetails(local, doorW, doorH, 0, bottom + h * 0.36, ld * 0.5 + 0.05);
      addBox(local, doorW + 0.10, 0.06, 0.10, '#b96d3a', 0, bottom + h * 0.11, ld * 0.5 + 0.26, {
        cast: false,
      });
      addBox(local, lw * 0.76, 0.10, 0.58, '#3c2017', 0, bottom + h * 0.14, ld * 0.5 + 0.28, {
        cast: false,
      });
      addAwning(local, lw * 0.88, bottom + h - 0.9, ld * 0.5, 0.7, '#a13a2d', '#e4c390');
    } else {
      const winW = lw * 0.23;
      const winH = h * 0.38;
      for (const sx of [-1, 1]) {
        const wx = sx * lw * 0.27;
        addLatticeWindow(local, winW, winH, wx, bottom + h * 0.54, ld * 0.5 + 0.045, 0, 0xffcb8d);
      }
      // balcony floor, rear and side railings wrap the upper storey
      addBox(local, lw + 0.92, 0.16, ld + 0.86, '#513023', 0, bottom - 0.02, 0.22, { outline: true });
      addRailing(local, lw + 0.65, 0, bottom + 0.18, ld * 0.5 + 0.48, 0, '#7e3325', trim);
      addRailing(local, lw + 0.52, 0, bottom + 0.18, -ld * 0.5 - 0.20, Math.PI, '#7e3325', trim);
      for (const side of [-1, 1]) {
        addRailing(local, ld + 0.80, side * (lw * 0.5 + 0.40), bottom + 0.18, 0.12, side * Math.PI / 2, '#7e3325', trim);
        addBox(local, 0.11, 0.6, 0.11, '#6f2f23', side * (lw * 0.5 + 0.40), bottom + 0.02, -ld * 0.5 - 0.20, {
          outline: true,
        });
        addBox(local, 0.11, 0.6, 0.11, '#6f2f23', side * (lw * 0.5 + 0.40), bottom + 0.02, ld * 0.5 + 0.40, {
          outline: true,
        });
      }
      for (const sx of [-1, 1]) {
        addBox(local, 0.10, 0.85, 0.10, '#6f2f23', sx * (lw * 0.5 + 0.28), bottom + 0.12, ld * 0.5 + 0.46, {
          outline: true,
        });
      }
      // small bracket sets carry the projecting balcony
      for (const side of [-1, 1]) {
        for (const zz of [-0.3, 0, 0.3]) {
          addBracketSet(local, side * (lw * 0.5 + 0.28), bottom - 0.38, zz, side * Math.PI / 2, 0.78);
        }
      }
    }

    // layered painted beams, vertical pilasters and fuller bracket sets
    addBox(local, lw + 0.08, 0.085, 0.09, '#612d21', 0, bottom + h * 0.76, ld * 0.5 + 0.045, { cast: false });
    addBox(local, lw + 0.12, 0.13, 0.075, '#315a50', 0, bottom + h - 0.26, ld * 0.5 + 0.06, { cast: false });
    addBox(local, lw + 0.14, 0.032, 0.035, trim, 0, bottom + h - 0.33, ld * 0.5 + 0.11, { cast: false });
    addBox(local, lw + 0.10, 0.05, 0.06, '#6b2e21', 0, bottom + h * 0.42, ld * 0.5 + 0.05, { cast: false });
    for (const side of [-1, 1]) {
      for (const zz of [-ld * 0.46, 0, ld * 0.46]) {
        addBox(local, 0.085, h - 0.22, 0.085, '#6b2e21', side * (lw * 0.5 + 0.025), cy, zz, {
          cast: false,
        });
      }
      addBox(local, 0.05, 0.30, ld * 0.72, '#523026', side * (lw * 0.5 + 0.04), bottom + 0.30, 0, {
        cast: false,
      });
      addBox(local, 0.075, 0.07, ld * 0.74, trim, side * (lw * 0.5 + 0.09), bottom + h * 0.63, 0, {
        cast: false,
      });
    }
    for (let i = 1; i < bays; i++) {
      const px = -lw * 0.5 + (i / bays) * lw;
      addBracketSet(local, px, bottom + h - 0.17, ld * 0.5 + 0.10, 0, isUpper ? 0.9 : 0.82);
    }

    bottom += h;
  }

  // top roof, with a deep overhang
  const topY = bottom + 0.06;
  const topRoof = addRoof(local, {
    y: topY,
    w: w + 1.32,
    d: d + 1.38,
    rise: 1.72,
    upturn: 0.54,
    color: roofColor,
    trim,
    lanternCorners: true,
    lanternY: -0.28,
  });
  addRoofFinial(local, topY, 1.72, trim);

  // Side and rear eave tiers give the houses the layered, stacked-roof
  // silhouette of a larger pavilion without changing their footprint.
  const upperW = levels > 1 ? w - 0.48 : w;
  const upperD = levels > 1 ? d - 0.48 : d;
  addAtticFrieze(local, upperW, upperD, topY, levels, trim);
  if (levels > 1) {
    addSurroundEaves(
      local,
      w * 0.5,
      d * 0.5,
      0.35 + levelHeight - 0.24,
      w + 1.00,
      d + 1.00,
      roofColor,
      trim,
      { projection: 0.72, drop: 0.30, upturn: 0.12 }
    );
    addSurroundEaves(
      local,
      upperW * 0.5,
      upperD * 0.5,
      topY - 0.62,
      upperW + 1.00,
      upperD + 1.00,
      roofColor,
      trim,
      { projection: 0.98, drop: 0.34, upturn: 0.15 }
    );
    addEaveStrip(local, {
      x: 0,
      y: topY - 0.62,
      z: upperD * 0.5,
      ry: -Math.PI / 2,
      length: upperW + 1.00,
      projection: 0.98,
      drop: 0.34,
      upturn: 0.15,
      roofColor,
      trim,
    });
  } else {
    addSurroundEaves(
      local,
      w * 0.5,
      d * 0.5,
      topY - 0.36,
      w + 1.00,
      d + 1.00,
      roofColor,
      trim,
      { projection: 0.85, drop: 0.30, upturn: 0.13 }
    );
  }

  // Small wind bells at the four roof corners.
  const roofW = w + 1.32;
  const roofD = d + 1.38;
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const bx = sx * roofW * 0.43;
      const bz = sz * roofD * 0.43;
      addCylinder(local, 0.012, 0.012, 0.24, '#3a1d14', bx, topY + 0.10, bz, {
        segments: 5,
        cast: false,
      });
      addCylinder(local, 0.05, 0.062, 0.11, trim, bx, topY - 0.045, bz, {
        segments: 8,
        cast: false,
      });
      addSphere(local, 0.03, '#f0cb83', bx, topY - 0.11, bz, { sx: 1, sy: 1, sz: 1, segments: 6, cast: false });
    }
  }

  // front valance beneath the eaves
  addValance(local, w + 1.0, topY - 0.14, d * 0.5 + 0.78, 0, '#9d3027');
  addValance(local, w + 1.0, topY - 0.14, -d * 0.5 - 0.78, Math.PI, '#8e2a24');
  for (const side of [-1, 1]) {
    const geo = new THREE.PlaneGeometry(d + 0.9, 0.42, 10, 1);
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      if (pos.getY(i) < 0) pos.setY(i, -0.42 + 0.08 * Math.sin(pos.getX(i) * 9.5));
    }
    geo.computeVertexNormals();
    meshStatic(local, geo, cloth('#922d25'), {
      x: side * (w * 0.5 + 0.8),
      y: topY - 0.14,
      z: 0,
      ry: side * Math.PI / 2,
      cast: false,
      receive: true,
    });
    addBox(local, 0.055, 0.05, d + 0.9, '#d0a353', side * (w * 0.5 + 0.8), topY - 0.35, 0, { cast: false });
  }

  // fascia sign over the storefront
  const signW = Math.min(1.82, w * 0.48);
  const signY = 0.35 + levelHeight - 0.47;
  addSign(local, sign % 8, signW, signW * 0.46, 0, signY, d * 0.5 + 0.13);
  addBox(local, signW * 1.12, 0.07, 0.20, trim, 0, signY - signW * 0.27, d * 0.5 + 0.16, { cast: false });

  if (banner !== null) {
    addBanner(local, banner % 4, 0.62, 2.0, w * 0.5 + 0.25, 3.25, d * 0.5 + 0.55, 0);
  }

  // shop lanterns, registered in world space after the group matrix updates
  local.updateMatrixWorld(true);
  const anchors = [
    { p: V3(-w * 0.38, 2.45, d * 0.5 + 0.92), s: 0.42, c: '#f05a2d' },
    { p: V3(w * 0.38, 2.45, d * 0.5 + 0.92), s: 0.42, c: '#ff8a39' },
    { p: V3(-w * 0.5 - 0.63, topY - 0.24, d * 0.5 + 0.72), s: 0.36, c: '#df4328' },
    { p: V3(w * 0.5 + 0.63, topY - 0.24, d * 0.5 + 0.72), s: 0.36, c: '#f06a2e' },
  ];
  for (const a of anchors) {
    const p = a.p.clone().applyMatrix4(local.matrixWorld);
    addLantern(p.x, p.y, p.z, a.s, a.c);
  }

  // rooftop corner lanterns requested by the roof builder
  if (topRoof?.userData?.lanternAnchors) {
    for (const a of topRoof.userData.lanternAnchors) {
      const p = a.local.clone().add(topRoof.position).applyMatrix4(local.matrixWorld);
      addLantern(p.x, p.y, p.z, a.size, '#e9562d');
    }
  }

  return local;
}

// ---------------------------------------------------------------------------
// The arched wooden bridge
// ---------------------------------------------------------------------------

const BRIDGE = {
  x: 0,
  z: 7.45,
  span: 5.35,
  width: 4.45,
  rise: 1.34,
};

function bridgeDeckY(z) {
  const t = clamp01((z - (BRIDGE.z - BRIDGE.span * 0.5)) / BRIDGE.span);
  return 0.15 + BRIDGE.rise * Math.cos(Math.PI * (t - 0.5));
}

function bridgeSlope(z) {
  const t = clamp01((z - (BRIDGE.z - BRIDGE.span * 0.5)) / BRIDGE.span);
  return (-BRIDGE.rise * Math.PI) / BRIDGE.span * Math.sin(Math.PI * (t - 0.5));
}

function buildBridge() {
  const g = new THREE.Group();
  staticRoot.add(g);

  const { width, span, z: zc } = BRIDGE;

  // stone abutments
  for (const zSide of [-1, 1]) {
    addBox(g, width + 1.25, 0.52, 0.75, '#4d5d69', 0, 0.12, zc + zSide * (span * 0.5 + 0.28), {
      outline: true,
    });
    addBox(g, width + 1.55, 0.13, 0.92, '#778084', 0, 0.045, zc + zSide * (span * 0.5 + 0.33));
  }

  // deck planks
  const N = 26;
  for (let i = 0; i < N; i++) {
    const t = (i + 0.5) / N;
    const z = zc - span * 0.5 + t * span;
    const y = bridgeDeckY(z);
    const slope = bridgeSlope(z);
    const wood = choose(['#6c412d', '#764934', '#5a3527', '#80503a']);
    addBox(g, width, 0.13, (span / N) * 0.96, wood, 0, y, z, {
      rx: -Math.atan(slope),
      outline: false,
    });
  }

  // side beams and the arched underside
  const archCurves = [];
  for (const side of [-1, 1]) {
    for (let i = 0; i < N; i++) {
      const t = (i + 0.5) / N;
      const z = zc - span * 0.5 + t * span;
      const y = bridgeDeckY(z);
      const slope = bridgeSlope(z);
      addBox(g, 0.22, 0.30, (span / N) * 1.04, '#592f24', side * (width * 0.5 - 0.02), y - 0.19, z, {
        rx: -Math.atan(slope),
        outline: false,
      });
      addBox(g, 0.13, 0.075, (span / N) * 1.04, '#d3a455', side * (width * 0.5 + 0.09), y - 0.33, z, {
        rx: -Math.atan(slope),
        outline: false,
        cast: false,
      });
    }
    const archPoints = [];
    for (let i = 0; i <= 18; i++) {
      const t = i / 18;
      const z = zc - span * 0.54 + t * span * 1.08;
      const y = 0.12 + Math.sin(t * Math.PI) * 0.96;
      archPoints.push(V3(side * (width * 0.5 - 0.30), y, z));
    }
    const curve = new THREE.CatmullRomCurve3(archPoints);
    meshStatic(g, new THREE.TubeGeometry(curve, 44, 0.105, 6, false), toon('#643728'), {
      outline: true,
      cast: true,
      receive: true,
    });
    archCurves.push(curve);
  }

  // central support arch, visible under the bridge from the water
  const centerArch = [];
  for (let i = 0; i <= 22; i++) {
    const t = i / 22;
    const z = zc - span * 0.52 + t * span * 1.04;
    const y = 0.04 + Math.sin(t * Math.PI) * 0.78;
    centerArch.push(V3(0, y, z));
  }
  meshStatic(g, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(centerArch), 44, 0.08, 6, false), toon('#4b2b22'), {
    cast: false,
  });

  // vertical hangers from deck to arch
  for (let i = 1; i < 7; i++) {
    const t = i / 7;
    const z = zc - span * 0.5 + t * span;
    const top = bridgeDeckY(z) - 0.14;
    const bottom = 0.08 + Math.sin(t * Math.PI) * 0.96;
    for (const side of [-1, 1]) {
      addBox(g, 0.075, Math.max(0.1, top - bottom), 0.075, '#4e2c22', side * (width * 0.5 - 0.28), (top + bottom) * 0.5, z, {
        cast: false,
      });
    }
  }

  // railings
  const postPositions = [];
  for (let i = 0; i <= 8; i++) {
    const t = i / 8;
    const z = zc - span * 0.48 + t * span * 0.96;
    const y = bridgeDeckY(z);
    postPositions.push({ t, z, y });
    for (const side of [-1, 1]) {
      addBox(g, 0.15, 0.75, 0.15, '#6d3024', side * (width * 0.5 - 0.14), y + 0.38, z, {
        outline: true,
      });
      addBox(g, 0.18, 0.06, 0.18, '#d0a353', side * (width * 0.5 - 0.14), y + 0.78, z, { cast: false });
      addSphere(g, 0.075, '#d5a759', side * (width * 0.5 - 0.14), y + 0.86, z, { sx: 1, sy: 1.3, sz: 1 });
    }
  }

  for (const side of [-1, 1]) {
    for (const railYOffset of [0.56, 0.80]) {
      const pts = postPositions.map((p) => V3(side * (width * 0.5 - 0.14), p.y + railYOffset, p.z));
      const curve = new THREE.CatmullRomCurve3(pts);
      meshStatic(g, new THREE.TubeGeometry(curve, 40, 0.052, 6, false), toon(railYOffset > 0.7 ? '#a53729' : '#7e3025'), {
        cast: false,
      });
    }
  }

  // festive red silk swags between the rail posts
  for (const side of [-1, 1]) {
    for (let i = 1; i < 8; i += 2) {
      const a = postPositions[i];
      const b = postPositions[Math.min(8, i + 2)];
      if (!b) continue;
      const pts = [];
      const sag = 0.38;
      for (let k = 0; k <= 8; k++) {
        const t = k / 8;
        const z = THREE.MathUtils.lerp(a.z, b.z, t);
        const y = bridgeDeckY(z) + 0.67 - Math.sin(t * Math.PI) * sag;
        pts.push(V3(side * (width * 0.5 - 0.045), y, z));
      }
      meshStatic(g, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 18, 0.06, 6, false), toon('#b23c2d'), {
        cast: false,
      });
      const knotZ = THREE.MathUtils.lerp(a.z, b.z, 0.5);
      const knotY = bridgeDeckY(knotZ) + 0.67 - sag;
      addSphere(g, 0.095, '#d1a253', side * (width * 0.5 - 0.045), knotY, knotZ, { sx: 1, sy: 1.25, sz: 1 });
      addBox(g, 0.035, 0.42, 0.035, '#c99a4e', side * (width * 0.5 - 0.045), knotY - 0.28, knotZ, { cast: false });
    }
  }

  // bridge lanterns
  for (const side of [-1, 1]) {
    for (const i of [1, 3, 5, 7]) {
      const p = postPositions[i];
      const x = side * (width * 0.5 - 0.06);
      addLantern(x, p.y + 0.24, p.z, 0.38, i % 2 ? '#ff8e3e' : '#ffad52');
      addBox(g, 0.022, 0.30, 0.022, '#3a1d14', x, p.y + 0.54, p.z, { cast: false });
    }
  }

  // tall welcoming poles at the southern end
  for (const side of [-1, 1]) {
    const pole = new THREE.Group();
    pole.position.set(side * 3.35, 0, zc + span * 0.5 + 0.5);
    g.add(pole);
    addCylinder(pole, 0.10, 0.13, 4.45, '#5b2b20', 0, 2.25, 0, { outline: true, segments: 10 });
    addBox(pole, 0.42, 0.11, 0.42, '#c9974e', 0, 0.08, 0, { outline: false });
    addSphere(pole, 0.11, '#d5a759', 0, 4.54, 0, { sx: 1, sy: 1.5, sz: 1 });
    addBanner(pole, side > 0 ? 1 : 2, 0.58, 1.85, 0, 3.46, 0.11, 0);
    addLantern(side * 3.35, 4.20, zc + span * 0.5 + 0.5, 0.46, '#ff8a3c');
    addBox(pole, 0.70, 0.07, 0.07, '#8e3b2b', 0, 4.25, 0, { cast: false });
  }

  // Snow lies in two bands along the walking deck, leaving the centre path
  // clear for the people. The bands sit just above the planks.
  const bridgeSnowRows = 28;
  for (const side of [-1, 1]) {
    const positions = [];
    const uvs = [];
    const indices = [];
    const edgePoints = [];
    for (let i = 0; i <= bridgeSnowRows; i++) {
      const t = i / bridgeSnowRows;
      const z = zc - span * 0.5 + t * span;
      const y = bridgeDeckY(z) + 0.082 + Math.sin(t * 19.0 + side) * 0.004;
      const innerX = side * (0.92 + Math.sin(t * 8.0 + side * 1.7) * 0.05);
      const outerX = side * (width * 0.5 - 0.17 + Math.sin(t * 6.0 + side) * 0.025);
      positions.push(innerX, y, z, outerX, y + 0.006, z);
      uvs.push(t, 0, t, 1);
      if (i < bridgeSnowRows) {
        const a = i * 2;
        indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
      }
      edgePoints.push(V3(outerX, y + 0.025, z));
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    if (geo.attributes.normal.getY(0) < 0) {
      const idx = geo.index.array;
      for (let i = 0; i < idx.length; i += 3) {
        const tmp = idx[i + 1];
        idx[i + 1] = idx[i + 2];
        idx[i + 2] = tmp;
      }
      geo.index.needsUpdate = true;
      geo.computeVertexNormals();
    }
    meshStatic(g, geo, snowSurfaceMaterial, { cast: false, receive: true });
    meshStatic(g, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(edgePoints), 32, 0.03, 4, false), snowSurfaceMaterial, {
      cast: false,
      receive: true,
    });
  }

  // A thin cap of snow along the top rail and on each post finial.
  for (const side of [-1, 1]) {
    const railPts = postPositions.map((p) => V3(side * (width * 0.5 - 0.14), p.y + 0.865, p.z));
    meshStatic(g, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(railPts), 36, 0.025, 4, false), snowSurfaceMaterial, {
      cast: false,
      receive: true,
    });
    for (const p of postPositions) {
      meshStatic(g, UNIT_SPHERE, snowSurfaceMaterial, {
        x: side * (width * 0.5 - 0.14),
        y: p.y + 0.94,
        z: p.z,
        sx: 0.17,
        sy: 0.055,
        sz: 0.17,
        cast: false,
        receive: true,
      });
    }
  }

  return g;
}

// ---------------------------------------------------------------------------
// Little painted boats on the canal
// ---------------------------------------------------------------------------

function buildBoat(x, z, rot, scale = 1) {
  const g = new THREE.Group();
  g.position.set(x, -0.43, z);
  g.rotation.y = rot;
  g.scale.setScalar(scale);
  staticRoot.add(g);

  // shallow hull
  addSphere(g, 0.5, '#5c3525', 0, 0.02, 0, { sx: 2.0, sy: 0.30, sz: 0.64, segments: 12 });
  addSphere(g, 0.5, '#7a4a30', 0, 0.18, 0, { sx: 1.8, sy: 0.11, sz: 0.55, segments: 12 });
  addBox(g, 1.6, 0.13, 0.12, '#3f2418', 0, 0.12, 0.58, { cast: false });
  addBox(g, 1.6, 0.13, 0.12, '#3f2418', 0, 0.12, -0.58, { cast: false });
  for (const side of [-1, 1]) {
    addCylinder(g, 0.045, 0.055, 0.8, '#5e3925', side * 0.55, 0.28, 0, {
      rz: Math.PI / 2,
      segments: 6,
    });
    addCylinder(g, 0.045, 0.055, 0.8, '#5e3925', side * 0.55, 0.28, -0.28, {
      rz: Math.PI / 2,
      segments: 6,
    });
  }
  const canopy = meshStatic(g, makeCanopyGeometry(1.2, 0.95, 0.34), cloth('#a3382b'), {
    y: 0.64,
    z: -0.15,
    cast: false,
    receive: true,
  });
  canopy.userData.batch = 'cloth';
  addBox(g, 1.2, 0.04, 0.04, '#d0a052', 0, 0.66, 0.33, { cast: false });
  // bow lantern
  addLantern(x + Math.cos(rot) * 0.75 * scale, -0.05, z - Math.sin(rot) * 0.75 * scale, 0.29 * scale, '#ff8a37');
  addCylinder(g, 0.018, 0.018, 0.54, '#4b2b1c', 0.75, 0.23, 0.32, {
    rx: 0.28,
    segments: 5,
    cast: false,
  });
  return g;
}

// ---------------------------------------------------------------------------
// The little paifang marking the turn into the L-shaped lane
// ---------------------------------------------------------------------------

function buildGate(x, z, rot, width = 4.35) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rot;
  staticRoot.add(g);

  for (const sx of [-1, 1]) {
    const px = sx * width * 0.5;
    addBox(g, 0.62, 0.32, 0.62, '#4d5962', px, 0.16, 0, { outline: true });
    addCylinder(g, 0.16, 0.21, 4.45, '#7b2d23', px, 2.42, 0, { segments: 10, outline: true });
    addCylinder(g, 0.22, 0.22, 0.10, '#d0a052', px, 0.48, 0, { segments: 10 });
    addCylinder(g, 0.20, 0.20, 0.09, '#d0a052', px, 4.48, 0, { segments: 10 });
    addBox(g, 0.36, 0.11, 0.36, '#d0a052', px, 4.58, 0, { outline: false });
  }
  addBox(g, width + 0.8, 0.28, 0.24, '#6c2d23', 0, 4.28, 0, { outline: true });
  addBox(g, width + 0.5, 0.17, 0.18, '#d0a052', 0, 4.10, 0, { outline: false });
  addSign(g, 0, 2.15, 1.02, 0, 3.62, 0.16);
  addRoof(g, {
    y: 4.48,
    w: width + 1.45,
    d: 1.52,
    rise: 0.68,
    upturn: 0.28,
    color: '#2b5752',
    trim: '#d0a052',
  });
  // little ornamental brackets under the roof
  for (const sx of [-1, 1]) {
    for (let i = 0; i < 3; i++) {
      addBox(g, 0.10, 0.24, 0.46, '#d0a052', sx * (width * 0.5 - 0.18 - i * 0.33), 4.12, 0, {
        rx: 0.25,
        cast: false,
      });
    }
  }
  g.updateMatrixWorld(true);
  for (const sx of [-1, 1]) {
    const p = V3(sx * width * 0.36, 4.0, 0.34).applyMatrix4(g.matrixWorld);
    addLantern(p.x, p.y, p.z, 0.42, '#ff9040');
  }
  return g;
}

// ---------------------------------------------------------------------------
// Stone lions & the old well
// ---------------------------------------------------------------------------

function buildLion(x, z, rot = 0, scale = 1) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rot;
  g.scale.setScalar(scale);
  staticRoot.add(g);

  addBox(g, 1.08, 0.36, 0.92, '#59636b', 0, 0.18, 0, { outline: true });
  addBox(g, 1.20, 0.10, 1.04, '#85867f', 0, 0.40, 0, { outline: false });
  // haunches and chest
  addSphere(g, 0.36, '#85867e', 0, 0.78, 0.02, { sx: 1.05, sy: 0.9, sz: 1.15, outline: true });
  addSphere(g, 0.28, '#8b8b81', 0, 1.03, 0.22, { sx: 0.85, sy: 1.0, sz: 0.85, outline: true });
  // head and mane
  addSphere(g, 0.25, '#98978a', 0, 1.34, 0.30, { sx: 1.0, sy: 1.0, sz: 0.94, outline: true });
  for (let i = 0; i < 13; i++) {
    const a = (i / 13) * Math.PI * 2;
    const rr = 0.29;
    addSphere(g, 0.075, '#6e716b', Math.cos(a) * rr, 1.34 + Math.sin(a) * rr * 0.7, 0.25, {
      sx: 1,
      sy: 1,
      sz: 1,
    });
  }
  addSphere(g, 0.055, '#3b3330', -0.085, 1.38, 0.505, { sx: 1, sy: 1, sz: 0.5 });
  addSphere(g, 0.055, '#3b3330', 0.085, 1.38, 0.505, { sx: 1, sy: 1, sz: 0.5 });
  addBox(g, 0.11, 0.09, 0.18, '#42342c', 0, 1.26, 0.50, { outline: false });
  // front legs and paws
  for (const sx of [-1, 1]) {
    addCylinder(g, 0.105, 0.13, 0.55, '#89887d', sx * 0.23, 0.66, 0.30, { segments: 8 });
    addSphere(g, 0.14, '#7a7b72', sx * 0.23, 0.44, 0.40, { sx: 1.1, sy: 0.55, sz: 1.25 });
    addSphere(g, 0.10, '#686b65', sx * 0.23, 0.66, 0.51, { sx: 0.8, sy: 0.45, sz: 0.55 });
  }
  // curling tail
  const tail = new THREE.CatmullRomCurve3([
    V3(0, 0.74, -0.30),
    V3(0.26, 0.88, -0.48),
    V3(0.38, 1.13, -0.29),
    V3(0.27, 1.30, -0.17),
  ]);
  meshStatic(g, new THREE.TubeGeometry(tail, 14, 0.055, 5, false), toon('#6d706a'), { cast: true });
  addSphere(g, 0.105, '#777870', 0.23, 1.37, -0.15, { sx: 1.2, sy: 0.9, sz: 1.2 });
  // hint of a gilded ball under one paw
  addSphere(g, 0.14, '#b88945', 0.33, 0.46, 0.42, { sx: 1, sy: 1, sz: 1 });
  addBox(g, 0.04, 0.04, 0.04, '#e1ba6c', 0.33, 0.46, 0.55, { cast: false });
  return g;
}

function buildWell(x, z) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  staticRoot.add(g);

  addCylinder(g, 0.62, 0.68, 0.58, '#4c5b66', 0, 0.29, 0, { outline: true, segments: 16 });
  addCylinder(g, 0.52, 0.54, 0.62, '#182a35', 0, 0.32, 0, { segments: 16 });
  const ring = new THREE.TorusGeometry(0.57, 0.10, 6, 18);
  meshStatic(g, ring, toon('#6e7778'), { y: 0.57, rx: Math.PI / 2, outline: true });
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2;
    addBox(g, 0.22, 0.08, 0.12, '#7c7e77', Math.cos(a) * 0.57, 0.62, Math.sin(a) * 0.57, {
      ry: -a,
    });
  }
  addBox(g, 0.12, 1.58, 0.12, '#5a2c20', -0.62, 0.82, 0, { outline: true });
  addBox(g, 0.12, 1.58, 0.12, '#5a2c20', 0.62, 0.82, 0, { outline: true });
  addBox(g, 1.55, 0.13, 0.14, '#6d3325', 0, 1.63, 0, { outline: true });
  addBox(g, 0.42, 0.28, 0.05, '#392219', 0.50, 1.23, 0.10, { rx: 0.25 });
  addRoof(g, {
    y: 1.78,
    w: 1.65,
    d: 1.32,
    rise: 0.46,
    upturn: 0.18,
    color: '#30534f',
    trim: '#b5894e',
  });
  addCylinder(g, 0.018, 0.018, 0.72, '#b69c70', 0.05, 1.25, 0, { cast: false, segments: 5 });
  addCylinder(g, 0.12, 0.11, 0.18, '#3f2c20', 0.05, 0.88, 0, { segments: 8 });
  addLantern(x + 0.62, 1.47, z + 0.10, 0.28, '#ff8e3c');
  return g;
}

// ---------------------------------------------------------------------------
// Market stalls
// ---------------------------------------------------------------------------

function makeCanopyGeometry(w, d, rise) {
  const nx = 8;
  const nz = 8;
  const positions = [];
  const uvs = [];
  const indices = [];
  for (let iz = 0; iz <= nz; iz++) {
    for (let ix = 0; ix <= nx; ix++) {
      const sx = ix / nx;
      const sz = iz / nz;
      const x = -w * 0.5 + sx * w;
      const z = -d * 0.5 + sz * d;
      const az = Math.abs(z) / (d * 0.5);
      const y = rise * (1 - Math.pow(az, 1.3)) + 0.12 * Math.pow(Math.abs(x) / (w * 0.5), 4) * Math.pow(az, 3);
      positions.push(x, y, z);
      uvs.push(sx * w / 1.5, sz * d / 1.5);
    }
  }
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const a = iz * (nx + 1) + ix;
      const b = a + 1;
      const c = a + nx + 1;
      const dd = c + 1;
      indices.push(a, c, b, b, c, dd);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function addCandySkewer(parent, x, y, z, lean = 0) {
  addCylinder(parent, 0.012, 0.012, 0.79, '#b99362', x, y + 0.38, z, {
    rz: lean,
    segments: 5,
    cast: false,
  });
  for (let i = 0; i < 5; i++) {
    const localY = y + 0.58 + i * 0.11;
    const localX = x + Math.sin(lean) * (localY - y);
    addSphere(parent, 0.055, i % 2 ? '#b72b22' : '#cf3e2b', localX, localY, z, {
      sx: 1,
      sy: 1,
      sz: 1,
      segments: 8,
    });
    addSphere(parent, 0.018, '#ffd28a', localX - 0.025, localY + 0.035, z + 0.035, {
      sx: 1,
      sy: 1,
      sz: 1,
      segments: 6,
    });
  }
}

function addMask(parent, x, y, z, color) {
  addSphere(parent, 0.160, color, x, y, z + 0.08, {
    sx: 0.72,
    sy: 1.15,
    sz: 0.33,
    segments: 10,
  });
  for (const sx of [-1, 1]) {
    addSphere(parent, 0.025, '#2c1b16', x + sx * 0.052, y + 0.025, z + 0.145, {
      sx: 1,
      sy: 0.65,
      sz: 0.35,
      segments: 6,
    });
  }
  addBox(parent, 0.055, 0.017, 0.018, '#9a3c2d', x, y - 0.055, z + 0.15, { cast: false });
  addBox(parent, 0.115, 0.015, 0.014, '#d0a454', x, y + 0.092, z + 0.135, { cast: false });
}

function makeCanopySnowGeometry(width, depth, rise) {
  const nx = 8;
  const nz = 5;
  const zMin = -depth * 0.5;
  const zMax = depth * 0.18;
  const positions = [];
  const uvs = [];
  const indices = [];
  for (let iz = 0; iz <= nz; iz++) {
    for (let ix = 0; ix <= nx; ix++) {
      const sx = ix / nx;
      const sz = iz / nz;
      const x = -width * 0.5 + sx * width;
      const z = THREE.MathUtils.lerp(zMin, zMax, sz);
      const az = Math.abs(z) / (depth * 0.5);
      const y = rise * (1 - Math.pow(az, 1.3)) + 0.12 * Math.pow(Math.abs(x) / (width * 0.5), 4) * Math.pow(az, 3);
      positions.push(x, y + 0.065, z);
      uvs.push(sx, sz);
    }
  }
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const a = iz * (nx + 1) + ix;
      const b = a + 1;
      const c = a + nx + 1;
      const d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function buildStall(opts) {
  const {
    x,
    z,
    rot = 0,
    type = 'candy',
    sign = 5,
    main = '#a73829',
    trim = '#d1a052',
    width = 2.12,
    depth = 1.16,
  } = opts;
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rot;
  staticRoot.add(g);

  const w = width;
  const d = depth;
  const topY = 2.22;

  // little paved pad and counter
  addBox(g, w + 0.32, 0.12, d + 0.34, '#4d5c67', 0, 0.06, 0, { outline: true });
  addBox(g, w * 0.93, 0.74, d * 0.70, '#6b3b28', 0, 0.51, 0.05, { outline: true });
  addBox(g, w * 0.99, 0.10, d * 0.76, '#a75d35', 0, 0.91, 0.05, { outline: false });
  addBox(g, w * 0.87, 0.055, d * 0.66, '#d4a052', 0, 0.95, 0.05, { cast: false });

  // posts and cross beams
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      addBox(g, 0.075, topY, 0.075, '#50291c', sx * w * 0.44, topY * 0.5 + 0.06, sz * d * 0.38, {
        outline: true,
      });
      addSphere(g, 0.065, trim, sx * w * 0.44, topY + 0.08, sz * d * 0.38, { sx: 1, sy: 1.1, sz: 1 });
    }
  }
  addBox(g, w * 0.96, 0.09, 0.10, '#5b2c1f', 0, topY, d * 0.38, { outline: false });
  addBox(g, w * 0.96, 0.09, 0.10, '#5b2c1f', 0, topY, -d * 0.38, { outline: false });

  // scalloped cloth canopy
  const canopy = meshStatic(g, makeCanopyGeometry(w + 0.28, d + 0.30, 0.42), cloth(main), {
    y: topY + 0.04,
    cast: true,
    receive: true,
  });
  canopy.userData.batch = 'cloth';
  addBox(g, w + 0.31, 0.045, 0.06, trim, 0, topY + 0.06, d * 0.5 + 0.15, { cast: false });
  addBox(g, w + 0.31, 0.045, 0.06, trim, 0, topY + 0.06, -d * 0.5 - 0.15, { cast: false });
  // alternating cream stripes on the canopy
  for (let i = 0; i < 5; i++) {
    const sx = -w * 0.36 + i * w * 0.18;
    addBox(g, 0.16, 0.015, d + 0.18, i % 2 ? '#e7c58f' : '#bd4a33', sx, topY + 0.47, 0, {
      cast: false,
      receive: false,
    });
  }
  // snow settles on the rear two-thirds of the canopy, leaving the lantern-lit
  // front edge and its hanging lanterns clear.
  meshStatic(g, makeCanopySnowGeometry(w + 0.22, d + 0.24, 0.42), snowSurfaceMaterial, {
    y: topY + 0.055,
    cast: false,
    receive: true,
  });

  // scalloped front valance
  const valGeo = new THREE.PlaneGeometry(w + 0.28, 0.34, 12, 1);
  const vpos = valGeo.attributes.position;
  for (let i = 0; i < vpos.count; i++) {
    if (vpos.getY(i) < 0) vpos.setY(i, -0.34 + 0.07 * Math.sin(vpos.getX(i) * 9.0));
  }
  valGeo.computeVertexNormals();
  const val = meshStatic(g, valGeo, cloth(main), {
    y: topY - 0.03,
    z: d * 0.5 + 0.14,
    cast: false,
  });
  val.userData.batch = 'cloth';
  for (let i = 0; i < 7; i++) {
    addBox(g, 0.032, 0.12, 0.032, '#d7a653', -w * 0.40 + i * w * 0.133, topY - 0.27, d * 0.5 + 0.16, {
      cast: false,
    });
  }

  // sign on the front beam
  addSign(g, sign % 8, 1.55, 0.76, 0, topY - 0.28, d * 0.5 + 0.205);
  g.updateMatrixWorld(true);

  // goods
  if (type === 'candy') {
    const rack = new THREE.Group();
    rack.position.set(0, 1.02, 0.04);
    g.add(rack);
    for (let r = 0; r < 2; r++) {
      for (let c = 0; c < 7; c++) {
        addCandySkewer(rack, -0.55 + c * 0.18, 0.31 + r * 0.24, -0.08 + r * 0.12, (r ? 0.06 : -0.06));
      }
    }
    addBox(rack, 1.36, 0.09, 0.16, '#8e5a31', 0, 0.24, 0, { outline: false });
    for (let i = 0; i < 5; i++) {
      addSphere(rack, 0.105, i % 2 ? '#f0a338' : '#d96f2d', -0.58 + i * 0.29, 1.07, 0.04, {
        sx: 1.15,
        sy: 0.78,
        sz: 1.15,
      });
    }
  } else if (type === 'mask') {
    addBox(g, 1.62, 1.18, 0.08, '#3a2117', 0, 1.53, 0.21, { outline: true });
    const colors = ['#d8573c', '#3d7b70', '#d9a441', '#9c3d32', '#557b98', '#c8893d'];
    for (let i = 0; i < 6; i++) {
      addMask(g, -0.52 + (i % 3) * 0.52, 1.74 - Math.floor(i / 3) * 0.48, 0.26, colors[i]);
    }
    addBox(g, 1.45, 0.08, 0.28, '#6e3f28', 0, 1.03, 0.14, { outline: false });
  } else if (type === 'food') {
    for (let i = 0; i < 4; i++) {
      addCylinder(g, 0.20, 0.16, 0.16, '#6b4d30', -0.66 + i * 0.42, 1.04, 0.08, {
        segments: 12,
        outline: false,
      });
      addSphere(g, 0.15, i % 2 ? '#e1af66' : '#c78245', -0.66 + i * 0.42, 1.13, 0.08, {
        sx: 1,
        sy: 0.4,
        sz: 1,
      });
    }
    for (let i = 0; i < 3; i++) {
      addSphere(g, 0.13, '#e8cda1', -0.5 + i * 0.5, 0.98, 0.46, { sx: 1.2, sy: 0.28, sz: 1.2 });
    }
    addSteam(x + Math.sin(rot) * 0.3, 1.5, z + Math.cos(rot) * 0.3, { size: 1.25 });
  } else if (type === 'lantern') {
    for (let i = 0; i < 3; i++) {
      addBox(g, 0.60, 0.20, 0.26, '#51291c', -0.56 + i * 0.58, 1.10, 0.02, { outline: false });
      for (let k = 0; k < 2; k++) {
        const local = V3(-0.56 + i * 0.58, 1.62 + k * 0.19, 0.0);
        const p = local.clone().applyMatrix4(g.matrixWorld);
        addLantern(p.x, p.y, p.z, 0.28, k ? '#ff8d3e' : '#ffbd63');
      }
    }
  } else if (type === 'sachet') {
    for (let i = 0; i < 12; i++) {
      const cc = choose(['#a5342d', '#d4933f', '#3e756b', '#c66a3e']);
      addBox(g, 0.17, 0.26, 0.06, cc, -0.7 + (i % 6) * 0.28, 1.22 + Math.floor(i / 6) * 0.34, 0.12, {
        rz: rand(-0.15, 0.15),
        cast: false,
      });
      addSphere(g, 0.026, '#e2b66a', -0.7 + (i % 6) * 0.28, 1.38 + Math.floor(i / 6) * 0.34, 0.17, {
        sx: 1,
        sy: 1,
        sz: 1,
        segments: 6,
      });
    }
    addBox(g, 1.45, 0.08, 0.26, '#623822', 0, 1.03, 0.14, { outline: false });
  }

  // countertop snacks and bowls
  for (let i = 0; i < 3; i++) {
    addCylinder(g, 0.15, 0.12, 0.09, '#d3b07a', -0.55 + i * 0.50, 1.00, 0.35, { segments: 9, outline: false });
    addSphere(g, 0.10, choose(['#e2b55c', '#c07035', '#c49a5a']), -0.55 + i * 0.50, 1.08, 0.35, {
      sx: 1,
      sy: 0.6,
      sz: 1,
    });
  }

  // little lanterns on both front posts
  g.updateMatrixWorld(true);
  for (const sx of [-1, 1]) {
    const p = V3(sx * w * 0.47, topY - 0.27, d * 0.43).applyMatrix4(g.matrixWorld);
    addLantern(p.x, p.y, p.z, 0.31, sx > 0 ? '#ffab4e' : '#ff8c3c');
  }
  const centerLantern = V3(0, topY + 0.16, d * 0.46).applyMatrix4(g.matrixWorld);
  addLantern(centerLantern.x, centerLantern.y, centerLantern.z, 0.35, '#ffb257');

  return g;
}

// ---------------------------------------------------------------------------
// Trees, shrubs and flowers
// ---------------------------------------------------------------------------

function makeTaperedTubeGeometry(curve, radiusStart, radiusEnd, tubularSegments = 14, radialSegments = 6) {
  const frames = curve.computeFrenetFrames(tubularSegments, false);
  const positions = [];
  const normals = [];
  const uvs = [];
  const indices = [];
  const point = new THREE.Vector3();
  const normal = new THREE.Vector3();

  for (let i = 0; i <= tubularSegments; i++) {
    const t = i / tubularSegments;
    curve.getPointAt(t, point);
    const N = frames.normals[i];
    const B = frames.binormals[i];
    const radius = THREE.MathUtils.lerp(radiusStart, radiusEnd, Math.pow(t, 0.72));
    for (let j = 0; j <= radialSegments; j++) {
      const v = (j / radialSegments) * Math.PI * 2;
      const sin = Math.sin(v);
      const cos = -Math.cos(v);
      normal.set(N.x * cos + B.x * sin, N.y * cos + B.y * sin, N.z * cos + B.z * sin).normalize();
      positions.push(point.x + normal.x * radius, point.y + normal.y * radius, point.z + normal.z * radius);
      normals.push(normal.x, normal.y, normal.z);
      uvs.push(t, j / radialSegments);
    }
  }

  for (let i = 0; i < tubularSegments; i++) {
    for (let j = 0; j < radialSegments; j++) {
      const a = i * (radialSegments + 1) + j;
      const b = (i + 1) * (radialSegments + 1) + j;
      const c = (i + 1) * (radialSegments + 1) + j + 1;
      const d = i * (radialSegments + 1) + j + 1;
      indices.push(a, b, d, b, c, d);
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  return geometry;
}

function addTreeBranch(parent, points, radiusStart, radiusEnd, color, opts = {}) {
  const curve = new THREE.CatmullRomCurve3(points);
  const geometry = makeTaperedTubeGeometry(
    curve,
    radiusStart,
    radiusEnd,
    opts.tubularSegments || 12,
    opts.radialSegments || 5
  );
  return meshStatic(parent, geometry, toon(color), {
    cast: opts.cast !== false,
    receive: true,
    outline: !!opts.outline,
  });
}

function makeLeafSprayGeometry(seed) {
  const rng = mulberry32(seed);
  const leaves = [];
  for (let i = 0; i < 21; i++) {
    const leaf = new THREE.IcosahedronGeometry(0.5, 0);
    const theta = rng() * Math.PI * 2;
    const phi = Math.acos(2 * rng() - 1);
    const distance = 0.14 + Math.pow(rng(), 0.58) * 0.9;
    const px = Math.sin(phi) * Math.cos(theta) * distance * 0.68;
    const py = Math.cos(phi) * distance * 0.48 + (rng() - 0.5) * 0.09;
    const pz = Math.sin(phi) * Math.sin(theta) * distance * 0.68;
    const size = 0.11 + rng() * 0.125;
    const q = new THREE.Quaternion().setFromEuler(
      new THREE.Euler(rng() * Math.PI * 2, rng() * Math.PI * 2, rng() * Math.PI * 2)
    );
    const matrix = new THREE.Matrix4().compose(
      V3(px, py, pz),
      q,
      V3(size * (0.7 + rng() * 0.65), size * (0.5 + rng() * 0.45), size * (0.7 + rng() * 0.6))
    );
    leaf.applyMatrix4(matrix);
    leaves.push(leaf);
  }
  const geometry = mergeGeometries(leaves, false);
  for (const leaf of leaves) leaf.dispose();
  return geometry;
}

const leafSprayGeometries = [
  makeLeafSprayGeometry(0x57a91b),
  makeLeafSprayGeometry(0x8d31c7),
  makeLeafSprayGeometry(0x3df02e),
];

function addLeafClump(parent, x, y, z, size, palette, rng, opts = {}) {
  const color = palette[Math.floor(rng() * palette.length)];
  const geometry = leafSprayGeometries[Math.floor(rng() * leafSprayGeometries.length)];
  const scale = size * 2.25;
  meshStatic(parent, geometry, toon(color), {
    x,
    y,
    z,
    sx: scale * (0.88 + rng() * 0.35),
    sy: scale * (0.64 + rng() * 0.3),
    sz: scale * (0.88 + rng() * 0.35),
    rx: (rng() - 0.5) * 0.35,
    ry: rng() * Math.PI * 2,
    rz: (rng() - 0.5) * 0.32,
    cast: opts.cast !== false,
    receive: true,
  });

  const satelliteCount = opts.satellites === undefined ? 1 : opts.satellites;
  for (let i = 0; i < satelliteCount; i++) {
    const angle = rng() * Math.PI * 2;
    const distance = size * (0.5 + rng() * 0.42);
    const satelliteColor = palette[Math.floor(rng() * palette.length)];
    const satelliteScale = size * (1.45 + rng() * 0.35);
    meshStatic(
      parent,
      leafSprayGeometries[Math.floor(rng() * leafSprayGeometries.length)],
      toon(satelliteColor),
      {
        x: x + Math.cos(angle) * distance,
        y: y + (rng() - 0.3) * size * 0.75,
        z: z + Math.sin(angle) * distance,
        sx: satelliteScale * (0.9 + rng() * 0.3),
        sy: satelliteScale * (0.65 + rng() * 0.25),
        sz: satelliteScale * (0.9 + rng() * 0.3),
        ry: rng() * Math.PI * 2,
        rz: (rng() - 0.5) * 0.3,
        cast: opts.cast !== false,
        receive: true,
      }
    );
  }
}

function buildTree(opts) {
  const { x, z, height = 5.5, kind = 'broadleaf', scale = 1, lanterns = false } = opts;
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.scale.setScalar(scale);
  staticRoot.add(g);

  const seed =
    ((Math.round((x + 40) * 97) * 73856093) ^
      (Math.round((z + 40) * 131) * 19349663) ^
      (Math.round(height * 41) * 83492791) ^
      (kind.charCodeAt(0) * 2654435761)) >>>
    0;
  const rng = mulberry32(seed);
  const R = (a, b) => a + (b - a) * rng();
  const pick = (arr) => arr[Math.floor(rng() * arr.length)];

  const isPlum = kind === 'plum';
  const isWillow = kind === 'willow';
  const trunkColor = isPlum ? '#4b2e23' : '#3e2b22';
  const foliagePalette = isPlum
    ? ['#477a55', '#5c8c5c', '#729f68', '#3b6a4c', '#86ad79']
    : isWillow
      ? ['#4a805c', '#5e9366', '#73a571', '#3f7050', '#88b17f']
      : ['#3f6f4e', '#527f53', '#67955f', '#78a46d', '#345f46', '#8bb47d'];
  const blossomPalette = ['#dfa2a0', '#e7bab1', '#c97e82', '#f0cbc0', '#d99196'];

  // Flared root and a gently leaning trunk.
  addCylinder(g, 0.18, 0.33, 0.5, trunkColor, 0, 0.24, 0, {
    segments: 9,
    outline: true,
    cast: true,
    receive: true,
  });

  const trunkPoints = [
    V3(0, 0, 0),
    V3(R(-0.1, 0.1), height * 0.2, R(-0.06, 0.06)),
    V3(R(-0.2, 0.2), height * 0.45, R(-0.12, 0.12)),
    V3(R(-0.3, 0.3), height * 0.68, R(-0.15, 0.15)),
    V3(R(-0.18, 0.18), height * 0.92, R(-0.1, 0.1)),
  ];
  const trunkCurve = new THREE.CatmullRomCurve3(trunkPoints);
  const trunkGeometry = makeTaperedTubeGeometry(trunkCurve, 0.23, 0.07, 30, 8);
  meshStatic(g, trunkGeometry, toon(trunkColor), {
    outline: true,
    cast: true,
    receive: true,
  });

  // Add a few darker bark strips so the trunk does not read as a smooth pole.
  for (let i = 0; i < 4; i++) {
    const t = R(0.15, 0.68);
    const base = trunkCurve.getPointAt(t);
    const side = R(0, Math.PI * 2);
    const length = R(0.35, 0.9);
    const pts = [
      V3(base.x + Math.cos(side) * 0.14, base.y, base.z + Math.sin(side) * 0.14),
      V3(
        base.x + Math.cos(side) * 0.13 + R(-0.03, 0.03),
        base.y + length * 0.5,
        base.z + Math.sin(side) * 0.13 + R(-0.03, 0.03)
      ),
      V3(base.x + Math.cos(side) * 0.1 + R(-0.04, 0.04), base.y + length, base.z + Math.sin(side) * 0.1),
    ];
    addTreeBranch(g, pts, 0.018, 0.006, '#2b1d18', { tubularSegments: 7, radialSegments: 4, cast: false });
  }

  const crownTips = [];
  const primaryBranches = [];
  const layers = [
    { t: 0.37, count: 2 },
    { t: 0.47, count: 2 },
    { t: 0.57, count: 3 },
    { t: 0.66, count: 3 },
    { t: 0.74, count: 2 },
    { t: 0.82, count: 2 },
    { t: 0.9, count: 1 },
  ];

  layers.forEach((layer, layerIndex) => {
    for (let b = 0; b < layer.count; b++) {
      const baseT = THREE.MathUtils.clamp(layer.t + R(-0.018, 0.018), 0.3, 0.93);
      const base = trunkCurve.getPointAt(baseT);
      const angle = layerIndex * 2.399 + b * 2.05 + R(-0.32, 0.32);
      const crownWindow = THREE.MathUtils.clamp((baseT - 0.3) / 0.62, 0, 1);
      const profile = 0.58 + Math.sin(Math.PI * crownWindow) * 0.82;
      const reach = R(0.78, 1.22) * profile * (height / 5.5) * (isWillow ? 1.06 : 1);
      const lift = R(0.32, 0.9) * (1.08 - baseT * 0.35) * (height / 5.5);
      const end = V3(base.x + Math.cos(angle) * reach, base.y + lift, base.z + Math.sin(angle) * reach * 0.82);
      const mid = V3(
        base.x + Math.cos(angle) * reach * 0.48 + R(-0.12, 0.12),
        base.y + lift * 0.42 + R(0.02, 0.18),
        base.z + Math.sin(angle) * reach * 0.48 + R(-0.12, 0.12)
      );
      addTreeBranch(g, [base, mid, end], 0.092, 0.028, trunkColor, {
        tubularSegments: 13,
        radialSegments: 5,
      });
      const curve = new THREE.CatmullRomCurve3([base, mid, end]);
      primaryBranches.push({ curve, end, baseT, angle });
      crownTips.push({ point: end, baseT, angle, size: 0.92 });

      const secondaryCount = baseT < 0.76 ? 2 : 1;
      for (let s = 0; s < secondaryCount; s++) {
        const at = R(0.5, 0.82);
        const start = curve.getPointAt(at);
        const sideAngle = angle + (s === 0 ? -0.75 : 0.75) + R(-0.28, 0.28);
        const reach2 = R(0.34, 0.72) * (height / 5.5) * (1.08 - baseT * 0.3);
        const tip = V3(
          start.x + Math.cos(sideAngle) * reach2,
          start.y + R(0.16, 0.48),
          start.z + Math.sin(sideAngle) * reach2 * 0.9
        );
        const mid2 = V3(
          start.x + Math.cos(sideAngle) * reach2 * 0.48 + R(-0.08, 0.08),
          start.y + R(0.1, 0.24),
          start.z + Math.sin(sideAngle) * reach2 * 0.48 + R(-0.08, 0.08)
        );
        addTreeBranch(g, [start, mid2, tip], 0.031, 0.008, trunkColor, {
          tubularSegments: 9,
          radialSegments: 4,
        });
        crownTips.push({ point: tip, baseT, angle: sideAngle, size: 0.8 });

        // Fine twig extension for a looser, less clipped silhouette.
        const twigAngle = sideAngle + R(-0.5, 0.5);
        const twigLength = R(0.18, 0.4) * (height / 5.5);
        const twigTip = V3(
          tip.x + Math.cos(twigAngle) * twigLength,
          tip.y + R(0.04, 0.2),
          tip.z + Math.sin(twigAngle) * twigLength
        );
        addTreeBranch(g, [tip, twigTip], 0.009, 0.003, trunkColor, {
          tubularSegments: 6,
          radialSegments: 4,
          cast: false,
        });
        crownTips.push({ point: twigTip, baseT, angle: twigAngle, size: 0.7 });
      }
    }
  });

  // Leaf clumps at the fine outer tips, with occasional inner fill.
  for (const tip of crownTips) {
    if (tip.size < 0.75) continue;
    const size = R(0.23, 0.36) * (1.08 - tip.baseT * 0.22) * (height / 5.5) * tip.size;
    addLeafClump(g, tip.point.x, tip.point.y, tip.point.z, size, foliagePalette, rng);
  }

  for (const branch of primaryBranches) {
    const p = branch.curve.getPointAt(R(0.52, 0.78));
    const size = R(0.16, 0.24) * (height / 5.5);
    addLeafClump(
      g,
      p.x + R(-0.14, 0.14),
      p.y + R(-0.08, 0.14),
      p.z + R(-0.14, 0.14),
      size,
      foliagePalette,
      rng,
      { satellites: 1, cast: false }
    );
  }

  // A few clusters close to the upper trunk fill the crown without making it solid.
  for (let i = 0; i < 4; i++) {
    const p = trunkCurve.getPointAt(0.58 + i * 0.09);
    const a = i * 2.2 + R(-0.5, 0.5);
    const rr = R(0.18, 0.42);
    addLeafClump(
      g,
      p.x + Math.cos(a) * rr,
      p.y + R(-0.08, 0.12),
      p.z + Math.sin(a) * rr,
      R(0.13, 0.21) * (height / 5.5),
      foliagePalette,
      rng,
      { satellites: 1, cast: false }
    );
  }

  // A soft upper crown fills the space between the branches and keeps the
  // silhouette rounded rather than umbrella-flat.
  for (let i = 0; i < 9; i++) {
    const t = R(0.6, 0.94);
    const p = trunkCurve.getPointAt(t);
    const a = R(0, Math.PI * 2);
    const reach = R(0.2, 1.05) * (1 - (t - 0.6) * 1.25);
    addLeafClump(
      g,
      p.x + Math.cos(a) * reach,
      p.y + R(-0.02, 0.24),
      p.z + Math.sin(a) * reach * 0.82,
      R(0.17, 0.29) * (height / 5.5),
      foliagePalette,
      rng,
      { satellites: 1, cast: false }
    );
  }

  // Close the middle of the crown so the tiers read as one continuous canopy.
  for (let i = 0; i < 6; i++) {
    const t = 0.6 + i * 0.045 + R(-0.018, 0.018);
    const p = trunkCurve.getPointAt(t);
    const a = i * 2.17 + R(-0.35, 0.35);
    const reach = R(0.32, 0.82) * (1 - (t - 0.6) * 0.7);
    addLeafClump(
      g,
      p.x + Math.cos(a) * reach,
      p.y + R(-0.04, 0.18),
      p.z + Math.sin(a) * reach * 0.8,
      R(0.2, 0.3) * (height / 5.5),
      foliagePalette,
      rng,
      { satellites: 1, cast: false }
    );
  }

  const crownTop = trunkCurve.getPointAt(0.965);
  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * Math.PI * 2 + R(-0.4, 0.4);
    const rr = R(0.08, 0.28);
    addLeafClump(
      g,
      crownTop.x + Math.cos(a) * rr,
      crownTop.y + R(-0.06, 0.14),
      crownTop.z + Math.sin(a) * rr,
      R(0.16, 0.24) * (height / 5.5),
      foliagePalette,
      rng,
      { satellites: 0, cast: false }
    );
  }

  if (isPlum) {
    for (const tip of crownTips) {
      if (tip.size < 0.75) continue;
      const blossomCount = 2 + Math.floor(rng() * 3);
      for (let i = 0; i < blossomCount; i++) {
        const a = rng() * Math.PI * 2;
        const rr = R(0.04, 0.32);
        addSphere(
          g,
          R(0.033, 0.062),
          pick(blossomPalette),
          tip.point.x + Math.cos(a) * rr,
          tip.point.y + R(-0.18, 0.22),
          tip.point.z + Math.sin(a) * rr,
          {
            sx: 0.9 + rng() * 0.5,
            sy: 0.62 + rng() * 0.35,
            sz: 0.9 + rng() * 0.5,
            rx: rng() * Math.PI,
            ry: rng() * Math.PI,
            rz: rng() * Math.PI,
            segments: 4,
            cast: false,
            receive: false,
          }
        );
      }
    }
  }

  if (isWillow) {
    // A handful of weeping strands break up the crown edge.
    for (let s = 0; s < 7; s++) {
      const tip = crownTips[Math.floor(rng() * crownTips.length)].point;
      const base = V3(tip.x + R(-0.2, 0.2), tip.y - R(0.05, 0.24), tip.z + R(-0.2, 0.2));
      const pts = [base];
      for (let i = 1; i <= 5; i++) {
        pts.push(
          V3(
            base.x + Math.sin(i * 0.9 + s) * 0.11,
            base.y - i * (0.16 + R(0.03, 0.09)),
            base.z + Math.cos(i * 0.8 + s) * 0.1
          )
        );
      }
      addTreeBranch(g, pts, 0.012, 0.003, '#456f50', {
        tubularSegments: 8,
        radialSegments: 4,
        cast: false,
      });
      for (let i = 1; i < 5; i++) {
        const p = pts[i];
        addSphere(g, R(0.025, 0.045), pick(foliagePalette), p.x + R(-0.06, 0.06), p.y, p.z + R(-0.06, 0.06), {
          sx: 1.0,
          sy: 0.52,
          sz: 0.9,
          segments: 4,
          cast: false,
        });
      }
    }
  }

  if (lanterns) {
    g.updateMatrixWorld(true);
    for (let i = 0; i < 5; i++) {
      const a = R(0, Math.PI * 2);
      const rr = R(0.5, 1.55);
      const p = V3(Math.cos(a) * rr, height * R(0.45, 0.74), Math.sin(a) * rr * 0.8).applyMatrix4(g.matrixWorld);
      addLantern(p.x, p.y, p.z, R(0.2, 0.3), pick(['#ffa957', '#ff8a3a', '#ffbe69']));
    }
  }

  return g;
}

// ---------------------------------------------------------------------------
// Miniature people
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Animated pedestrians
// ---------------------------------------------------------------------------

const walkers = [];
let personSerial = 0;

const walkerShadowGeometry = new THREE.PlaneGeometry(0.95, 0.62);
const walkerShadowMaterial = new THREE.MeshBasicMaterial({
  map: glowTexture,
  color: 0x000000,
  transparent: true,
  opacity: 0.22,
  depthWrite: false,
  toneMapped: false,
});

function mergePersonGroup(group) {
  group.updateMatrixWorld(true);
  const toonParts = [];
  const clothParts = [];
  const outlineParts = [];
  const meshes = [];
  group.traverse((obj) => {
    if (obj.isMesh) meshes.push(obj);
  });

  for (const mesh of meshes) {
    mesh.updateMatrix();
    const color = mesh.material?.color ? mesh.material.color.clone() : new THREE.Color(0xffffff);
    const geo = cleanForBatch(mesh.geometry, mesh.matrix, color);
    if (mesh.userData.batch === 'cloth') clothParts.push(geo);
    else toonParts.push(geo);
    if (mesh.userData.outline) {
      outlineParts.push(cleanForBatch(mesh.geometry, mesh.matrix, new THREE.Color(0x201211)));
    }
  }

  for (const mesh of meshes) group.remove(mesh);

  const addMerged = (parts, material, castShadow = false) => {
    if (!parts.length) return;
    const merged = mergeGeometries(parts, false);
    for (const part of parts) part.dispose();
    if (!merged) return;
    merged.computeBoundingSphere();
    const mesh = new THREE.Mesh(merged, material);
    mesh.castShadow = castShadow;
    mesh.receiveShadow = true;
    group.add(mesh);
  };

  addMerged(toonParts, batchMaterials.toon);
  addMerged(clothParts, batchMaterials.cloth);
  addMerged(outlineParts, outlineMaterial);

  const shadow = new THREE.Mesh(walkerShadowGeometry, walkerShadowMaterial);
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.018;
  shadow.renderOrder = 2;
  group.add(shadow);
}

function makeWalkerRoute(x, z, y, index) {
  const speed = 0.32 + (index % 5) * 0.045;
  const pauseTime = 0.8 + (index % 4) * 0.28;
  const phase = index * 1.37;
  const stride = 4.2 + (index % 4) * 0.24;

  if (y > 0.5) {
    return { ax: x, az: 5.45, bx: x, bz: 9.65, bridge: true, speed: speed + 0.04, pauseTime, phase, stride };
  }

  if (z > 8.8) {
    const narrow = Math.abs(x) < 2.3;
    const az = narrow ? 10.35 : 9.75;
    const bz = Math.min(14.25, Math.max(az + 2.0, z + 2.1));
    return { ax: x, az, bx: x, bz, bridge: false, speed, pauseTime, phase, stride };
  }

  if (z >= 3.6 && Math.abs(x) < 5.4) {
    return {
      ax: x,
      az: Math.max(3.45, z - 0.75),
      bx: x,
      bz: Math.min(4.7, z + 0.75),
      bridge: false,
      speed,
      pauseTime,
      phase,
      stride,
    };
  }

  const half = 0.72 + (index % 3) * 0.1;
  return {
    ax: x,
    az: z - half,
    bx: x,
    bz: z + half,
    bridge: false,
    speed,
    pauseTime,
    phase,
    stride,
  };
}

function clampWalkerT(route, x, z) {
  const dx = route.bx - route.ax;
  const dz = route.bz - route.az;
  const len2 = dx * dx + dz * dz;
  if (len2 < 1e-4) return 0;
  return THREE.MathUtils.clamp(((x - route.ax) * dx + (z - route.az) * dz) / len2, 0, 1);
}

function dampHeading(current, target, lambda, dt) {
  let delta = target - current;
  delta = Math.atan2(Math.sin(delta), Math.cos(delta));
  return current + delta * (1 - Math.exp(-lambda * dt));
}

function updateWalkers(dt, time) {
  for (const walker of walkers) {
    if (walker.pause > 0) {
      walker.pause = Math.max(0, walker.pause - dt);
    } else {
      walker.t += (walker.dir * walker.speed * dt) / walker.length;
      if (walker.t >= 1) {
        walker.t = 1;
        walker.dir = -1;
        walker.pause = walker.pauseTime;
      } else if (walker.t <= 0) {
        walker.t = 0;
        walker.dir = 1;
        walker.pause = walker.pauseTime;
      }
    }

    const dx = walker.bx - walker.ax;
    const dz = walker.bz - walker.az;
    const px = walker.ax + dx * walker.t;
    const pz = walker.az + dz * walker.t;
    const moving = walker.pause <= 0.001;
    const sway = Math.sin(time * 1.35 + walker.phase) * 0.035;
    const alongX = Math.abs(dx) > Math.abs(dz);
    const x = px + (alongX ? 0 : sway);
    const z = pz + (alongX ? sway : 0);
    const y = (walker.bridge ? bridgeDeckY(z) : 0) + (moving ? Math.abs(Math.sin(time * walker.stride + walker.phase)) * 0.022 : 0);

    walker.group.position.set(x, y, z);
    const targetHeading = Math.atan2(dx * walker.dir, dz * walker.dir);
    walker.heading = dampHeading(walker.heading, targetHeading, 6.0, dt);
    walker.group.rotation.y = walker.heading;
    walker.group.rotation.z = moving ? Math.sin(time * walker.stride + walker.phase) * 0.018 : 0;
  }
}

function buildPerson(opts) {
  const {
    x,
    z,
    y = 0,
    rot = 0,
    scale = 1,
    robe = '#a7382b',
    coat = '#2f675d',
    accent = '#d1a050',
    hair = '#241713',
    pose = 0,
    scarf = null,
  } = opts;
  const personIndex = personSerial++;
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rot;
  g.scale.setScalar(scale);
  scene.add(g);

  // flowing robe
  addCylinder(g, 0.22, 0.40, 0.92, robe, 0, 0.48, 0, { segments: 10, outline: true });
  addCylinder(g, 0.16, 0.25, 0.52, coat, 0, 1.14, 0, { segments: 9, outline: true });
  addCylinder(g, 0.25, 0.27, 0.10, accent, 0, 0.97, 0, { segments: 10, outline: false });
  addBox(g, 0.08, 0.34, 0.035, accent, 0, 0.78, 0.24, { cast: false });
  addBox(g, 0.32, 0.045, 0.035, accent, 0, 0.65, 0.23, { cast: false });

  // sleeves, hands
  for (const sx of [-1, 1]) {
    const lean = sx * (0.32 + pose * 0.12);
    addCylinder(g, 0.075, 0.12, 0.54, coat, sx * 0.25, 1.12, 0.03, {
      rz: lean,
      segments: 7,
      outline: true,
    });
    addSphere(g, 0.055, '#e2b393', sx * 0.37, 0.91, 0.05, { sx: 0.9, sy: 0.8, sz: 0.9, segments: 7 });
    addCylinder(g, 0.04, 0.055, 0.32, robe, sx * 0.24, 1.27, 0.02, {
      rz: lean * 1.3,
      segments: 5,
      outline: false,
    });
  }

  // neck, face and hair
  addCylinder(g, 0.055, 0.06, 0.08, '#d9a67f', 0, 1.42, 0, { segments: 7, cast: false });
  addSphere(g, 0.145, '#ecc2a0', 0, 1.56, 0.01, { sx: 0.92, sy: 1.05, sz: 0.88, outline: true });
  addSphere(g, 0.145, hair, 0, 1.62, -0.035, { sx: 0.98, sy: 0.9, sz: 0.92, segments: 10 });
  if (pose % 2 === 0) {
    addSphere(g, 0.095, hair, 0, 1.78, -0.02, { sx: 1.3, sy: 0.6, sz: 1.0, segments: 8 });
    addSphere(g, 0.055, hair, 0, 1.82, -0.10, { sx: 1, sy: 1.5, sz: 1, segments: 7 });
    addBox(g, 0.03, 0.025, 0.12, accent, 0.10, 1.73, 0.02, { rz: -0.4, cast: false });
  } else {
    addCylinder(g, 0.11, 0.11, 0.07, '#1f1714', 0, 1.73, 0, { segments: 8, outline: false });
    addBox(g, 0.05, 0.025, 0.14, accent, 0.08, 1.74, 0.03, { rz: 0.22, cast: false });
  }

  // Scarf tails used to read as stiff pale rods from this camera; keep the
  // figures clean and let the robe colours carry the costume instead.

  mergePersonGroup(g);

  const route = makeWalkerRoute(x, z, y, personIndex);
  const initialT = clampWalkerT(route, x, z);
  let dir = personIndex % 2 === 0 ? 1 : -1;
  if (initialT <= 0.02) dir = 1;
  else if (initialT >= 0.98) dir = -1;

  const dx = route.bx - route.ax;
  const dz = route.bz - route.az;
  const startX = route.ax + dx * initialT;
  const startZ = route.az + dz * initialT;
  const heading = Math.atan2(dx * dir, dz * dir);
  g.position.set(startX, route.bridge ? bridgeDeckY(startZ) : 0, startZ);
  g.rotation.set(0, heading, 0);

  walkers.push({
    group: g,
    ax: route.ax,
    az: route.az,
    bx: route.bx,
    bz: route.bz,
    bridge: route.bridge,
    speed: route.speed,
    pauseTime: route.pauseTime,
    pause: 0.15 + (personIndex % 4) * 0.22,
    phase: route.phase,
    stride: route.stride,
    heading,
    dir,
    t: initialT,
    length: Math.max(0.01, Math.hypot(dx, dz)),
  });

  return g;
}

// ---------------------------------------------------------------------------
// The great flower-lantern carriage (the heart of the scene)
// ---------------------------------------------------------------------------

function makeHexRoofGeometry(radius, rise, upturn, segments = 36, rings = 8) {
  const positions = [];
  const uvs = [];
  const indices = [];
  for (let ir = 0; ir <= rings; ir++) {
    const t = ir / rings;
    for (let ia = 0; ia <= segments; ia++) {
      const theta = (ia / segments) * Math.PI * 2;
      const corner = Math.pow(Math.max(0, Math.cos(theta * 6)), 3.2);
      const r = Math.max(0.035, t * radius);
      const y = rise * (1 - Math.pow(t, 1.62)) + upturn * Math.pow(t, 5.0) * corner;
      positions.push(Math.cos(theta) * r, y, Math.sin(theta) * r);
      uvs.push((ia / segments) * 4.4, t * 3.2);
    }
  }
  for (let ir = 0; ir < rings; ir++) {
    for (let ia = 0; ia < segments; ia++) {
      const a = ir * (segments + 1) + ia;
      const b = a + 1;
      const c = a + segments + 1;
      const d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function addHexRoof(parent, opts) {
  const { y, radius, rise, upturn, color, trim } = opts;
  const g = new THREE.Group();
  g.position.y = y;
  parent.add(g);

  meshStatic(g, makeHexRoofGeometry(radius, rise, upturn), roofMat(color), {
    cast: true,
    receive: true,
  });

  // gold ridges from the crown to each eave corner
  for (let i = 0; i < 6; i++) {
    const theta = (i / 6) * Math.PI * 2;
    const pts = [];
    for (let k = 0; k <= 12; k++) {
      const t = k / 12;
      const corner = Math.pow(Math.max(0, Math.cos(theta * 6)), 3.2);
      const rr = Math.max(0.035, t * radius);
      const yy = rise * (1 - Math.pow(t, 1.62)) + upturn * Math.pow(t, 5) * corner;
      pts.push(V3(Math.cos(theta) * rr, yy + 0.02, Math.sin(theta) * rr));
    }
    meshStatic(g, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 20, 0.037, 5, false), toon(trim), {
      cast: false,
    });
    const tip = pts[pts.length - 1];
    const outDir = V3(Math.cos(theta), 0.32, Math.sin(theta));
    const curl = new THREE.CatmullRomCurve3([
      tip.clone(),
      tip.clone().add(outDir.clone().multiplyScalar(0.18)),
      tip.clone().add(outDir.clone().multiplyScalar(0.44)).add(V3(0, 0.24, 0)),
    ]);
    meshStatic(g, new THREE.TubeGeometry(curl, 10, 0.035, 5, false), toon(trim), { cast: false });
    addSphere(g, 0.06, trim, tip.x + outDir.x * 0.44, tip.y + 0.26, tip.z + outDir.z * 0.44, {
      sx: 1,
      sy: 1.2,
      sz: 1,
    });
  }

  // eave border
  const eavePoints = [];
  for (let i = 0; i <= 72; i++) {
    const theta = (i / 72) * Math.PI * 2;
    const corner = Math.pow(Math.max(0, Math.cos(theta * 6)), 3.2);
    eavePoints.push(V3(Math.cos(theta) * radius, upturn * corner + 0.025, Math.sin(theta) * radius));
  }
  meshStatic(
    g,
    new THREE.TubeGeometry(new THREE.CatmullRomCurve3(eavePoints, true), 90, 0.035, 5, true),
    toon(trim),
    { cast: false }
  );

  // little ridge-end pearls
  for (let i = 0; i < 6; i++) {
    const theta = (i / 6) * Math.PI * 2;
    addSphere(g, 0.07, trim, Math.cos(theta) * radius * 0.43, rise * 0.82, Math.sin(theta) * radius * 0.43, {
      sx: 0.9,
      sy: 1.2,
      sz: 0.9,
    });
  }

  // hanging cloth valance
  const segs = 30;
  const positions = [];
  const uvs = [];
  const indices = [];
  for (let row = 0; row <= 1; row++) {
    for (let i = 0; i <= segs; i++) {
      const theta = (i / segs) * Math.PI * 2;
      const r = 2.34;
      const scallop = row === 0 ? 0 : Math.max(0, Math.sin(theta * 6)) * 0.13;
      positions.push(Math.cos(theta) * r, -row * 0.52 - scallop, Math.sin(theta) * r);
      uvs.push(i / segs, row);
    }
  }
  for (let i = 0; i < segs; i++) {
    const a = i;
    const b = i + 1;
    const c = i + segs + 1;
    const d = c + 1;
    indices.push(a, c, b, b, c, d);
  }
  const valGeo = new THREE.BufferGeometry();
  valGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  valGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  valGeo.setIndex(indices);
  valGeo.computeVertexNormals();
  meshStatic(g, valGeo, cloth('#a53128'), { y: -0.10, cast: false, receive: false });
  addCylinder(g, 2.38, 2.38, 0.05, trim, 0, -0.08, 0, {
    segments: 30,
    cast: false,
    receive: false,
  });

  return g;
}

function buildFloat() {
  const fx = 0;
  const fz = -1.7;
  const g = new THREE.Group();
  g.position.set(fx, 0, fz);
  g.scale.setScalar(1.1);
  staticRoot.add(g);

  // carved wheels
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const wx = sx * 1.95;
      const wz = sz * 1.55;
      addCylinder(g, 0.74, 0.74, 0.25, '#4b2b20', wx, 0.76, wz, {
        rz: Math.PI / 2,
        segments: 18,
        outline: true,
      });
      addCylinder(g, 0.54, 0.54, 0.29, '#9c6d39', wx, 0.76, wz, {
        rz: Math.PI / 2,
        segments: 16,
        outline: false,
      });
      for (let s = 0; s < 8; s++) {
        const a = (s / 8) * Math.PI * 2;
        addBox(g, 0.04, 0.92, 0.05, '#4a2d20', wx, 0.76, wz, {
          rx: a,
          cast: false,
        });
      }
      addSphere(g, 0.14, '#d0a154', wx + sx * 0.14, 0.76, wz, { sx: 0.65, sy: 1, sz: 1 });
    }
  }

  // carriage chassis
  addBox(g, 5.45, 0.36, 4.28, '#4a2419', 0, 1.25, 0, { outline: true });
  addBox(g, 5.62, 0.13, 4.45, '#ba8a47', 0, 1.46, 0, { outline: false });
  addBox(g, 5.12, 0.66, 4.02, '#2c5a50', 0, 1.84, 0, { outline: true });
  addBox(g, 5.24, 0.12, 4.14, '#d2a553', 0, 2.18, 0, { outline: false });

  // glowing lotus panels around the lower cabinet
  for (let i = 0; i < 6; i++) {
    const theta = (i / 6) * Math.PI * 2;
    const lx = Math.cos(theta) * 2.28;
    const lz = Math.sin(theta) * 1.76;
    const panel = new THREE.Mesh(
      new THREE.PlaneGeometry(0.9, 0.42),
      glowMat(i % 2 ? 0xffca7d : 0xffa24d, 2.4)
    );
    panel.position.set(lx, 1.84, lz);
    panel.rotation.y = -theta + Math.PI / 2;
    panel.userData.batch = 'glow';
    g.add(panel);
    addBox(g, 1.10, 0.07, 0.08, '#d3a653', lx, 2.10, lz, { ry: -theta + Math.PI / 2, cast: false });
  }

  // four great corner columns and their golden caps
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const px = sx * 2.02;
      const pz = sz * 1.63;
      addCylinder(g, 0.13, 0.17, 6.48, '#752b23', px, 5.54, pz, {
        segments: 10,
        outline: true,
      });
      for (const yy of [2.24, 3.85, 5.48, 7.56]) {
        addCylinder(g, 0.18, 0.18, 0.08, '#d2a04c', px, yy, pz, { segments: 10, cast: false });
      }
      addBox(g, 0.48, 0.22, 0.48, '#d2a04c', px, 8.00, pz, { outline: true });
      addBox(g, 0.76, 0.15, 0.76, '#7a3328', px, 8.18, pz, { outline: true });
    }
  }

  // lower gallery balustrade
  addCylinder(g, 2.42, 2.42, 0.20, '#4e2a1e', 0, 7.63, 0, { segments: 30, outline: true });
  addCylinder(g, 2.47, 2.47, 0.07, '#d2a24f', 0, 7.76, 0, { segments: 30, outline: false });
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    addBox(g, 0.06, 0.44, 0.06, '#7f3326', Math.cos(a) * 2.35, 7.93, Math.sin(a) * 2.35, {
      outline: false,
      cast: false,
    });
  }

  // wooden cage ribs around the painted lantern
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + Math.PI / 6;
    const px = Math.cos(a) * 1.94;
    const pz = Math.sin(a) * 1.56;
    addBox(g, 0.10, 5.36, 0.10, '#5b2a1d', px, 4.96, pz, { outline: false });
  }
  for (const yy of [2.30, 4.95, 7.58]) {
    const ringGeo = new THREE.TorusGeometry(1.90, 0.055, 5, 30);
    meshStatic(g, ringGeo, toon('#d1a04e'), { y: yy, rx: Math.PI / 2, cast: false });
  }
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2;
    const rr = 1.92;
    addSphere(g, 0.045, '#e2b665', Math.cos(a) * rr, 3.20, Math.sin(a) * rr * 0.81, {
      sx: 1,
      sy: 1,
      sz: 1,
      segments: 6,
    });
    addSphere(g, 0.045, '#e2b665', Math.cos(a) * rr, 6.62, Math.sin(a) * rr * 0.81, {
      sx: 1,
      sy: 1,
      sz: 1,
      segments: 6,
    });
  }

  // hanging silk banner on the front
  addBanner(g, 0, 0.82, 2.30, 0, 6.25, 2.44, 0);

  // roof and finial
  addHexRoof(g, {
    y: 8.04,
    radius: 3.10,
    rise: 1.48,
    upturn: 0.52,
    color: '#2b5753',
    trim: '#d2a354',
  });
  addCylinder(g, 0.23, 0.31, 0.34, '#d3a653', 0, 9.60, 0, { segments: 10, outline: true });
  addSphere(g, 0.23, '#e7ba68', 0, 9.86, 0, { sx: 1, sy: 1.1, sz: 1 });
  addSphere(g, 0.13, '#fff1c4', 0, 9.86, 0, { sx: 1.15, sy: 1.15, sz: 1.15, segments: 10 });
  addCylinder(g, 0.02, 0.045, 0.65, '#d2a354', 0, 10.34, 0, { segments: 6, cast: false });
  addSphere(g, 0.06, '#f3cd7c', 0, 10.65, 0, { sx: 1, sy: 1, sz: 1, segments: 7 });

  // hanging lanterns around the eaves and chassis
  g.updateMatrixWorld(true);
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + Math.PI / 6;
    const p = V3(Math.cos(a) * 2.62, 7.60, Math.sin(a) * 2.62).applyMatrix4(g.matrixWorld);
    addLantern(p.x, p.y, p.z, 0.40, i % 2 ? '#ff8a3b' : '#ffad53');
    addBox(g, 0.022, 0.42, 0.022, '#422217', Math.cos(a) * 2.62, 7.82, Math.sin(a) * 2.62, {
      cast: false,
    });
  }
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const p = V3(Math.cos(a) * 2.45, 2.74, Math.sin(a) * 2.1).applyMatrix4(g.matrixWorld);
    addLantern(p.x, p.y, p.z, 0.27, '#ff9846');
  }

  // a second, brighter painting cylinder is added directly to the scene below.
  const artMaterial = new THREE.MeshBasicMaterial({
    map: artworkTexture,
    color: 0xffffff,
    side: THREE.DoubleSide,
    transparent: false,
    toneMapped: true,
    depthWrite: true,
  });
  const artCylinder = new THREE.Mesh(new THREE.CylinderGeometry(2.10, 2.10, 5.81, 40, 1, true), artMaterial);
  artCylinder.position.set(fx, 5.46, fz);
  scene.add(artCylinder);

  const coreMaterial = new THREE.MeshBasicMaterial({
    color: new THREE.Color(0xffbd65).multiplyScalar(1.15),
    transparent: true,
    opacity: 0.55,
    toneMapped: true,
    side: THREE.DoubleSide,
  });
  const core = new THREE.Mesh(new THREE.CylinderGeometry(1.47, 1.47, 5.94, 24, 1, true), coreMaterial);
  core.position.set(fx, 5.46, fz);
  scene.add(core);

  // a warm halo behind the lantern carriage
  const halo = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      color: 0xffad55,
      transparent: true,
      opacity: 0.20,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      depthTest: true,
      fog: false,
      toneMapped: false,
    })
  );
  halo.position.set(fx, 5.8, fz);
  halo.scale.set(11.5, 11.5, 1);
  halo.renderOrder = 4;
  scene.add(halo);

  return { group: g, x: fx, z: fz, halo };
}

// ---------------------------------------------------------------------------
// Animated silk ribbons around the lantern carriage
// ---------------------------------------------------------------------------

class FloatRibbon {
  constructor({ color, width, radiusInner, radiusOuter, topY, bottomY, phase, turns, speed, segments = 72 }) {
    this.color = new THREE.Color(color);
    this.width = width;
    this.radiusInner = radiusInner;
    this.radiusOuter = radiusOuter;
    this.topY = topY;
    this.bottomY = bottomY;
    this.phase = phase;
    this.turns = turns;
    this.speed = speed;
    this.segments = segments;
    this.center = V3(0, 0, -1.7);

    const positions = new Float32Array((segments + 1) * 2 * 3);
    const colors = new Float32Array((segments + 1) * 2 * 3);
    const indices = [];
    for (let i = 0; i < segments; i++) {
      const a = i * 2;
      indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.setIndex(indices);
    this.geometry = geo;
    this.material = new THREE.MeshBasicMaterial({
      vertexColors: true,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.97,
      toneMapped: false,
      depthWrite: false,
    });
    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 1;
    scene.add(this.mesh);
    this.points = [];
    for (let i = 0; i <= segments; i++) this.points.push(V3());
    this._up = V3(0, 1, 0);
    this._tangent = V3();
    this._side = V3();
    this._left = V3();
    this._right = V3();
    this.update(0);
  }

  update(time) {
    const count = this.segments + 1;
    const pos = this.geometry.attributes.position.array;
    const colArr = this.geometry.attributes.color.array;
    const up = this._up;
    const tangent = this._tangent;
    const side = this._side;
    const left = this._left;
    const right = this._right;
    for (let i = 0; i < count; i++) {
      const t = i / this.segments;
      const angle = this.phase + t * this.turns + Math.sin(t * 3.2 + time * 0.24 + this.phase) * 0.18;
      const radius =
        this.radiusInner +
        (this.radiusOuter - this.radiusInner) * Math.pow(t, 0.72) +
        Math.sin(t * 6.0 + time * 0.34 + this.phase) * 0.10;
      const y = THREE.MathUtils.lerp(this.topY, this.bottomY, Math.pow(t, 0.92)) + Math.sin(t * 5.2 + time * 0.42 + this.phase) * 0.08;
      this.points[i].set(
        this.center.x + Math.cos(angle) * radius,
        y,
        this.center.z + Math.sin(angle) * radius
      );
    }
    for (let i = 0; i < count; i++) {
      const t = i / this.segments;
      const p = this.points[i];
      const a = this.points[Math.max(0, i - 1)];
      const b = this.points[Math.min(count - 1, i + 1)];
      tangent.copy(b).sub(a).normalize();
      side.copy(tangent).cross(up).normalize();
      if (side.lengthSq() < 0.01) side.set(1, 0, 0);
      const twist = Math.sin(t * 8.0 + time * 0.3 + this.phase) * 0.6;
      side.applyAxisAngle(tangent, twist);
      const halfW = this.width * (0.68 + Math.sin(t * 5.0 + this.phase) * 0.18) * 0.5;
      left.copy(p).addScaledVector(side, halfW);
      right.copy(p).addScaledVector(side, -halfW);
      const k = i * 2 * 3;
      pos[k] = left.x;
      pos[k + 1] = left.y;
      pos[k + 2] = left.z;
      pos[k + 3] = right.x;
      pos[k + 4] = right.y;
      pos[k + 5] = right.z;

      const glow = 0.55 + Math.sin(t * Math.PI) * 0.5;
      colArr[k] = this.color.r * glow;
      colArr[k + 1] = this.color.g * glow;
      colArr[k + 2] = this.color.b * glow;
      colArr[k + 3] = this.color.r * glow * 0.72;
      colArr[k + 4] = this.color.g * glow * 0.72;
      colArr[k + 5] = this.color.b * glow * 0.72;
    }
    this.geometry.attributes.position.needsUpdate = true;
    this.geometry.attributes.color.needsUpdate = true;
  }
}

const floatRibbons = [
  new FloatRibbon({
    color: '#ec4b34',
    width: 0.48,
    radiusInner: 2.30,
    radiusOuter: 4.15,
    topY: 8.72,
    bottomY: 2.55,
    phase: 0.25,
    turns: Math.PI * 1.35,
    speed: 1,
  }),
  new FloatRibbon({
    color: '#ffe0a9',
    width: 0.30,
    radiusInner: 2.42,
    radiusOuter: 4.42,
    topY: 8.42,
    bottomY: 3.3,
    phase: 2.1,
    turns: Math.PI * 1.22,
    speed: 1,
  }),
  new FloatRibbon({
    color: '#6cae94',
    width: 0.34,
    radiusInner: 2.50,
    radiusOuter: 3.7,
    topY: 8.96,
    bottomY: 2.1,
    phase: 4.15,
    turns: Math.PI * 1.1,
    speed: 1,
  }),
  new FloatRibbon({
    color: '#c22f2c',
    width: 0.16,
    radiusInner: 2.4,
    radiusOuter: 4.55,
    topY: 9.18,
    bottomY: 4.15,
    phase: 5.1,
    turns: Math.PI * 1.55,
    speed: 1,
  }),
];

// ---------------------------------------------------------------------------
// Lantern strings and pennants
// ---------------------------------------------------------------------------

function addPennant(parent, x, y, z, ry, color) {
  const w = 0.24;
  const h = 0.34;
  const geo = new THREE.BufferGeometry();
  geo.setAttribute(
    'position',
    new THREE.Float32BufferAttribute(
      [-w * 0.5, 0, 0, w * 0.5, 0, 0, 0, -h, 0],
      3
    )
  );
  geo.setAttribute(
    'uv',
    new THREE.Float32BufferAttribute([0, 1, 1, 1, 0.5, 0], 2)
  );
  geo.computeVertexNormals();
  const mesh = meshStatic(parent, geo, cloth(color), {
    x,
    y,
    z,
    ry,
    cast: false,
    receive: false,
  });
  mesh.userData.batch = 'cloth';
  addBox(parent, w + 0.04, 0.025, 0.025, '#d2a353', x, y + 0.01, z, { ry, cast: false });
}

function addLanternString(from, to, sag, count, size = 0.32, opts = {}) {
  const points = [];
  const N = 24;
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    points.push(
      V3(
        THREE.MathUtils.lerp(from.x, to.x, t),
        THREE.MathUtils.lerp(from.y, to.y, t) - Math.sin(t * Math.PI) * sag,
        THREE.MathUtils.lerp(from.z, to.z, t)
      )
    );
  }
  const curve = new THREE.CatmullRomCurve3(points);
  meshStatic(staticRoot, new THREE.TubeGeometry(curve, 36, 0.015, 4, false), toon('#382118'), {
    cast: false,
    receive: false,
  });
  meshStatic(staticRoot, new THREE.TubeGeometry(curve, 36, 0.003, 3, false), toon('#a47a45'), {
    cast: false,
    receive: false,
  });

  for (let i = 1; i < count; i++) {
    const t = i / count;
    const p = curve.getPoint(t);
    const drop = 0.34;
    addBox(staticRoot, 0.022, drop, 0.022, '#392119', p.x, p.y - drop * 0.5, p.z, { cast: false });
    addLantern(
      p.x,
      p.y - drop - size * 0.42,
      p.z,
      size * rand(0.9, 1.12),
      i % 4 === 0 ? '#ee4d2c' : i % 3 === 0 ? '#ffc26e' : '#ff8e3b'
    );
  }

  if (opts.pennants !== false) {
    for (let i = 0; i < count - 1; i++) {
      if (i % 2 === 1) continue;
      const t = (i + 0.55) / count;
      const p = curve.getPoint(t);
      addPennant(
        staticRoot,
        p.x,
        p.y - 0.035,
        p.z,
        opts.ry || 0,
        i % 4 === 0 ? '#b33b2d' : '#d9ae70'
      );
    }
  }
}

function addLanternPost(x, z, height = 3.7, color = '#ff9848', ry = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = ry;
  staticRoot.add(g);
  addCylinder(g, 0.10, 0.14, height, '#55291d', 0, height * 0.5, 0, { outline: true, segments: 9 });
  addBox(g, 0.62, 0.09, 0.09, '#6a3023', 0.23, height - 0.18, 0, { outline: true });
  addBox(g, 0.10, 0.09, 0.10, '#d1a052', 0.53, height - 0.18, 0, { cast: false });
  addLantern(x + Math.cos(ry) * 0.53, height - 0.42, z - Math.sin(ry) * 0.53, 0.42, color);
  addBox(g, 0.024, 0.34, 0.024, '#3b2016', 0.55, height - 0.30, 0, { cast: false });
  addBox(g, 0.45, 0.10, 0.20, '#4a4c4c', 0, 0.05, 0, { outline: false });
  addSphere(g, 0.08, '#d1a052', 0, height + 0.02, 0, { sx: 1, sy: 1.4, sz: 1 });
  return g;
}

// ---------------------------------------------------------------------------
// Place the streetscape
// ---------------------------------------------------------------------------

function populateStreetscape() {
  // main street, west side
  buildBuilding({
    x: -7.8,
    z: 3.0,
    w: 7.0,
    d: 4.5,
    levels: 2,
    rot: Math.PI / 2,
    sign: 1,
    banner: 0,
    roofColor: '#2b5955',
    wallColor: '#896247',
    upperColor: '#b58b66',
    seed: 3,
  });
  // main street, east side — exact mirror of the west front house
  buildBuilding({
    x: 7.8,
    z: 3.0,
    w: 7.0,
    d: 4.5,
    levels: 2,
    rot: -Math.PI / 2,
    sign: 2,
    banner: 1,
    roofColor: '#315d52',
    wallColor: '#7e5844',
    upperColor: '#ac8060',
    seed: 7,
  });
  // north-east, mirrored pair of the north-west house
  buildBuilding({
    x: 8.2,
    z: -7.0,
    w: 5.8,
    d: 4.2,
    levels: 2,
    rot: -Math.PI / 2,
    sign: 3,
    banner: 1,
    roofColor: '#2a5551',
    wallColor: '#7d5742',
    upperColor: '#ad815f',
    seed: 23,
  });
  // north-west
  buildBuilding({
    x: -8.2,
    z: -7.0,
    w: 5.8,
    d: 4.2,
    levels: 2,
    rot: Math.PI / 2,
    sign: 0,
    banner: 3,
    roofColor: '#315a51',
    wallColor: '#8a6249',
    upperColor: '#b88c66',
    seed: 29,
  });
  // north side of the L-shaped lane
  buildBuilding({
    x: -7.8,
    z: -12.8,
    w: 6.0,
    d: 3.5,
    levels: 1,
    rot: 0,
    sign: 7,
    banner: 0,
    roofColor: '#28544f',
    wallColor: '#825c46',
    upperColor: '#b58a64',
    seed: 31,
  });
  buildBuilding({
    x: -13.4,
    z: -12.8,
    w: 2.95,
    d: 3.0,
    levels: 2,
    rot: 0,
    sign: 6,
    banner: null,
    roofColor: '#2e5951',
    wallColor: '#7d5844',
    upperColor: '#ac8160',
    seed: 37,
  });
  // south side of the lane
  buildBuilding({
    x: -13.3,
    z: -5.8,
    w: 3.2,
    d: 2.8,
    levels: 1,
    rot: Math.PI,
    sign: 3,
    banner: null,
    roofColor: '#2b544e',
    wallColor: '#845d46',
    upperColor: '#b08763',
    seed: 41,
  });
  // far background gate-house
  buildBuilding({
    x: 0,
    z: -12.8,
    w: 8.0,
    d: 3.2,
    levels: 2,
    rot: 0,
    sign: 0,
    banner: 2,
    roofColor: '#244b4b',
    wallColor: '#75513e',
    upperColor: '#9d7458',
    seed: 43,
  });
  // far back-right house
  buildBuilding({
    x: 11.2,
    z: -12.8,
    w: 3.95,
    d: 3.15,
    levels: 1,
    rot: 0,
    sign: 1,
    banner: null,
    roofColor: '#2f5a50',
    wallColor: '#7f5b45',
    upperColor: '#ac8160',
    seed: 47,
  });

  // market stalls
  buildStall({ x: -3.45, z: 11.2, rot: Math.PI / 2, type: 'candy', sign: 5, main: '#9f3028' });
  buildStall({ x: 3.45, z: 11.15, rot: -Math.PI / 2, type: 'mask', sign: 4, main: '#a53c2c' });
  buildStall({ x: -3.2, z: 3.05, rot: Math.PI / 2, type: 'food', sign: 6, main: '#a4392a' });
  buildStall({ x: 3.2, z: 2.65, rot: -Math.PI / 2, type: 'lantern', sign: 0, main: '#a83229' });
  buildStall({ x: -3.2, z: -4.5, rot: Math.PI / 2, type: 'sachet', sign: 7, main: '#9c3628' });
  buildStall({ x: 3.2, z: -4.8, rot: -Math.PI / 2, type: 'food', sign: 1, main: '#a53a2b' });
  buildStall({ x: -10.3, z: -6.9, rot: Math.PI, type: 'sachet', sign: 7, main: '#9d3529' });
  buildStall({ x: -9.3, z: -9.85, rot: 0, type: 'candy', sign: 5, main: '#a63a2b' });
  // outer foreground stalls frame the square without blocking the bridge
  buildStall({ x: -9.55, z: 12.5, rot: Math.PI / 2 - 0.25, type: 'lantern', sign: 0, main: '#a4342a' });
  buildStall({ x: 9.55, z: 12.35, rot: -Math.PI / 2 + 0.25, type: 'candy', sign: 5, main: '#9f3329' });

  // bridge, boats, lane gate, lions and the old well
  buildBridge();
  buildBoat(-7.3, 8.2, -0.3, 0.82);
  buildBoat(7.8, 6.65, 2.8, 0.7);
  buildGate(-4.45, -8.15, Math.PI / 2, 4.0);
  buildLion(-3.45, 9.55, 0, 0.88);
  buildLion(3.45, 9.55, 0, 0.88);
  buildWell(4.1, 13.15);

  // trees and shrubs
  buildTree({ x: -12.35, z: 9.9, height: 5.0, kind: 'plum', scale: 1.12, lanterns: true });
  buildTree({ x: 11.35, z: -7.65, height: 6.2, kind: 'pine', scale: 1.16, lanterns: false });
  buildTree({ x: 11.55, z: 10.45, height: 4.9, kind: 'willow', scale: 1.0, lanterns: true });
  buildTree({ x: -13.7, z: -8.6, height: 6.5, kind: 'pine', scale: 1.05, lanterns: false });
  buildTree({ x: 13.15, z: 3.15, height: 4.5, kind: 'plum', scale: 0.92, lanterns: true });
  buildTree({ x: 13.9, z: 13.7, height: 4.0, kind: 'pine', scale: 0.8, lanterns: false });

  // a few clipped shrubs at the plinth corners
  for (const [sx, sz] of [
    [-14.0, 13.3],
    [14.1, -13.6],
    [-14.2, -1.0],
    [9.0, 13.8],
  ]) {
    for (let i = 0; i < 4; i++) {
      addSphere(staticRoot, rand(0.28, 0.56), choose(['#284d42', '#335d49', '#25463f']), sx + rand(-0.2, 0.2), 0.18, sz + rand(-0.2, 0.2), {
        sx: 1.25,
        sy: 0.55,
        sz: 1.05,
        segments: 5,
      });
    }
  }

  // a deep red processional runner between the bridge and the lantern carriage
  const runner = meshStatic(staticRoot, UNIT_PLANE, cloth('#7c211b'), {
    x: 0,
    y: 0.026,
    z: 2.35,
    rx: -Math.PI / 2,
    sx: 2.55,
    sy: 4.85,
    cast: false,
    receive: true,
  });
  runner.userData.batch = 'cloth';
  const runnerSouth = meshStatic(staticRoot, UNIT_PLANE, cloth('#772019'), {
    x: 0,
    y: 0.026,
    z: 11.25,
    rx: -Math.PI / 2,
    sx: 2.3,
    sy: 4.0,
    cast: false,
    receive: true,
  });
  runnerSouth.userData.batch = 'cloth';
  for (const side of [-1, 1]) {
    addBox(staticRoot, 0.055, 0.035, 4.85, '#c99a50', side * 1.22, 0.04, 2.35, { cast: false });
    addBox(staticRoot, 0.055, 0.035, 4.0, '#c99a50', side * 1.10, 0.04, 11.25, { cast: false });
  }
  for (let i = 0; i < 5; i++) {
    addSphere(staticRoot, 0.07, '#d4a75b', 0, 0.045, -0.2 + i * 1.25, { sx: 1.5, sy: 0.2, sz: 0.5 });
  }

  // a narrower runner drawing the eye around the L-shaped lane
  const runnerLane = meshStatic(staticRoot, UNIT_PLANE, cloth('#73201a'), {
    x: -9.0,
    y: 0.025,
    z: -8.15,
    rx: -Math.PI / 2,
    sx: 9.0,
    sy: 1.55,
    cast: false,
    receive: true,
  });
  runnerLane.userData.batch = 'cloth';
  for (const side of [-1, 1]) {
    addBox(staticRoot, 9.0, 0.03, 0.045, '#b88b45', -9.0, 0.042, -8.15 + side * 0.75, { cast: false });
  }

  // lantern posts framing the bridge approach and the high entrance string
  addLanternPost(-4.25, 5.15, 3.85, '#ff9d4b', 0);
  addLanternPost(4.25, 5.15, 3.85, '#ff9343', Math.PI);
  addLanternPost(-4.85, 10.15, 7.25, '#ff8e42', 0);
  addLanternPost(4.85, 10.15, 7.25, '#ff9c4d', Math.PI);

  // long strings of festival lanterns, kept clear of the main sight line
  addLanternString(V3(-4.9, 7.15, 10.15), V3(4.9, 7.15, 10.15), 0.86, 8, 0.34);
  addLanternString(
    V3(-9.05, 4.55, -10.2),
    V3(-9.05, 4.55, -6.35),
    0.62,
    6,
    0.31,
    { ry: Math.PI / 2 }
  );
  addLanternString(V3(-4.2, 4.8, -8.15), V3(3.9, 4.75, -8.15), 0.66, 7, 0.3, {
    pennants: false,
  });

  // people strolling, watching and shopping
  buildPerson({
    x: -2.05,
    z: 10.65,
    rot: -0.25,
    robe: '#b23a2c',
    coat: '#35675c',
    accent: '#d6a24f',
    pose: 0,
    scarf: '#d8a363',
  });
  buildPerson({
    x: 1.45,
    z: 12.6,
    rot: 2.25,
    robe: '#3c756a',
    coat: '#c2a06a',
    accent: '#9f3b2f',
    pose: 1,
  });
  buildPerson({
    x: -0.72,
    z: 7.82,
    y: bridgeDeckY(7.82),
    rot: -1.45,
    robe: '#ce5e40',
    coat: '#305c57',
    accent: '#dfb467',
    pose: 0,
    scarf: '#f0c58e',
    scale: 0.96,
  });
  buildPerson({
    x: 1.35,
    z: 6.4,
    y: bridgeDeckY(6.4),
    rot: 0.2,
    robe: '#486f88',
    coat: '#8d3d2f',
    accent: '#d6a14f',
    pose: 1,
    scale: 0.91,
  });
  buildPerson({
    x: 1.7,
    z: 4.5,
    rot: 2.8,
    robe: '#b38250',
    coat: '#7f2e27',
    accent: '#d7b16e',
    pose: 0,
    scale: 0.98,
  });
  buildPerson({
    x: -3.15,
    z: -0.4,
    rot: 1.45,
    robe: '#a93f32',
    coat: '#396b5d',
    accent: '#d7a24f',
    pose: 1,
    scarf: '#e7bd82',
  });
  buildPerson({
    x: 3.25,
    z: -3.2,
    rot: -1.05,
    robe: '#355e74',
    coat: '#bc9a66',
    accent: '#a73c2f',
    pose: 0,
  });
  buildPerson({
    x: -4.6,
    z: 3.6,
    rot: -1.9,
    robe: '#cb6b45',
    coat: '#417065',
    accent: '#d9ad63',
    pose: 1,
  });
  buildPerson({
    x: 4.6,
    z: 1.5,
    rot: 1.2,
    robe: '#aa3b2d',
    coat: '#5d7c6b',
    accent: '#e2b974',
    pose: 0,
    scale: 0.9,
  });
  buildPerson({
    x: -2.85,
    z: 11.65,
    rot: 0.4,
    robe: '#e3b176',
    coat: '#a0372c',
    accent: '#d6a14f',
    pose: 1,
    scale: 0.67,
  });
  buildPerson({
    x: -2.7,
    z: 1.5,
    rot: -0.8,
    robe: '#ca5138',
    coat: '#2f5f55',
    accent: '#d3a255',
    pose: 1,
    scarf: '#e7c08c',
    scale: 0.94,
  });
  buildPerson({
    x: 2.55,
    z: -0.65,
    rot: 0.5,
    robe: '#d7aa71',
    coat: '#7b2f27',
    accent: '#cc9b4d',
    pose: 0,
    scale: 0.7,
  });
  buildPerson({
    x: -1.45,
    z: 13.35,
    rot: 0.08,
    robe: '#b33b30',
    coat: '#386a5f',
    accent: '#d6a85d',
    pose: 1,
    scarf: '#e9c38d',
  });
  buildPerson({
    x: 0.95,
    z: 9.45,
    rot: 2.9,
    robe: '#52758b',
    coat: '#c49d68',
    accent: '#a9382d',
    pose: 0,
    scale: 0.93,
  });
  buildPerson({
    x: 2.4,
    z: 11.85,
    rot: -0.7,
    robe: '#d0a06c',
    coat: '#8f342a',
    accent: '#d7ae67',
    pose: 1,
    scale: 0.66,
  });
  buildPerson({
    x: -2.62,
    z: 10.72,
    rot: -1.3,
    robe: '#3e7163',
    coat: '#b35736',
    accent: '#d0a25b',
    pose: 0,
    scale: 0.92,
  });

  // lantern carriers by the great float
  addLantern(-2.92, 1.55, -1.9, 0.28, '#ff8d3d');
  addLantern(2.92, 1.52, -1.75, 0.28, '#ffa54c');
}

// ---------------------------------------------------------------------------
// Build the static scene into a handful of draw calls
// ---------------------------------------------------------------------------

buildBase();
buildWater();
populateStreetscape();
const floatParts = buildFloat();
const staticMeshes = bakeStatic(staticRoot);

// ---------------------------------------------------------------------------
// Instanced paper lanterns, halos and pools of light
// ---------------------------------------------------------------------------

function buildLanternSystem() {
  const count = lanternSpecs.length;
  const group = new THREE.Group();
  scene.add(group);

  const profile = [
    new THREE.Vector2(0.15, -0.5),
    new THREE.Vector2(0.28, -0.44),
    new THREE.Vector2(0.41, -0.28),
    new THREE.Vector2(0.48, -0.06),
    new THREE.Vector2(0.45, 0.17),
    new THREE.Vector2(0.36, 0.35),
    new THREE.Vector2(0.24, 0.47),
    new THREE.Vector2(0.14, 0.5),
  ];
  const bodyGeo = new THREE.LatheGeometry(profile, 14);
  const bodyMat = new THREE.MeshBasicMaterial({
    map: lanternTexture,
    color: 0xffc98d,
    toneMapped: false,
    side: THREE.FrontSide,
  });
  const bodyMesh = new THREE.InstancedMesh(bodyGeo, bodyMat, count);
  bodyMesh.instanceMatrix.setUsage(THREE.StaticDrawUsage);
  bodyMesh.castShadow = false;
  bodyMesh.receiveShadow = false;
  bodyMesh.frustumCulled = false;

  const capGeo = new THREE.CylinderGeometry(0.5, 0.5, 1, 9);
  const capMat = new THREE.MeshToonMaterial({ color: 0x8f5a2f, gradientMap });
  const capMesh = new THREE.InstancedMesh(capGeo, capMat, count * 2);
  capMesh.castShadow = false;
  capMesh.frustumCulled = false;

  const tasselGeo = new THREE.CylinderGeometry(0.5, 0.5, 1, 5);
  const tasselMat = new THREE.MeshToonMaterial({ color: 0x8d2c23, gradientMap });
  const tasselMesh = new THREE.InstancedMesh(tasselGeo, tasselMat, count);
  tasselMesh.castShadow = false;
  tasselMesh.frustumCulled = false;

  const matrix = new THREE.Matrix4();
  const quat = new THREE.Quaternion();
  const scaleV = new THREE.Vector3();
  const posV = new THREE.Vector3();
  const colorV = new THREE.Color();
  let capIndex = 0;

  for (let i = 0; i < count; i++) {
    const spec = lanternSpecs[i];
    const s = spec.size * 0.8;
    posV.copy(spec.position);
    scaleV.set(s * 0.88, s * 1.22, s * 0.88);
    quat.setFromAxisAngle(V3(0, 1, 0), rand(0, Math.PI * 2));
    matrix.compose(posV, quat, scaleV);
    bodyMesh.setMatrixAt(i, matrix);
    colorV.copy(spec.color).multiplyScalar(1.85);
    bodyMesh.setColorAt(i, colorV);

    // top and bottom caps
    for (const sy of [-1, 1]) {
      posV.copy(spec.position);
      posV.y += sy * s * 0.58;
      scaleV.set(s * 0.56, s * 0.13, s * 0.56);
      quat.identity();
      matrix.compose(posV, quat, scaleV);
      capMesh.setMatrixAt(capIndex++, matrix);
    }

    // tassel
    if (spec.tassel) {
      posV.copy(spec.position);
      posV.y -= s * 0.83;
      scaleV.set(s * 0.06, s * 0.58, s * 0.06);
      matrix.compose(posV, quat, scaleV);
      tasselMesh.setMatrixAt(i, matrix);
    } else {
      scaleV.set(0.0001, 0.0001, 0.0001);
      matrix.compose(posV, quat, scaleV);
      tasselMesh.setMatrixAt(i, matrix);
    }
  }
  bodyMesh.instanceMatrix.needsUpdate = true;
  if (bodyMesh.instanceColor) bodyMesh.instanceColor.needsUpdate = true;
  capMesh.instanceMatrix.needsUpdate = true;
  tasselMesh.instanceMatrix.needsUpdate = true;

  group.add(bodyMesh, capMesh, tasselMesh);

  // soft additive halos, one draw call
  const positions = new Float32Array(count * 3);
  const sizes = new Float32Array(count);
  const colors = new Float32Array(count * 3);
  const haloColor = new THREE.Color();
  for (let i = 0; i < count; i++) {
    const spec = lanternSpecs[i];
    positions.set([spec.position.x, spec.position.y, spec.position.z], i * 3);
    sizes[i] = spec.size * 0.62 * (1.85 + spec.glow * 0.45);
    haloColor.copy(spec.color).lerp(new THREE.Color('#ffdca6'), 0.16).multiplyScalar(0.8);
    colors.set([haloColor.r, haloColor.g, haloColor.b], i * 3);
  }
  const glowGeo = new THREE.BufferGeometry();
  glowGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  glowGeo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  glowGeo.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
  const glowMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uPixelRatio: { value: Math.min(window.devicePixelRatio || 1, 1.45) },
    },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */ `
      attribute float aSize;
      attribute vec3 aColor;
      varying vec3 vColor;
      uniform float uPixelRatio;
      void main() {
        vColor = aColor;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = aSize * (220.0 / max(1.0, -mv.z)) * uPixelRatio;
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      varying vec3 vColor;
      void main() {
        vec2 p = gl_PointCoord - 0.5;
        float d = length(p) * 2.0;
        float a = pow(max(0.0, 1.0 - d), 2.4) * 0.075;
        if (a < 0.005) discard;
        gl_FragColor = vec4(vColor, a);
      }
    `,
  });
  const halos = new THREE.Points(glowGeo, glowMaterial);
  halos.frustumCulled = false;
  halos.renderOrder = 5;
  // The bodies themselves bloom; the old additive halos made every lantern read
  // as a large pale sphere. Keep the object for resize bookkeeping but leave it
  // out of the scene.
  halos.visible = false;

  // warm pools of light on the paving
  const poolSpecs = [];
  for (const spec of lanternSpecs) {
    if (spec.position.y > 4.4) continue;
    if (spec.position.z > 5.68 && spec.position.z < 9.2) continue;
    if (Math.abs(spec.position.x) > 14.6 || Math.abs(spec.position.z) > 14.6) continue;
    poolSpecs.push({
      x: spec.position.x,
      z: spec.position.z,
      size: 0.9 + spec.size * 2.2 + spec.position.y * 0.06,
      color: spec.color,
    });
  }
  const poolGeo = new THREE.PlaneGeometry(1, 1);
  const poolMat = new THREE.MeshBasicMaterial({
    map: glowTexture,
    color: 0xffffff,
    transparent: true,
    opacity: 0.24,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    toneMapped: false,
  });
  const pools = new THREE.InstancedMesh(poolGeo, poolMat, poolSpecs.length);
  const pmat = new THREE.Matrix4();
  const pq = new THREE.Quaternion().setFromEuler(new THREE.Euler(-Math.PI / 2, 0, 0));
  for (let i = 0; i < poolSpecs.length; i++) {
    const s = poolSpecs[i];
    pmat.compose(V3(s.x, 0.028, s.z), pq, V3(s.size, s.size, 1));
    pools.setMatrixAt(i, pmat);
    pools.setColorAt(i, s.color);
  }
  pools.instanceMatrix.needsUpdate = true;
  if (pools.instanceColor) pools.instanceColor.needsUpdate = true;
  pools.frustumCulled = false;
  pools.renderOrder = 3;
  scene.add(pools);

  // warm vertical reflections on the canal
  const reflectionSpecs = [
    [-7.6, 7.3, 0.8, 2.5],
    [-4.6, 7.9, 0.65, 2.1],
    [-1.7, 6.8, 0.75, 2.8],
    [1.3, 8.1, 0.70, 2.6],
    [4.4, 7.2, 0.80, 2.9],
    [7.7, 8.0, 0.60, 2.0],
    [10.6, 7.4, 0.65, 2.2],
  ];
  const reflGeo = new THREE.PlaneGeometry(1, 1);
  const reflMat = new THREE.MeshBasicMaterial({
    map: glowTexture,
    color: 0xff9d4c,
    transparent: true,
    opacity: 0.18,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    toneMapped: false,
  });
  const reflections = new THREE.InstancedMesh(reflGeo, reflMat, reflectionSpecs.length);
  for (let i = 0; i < reflectionSpecs.length; i++) {
    const [x, z, w, l] = reflectionSpecs[i];
    pmat.compose(V3(x, -0.468, z), pq, V3(w, l, 1));
    reflections.setMatrixAt(i, pmat);
  }
  reflections.instanceMatrix.needsUpdate = true;
  reflections.frustumCulled = false;
  reflections.renderOrder = 3;
  scene.add(reflections);

  return { bodyMesh, capMesh, tasselMesh, halos, pools, count };
}

const lanternSystem = buildLanternSystem();

// ---------------------------------------------------------------------------
// Sky lanterns
// ---------------------------------------------------------------------------

const skyLanterns = [];

function createSkyLantern(x, y, z, scale, color) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  const profile = [
    new THREE.Vector2(0.26, -0.50),
    new THREE.Vector2(0.38, -0.47),
    new THREE.Vector2(0.45, -0.27),
    new THREE.Vector2(0.46, 0.08),
    new THREE.Vector2(0.38, 0.36),
    new THREE.Vector2(0.24, 0.50),
  ];
  const mat = new THREE.MeshBasicMaterial({
    map: lanternTexture,
    color: new THREE.Color(color),
    toneMapped: false,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.95,
  });
  const paper = new THREE.Mesh(new THREE.LatheGeometry(profile, 12), mat);
  paper.scale.setScalar(scale);
  g.add(paper);
  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(0.27 * scale, 0.025 * scale, 4, 10),
    new THREE.MeshBasicMaterial({ color: 0x6d3920, toneMapped: false })
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.y = -0.48 * scale;
  g.add(rim);
  const flame = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      color: 0xffd08a,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    })
  );
  flame.scale.setScalar(scale * 1.35);
  flame.position.y = 0.05 * scale;
  g.add(flame);
  const halo = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      color: 0xffb55c,
      transparent: true,
      opacity: 0.30,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    })
  );
  halo.scale.setScalar(scale * 2.8);
  halo.position.y = 0.05 * scale;
  g.add(halo);
  scene.add(g);
  return {
    group: g,
    baseX: x,
    baseY: y,
    baseZ: z,
    speed: rand(0.22, 0.52),
    phase: rand(0, Math.PI * 2),
    sway: rand(0.15, 0.55),
    spin: rand(-0.12, 0.12),
    minY: 11.5,
    maxY: 30.0,
  };
}

const skyLanternDefs = [
  [-10.0, 14.0, -4.0, 1.0, '#ffad52'],
  [8.0, 15.0, -6.0, 0.82, '#ffca7f'],
  [0.0, 16.0, 2.0, 0.74, '#ff9f4c'],
  [-4.0, 18.0, 8.0, 0.66, '#ffbf69'],
  [12.0, 14.0, 2.0, 0.8, '#ffac55'],
  [-12.0, 18.0, -8.0, 0.68, '#ffd18c'],
  [5.0, 19.0, -9.0, 0.58, '#ff9c48'],
  [13.0, 20.0, -3.0, 0.54, '#ffd491'],
];
for (const [x, y, z, s, c] of skyLanternDefs) skyLanterns.push(createSkyLantern(x, y, z, s, c));

// Two translucent koi kites drift above the street, echoing the painted sky
// fish of the reference imagery.
const skyKoi = [];
function createSkyKoi(x, y, z, scale, phase) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  const bodyMat = new THREE.MeshBasicMaterial({
    color: 0xf6ac48,
    toneMapped: true,
    transparent: true,
    opacity: 0.8,
    side: THREE.DoubleSide,
  });
  const finMat = new THREE.MeshBasicMaterial({
    color: 0xffd58b,
    toneMapped: true,
    transparent: true,
    opacity: 0.5,
    side: THREE.DoubleSide,
  });
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.5, 18, 10), bodyMat);
  body.scale.set(1.7, 0.34, 0.55);
  g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.5, 14, 8), bodyMat);
  head.scale.set(0.5, 0.38, 0.58);
  head.position.x = 0.9;
  g.add(head);
  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1, 8), finMat);
  tail.scale.set(0.9, 1.1, 0.22);
  tail.rotation.z = -Math.PI / 2;
  tail.position.x = -1.0;
  g.add(tail);
  for (const sz of [-1, 1]) {
    const fin = new THREE.Mesh(new THREE.ConeGeometry(0.5, 0.8, 5), finMat);
    fin.scale.set(0.36, 0.8, 0.10);
    fin.rotation.z = Math.PI / 2;
    fin.rotation.y = sz * 0.45;
    fin.position.set(0.25, 0, sz * 0.42);
    g.add(fin);
  }
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x32180d, toneMapped: false });
  for (const sz of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.055, 6, 5), eyeMat);
    eye.position.set(1.08, 0.08, sz * 0.22);
    g.add(eye);
  }
  const glow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      color: 0xffb95c,
      transparent: true,
      opacity: 0.16,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    })
  );
  glow.scale.setScalar(4.0);
  g.add(glow);
  g.scale.setScalar(scale);
  scene.add(g);
  skyKoi.push({ group: g, base: V3(x, y, z), phase, scale });
}

createSkyKoi(-12.5, 17.6, -7.0, 1.05, 0.8);
createSkyKoi(11.0, 16.2, -4.0, 0.78, 2.8);

// ---------------------------------------------------------------------------
// Canal life: koi and floating lotus lanterns
// ---------------------------------------------------------------------------

const koiFish = [];
const koiBodyGeo = new THREE.SphereGeometry(0.5, 16, 10);
const koiBodyMat = new THREE.MeshBasicMaterial({ color: 0xffb45d, toneMapped: false });
const koiFinMat = new THREE.MeshBasicMaterial({
  color: 0xffdd9a,
  toneMapped: false,
  transparent: true,
  opacity: 0.78,
  side: THREE.DoubleSide,
});
const koiTailGeo = new THREE.ConeGeometry(0.5, 1, 8);
const koiFinGeo = new THREE.ConeGeometry(0.5, 0.6, 5);

function createKoi(radiusX, radiusZ, centerX, centerZ, speed, phase, scale) {
  const g = new THREE.Group();
  const body = new THREE.Mesh(koiBodyGeo, koiBodyMat);
  body.scale.set(0.72 * scale, 0.22 * scale, 0.28 * scale);
  g.add(body);
  const tail = new THREE.Mesh(koiTailGeo, koiFinMat);
  tail.rotation.z = Math.PI / 2;
  tail.scale.set(0.35 * scale, 0.38 * scale, 0.18 * scale);
  tail.position.x = -0.56 * scale;
  g.add(tail);
  for (const sz of [-1, 1]) {
    const fin = new THREE.Mesh(koiFinGeo, koiFinMat);
    fin.rotation.z = Math.PI / 2;
    fin.rotation.y = sz * 0.5;
    fin.scale.set(0.15 * scale, 0.24 * scale, 0.06 * scale);
    fin.position.set(0.1 * scale, 0, sz * 0.20 * scale);
    g.add(fin);
  }
  const head = new THREE.Mesh(koiBodyGeo, koiBodyMat);
  head.scale.set(0.22 * scale, 0.19 * scale, 0.24 * scale);
  head.position.x = 0.34 * scale;
  g.add(head);
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x211612 });
  for (const sz of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.035 * scale, 6, 5), eyeMat);
    eye.position.set(0.46 * scale, 0.06 * scale, sz * 0.10 * scale);
    g.add(eye);
  }
  g.position.y = -0.72;
  scene.add(g);
  koiFish.push({ group: g, radiusX, radiusZ, centerX, centerZ, speed, phase });
}

createKoi(4.6, 1.05, -4.2, 7.45, 0.22, 0.2, 0.72);
createKoi(3.4, 0.82, 5.4, 7.6, -0.18, 2.2, 0.58);
createKoi(5.5, 0.95, 1.1, 7.35, 0.15, 4.1, 0.64);
createKoi(2.8, 0.72, 10.0, 7.7, -0.26, 5.3, 0.5);

const waterLanterns = [];
function createWaterLantern(x, z, scale, hue = 0) {
  const g = new THREE.Group();
  g.position.set(x, -0.43, z);
  g.scale.setScalar(scale);
  const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.5, 12, 6), toon('#3c6f51'));
  leaf.scale.set(1.65, 0.12, 1.25);
  leaf.position.y = -0.04;
  g.add(leaf);
  const petalGeo = new THREE.SphereGeometry(0.5, 8, 6);
  const petalColors = ['#e88e94', '#f0b0a6', '#d9707c', '#f2c3b4'];
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const petal = new THREE.Mesh(petalGeo, toon(petalColors[(i + hue) % petalColors.length]));
    petal.scale.set(0.45, 0.10, 0.17);
    petal.position.set(Math.cos(a) * 0.18, 0.06 + Math.sin(i * 2.1) * 0.02, Math.sin(a) * 0.18);
    petal.rotation.y = -a;
    petal.rotation.z = 0.35;
    g.add(petal);
  }
  const candle = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.17, 0.12),
    new THREE.MeshBasicMaterial({ color: 0xffdaa0, toneMapped: false })
  );
  candle.position.y = 0.20;
  g.add(candle);
  const glow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      color: 0xffb85f,
      transparent: true,
      opacity: 0.48,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    })
  );
  glow.scale.setScalar(1.25);
  glow.position.y = 0.23;
  g.add(glow);
  scene.add(g);
  waterLanterns.push({ group: g, baseY: -0.43, phase: rand(0, Math.PI * 2), x, z });
}

createWaterLantern(-7.6, 6.7, 0.56, 0);
createWaterLantern(-11.0, 8.1, 0.42, 1);
createWaterLantern(6.2, 8.25, 0.50, 2);
createWaterLantern(10.4, 6.55, 0.38, 3);
createWaterLantern(13.2, 7.9, 0.32, 1);

// ---------------------------------------------------------------------------
// Drifting sparks, petals and stall steam
// ---------------------------------------------------------------------------

function makeMoteSystem({ count, colorA, colorB, rising, area, sizeMin, sizeMax, speedMin, speedMax }) {
  const positions = new Float32Array(count * 3);
  const phases = new Float32Array(count);
  const sizes = new Float32Array(count);
  const colors = new Float32Array(count * 3);
  const r = mulberry32(0xabc + count);
  for (let i = 0; i < count; i++) {
    positions.set(
      [
        (r() - 0.5) * area,
        rising ? r() * 15 : 0.3 + r() * 11,
        (r() - 0.5) * area,
      ],
      i * 3
    );
    phases[i] = r() * Math.PI * 2;
    sizes[i] = sizeMin + Math.pow(r(), 2.0) * (sizeMax - sizeMin);
    const col = new THREE.Color(r() > 0.5 ? colorA : colorB);
    colors.set([col.r, col.g, col.b], i * 3);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
  geo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geo.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio || 1, 1.45) },
      uRising: { value: rising ? 1 : 0 },
      uSpeedMin: { value: speedMin },
      uSpeedMax: { value: speedMax },
    },
    transparent: true,
    depthWrite: false,
    blending: rising ? THREE.AdditiveBlending : THREE.NormalBlending,
    vertexShader: /* glsl */ `
      attribute float aPhase;
      attribute float aSize;
      attribute vec3 aColor;
      varying vec3 vColor;
      varying float vFade;
      uniform float uTime;
      uniform float uPixelRatio;
      uniform float uRising;
      uniform float uSpeedMin;
      uniform float uSpeedMax;
      void main() {
        vColor = aColor;
        vec3 p = position;
        float speed = mix(uSpeedMin, uSpeedMax, fract(aPhase * 9.37));
        if (uRising > 0.5) {
          p.y = 0.7 + mod(position.y + uTime * speed, 13.2);
          p.x += sin(uTime * 0.24 + aPhase) * 0.55;
          p.z += cos(uTime * 0.19 + aPhase * 1.7) * 0.42;
          vFade = 0.35 + 0.65 * smoothstep(0.0, 2.0, p.y) * (1.0 - smoothstep(9.0, 13.2, p.y));
        } else {
          p.y = 12.8 - mod(position.y + uTime * speed, 12.4);
          p.x += sin(uTime * 0.22 + aPhase) * 0.7;
          p.z += cos(uTime * 0.18 + aPhase * 1.3) * 0.55;
          vFade = 0.35 + 0.65 * smoothstep(0.0, 3.0, p.y) * (1.0 - smoothstep(10.0, 12.8, p.y));
        }
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = aSize * (230.0 / max(1.0, -mv.z)) * uPixelRatio;
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      varying vec3 vColor;
      varying float vFade;
      void main() {
        vec2 p = gl_PointCoord - 0.5;
        float d = length(p) * 2.0;
        float a = pow(max(0.0, 1.0 - d), 2.0) * vFade;
        if (a < 0.01) discard;
        gl_FragColor = vec4(vColor, a * 0.8);
      }
    `,
  });
  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  points.renderOrder = 6;
  scene.add(points);
  return { points, mat };
}

const emberSystem = makeMoteSystem({
  count: 260,
  colorA: '#ffb354',
  colorB: '#ff7c3d',
  rising: true,
  area: 28,
  sizeMin: 0.7,
  sizeMax: 2.6,
  speedMin: 0.15,
  speedMax: 0.52,
});
const petalSystem = makeMoteSystem({
  count: 140,
  colorA: '#ef9a96',
  colorB: '#f3c09d',
  rising: false,
  area: 27,
  sizeMin: 1.0,
  sizeMax: 3.0,
  speedMin: 0.10,
  speedMax: 0.30,
});

const steamSprites = [];
for (const spec of steamSpecs) {
  for (let i = 0; i < 2; i++) {
    const material = new THREE.SpriteMaterial({
      map: steamTexture,
      color: 0xe9ddd0,
      transparent: true,
      opacity: 0.25,
      depthWrite: false,
      fog: true,
      toneMapped: false,
    });
    const sprite = new THREE.Sprite(material);
    sprite.position.copy(spec.position);
    sprite.position.y += i * 0.38;
    sprite.scale.setScalar(spec.size * (0.95 + i * 0.55));
    sprite.userData = {
      baseX: spec.position.x,
      baseY: spec.position.y,
      baseZ: spec.position.z,
      phase: spec.phase + i * 1.9,
      speed: 0.20 + i * 0.04,
      size: spec.size,
    };
    scene.add(sprite);
    steamSprites.push(sprite);
  }
}

// ---------------------------------------------------------------------------
// Interactive weather and wish-lantern systems
// ---------------------------------------------------------------------------

function damp(current, target, lambda, dt) {
  return THREE.MathUtils.lerp(current, target, 1 - Math.exp(-lambda * dt));
}

// ---- Snow -----------------------------------------------------------------

function createSnowSystem() {
  // Sparse, slow flurries: about one fifth of the previous particle count.
  const COUNT = 800;
  const rngSnow = mulberry32(0x5a19f3);
  const positions = new Float32Array(COUNT * 3);
  const phases = new Float32Array(COUNT);
  const speeds = new Float32Array(COUNT);
  const drifts = new Float32Array(COUNT);
  const sizes = new Float32Array(COUNT);
  const twinkles = new Float32Array(COUNT);

  for (let i = 0; i < COUNT; i++) {
    positions[i * 3] = (rngSnow() * 2 - 1) * 14.25;
    positions[i * 3 + 1] = rngSnow() * 16.5;
    positions[i * 3 + 2] = (rngSnow() * 2 - 1) * 14.25;
    phases[i] = rngSnow();
    speeds[i] = 0.012 + rngSnow() * 0.017;
    drifts[i] = 0.20 + rngSnow() * 0.76;
    sizes[i] = 0.65 + Math.pow(rngSnow(), 2.1) * 3.1;
    twinkles[i] = rngSnow() * Math.PI * 2;
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
  geometry.setAttribute('aSpeed', new THREE.BufferAttribute(speeds, 1));
  geometry.setAttribute('aDrift', new THREE.BufferAttribute(drifts, 1));
  geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geometry.setAttribute('aTwinkle', new THREE.BufferAttribute(twinkles, 1));

  const material = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uOpacity: { value: 0 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio || 1, 1.45) },
    },
    transparent: true,
    depthWrite: false,
    depthTest: true,
    blending: THREE.NormalBlending,
    vertexShader: /* glsl */ `
      attribute float aPhase;
      attribute float aSpeed;
      attribute float aDrift;
      attribute float aSize;
      attribute float aTwinkle;
      uniform float uTime;
      uniform float uOpacity;
      uniform float uPixelRatio;
      varying float vAlpha;
      varying float vSpark;

      void main() {
        float fall = fract(aPhase - uTime * aSpeed);
        float y = 0.25 + fall * 16.4;
        float swayA = sin(uTime * (0.33 + aPhase * 0.18) + aPhase * 31.0) * aDrift;
        float swayB = sin(uTime * 0.17 + aPhase * 19.0) * aDrift * 0.5;
        vec3 p = position;
        p.x += swayA + swayB;
        p.y = y;
        p.z += cos(uTime * 0.27 + aPhase * 23.0) * aDrift * 0.7;

        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        float edgeFade = smoothstep(0.0, 0.045, fall) * (1.0 - smoothstep(0.88, 1.0, fall));
        float twinkle = 0.86 + 0.14 * sin(uTime * 1.7 + aTwinkle);
        vAlpha = edgeFade * twinkle * uOpacity;
        vSpark = smoothstep(0.2, 1.0, fall);
        gl_PointSize = aSize * uPixelRatio * (100.0 / max(1.0, -mv.z));
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      varying float vAlpha;
      varying float vSpark;
      void main() {
        vec2 p = gl_PointCoord - 0.5;
        float d = length(p) * 2.0;
        float flake = smoothstep(1.0, 0.10, d);
        float core = smoothstep(0.40, 0.0, d);
        float alpha = (flake * 0.70 + core * 0.36) * vAlpha;
        if (alpha < 0.006) discard;
        gl_FragColor = vec4(vec3(1.0), alpha * 0.96);
      }
    `,
  });

  const points = new THREE.Points(geometry, material);
  points.visible = false;
  points.frustumCulled = false;
  points.renderOrder = 9;
  scene.add(points);
  return { points, material };
}

const snowSystem = createSnowSystem();
let snowEnabled = false;
let snowMix = 0;
let snowRoofMix = 0;

const snowAmbience = {
  hemi: { color: hemi.color.clone(), intensity: hemi.intensity },
  ambient: { color: ambient.color.clone(), intensity: ambient.intensity },
  moon: { color: moonLight.color.clone(), intensity: moonLight.intensity },
  fog: scene.fog.color.clone(),
  grounds: [
    {
      material: groundMaterialBase,
      color: groundMaterialBase.color.clone(),
      roughness: groundMaterialBase.roughness,
      metalness: groundMaterialBase.metalness,
    },
    {
      material: groundMaterialStreet,
      color: groundMaterialStreet.color.clone(),
      roughness: groundMaterialStreet.roughness,
      metalness: groundMaterialStreet.metalness,
    },
    {
      material: groundMaterialDark,
      color: groundMaterialDark.color.clone(),
      roughness: groundMaterialDark.roughness,
      metalness: groundMaterialDark.metalness,
    },
  ],
  snowGroundColor: new THREE.Color(0xcfdde6),
  snowFogColor: new THREE.Color(0x102438),
  snowHemiColor: new THREE.Color(0x91aee0),
  snowAmbientColor: new THREE.Color(0x4a6188),
  snowMoonColor: new THREE.Color(0xc9ddff),
};

function applySnowAmbience(mix) {
  const eased = mix * mix * (3 - 2 * mix);
  hemi.color.copy(snowAmbience.hemi.color).lerp(snowAmbience.snowHemiColor, eased * 0.62);
  hemi.intensity = snowAmbience.hemi.intensity * (1 + eased * 0.1);
  ambient.color.copy(snowAmbience.ambient.color).lerp(snowAmbience.snowAmbientColor, eased * 0.56);
  ambient.intensity = snowAmbience.ambient.intensity * (1 + eased * 0.12);
  moonLight.color.copy(snowAmbience.moon.color).lerp(snowAmbience.snowMoonColor, eased * 0.76);
  moonLight.intensity = snowAmbience.moon.intensity * (1 + eased * 0.18);
  scene.fog.color.copy(snowAmbience.fog).lerp(snowAmbience.snowFogColor, eased * 0.5);
  for (const ground of snowAmbience.grounds) {
    ground.material.color.copy(ground.color).lerp(snowAmbience.snowGroundColor, eased * 0.2);
    ground.material.roughness = ground.roughness * (1 - eased * 0.13);
    ground.material.metalness = ground.metalness + eased * 0.025;
  }
}

function updateSnow(dt, time) {
  snowMix = damp(snowMix, snowEnabled ? 1 : 0, 2.8, dt);
  snowRoofMix = damp(snowRoofMix, snowEnabled ? 1 : 0, 0.72, dt);

  if (snowEnabled) {
    snowSystem.points.visible = true;
    if (snowSurfaceMesh) snowSurfaceMesh.visible = true;
  }
  if (!snowEnabled && snowMix < 0.006) {
    snowMix = 0;
    snowSystem.points.visible = false;
  }
  if (!snowEnabled && snowRoofMix < 0.004) {
    snowRoofMix = 0;
    if (snowSurfaceMesh) snowSurfaceMesh.visible = false;
  }

  if (snowSurfaceMesh) {
    snowBatchMaterial.opacity = snowRoofMix;
  }
  snowSystem.material.uniforms.uTime.value = time;
  snowSystem.material.uniforms.uOpacity.value = snowMix;
  applySnowAmbience(snowMix);
}

// ---- Wish lanterns --------------------------------------------------------

function makeWishLanternTexture() {
  const [c, ctx] = makeCanvas(256, 512);
  const r = mulberry32(0x7ad491);
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#3d1c0c');
  grad.addColorStop(0.08, '#b76f32');
  grad.addColorStop(0.16, '#ffd995');
  grad.addColorStop(0.5, '#fff6dc');
  grad.addColorStop(0.86, '#ffd08a');
  grad.addColorStop(0.94, '#9b5526');
  grad.addColorStop(1, '#3a1a0b');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 512);
  for (let x = 9; x < 256; x += 22) {
    ctx.strokeStyle = `rgba(110,51,20,${0.22 + r() * 0.16})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 512);
    ctx.stroke();
  }
  for (let i = 0; i < 400; i++) {
    ctx.fillStyle = r() > 0.5 ? 'rgba(255,248,218,.14)' : 'rgba(103,48,18,.08)';
    ctx.fillRect(r() * 256, r() * 512, 1, 1 + r() * 2);
  }
  const tex = makeTexture(c, { repeat: true, anisotropy: 4 });
  return tex;
}
const wishLanternTexture = makeWishLanternTexture();

const WISH_COUNT = 26;
const wishGroup = new THREE.Group();
wishGroup.name = '可升起的孔明灯群';
wishGroup.visible = false;
scene.add(wishGroup);

const wishProfile = [
  new THREE.Vector2(0.20, -0.5),
  new THREE.Vector2(0.31, -0.44),
  new THREE.Vector2(0.40, -0.22),
  new THREE.Vector2(0.41, 0.08),
  new THREE.Vector2(0.33, 0.35),
  new THREE.Vector2(0.19, 0.5),
];
const wishBodyGeometry = new THREE.LatheGeometry(wishProfile, 10);
const wishPalette = [0xffa54f, 0xffbb69, 0xff9141, 0xffc477, 0xf28d47];
const wishRng = mulberry32(0x91c3f7);

const wishZones = [
  [-2.7, 2.7, 9.5, 14.2, 6],
  [-4.5, 4.5, 4.8, 9.0, 4],
  [-4.2, 4.2, -6.2, 4.2, 6],
  [-13.0, -5.0, -9.3, -6.4, 4],
  [-11.8, -5.5, -1.8, 8.2, 3],
  [5.5, 11.8, -1.8, 8.2, 3],
];

const wishLanterns = [];
const wishGlowPositions = new Float32Array(WISH_COUNT * 3);
const wishGlowSizes = new Float32Array(WISH_COUNT);
const wishGlowColors = new Float32Array(WISH_COUNT * 3);
const wishGlowAlphas = new Float32Array(WISH_COUNT);

for (let i = 0; i < WISH_COUNT; i++) {
  let zone = wishZones[0];
  let running = i;
  for (const candidate of wishZones) {
    if (running < candidate[4]) {
      zone = candidate;
      break;
    }
    running -= candidate[4];
  }
  zone = zone || wishZones[wishZones.length - 1];
  const baseX = THREE.MathUtils.lerp(zone[0], zone[1], wishRng());
  const baseZ = THREE.MathUtils.lerp(zone[2], zone[3], wishRng());
  const baseY = 0.55 + wishRng() * 1.25;
  const topY = 19.5 + wishRng() * 7.5;
  const color = new THREE.Color(wishPalette[Math.floor(wishRng() * wishPalette.length)]);
  const material = new THREE.MeshBasicMaterial({
    map: wishLanternTexture,
    color: color.clone().multiplyScalar(1.24),
    transparent: true,
    opacity: 0,
    depthWrite: false,
    side: THREE.DoubleSide,
    toneMapped: false,
  });
  const mesh = new THREE.Mesh(wishBodyGeometry, material);
  mesh.renderOrder = 5;
  const g = new THREE.Group();
  g.position.set(baseX, baseY, baseZ);
  g.scale.setScalar(0.3);
  g.add(mesh);
  wishGroup.add(g);

  const lantern = {
    group: g,
    material,
    baseX,
    baseZ,
    baseY,
    topY,
    delay: wishRng() * 2.2,
    duration: 15.5 + wishRng() * 8.5,
    swayPhase: wishRng() * Math.PI * 2,
    swaySpeed: 0.45 + wishRng() * 0.75,
    swayAmp: 0.28 + wishRng() * 0.7,
    scale0: 0.28 + wishRng() * 0.17,
    scale1: 1.0 + wishRng() * 0.42,
    rotationBias: wishRng() * Math.PI * 2,
    color: color.clone(),
    alpha: 0,
  };
  wishLanterns.push(lantern);

  wishGlowPositions[i * 3] = baseX;
  wishGlowPositions[i * 3 + 1] = baseY;
  wishGlowPositions[i * 3 + 2] = baseZ;
  wishGlowSizes[i] = 0.9;
  wishGlowAlphas[i] = 0;
  wishGlowColors[i * 3] = color.r * 1.15;
  wishGlowColors[i * 3 + 1] = color.g * 1.15;
  wishGlowColors[i * 3 + 2] = color.b * 1.15;
}

const wishGlowGeometry = new THREE.BufferGeometry();
wishGlowGeometry.setAttribute('position', new THREE.BufferAttribute(wishGlowPositions, 3).setUsage(THREE.DynamicDrawUsage));
wishGlowGeometry.setAttribute('aSize', new THREE.BufferAttribute(wishGlowSizes, 1).setUsage(THREE.DynamicDrawUsage));
wishGlowGeometry.setAttribute('aColor', new THREE.BufferAttribute(wishGlowColors, 3));
wishGlowGeometry.setAttribute('aAlpha', new THREE.BufferAttribute(wishGlowAlphas, 1).setUsage(THREE.DynamicDrawUsage));

const wishGlowMaterial = new THREE.ShaderMaterial({
  uniforms: {
    uPixelRatio: { value: Math.min(window.devicePixelRatio || 1, 1.45) },
  },
  transparent: true,
  depthWrite: false,
  blending: THREE.AdditiveBlending,
  vertexShader: /* glsl */ `
    attribute float aSize;
    attribute float aAlpha;
    attribute vec3 aColor;
    varying vec3 vColor;
    varying float vAlpha;
    uniform float uPixelRatio;
    void main() {
      vColor = aColor;
      vAlpha = aAlpha;
      vec4 mv = modelViewMatrix * vec4(position, 1.0);
      gl_PointSize = aSize * (150.0 / max(1.0, -mv.z)) * uPixelRatio;
      gl_Position = projectionMatrix * mv;
    }
  `,
  fragmentShader: /* glsl */ `
    varying vec3 vColor;
    varying float vAlpha;
    void main() {
      vec2 p = gl_PointCoord - 0.5;
      float d = length(p) * 2.0;
      float a = pow(max(0.0, 1.0 - d), 2.2) * vAlpha;
      if (a < 0.006) discard;
      gl_FragColor = vec4(vColor, a);
    }
  `,
});
const wishGlow = new THREE.Points(wishGlowGeometry, wishGlowMaterial);
wishGlow.visible = false;
wishGlow.frustumCulled = false;
wishGlow.renderOrder = 6;
scene.add(wishGlow);

let wishEnabled = false;
let wishMix = 0;
let wishTime = 0;

function updateWishLanterns(dt, time) {
  wishMix = damp(wishMix, wishEnabled ? 1 : 0, 2.3, dt);

  if (wishEnabled) {
    wishGroup.visible = true;
    wishGlow.visible = true;
  }

  if (!wishEnabled && wishMix < 0.006) {
    wishMix = 0;
    wishGroup.visible = false;
    wishGlow.visible = false;
    return;
  }

  if (wishGroup.visible) wishTime += dt;

  for (let i = 0; i < WISH_COUNT; i++) {
    const lantern = wishLanterns[i];
    const local = wishTime - lantern.delay;
    let progress = 0;
    if (local > 0) progress = (local % lantern.duration) / lantern.duration;

    const fadeIn = smooth01(progress, 0.0, 0.045);
    const fadeOut = 1 - smooth01(progress, 0.8, 0.98);
    const alpha = Math.max(0, fadeIn * fadeOut * wishMix);

    const swayX = Math.sin(time * lantern.swaySpeed + lantern.swayPhase) * lantern.swayAmp * (0.3 + progress * 0.95);
    const swayZ = Math.cos(time * lantern.swaySpeed * 0.83 + lantern.swayPhase * 1.7) * lantern.swayAmp * (0.22 + progress * 0.7);
    const x = lantern.baseX + swayX;
    const z = lantern.baseZ + swayZ;
    const y = lantern.baseY + progress * (lantern.topY - lantern.baseY);
    const scale = THREE.MathUtils.lerp(lantern.scale0, lantern.scale1, progress);

    lantern.group.position.set(x, y, z);
    lantern.group.scale.setScalar(scale);
    lantern.group.rotation.y = lantern.rotationBias + time * 0.08;
    lantern.group.rotation.z = Math.sin(time * 0.7 + lantern.swayPhase) * 0.035;
    lantern.group.visible = alpha > 0.004;
    lantern.material.opacity = alpha * 0.92;
    lantern.alpha = alpha;

    const k = i * 3;
    wishGlowPositions[k] = x;
    wishGlowPositions[k + 1] = y;
    wishGlowPositions[k + 2] = z;
    wishGlowSizes[i] = 0.72 + progress * 1.55;
    wishGlowAlphas[i] = alpha * 0.58;
  }

  wishGlowGeometry.attributes.position.needsUpdate = true;
  wishGlowGeometry.attributes.aSize.needsUpdate = true;
  wishGlowGeometry.attributes.aAlpha.needsUpdate = true;
}

function smooth01(value, min, max) {
  const t = THREE.MathUtils.clamp((value - min) / (max - min), 0, 1);
  return t * t * (3 - 2 * t);
}

// UI wiring -----------------------------------------------------------------

const ui = document.createElement('div');
ui.className = 'winter-scene-ui';
ui.setAttribute('role', 'group');
ui.setAttribute('aria-label', '冬季场景效果');
ui.innerHTML = `
  <button class="winter-scene-btn" type="button" data-action="snow" aria-pressed="false">
    <span class="winter-scene-seal" aria-hidden="true">雪</span>
    <span class="winter-scene-label">落雪</span>
    <span class="winter-scene-state" aria-hidden="true"></span>
  </button>
  <button class="winter-scene-btn" type="button" data-action="wish" aria-pressed="false">
    <span class="winter-scene-seal" aria-hidden="true">灯</span>
    <span class="winter-scene-label">祈愿</span>
    <span class="winter-scene-state" aria-hidden="true"></span>
  </button>
`;
host.appendChild(ui);
const snowButton = ui.querySelector('[data-action="snow"]');
const wishButton = ui.querySelector('[data-action="wish"]');

function setToggleState(button, active) {
  button.classList.toggle('is-on', active);
  button.setAttribute('aria-pressed', active ? 'true' : 'false');
}

if (snowButton) {
  snowButton.addEventListener('click', () => {
    snowEnabled = !snowEnabled;
    setToggleState(snowButton, snowEnabled);
    if (snowEnabled) snowSystem.points.visible = true;
  });
}

if (wishButton) {
  wishButton.addEventListener('click', () => {
    wishEnabled = !wishEnabled;
    setToggleState(wishButton, wishEnabled);
    if (wishEnabled) {
      wishTime = 0;
      wishGroup.visible = true;
      wishGlow.visible = true;
    }
  });
}

// Keep both effects off until the visitor chooses them from the corner controls.

// ---------------------------------------------------------------------------
// Motion
// ---------------------------------------------------------------------------

const clock = new THREE.Clock();
renderer.shadowMap.autoUpdate = false;
renderer.shadowMap.needsUpdate = true;

let frameCount = 0;
let running = true;
let disposed = false;

function animate() {
  if (!running) return;
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = clock.elapsedTime;

  waterUniforms.uTime.value = t;
  stars.material.uniforms.uTime.value = t;
  emberSystem.mat.uniforms.uTime.value = t;
  petalSystem.mat.uniforms.uTime.value = t;

  updateSnow(dt, t);
  updateWishLanterns(dt, t);
  updateWalkers(dt, t);

  for (const ribbon of floatRibbons) ribbon.update(t);

  for (const sky of skyLanterns) {
    const range = sky.maxY - sky.minY;
    const y = sky.minY + ((sky.baseY - sky.minY + t * sky.speed * 1.45) % range);
    sky.group.position.set(
      sky.baseX + Math.sin(t * 0.17 + sky.phase) * (0.55 + sky.sway) + Math.sin(t * 0.61 + sky.phase * 2.0) * 0.10,
      y + Math.sin(t * 0.48 + sky.phase) * 0.12,
      sky.baseZ + Math.cos(t * 0.13 + sky.phase * 0.82) * 0.55
    );
    sky.group.rotation.y = sky.phase + t * sky.spin;
    sky.group.rotation.z = Math.sin(t * 0.22 + sky.phase) * 0.035;
  }

  for (const kite of skyKoi) {
    const drift = t * 0.13 + kite.phase;
    kite.group.position.set(
      kite.base.x + Math.sin(drift * 0.9) * 1.6,
      kite.base.y + Math.sin(drift * 1.7) * 0.5,
      kite.base.z + Math.cos(drift * 0.75) * 1.3
    );
    kite.group.rotation.y = Math.sin(drift * 0.55) * 0.32;
    kite.group.rotation.z = Math.sin(drift * 1.3) * 0.07;
  }

  for (const koi of koiFish) {
    const a = t * koi.speed + koi.phase;
    const x = koi.centerX + Math.cos(a) * koi.radiusX;
    const z = koi.centerZ + Math.sin(a) * koi.radiusZ;
    const dx = -Math.sin(a) * koi.radiusX * koi.speed;
    const dz = Math.cos(a) * koi.radiusZ * koi.speed;
    koi.group.position.set(x, -0.72 + Math.sin(a * 3.2 + 2.0) * 0.035, z);
    koi.group.rotation.y = Math.atan2(-dz, dx);
    koi.group.rotation.z = Math.sin(a * 2.0) * 0.045;
  }

  for (const wl of waterLanterns) {
    wl.group.position.y = wl.baseY + Math.sin(t * 0.82 + wl.phase) * 0.022;
    wl.group.rotation.y = Math.sin(t * 0.09 + wl.phase) * 0.22;
    wl.group.rotation.z = Math.cos(t * 0.62 + wl.phase) * 0.025;
  }

  for (const sprite of steamSprites) {
    const u = sprite.userData;
    const cycle = (t * u.speed + u.phase * 0.15) % 1;
    sprite.position.set(
      u.baseX + Math.sin(t * 0.55 + u.phase) * (0.18 + cycle * 0.25),
      u.baseY + cycle * 1.85,
      u.baseZ + Math.cos(t * 0.38 + u.phase) * 0.16
    );
    const s = u.size * (0.85 + cycle * 1.6);
    sprite.scale.setScalar(s);
    sprite.material.opacity = Math.pow(Math.sin(Math.PI * cycle), 1.2) * 0.22;
  }

  const wishBoost = 1 + wishMix * 0.22;
  floatLight.intensity = 280 * (0.93 + 0.045 * Math.sin(t * 3.6) + 0.025 * Math.sin(t * 8.1 + 1.2)) * wishBoost;
  bridgeLight.intensity = 86 * (0.91 + 0.07 * Math.sin(t * 4.1 + 0.8) + 0.02 * Math.sin(t * 9.7)) * wishBoost;
  leftStreetLight.intensity = 58 * (0.92 + 0.06 * Math.sin(t * 4.9 + 2.0)) * wishBoost;
  rightStreetLight.intensity = 64 * (0.9 + 0.08 * Math.sin(t * 3.3 + 4.1)) * wishBoost;
  southStreetLight.intensity = 76 * (0.92 + 0.06 * Math.sin(t * 4.4 + 1.4)) * wishBoost;

  controls.update();
  renderer.info.autoReset = false;
  renderer.info.reset();
  composer.render();
  if (window.__WINTER__ && window.__WINTER__.scene === scene) {
    window.__WINTER__.sceneStats = {
      calls: renderer.info.render.calls,
      triangles: renderer.info.render.triangles,
      points: renderer.info.render.points,
      lines: renderer.info.render.lines,
    };
  }
  frameCount += 1;
  if (frameCount === 3) host.dataset.sceneReady = '1';
}

renderer.setAnimationLoop(animate);

function onResize() {
  viewport = readHostSize();
  const width = viewport.width;
  const height = viewport.height;
  const dpr = Math.min(window.devicePixelRatio || 1, 1.45);
  renderer.setPixelRatio(dpr);
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.fov = width / height < 1.08 ? 54 : 42;
  camera.updateProjectionMatrix();
  composer.setSize(width, height);
  bloomPass.setSize(width, height);
  stars.material.uniforms.uPixelRatio.value = dpr;
  lanternSystem.halos.material.uniforms.uPixelRatio.value = dpr;
  emberSystem.mat.uniforms.uPixelRatio.value = dpr;
  petalSystem.mat.uniforms.uPixelRatio.value = dpr;
  snowSystem.material.uniforms.uPixelRatio.value = dpr;
  wishGlowMaterial.uniforms.uPixelRatio.value = dpr;
}

window.addEventListener('resize', onResize, { passive: true });
window.addEventListener('orientationchange', onResize, { passive: true });

function disposeScene() {
  if (disposed) return;
  disposed = true;

  running = false;
  renderer.setAnimationLoop(null);
  window.removeEventListener('resize', onResize);
  window.removeEventListener('orientationchange', onResize);
  controls.dispose();

  // The additive halos are kept outside the scene graph for resize bookkeeping.
  if (lanternSystem && lanternSystem.halos) {
    const halos = lanternSystem.halos;
    try { halos.geometry.dispose(); } catch (error) { /* already released */ }
    try { halos.material.dispose(); } catch (error) { /* already released */ }
  }

  if (composer) {
    for (let i = 0; i < composer.passes.length; i += 1) {
      const pass = composer.passes[i];
      if (pass && typeof pass.dispose === 'function') {
        try { pass.dispose(); } catch (error) { /* pass already released */ }
      }
    }
    try { composer.dispose(); } catch (error) { /* targets already released */ }
  }

  const textures = new Set();
  const materials = new Set();
  const geometries = new Set();
  const textureSlots = [
    'map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'emissiveMap',
    'alphaMap', 'bumpMap', 'displacementMap', 'clearcoatMap', 'clearcoatNormalMap',
    'clearcoatRoughnessMap', 'sheenColorMap', 'sheenRoughnessMap', 'specularMap',
    'transmissionMap', 'thicknessMap', 'lightMap', 'envMap', 'gradientMap',
  ];

  const collectMaterial = (material) => {
    if (!material || materials.has(material)) return;
    materials.add(material);
    for (let i = 0; i < textureSlots.length; i += 1) {
      const texture = material[textureSlots[i]];
      if (texture && texture.isTexture) textures.add(texture);
    }
    if (material.uniforms) {
      Object.keys(material.uniforms).forEach((key) => {
        const value = material.uniforms[key] && material.uniforms[key].value;
        if (value && value.isTexture) textures.add(value);
      });
    }
  };

  scene.traverse((object) => {
    if (object.geometry) geometries.add(object.geometry);
    if (object.material) {
      if (Array.isArray(object.material)) object.material.forEach(collectMaterial);
      else collectMaterial(object.material);
    }
  });

  textures.forEach((texture) => {
    try { texture.dispose(); } catch (error) { /* already released */ }
  });
  materials.forEach((material) => {
    try { material.dispose(); } catch (error) { /* already released */ }
  });
  geometries.forEach((geometry) => {
    try { geometry.dispose(); } catch (error) { /* already released */ }
  });

  scene.clear();
  if (host.dataset.sceneReady) delete host.dataset.sceneReady;
  host.classList.remove('is-winter-scene');
  host.replaceChildren();

  if (window.__WINTER__ && window.__WINTER__.scene === scene) {
    window.__WINTER__ = null;
  }

  renderer.dispose();
  try { renderer.forceContextLoss(); } catch (error) { /* best effort */ }
}

const api = {
  scene,
  camera,
  renderer,
  controls,
  composer,
  bloomPass,
  outputPass,
  snowButton,
  wishButton,
  toggleSnow: () => snowButton && snowButton.click(),
  toggleWish: () => wishButton && wishButton.click(),
  get snowEnabled() { return snowEnabled; },
  get wishEnabled() { return wishEnabled; },
  destroy: disposeScene,
  get disposed() { return disposed; },
};

window.__WINTER__ = api;
return api;
}
