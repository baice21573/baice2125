// Builds autumn-harvest.html: a single, fully offline HTML file.
// Three.js and OrbitControls are inlined, all textures are procedural.
import { readFileSync, writeFileSync } from 'node:fs';

let threeSource = readFileSync('vendor/three.module.js', 'utf8');
const exportMatch = threeSource.match(/export \{([\s\S]*?)\};?\s*$/);
if (!exportMatch) throw new Error('Could not locate the Three.js export list.');

const exportNames = exportMatch[1]
  .split(',')
  .map((name) => name.trim())
  .filter(Boolean);

if (exportNames.some((name) => name.includes(' as '))) {
  throw new Error('Aliased Three.js exports are not supported by this build script.');
}

threeSource = threeSource.slice(0, exportMatch.index);

let orbitSource = readFileSync('vendor/examples/jsm/controls/OrbitControls.js', 'utf8');
orbitSource = orbitSource
  .replace(/^import[\s\S]*?from 'three';\s*/, '')
  .replace(/export \{ OrbitControls \};?\s*$/, '');

let mergeSource = readFileSync('vendor/examples/jsm/utils/BufferGeometryUtils.js', 'utf8');
mergeSource = mergeSource
  .replace(/^import[\s\S]*?from 'three';\s*/m, '')
  .replace(/^export function /gm, 'function ')
  .replace(/^export \{[\s\S]*?\};?\s*$/m, '');

const postAddonPaths = [
  'vendor/examples/jsm/shaders/CopyShader.js',
  'vendor/examples/jsm/shaders/LuminosityHighPassShader.js',
  'vendor/examples/jsm/postprocessing/Pass.js',
  'vendor/examples/jsm/postprocessing/ShaderPass.js',
  'vendor/examples/jsm/postprocessing/MaskPass.js',
  'vendor/examples/jsm/postprocessing/EffectComposer.js',
  'vendor/examples/jsm/postprocessing/RenderPass.js',
  'vendor/examples/jsm/postprocessing/UnrealBloomPass.js',
  'vendor/examples/jsm/shaders/OutputShader.js',
  'vendor/examples/jsm/postprocessing/OutputPass.js',
];

const postAddonSource = postAddonPaths.map((path) => {
  let source = readFileSync(path, 'utf8');
  source = source
    .replace(/^import[\s\S]*?from\s+['"][^'"]+['"];\s*/gm, '')
    .replace(/^export\s*\{[^}]*\};?\s*$/gm, '');
  return source.trim();
}).join('\n\n');

let sceneSource = readFileSync('autumn-harvest-scene.js', 'utf8');
sceneSource = sceneSource.replace(/^import[^\n]*\n/gm, '');

const bundled = `(function () {
'use strict';

${threeSource}

const THREE = { ${exportNames.join(', ')} };

const OrbitControls = (function () {
${orbitSource}
return OrbitControls;
})();

const mergeGeometries = (function () {
${mergeSource}
return mergeGeometries;
})();

const PostAddons = (function () {
${postAddonSource}
return { EffectComposer, RenderPass, UnrealBloomPass, OutputPass };
})();
const { EffectComposer, RenderPass, UnrealBloomPass, OutputPass } = PostAddons;

(function (THREE, OrbitControls, mergeGeometries) {
${sceneSource}
})(THREE, OrbitControls, mergeGeometries);
})();`;

const safeBundle = bundled.replace(/<\/script/gi, '<\\/script');
const template = readFileSync('autumn-harvest.dev.html', 'utf8');
const standalone = template
  .replace(/[ \t]*<script type="importmap">[\s\S]*?<\/script>\s*\n/, '')
  .replace(
    /[ \t]*<script type="module" src="\.\/autumn-harvest-scene\.js[^"]*"><\/script>/,
    () => `<script>\n${safeBundle}\n</script>`
  );

writeFileSync('autumn-harvest.html', standalone, 'utf8');
console.log(`Wrote autumn-harvest.html (${(Buffer.byteLength(standalone) / 1024 / 1024).toFixed(2)} MB)`);
