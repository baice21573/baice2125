// Rebuilds the self-contained garden-day.html from the editable source.
// Usage: node build-garden.mjs
import { readFileSync, writeFileSync } from 'node:fs';
import { build } from 'esbuild';

const result = await build({
  entryPoints: ['garden-scene.js'],
  bundle: true,
  write: false,
  format: 'iife',
  target: ['es2020'],
  minify: true,
  legalComments: 'none',
  alias: {
    three: './vendor/three.module.js',
    'three/addons': './vendor/examples/jsm',
  },
});

const bundle = result.outputFiles[0].text;
const safeBundle = bundle.replace(/<\/script/gi, '<\\/script');
const template = readFileSync('garden-day.dev.html', 'utf8');

const standalone = template
  .replace(/[ \t]*<script type="importmap">[\s\S]*?<\/script>\s*\n/, '')
  .replace(
    /[ \t]*<script type="module" src="\.\/garden-scene\.js[^"]*"><\/script>/,
    () => `<script>\n${safeBundle}\n</script>`
  );

writeFileSync('garden-day.html', standalone, 'utf8');
console.log(`Wrote garden-day.html (${(Buffer.byteLength(standalone) / 1024 / 1024).toFixed(2)} MB)`);
