import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { Reflector } from 'three/addons/objects/Reflector.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

// ---------------------------------------------------------------------------
// 清夏荷园 · 微缩三维园林
// A hand-built, toon-shaded Chinese garden: square stone base, lotus pond,
// covered zig-zag walk, octagonal pavilion, white wall / dark tile roof, and
// a small arched bridge. Everything is procedural; no external assets.
// ---------------------------------------------------------------------------

const canvas = document.getElementById('scene');
const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: true,
  alpha: false,
  powerPreference: 'high-performance',
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const TARGET = new THREE.Vector3(0.0, 1.8, 0.0);
const camera = new THREE.PerspectiveCamera(42, window.innerWidth / window.innerHeight, 0.4, 220);

// Offset from TARGET; fitCamera() adds TARGET back in.
const BASE_CAMERA = new THREE.Vector3(18.5, 21.7, 29.5);

function fitCamera() {
  const aspect = window.innerWidth / window.innerHeight;
  const scale = THREE.MathUtils.clamp(1.34 / aspect, 1, 1.62);
  camera.position.copy(BASE_CAMERA).multiplyScalar(scale).add(TARGET);
  camera.fov = aspect < 0.92 ? 48 : 42;
  camera.updateProjectionMatrix();
}
fitCamera();

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.copy(TARGET);
controls.enableDamping = true;
controls.dampingFactor = 0.06;
controls.enablePan = false;
controls.rotateSpeed = 0.62;
controls.zoomSpeed = 0.8;
controls.minDistance = 21;
controls.maxDistance = 70;
controls.minPolarAngle = 0.28;
controls.maxPolarAngle = 1.32;

controls.update();

// ---------------------------------------------------------------------------
// Deterministic random helpers
// ---------------------------------------------------------------------------

function mulberry32(seed) {
  let a = seed >>> 0;
  return function random() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rng = mulberry32(0x517a2026);
const rand = (a = 0, b = 1) => a + (b - a) * rng();
const choose = (arr) => arr[Math.floor(rng() * arr.length)];
const clamp = THREE.MathUtils.clamp;
const V3 = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const V2 = (x = 0, y = 0) => new THREE.Vector2(x, y);

// ---------------------------------------------------------------------------
// Sky, light and atmosphere
// ---------------------------------------------------------------------------

function makeSkyTexture() {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 1024;
  const ctx = c.getContext('2d');

  const sky = ctx.createLinearGradient(0, 0, 0, 1024);
  sky.addColorStop(0.0, '#6a4f66');
  sky.addColorStop(0.08, '#8d5c69');
  sky.addColorStop(0.18, '#b66b64');
  sky.addColorStop(0.3, '#d87958');
  sky.addColorStop(0.42, '#ec8b4e');
  sky.addColorStop(0.54, '#f7a04d');
  sky.addColorStop(0.66, '#ffb85e');
  sky.addColorStop(0.76, '#ffd17c');
  sky.addColorStop(0.88, '#e6a060');
  sky.addColorStop(1.0, '#633c37');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, 1024, 1024);

  // A yellow-white setting sun at the horizontal centre, with a wide warm halo
  // that blends into the yellow and orange bands.
  const halo = ctx.createRadialGradient(512, 190, 10, 512, 190, 390);
  halo.addColorStop(0, 'rgba(255, 248, 207, 0.9)');
  halo.addColorStop(0.12, 'rgba(255, 226, 150, 0.62)');
  halo.addColorStop(0.32, 'rgba(255, 180, 105, 0.26)');
  halo.addColorStop(0.62, 'rgba(234, 113, 85, 0.09)');
  halo.addColorStop(1, 'rgba(196, 82, 75, 0)');
  ctx.fillStyle = halo;
  ctx.fillRect(0, 0, 1024, 1024);

  const sunDisc = ctx.createRadialGradient(512, 190, 2, 512, 190, 54);
  sunDisc.addColorStop(0, 'rgba(255, 255, 241, 1)');
  sunDisc.addColorStop(0.3, 'rgba(255, 247, 199, 0.98)');
  sunDisc.addColorStop(0.66, 'rgba(255, 215, 135, 0.85)');
  sunDisc.addColorStop(1, 'rgba(255, 186, 105, 0)');
  ctx.fillStyle = sunDisc;
  ctx.fillRect(0, 0, 1024, 1024);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeCloudTexture() {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 512;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, 1024, 512);
  ctx.filter = 'blur(20px)';
  const palette = [
    'rgba(232, 188, 160, 0.1)',
    'rgba(244, 201, 168, 0.08)',
    'rgba(202, 163, 173, 0.09)',
    'rgba(245, 188, 142, 0.08)',
  ];

  // Soft overlapping cloud groups, duplicated across the seam so the dome
  // drifts without a visible vertical join.
  for (let group = 0; group < 15; group++) {
    const cx = rand(0, 1024);
    const cy = rand(45, 390);
    const spread = rand(70, 230);
    const count = 4 + Math.floor(rng() * 5);
    for (let i = 0; i < count; i++) {
      const px = cx + rand(-spread, spread);
      const py = cy + rand(-32, 32);
      const rx = rand(55, 165);
      const ry = rand(8, 28);
      const angle = rand(-0.2, 0.2);
      ctx.fillStyle = palette[Math.floor(rng() * palette.length)];
      for (const offset of [-1024, 0, 1024]) {
        ctx.beginPath();
        ctx.ellipse(px + offset, py, rx, ry, angle, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
  ctx.filter = 'none';

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  return tex;
}

const skyTexture = makeSkyTexture();
scene.background = skyTexture;
scene.fog = new THREE.Fog(0xb28a82, 64, 156);

const cloudTexture = makeCloudTexture();
const cloudDome = new THREE.Mesh(
  new THREE.SphereGeometry(158, 48, 24),
  new THREE.MeshBasicMaterial({
    map: cloudTexture,
    side: THREE.BackSide,
    transparent: true,
    opacity: 0.34,
    depthWrite: false,
    fog: false,
  })
);
cloudDome.name = 'drifting-dusk-clouds';
cloudDome.rotation.y = 0.45;
cloudDome.renderOrder = -950;
cloudDome.frustumCulled = false;
scene.add(cloudDome);

const hemi = new THREE.HemisphereLight(0xffd5b2, 0x6f685a, 0.3);
scene.add(hemi);

const fillLight = new THREE.DirectionalLight(0xaab9cd, 0.15);
fillLight.position.set(17, 8, -14);
scene.add(fillLight);

const ambient = new THREE.AmbientLight(0xffd7ac, 0.46);
scene.add(ambient);

const sun = new THREE.DirectionalLight(0xffb366, 3.35);
sun.position.set(-23, 11, 16);
sun.target.position.set(0, 0, 0);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -28;
sun.shadow.camera.right = 28;
sun.shadow.camera.top = 28;
sun.shadow.camera.bottom = -28;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 90;
sun.shadow.bias = -0.00035;
sun.shadow.normalBias = 0.035;
sun.shadow.radius = 2.8;
scene.add(sun);
scene.add(sun.target);

// Soft sunset bloom. The threshold is high enough to avoid a milky veil,
// while sunlit lotus petals, white walls and water highlights gently glow.
const composer = new EffectComposer(renderer);
composer.setPixelRatio(renderer.getPixelRatio());
composer.addPass(new RenderPass(scene, camera));
const bloomPass = new UnrealBloomPass(
  new THREE.Vector2(window.innerWidth, window.innerHeight),
  0.56,
  0.62,
  0.74
);
composer.addPass(bloomPass);
composer.addPass(new OutputPass());
composer.setSize(window.innerWidth, window.innerHeight);

// ---------------------------------------------------------------------------
// Texture factories
// ---------------------------------------------------------------------------

function makeTexture(w, h, draw, { repeat = [1, 1], wrap = true } = {}) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  draw(ctx, w, h);
  const texture = new THREE.CanvasTexture(c);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  texture.wrapS = wrap ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  texture.wrapT = wrap ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  texture.repeat.set(repeat[0], repeat[1]);
  texture.needsUpdate = true;
  return texture;
}

function speckle(ctx, count, w, h, palette, minR = 0.4, maxR = 2.1) {
  for (let i = 0; i < count; i++) {
    ctx.globalAlpha = 0.08 + rng() * 0.17;
    ctx.fillStyle = palette[Math.floor(rng() * palette.length)];
    const r = minR + rng() * (maxR - minR);
    ctx.beginPath();
    ctx.arc(rng() * w, rng() * h, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

const pavingTexture = makeTexture(1024, 1024, (ctx, w, h) => {
  // Continuous weathered blue-grey stone. No repeated grid, no drawn seams:
  // individual slabs are added later as actual flat geometry.
  ctx.fillStyle = '#a8b0a9';
  ctx.fillRect(0, 0, w, h);
  const tints = ['#b2bab3', '#9da79f', '#aeb6ae', '#9aa59d', '#a4aea6', '#b7bdb6'];
  for (let i = 0; i < 170; i++) {
    ctx.globalAlpha = 0.06 + rng() * 0.09;
    ctx.fillStyle = tints[Math.floor(rng() * tints.length)];
    ctx.beginPath();
    ctx.ellipse(
      rng() * w,
      rng() * h,
      22 + rng() * 110,
      12 + rng() * 65,
      rng() * Math.PI,
      0,
      Math.PI * 2
    );
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  speckle(ctx, 1800, w, h, ['#5c6961', '#d4dcd3', '#819087', '#b4bdb6'], 0.35, 1.55);
  for (let i = 0; i < 80; i++) {
    ctx.globalAlpha = 0.1 + rng() * 0.14;
    ctx.strokeStyle = '#5a6860';
    ctx.lineWidth = 0.6 + rng() * 1.1;
    const x = rng() * w;
    const y = rng() * h;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + rand(-24, 24), y + rand(-11, 11));
    ctx.lineTo(x + rand(-34, 34), y + rand(-18, 18));
    ctx.stroke();
  }
  for (let i = 0; i < 86; i++) {
    ctx.globalAlpha = 0.06 + rng() * 0.11;
    ctx.fillStyle = rng() > 0.5 ? '#70855f' : '#627a69';
    ctx.beginPath();
    ctx.ellipse(rng() * w, rng() * h, 4 + rng() * 34, 2 + rng() * 12, rng() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}, { repeat: [1 / 24, 1 / 24] });
pavingTexture.offset.set(0.5, 0.5);

const stoneBumpTexture = makeTexture(256, 256, (ctx, w, h) => {
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, w, h);
  speckle(ctx, 900, w, h, ['#595959', '#b0b0b0', '#6f6f6f', '#9a9a9a'], 0.4, 2.6);
  for (let i = 0; i < 50; i++) {
    ctx.globalAlpha = 0.12 + rng() * 0.2;
    ctx.strokeStyle = '#5c5c5c';
    ctx.lineWidth = 0.8;
    const x = rng() * w;
    const y = rng() * h;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + rand(-18, 18), y + rand(-8, 8));
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}, { repeat: [2, 2] });
stoneBumpTexture.colorSpace = THREE.NoColorSpace;

const slabTexture = makeTexture(256, 256, (ctx, w, h) => {
  ctx.fillStyle = '#bac6bb';
  ctx.fillRect(0, 0, w, h);
  const grad = ctx.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, 'rgba(231, 239, 228, 0.25)');
  grad.addColorStop(0.55, 'rgba(255, 255, 255, 0)');
  grad.addColorStop(1, 'rgba(63, 82, 68, 0.18)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = 'rgba(73, 91, 78, 0.52)';
  ctx.lineWidth = 8;
  ctx.strokeRect(4, 4, w - 8, h - 8);
  ctx.strokeStyle = 'rgba(232, 240, 229, 0.42)';
  ctx.lineWidth = 2;
  ctx.strokeRect(11, 11, w - 22, h - 22);
  speckle(ctx, 180, w, h, ['#647c69', '#e5ecdf', '#879b8a', '#5c7462'], 0.5, 2.1);
});

const rockTexture = makeTexture(256, 256, (ctx, w, h) => {
  ctx.fillStyle = '#8c9c93';
  ctx.fillRect(0, 0, w, h);
  speckle(ctx, 400, w, h, ['#455a50', '#c3cec5', '#6e8277', '#a8b7ad', '#374b42'], 0.6, 3.2);
  ctx.globalAlpha = 0.22;
  for (let i = 0; i < 28; i++) {
    ctx.fillStyle = '#3b5046';
    ctx.beginPath();
    ctx.ellipse(rng() * w, rng() * h, 4 + rng() * 24, 1 + rng() * 5, rng() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
});

const woodTexture = makeTexture(192, 256, (ctx, w, h) => {
  const g = ctx.createLinearGradient(0, 0, w, 0);
  g.addColorStop(0, '#875b3f');
  g.addColorStop(0.45, '#966a49');
  g.addColorStop(1, '#7e5138');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  for (let i = 0; i < 28; i++) {
    ctx.globalAlpha = 0.08 + rng() * 0.1;
    ctx.strokeStyle = rng() > 0.5 ? '#4f3222' : '#c18b60';
    ctx.lineWidth = 0.6 + rng() * 1.3;
    ctx.beginPath();
    const x = rng() * w;
    ctx.moveTo(x, -10);
    ctx.bezierCurveTo(x + rand(-9, 9), h * 0.3, x + rand(-12, 12), h * 0.68, x + rand(-8, 8), h + 10);
    ctx.stroke();
  }
  ctx.globalAlpha = 0.15;
  ctx.strokeStyle = '#3f281b';
  for (let i = 0; i < 4; i++) {
    const x = 25 + rng() * (w - 50);
    const y = 25 + rng() * (h - 50);
    ctx.beginPath();
    ctx.ellipse(x, y, 4 + rng() * 5, 8 + rng() * 9, rng() * Math.PI, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}, { repeat: [1, 1] });

const tileTexture = makeTexture(320, 320, (ctx, w, h) => {
  ctx.fillStyle = '#56625e';
  ctx.fillRect(0, 0, w, h);
  const rows = 10;
  const cols = 8;
  const rh = h / rows;
  const cw = w / cols;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = c * cw;
      const y = r * rh;
      const g = ctx.createLinearGradient(x, 0, x + cw, 0);
      g.addColorStop(0, '#45524e');
      g.addColorStop(0.18, '#73817c');
      g.addColorStop(0.48, '#818e89');
      g.addColorStop(0.8, '#616d69');
      g.addColorStop(1, '#3e4a46');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.roundRect(x + 0.6, y + 0.8, cw - 1.2, rh - 2.2, [5, 5, 2, 2]);
      ctx.fill();
      ctx.strokeStyle = 'rgba(203, 217, 206, 0.24)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(x + cw / 2, y + rh - 1.4, cw * 0.35, Math.PI, Math.PI * 2);
      ctx.stroke();
    }
  }
  ctx.strokeStyle = 'rgba(52, 64, 59, 0.66)';
  ctx.lineWidth = 2;
  for (let r = 0; r <= rows; r++) {
    ctx.beginPath();
    ctx.moveTo(0, r * rh);
    ctx.lineTo(w, r * rh);
    ctx.stroke();
  }
  for (let c = 0; c <= cols; c++) {
    ctx.beginPath();
    ctx.moveTo(c * cw, 0);
    ctx.lineTo(c * cw, h);
    ctx.stroke();
  }
  speckle(ctx, 160, w, h, ['#2d403a', '#9aaba2', '#70827a'], 0.5, 2);
}, { repeat: [1, 1] });

const plasterTexture = makeTexture(256, 256, (ctx, w, h) => {
  ctx.fillStyle = '#f4f1e5';
  ctx.fillRect(0, 0, w, h);
  const g = ctx.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, 'rgba(255, 255, 255, 0.32)');
  g.addColorStop(0.7, 'rgba(255, 255, 255, 0)');
  g.addColorStop(1, 'rgba(154, 163, 145, 0.13)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  speckle(ctx, 540, w, h, ['#d9d5c4', '#ffffff', '#c9c8b9', '#e4e0d0'], 0.4, 1.8);
  // faint old-plaster blooms
  for (let i = 0; i < 9; i++) {
    ctx.globalAlpha = 0.045 + rng() * 0.035;
    ctx.fillStyle = '#7e8c78';
    ctx.beginPath();
    ctx.ellipse(rng() * w, rng() * h, 8 + rng() * 26, 5 + rng() * 18, rng() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
});

const leafTexture = makeTexture(256, 256, (ctx, w, h) => {
  const cx = w / 2;
  const cy = h / 2;
  const r = w * 0.47;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#d4e3cb';
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();

  const grad = ctx.createRadialGradient(cx - 16, cy - 18, 8, cx, cy, r);
  grad.addColorStop(0, '#b7d0ad');
  grad.addColorStop(0.52, '#d8e7cf');
  grad.addColorStop(0.86, '#eaf3e3');
  grad.addColorStop(1, '#d9e7d0');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, r - 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.save();
  ctx.translate(cx, cy);
  for (let i = 0; i < 26; i++) {
    const a = (i / 26) * Math.PI * 2 + 0.05;
    ctx.strokeStyle = i % 2 ? 'rgba(101, 145, 91, 0.2)' : 'rgba(255, 255, 244, 0.28)';
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * 24, Math.sin(a) * 24);
    ctx.quadraticCurveTo(
      Math.cos(a + 0.08) * r * 0.56,
      Math.sin(a + 0.08) * r * 0.56,
      Math.cos(a) * (r - 8),
      Math.sin(a) * (r - 8)
    );
    ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(118, 160, 105, 0.22)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, 0, r - 16, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  // Soft pale rim; deliberately not a dark contour.
  ctx.strokeStyle = 'rgba(238, 246, 230, 0.36)';
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.arc(cx, cy, r - 1, 0, Math.PI * 2);
  ctx.stroke();
});

// ---------------------------------------------------------------------------
// Materials
// ---------------------------------------------------------------------------
// Standard lit materials replace the previous toon ramp. Outlines are gone;
// form now comes from ambient fill, directional light, shadow and roughness.

function lit(color, opts = {}) {
  const material = new THREE.MeshStandardMaterial({
    color,
    roughness: opts.roughness ?? 0.88,
    metalness: opts.metalness ?? 0.0,
    ...opts,
  });
  material.userData.receiveShadow = opts.receiveShadow !== false;
  material.userData.castShadow = opts.castShadow !== false;
  return material;
}



const MAT = {
  paving: lit(0xb8c2ba, {
    map: pavingTexture,
    bumpMap: stoneBumpTexture,
    bumpScale: 0.045,
    roughness: 0.96,
  }),
  slab: lit(0xd9ded5, {
    map: slabTexture,
    bumpMap: stoneBumpTexture,
    bumpScale: 0.028,
    roughness: 0.95,
  }),
  slabDark: lit(0xa9b1a8, {
    map: slabTexture,
    color: 0xa9b1a8,
    bumpMap: stoneBumpTexture,
    bumpScale: 0.028,
    roughness: 0.95,
  }),
  flagA: lit(0x7f8b85, {
    bumpMap: stoneBumpTexture,
    bumpScale: 0.04,
    roughness: 0.97,
  }),
  flagB: lit(0x8d9892, {
    bumpMap: stoneBumpTexture,
    bumpScale: 0.04,
    roughness: 0.97,
  }),
  flagC: lit(0x74817a, {
    bumpMap: stoneBumpTexture,
    bumpScale: 0.045,
    roughness: 0.98,
  }),
  baseStone: lit(0xafb5aa, {
    map: rockTexture,
  }),
  baseTrim: lit(0x5c6258, {
    map: woodTexture,
    color: 0x5c6258,
  }),
  rock: lit(0xb7bdb2, {
    map: rockTexture,
    flatShading: true,
  }),
  rockDark: lit(0x7b857b, {
    map: rockTexture,
    color: 0x7b857b,
    flatShading: true,
  }),
  moss: lit(0x899d72, { castShadow: false }),
  mossDark: lit(0x718760, { castShadow: false }),
  rockery: lit(0x626a66, {
    flatShading: true,
    roughness: 0.98,
  }),
  rockeryDark: lit(0x4d5550, {
    flatShading: true,
    roughness: 1.0,
  }),
  hedge: lit(0x638b52, {
    flatShading: true,
    roughness: 0.92,
  }),
  hedgeLight: lit(0x7fa768, {
    flatShading: true,
    roughness: 0.92,
  }),
  shrubDeep: lit(0x466b3f, {
    flatShading: true,
    roughness: 0.94,
  }),
  shrubOlive: lit(0x7c9457, {
    flatShading: true,
    roughness: 0.94,
  }),
  lampGlow: lit(0xffc47c, {
    emissive: 0xff8a37,
    emissiveIntensity: 2.1,
    roughness: 0.48,
  }),
  wood: lit(0xe6cfb9, {
    map: woodTexture,
  }),
  woodDark: lit(0x6b5140, {
    map: woodTexture,
    color: 0x6b5140,
  }),
  woodLight: lit(0xd4b79b, {
    map: woodTexture,
    color: 0xd4b79b,
  }),
  plaster: lit(0xe8e3d7, {
    map: plasterTexture,
  }),
  roof: lit(0xc5cec9, {
    map: tileTexture,
    side: THREE.DoubleSide,
  }),
  roofDark: lit(0x5b6763, {
    color: 0x5b6763,
  }),
  roofLine: lit(0x55615d, {
    color: 0x55615d,
    castShadow: false,
    receiveShadow: true,
  }),
  jade: lit(0x87a39a, {
    roughness: 0.7,
  }),
  lattice: lit(0x71817a, {
    roughness: 0.82,
  }),
  gold: lit(0xcdb47d, {
    metalness: 0.55,
    roughness: 0.38,
  }),
  bamboo: lit(0x6f9b53, {
    roughness: 0.82,
  }),
  bambooDark: lit(0x55783f, {
    roughness: 0.85,
  }),
  bark: lit(0x776a59, {
    map: rockTexture,
    color: 0x776a59,
    roughness: 0.98,
  }),
  lotusStem: lit(0x8aa47b),
  lotusHeart: lit(0xe6d89b, { castShadow: false, roughness: 0.85 }),
  lotusHeartDark: lit(0xbcc293, { castShadow: false }),
  koiOrange: lit(0xdc9b6b, { roughness: 0.6 }),
  koiWhite: lit(0xeee7d8, { roughness: 0.6 }),
  koiBlack: lit(0x5b5d52, { castShadow: false }),
  dragonBody: lit(0x6a7d74, { castShadow: false }),
  dragonWing: new THREE.MeshBasicMaterial({
    color: 0xe5eee9,
    transparent: true,
    opacity: 0.45,
    side: THREE.DoubleSide,
    depthWrite: false,
  }),
  petalFloat: lit(0xedd9dc, { side: THREE.DoubleSide, castShadow: false }),
  metalDark: lit(0x4d5851, { castShadow: false }),
  paperLantern: lit(0xf2e2bb, {
    color: 0xf2e2bb,
    emissive: 0x513a1d,
    emissiveIntensity: 0.25,
    castShadow: false,
  }),
};

// ---------------------------------------------------------------------------
// Geometry helpers and static batching
// ---------------------------------------------------------------------------

function addMesh(parent, geometry, material, { x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1 } = {}) {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(x, y, z);
  mesh.rotation.set(rx, ry, rz);
  mesh.scale.set(sx, sy, sz);
  parent.add(mesh);
  return mesh;
}

function addBox(parent, w, h, d, material, x, y, z, rx = 0, ry = 0, rz = 0) {
  return addMesh(parent, new THREE.BoxGeometry(w, h, d), material, { x, y, z, rx, ry, rz });
}

function addCylinder(parent, radiusTop, radiusBottom, height, segments, material, x, y, z, rx = 0, ry = 0, rz = 0) {
  return addMesh(parent, new THREE.CylinderGeometry(radiusTop, radiusBottom, height, segments), material, {
    x, y, z, rx, ry, rz,
  });
}

function addTube(parent, points, radius, material, segments = 16, radialSegments = 6) {
  const curve = new THREE.CatmullRomCurve3(points);
  return addMesh(parent, new THREE.TubeGeometry(curve, segments, radius, radialSegments, false), material);
}

const staticRoot = new THREE.Group();
scene.add(staticRoot);

function bakeStatic(root) {
  root.updateMatrixWorld(true);
  const buckets = new Map();

  root.traverse((obj) => {
    if (!obj.isMesh || obj.isInstancedMesh || obj.userData.noMerge) return;
    const material = obj.material;
    if (!material || Array.isArray(material) || material.transparent) return;

    let entry = buckets.get(material.uuid);
    if (!entry) {
      entry = { material, geometries: [] };
      buckets.set(material.uuid, entry);
    }

    let geo = obj.geometry.index ? obj.geometry.toNonIndexed() : obj.geometry.clone();
    for (const name of Object.keys(geo.attributes)) {
      if (!['position', 'normal', 'uv'].includes(name)) geo.deleteAttribute(name);
    }
    if (!geo.attributes.normal) geo.computeVertexNormals();
    if (!geo.attributes.uv) {
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(geo.attributes.position.count * 2), 2));
    }
    if (obj.matrixWorld.determinant() < 0) {
      // Keep winding while mirroring where necessary.
      const index = geo.index;
      if (index) {
        const arr = index.array;
        for (let i = 0; i < arr.length; i += 3) {
          const t = arr[i + 1];
          arr[i + 1] = arr[i + 2];
          arr[i + 2] = t;
        }
      }
    }
    geo.applyMatrix4(obj.matrixWorld);
    entry.geometries.push(geo);
  });

  root.clear();

  const mergedRoot = new THREE.Group();
  mergedRoot.name = 'static-garden';
  for (const { material, geometries } of buckets.values()) {
    if (!geometries.length) continue;
    const merged = mergeGeometries(geometries, false);
    if (!merged) continue;
    merged.computeBoundingSphere();
    const mesh = new THREE.Mesh(merged, material);
    mesh.castShadow = material.userData.castShadow !== false;
    mesh.receiveShadow = material.userData.receiveShadow !== false;
    mesh.name = material.name || 'garden-part';
    mergedRoot.add(mesh);
  }
  scene.add(mergedRoot);
  return mergedRoot;
}

// ---------------------------------------------------------------------------
// The square base and pond
// ---------------------------------------------------------------------------

const BASE_SIZE = 26;
const PAVE_TOP = 0.32;
const WATER_Y = 0.285;

const POND_CONTROL = [
  V2(-6.85, -3.6),
  V2(-5.4, -4.75),
  V2(-2.5, -4.82),
  V2(1.4, -4.95),
  V2(4.8, -4.3),
  V2(6.95, -2.5),
  V2(7.55, 0.3),
  V2(7.3, 3.25),
  V2(6.5, 5.9),
  V2(4.0, 6.9),
  V2(0.5, 7.05),
  V2(-3.4, 7.05),
  V2(-6.2, 6.15),
  V2(-7.4, 3.4),
  V2(-7.6, -0.5),
];

const pondCurve = new THREE.CatmullRomCurve3(
  POND_CONTROL.map((p) => V3(p.x, 0, p.y)),
  true,
  'catmullrom',
  0.42
);
const pondSamples = pondCurve.getPoints(160);

function shapeFromPond() {
  const shape = new THREE.Shape();
  shape.moveTo(pondSamples[0].x, -pondSamples[0].z);
  for (let i = 1; i < pondSamples.length; i++) {
    shape.lineTo(pondSamples[i].x, -pondSamples[i].z);
  }
  shape.closePath();
  return shape;
}

const pondShape = shapeFromPond();

function pointInPond(x, z, margin = 0) {
  let inside = false;
  for (let i = 0, j = pondSamples.length - 1; i < pondSamples.length; j = i++) {
    const xi = pondSamples[i].x;
    const zi = pondSamples[i].z;
    const xj = pondSamples[j].x;
    const zj = pondSamples[j].z;
    if (zi > z !== zj > z && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) inside = !inside;
  }
  if (!inside) return false;
  if (margin <= 0) return true;
  for (let i = 0; i < pondSamples.length; i++) {
    const a = pondSamples[i];
    const b = pondSamples[(i + 1) % pondSamples.length];
    const vx = b.x - a.x;
    const vz = b.z - a.z;
    const wx = x - a.x;
    const wz = z - a.z;
    const t = clamp((wx * vx + wz * vz) / (vx * vx + vz * vz || 1), 0, 1);
    const dx = x - (a.x + vx * t);
    const dz = z - (a.z + vz * t);
    if (dx * dx + dz * dz < margin * margin) return false;
  }
  return true;
}

function buildBase() {
  const root = new THREE.Group();
  root.name = 'base';

  addMesh(root, new THREE.BoxGeometry(26.2, 1.5, 26.2), MAT.baseStone, { y: -0.76 });
  addMesh(root, new THREE.BoxGeometry(26.9, 0.34, 26.9), MAT.baseTrim, { y: -1.58 });
  addMesh(root, new THREE.BoxGeometry(25.4, 0.18, 25.4), MAT.slabDark, { y: -1.34 });

  // Outer wooden rim around the stone tabletop.
  addBox(root, 26.9, 0.24, 0.36, MAT.baseTrim, 0, 0.11, 13.03);
  addBox(root, 26.9, 0.24, 0.36, MAT.baseTrim, 0, 0.11, -13.03);
  addBox(root, 0.36, 0.24, 26.9, MAT.baseTrim, 13.03, 0.11, 0);
  addBox(root, 0.36, 0.24, 26.9, MAT.baseTrim, -13.03, 0.11, 0);

  // Carved side panels and a restrained gold inlay.
  const sides = [
    { x: 0, z: 13.12, ry: 0, w: 7.4 },
    { x: 0, z: -13.12, ry: 0, w: 7.4 },
    { x: 13.12, z: 0, ry: Math.PI / 2, w: 7.4 },
    { x: -13.12, z: 0, ry: Math.PI / 2, w: 7.4 },
  ];
  for (const s of sides) {
    const panel = new THREE.Group();
    panel.position.set(s.x, -0.83, s.z);
    panel.rotation.y = s.ry;
    root.add(panel);
    addBox(panel, s.w, 0.68, 0.08, MAT.slabDark, 0, 0, 0);
    addBox(panel, s.w - 0.46, 0.52, 0.055, MAT.baseStone, 0, 0, 0.055);
    addBox(panel, s.w - 0.18, 0.055, 0.09, MAT.gold, 0, 0.41, 0.02);
    addBox(panel, s.w - 0.18, 0.055, 0.09, MAT.gold, 0, -0.41, 0.02);
    // Small corner studs.
    for (const sx of [-1, 1]) {
      addBox(panel, 0.17, 0.17, 0.1, MAT.gold, sx * (s.w / 2 - 0.23), 0, 0.06, 0, 0, Math.PI / 4);
    }
  }

  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      addMesh(root, new THREE.CylinderGeometry(0.47, 0.58, 1.2, 8), MAT.baseStone, {
        x: sx * 12.25,
        y: -0.74,
        z: sz * 12.25,
      });
      addBox(root, 1.15, 0.16, 1.15, MAT.baseTrim, sx * 12.25, -0.18, sz * 12.25, 0, Math.PI / 4, 0);
    }
  }

  // Paving with a clean, shaped hole for the pond.
  const outer = new THREE.Shape();
  outer.moveTo(-12.48, -12.48);
  outer.lineTo(12.48, -12.48);
  outer.lineTo(12.48, 12.48);
  outer.lineTo(-12.48, 12.48);
  outer.closePath();
  const holePath = new THREE.Path();
  holePath.moveTo(pondSamples[0].x, -pondSamples[0].z);
  for (let i = pondSamples.length - 1; i >= 1; i--) {
    holePath.lineTo(pondSamples[i].x, -pondSamples[i].z);
  }
  holePath.closePath();
  outer.holes.push(holePath);

  const pavingGeometry = new THREE.ExtrudeGeometry(outer, {
    depth: 0.31,
    bevelEnabled: true,
    bevelSize: 0.055,
    bevelThickness: 0.035,
    bevelSegments: 1,
    curveSegments: 12,
  });
  pavingGeometry.rotateX(-Math.PI / 2);
  addMesh(root, pavingGeometry, MAT.paving, { y: 0.005 });

  // Raised, irregular coping stones at the water's edge.
  const edgeRoot = new THREE.Group();
  root.add(edgeRoot);
  for (let i = 0; i < pondSamples.length; i += 3) {
    const p = pondSamples[i];
    const prev = pondSamples[(i - 3 + pondSamples.length) % pondSamples.length];
    const next = pondSamples[(i + 3) % pondSamples.length];
    const dx = next.x - prev.x;
    const dz = next.z - prev.z;
    const len = Math.hypot(dx, dz) || 1;
    const nx = -dz / len;
    const nz = dx / len;
    const offset = rand(0.04, 0.18);
    const size = rand(0.19, 0.34);
    addMesh(edgeRoot, new THREE.DodecahedronGeometry(size, 0), MAT.rock, {
      x: p.x + nx * offset,
      y: PAVE_TOP + rand(-0.02, 0.04),
      z: p.z + nz * offset,
      rx: rand(-0.2, 0.2),
      ry: rand(0, Math.PI),
      rz: rand(-0.2, 0.2),
      sx: rand(0.9, 1.6),
      sy: rand(0.55, 1.0),
      sz: rand(0.8, 1.4),
    });
  }

  // A darker stone border frames the water and keeps the eye in the garden.
  {
    const positions = [];
    const uvs = [];
    const indices = [];
    const innerOffset = 0.06;
    const outerOffset = 0.72;
    for (let i = 0; i < pondSamples.length; i++) {
      const p = pondSamples[i];
      const prev = pondSamples[(i - 1 + pondSamples.length) % pondSamples.length];
      const next = pondSamples[(i + 1) % pondSamples.length];
      let nx = -(next.z - prev.z);
      let nz = next.x - prev.x;
      const len = Math.hypot(nx, nz) || 1;
      nx /= len;
      nz /= len;
      if (nx * p.x + nz * p.z < 0) {
        nx *= -1;
        nz *= -1;
      }
      positions.push(
        p.x + nx * innerOffset, PAVE_TOP + 0.012, p.z + nz * innerOffset,
        p.x + nx * outerOffset, PAVE_TOP + 0.012, p.z + nz * outerOffset
      );
      const u = i / pondSamples.length;
      uvs.push(u * 9, 0, u * 9, 1);
      if (i < pondSamples.length - 1) {
        const a = i * 2;
        indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
      }
    }
    const borderGeo = new THREE.BufferGeometry();
    borderGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    borderGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    borderGeo.setIndex(indices);
    borderGeo.computeVertexNormals();
    addMesh(root, borderGeo, MAT.slabDark, { y: 0 });
  }

  // A few patch repairs / slab seams for a lived-in courtyard.
  for (let i = 0; i < 5; i++) {
    const angle = rand(0, Math.PI * 2);
    const radius = rand(8.3, 11.5);
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;
    addBox(root, rand(1.4, 2.8), 0.03, rand(0.18, 0.28), MAT.slabDark, x, PAVE_TOP + 0.012, z, 0, rand(-0.8, 0.8), 0);
  }

  // A hand-laid flagstone surface. Individual irregular slabs cover the
  // courtyard ring; the underlying mottled stone shows only in the joints.
  const flagMaterials = [MAT.flagA, MAT.flagB, MAT.flagC];
  let flagIndex = 0;
  for (let tries = 0; tries < 900 && flagIndex < 190; tries++) {
    const cx = rand(-11.8, 11.8);
    const cz = rand(-11.8, 11.8);
    if (pointInPond(cx, cz, 0.08)) continue;
    const sides = 5 + Math.floor(rand(0, 5));
    const rx = rand(0.3, 1.45);
    const rz = rand(0.25, 1.2);
    const shape = new THREE.Shape();
    for (let s = 0; s < sides; s++) {
      const a = (s / sides) * Math.PI * 2 + rand(-0.2, 0.2);
      const rr = rand(0.82, 1.06);
      const px = Math.cos(a) * rx * rr;
      const py = Math.sin(a) * rz * rr;
      if (s === 0) shape.moveTo(px, py);
      else shape.lineTo(px, py);
    }
    shape.closePath();
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: 0.035,
      bevelEnabled: true,
      bevelSize: 0.018,
      bevelThickness: 0.01,
      bevelSegments: 1,
      curveSegments: 4,
    });
    geo.rotateX(-Math.PI / 2);
    addMesh(root, geo, flagMaterials[flagIndex % flagMaterials.length], {
      x: cx,
      y: PAVE_TOP + 0.012 + rand(0, 0.015),
      z: cz,
      ry: rand(0, Math.PI * 2),
    });
    flagIndex++;
  }

  staticRoot.add(root);
}

buildBase();

function makeWaterNormalTexture() {
  const size = 256;
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  const image = ctx.createImageData(size, size);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = (x / size) * Math.PI * 2;
      const v = (y / size) * Math.PI * 2;
      const height =
        Math.sin(u * 3.0 + Math.sin(v * 2.0) * 1.7) * 0.65 +
        Math.sin(v * 5.0 - u * 1.2) * 0.35 +
        Math.cos((u + v) * 7.0) * 0.12;
      const hx = Math.cos(u * 3.0 + Math.sin(v * 2.0) * 1.7) * 3.0 * 0.65 +
        Math.cos((u + v) * 7.0) * 7.0 * 0.12;
      const hy = Math.cos(v * 5.0 - u * 1.2) * 5.0 * 0.35 -
        Math.sin((u + v) * 7.0) * 7.0 * 0.12;
      const nx = -hx * 0.055;
      const ny = -hy * 0.055;
      const nz = 1.0;
      const len = Math.hypot(nx, ny, nz);
      const i = (y * size + x) * 4;
      image.data[i] = Math.round((nx / len * 0.5 + 0.5) * 255);
      image.data[i + 1] = Math.round((ny / len * 0.5 + 0.5) * 255);
      image.data[i + 2] = Math.round((nz / len * 0.5 + 0.5) * 255);
      image.data[i + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3.2, 3.2);
  tex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  tex.needsUpdate = true;
  return tex;
}

const waterNormalTexture = makeWaterNormalTexture();
let waterMesh = null;
let waterReflector = null;

function buildPond() {
  const root = new THREE.Group();
  root.name = 'pond';

  // Pond floor, a little below the water.
  const floorGeo = new THREE.ShapeGeometry(shapeFromPond());
  floorGeo.rotateX(-Math.PI / 2);
  const floorMat = lit(0x40695f, { receiveShadow: false, castShadow: false });
  addMesh(root, floorGeo, floorMat, { y: 0.045 });

  // Underwater stones and a soft sandy patch.
  for (let i = 0; i < 22; i++) {
    let x;
    let z;
    let tries = 0;
    do {
      x = rand(-6.3, 6.6);
      z = rand(-4.0, 4.5);
      tries++;
    } while (!pointInPond(x, z, 0.7) && tries < 60);
    if (tries >= 60) continue;
    const s = rand(0.12, 0.36);
    addMesh(root, new THREE.DodecahedronGeometry(s, 0), MAT.rockDark, {
      x, y: 0.06, z,
      rx: rand(0, 1), ry: rand(0, 3), rz: rand(0, 1),
      sx: rand(1, 2.2), sy: rand(0.24, 0.55), sz: rand(0.8, 1.6),
    });
  }

  // Water surface. A physical material gives real light response; the cube
  // environment map is captured after the garden is built so the wall, roof
  // and lotus can be softly reflected in the surface.
  const waterGeometry = new THREE.ShapeGeometry(shapeFromPond(), 24);
  waterGeometry.rotateX(-Math.PI / 2);
  const waterMaterial = new THREE.MeshPhysicalMaterial({
    color: 0x789b8f,
    roughness: 0.18,
    metalness: 0.05,
    reflectivity: 0.62,
    ior: 1.33,
    clearcoat: 0.5,
    clearcoatRoughness: 0.15,
    transparent: true,
    opacity: 0.36,
    envMapIntensity: 0.35,
    normalMap: waterNormalTexture,
    normalScale: new THREE.Vector2(0.22, 0.22),
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  waterMesh = addMesh(root, waterGeometry, waterMaterial, { y: WATER_Y });
  waterMesh.renderOrder = 2;
  waterMesh.userData.noMerge = true;

  // A planar reflection layer under the physical surface. The surface above
  // supplies the green glass tint and roughness; this layer supplies the soft,
  // recognisable reflection of the white wall and lotus.
  const reflectionGeometry = new THREE.ShapeGeometry(shapeFromPond(), 24);
  waterReflector = new Reflector(reflectionGeometry, {
    textureWidth: 512,
    textureHeight: 512,
    clipBias: 0.003,
    color: 0x8da99f,
    transparent: true,
    opacity: 0.46,
    multisample: 0,
  });
  waterReflector.rotation.x = -Math.PI / 2;
  // Keep the reflective layer below the goldfish so the small fish remain
  // visible in the transparent water instead of being hidden by the mirror.
  waterReflector.position.y = WATER_Y - 0.19;
  waterReflector.renderOrder = 1;
  waterReflector.userData.noMerge = true;
  root.add(waterReflector);

  const hostBeforeRender = waterReflector.onBeforeRender;
  let reflectionTick = 0;
  const lastReflectionCameraPos = new THREE.Vector3(1e9, 1e9, 1e9);
  const lastReflectionCameraQuat = new THREE.Quaternion();
  waterReflector.onBeforeRender = function (renderer, scene, camera) {
    reflectionTick++;
    const moved = camera.position.distanceToSquared(lastReflectionCameraPos) > 1e-5
      || camera.quaternion.angleTo(lastReflectionCameraQuat) > 0.0004;
    if (!moved && reflectionTick > 3) return;
    lastReflectionCameraPos.copy(camera.position);
    lastReflectionCameraQuat.copy(camera.quaternion);

    const waterVisible = waterMesh.visible;
    const sheenVisible = sheen.visible;
    const ringVisibility = rippleRings.map((r) => r.visible);
    waterMesh.visible = false;
    sheen.visible = false;
    for (const ring of rippleRings) ring.visible = false;

    hostBeforeRender.call(this, renderer, scene, camera);

    waterMesh.visible = waterVisible;
    sheen.visible = sheenVisible;
    for (let i = 0; i < rippleRings.length; i++) rippleRings[i].visible = ringVisibility[i];
  };

  // Waterline sheen.
  const rimPoints = pondSamples.map((p) => V3(p.x, WATER_Y + 0.012, p.z));
  const rimCurve = new THREE.CatmullRomCurve3(rimPoints, true, 'catmullrom', 0.4);
  const sheen = addMesh(
    root,
    new THREE.TubeGeometry(rimCurve, 180, 0.028, 3, true),
    new THREE.MeshBasicMaterial({ color: 0xeaf7e7, transparent: true, opacity: 0.38, depthWrite: false }),
  );
  sheen.userData.noMerge = true;
  sheen.renderOrder = 3;

  // Pond contents stay outside the static merge pass so the physical water
  // surface, transparent sheen and ripple layers survive batching.
  scene.add(root);
  return waterMaterial;
}

const waterMaterial = buildPond();

// A soft grounding shadow under the diorama base.
const contactCanvas = document.createElement('canvas');
contactCanvas.width = 256;
contactCanvas.height = 256;
{
  const ctx = contactCanvas.getContext('2d');
  const g = ctx.createRadialGradient(128, 128, 26, 128, 128, 126);
  g.addColorStop(0, 'rgba(30, 45, 35, 0.38)');
  g.addColorStop(0.5, 'rgba(30, 45, 35, 0.2)');
  g.addColorStop(1, 'rgba(30, 45, 35, 0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
}
const contactTex = new THREE.CanvasTexture(contactCanvas);
contactTex.colorSpace = THREE.SRGBColorSpace;
const contact = addMesh(
  scene,
  new THREE.PlaneGeometry(42, 42),
  new THREE.MeshBasicMaterial({ map: contactTex, transparent: true, depthWrite: false, opacity: 0.9 }),
  { x: 0, y: -1.9, z: 0, rx: -Math.PI / 2 },
);
contact.renderOrder = -2;

// ---------------------------------------------------------------------------
// Chinese roof helpers
// ---------------------------------------------------------------------------

function makeRoofGeometry({
  radius = 3.3,
  height = 1.0,
  eaveLift = 0.34,
  segments = 8,
  rows = 8,
  cols = 4,
  topRadius = 0.09,
  cornerExtend = 0.04,
} = {}) {
  const positions = [];
  const uvs = [];
  const indices = [];

  for (let s = 0; s < segments; s++) {
    const a0 = (s / segments) * Math.PI * 2;
    const a1 = ((s + 1) / segments) * Math.PI * 2;
    const base = positions.length / 3;

    for (let r = 0; r <= rows; r++) {
      const t = r / rows;
      // Steep at the ridge, flattening toward the eave: a concave Chinese
      // roof profile rather than a domed umbrella.
      const y = height * Math.pow(1 - t, 1.48);
      const rad = topRadius + (radius - topRadius) * Math.pow(t, 0.9);
      for (let c = 0; c <= cols; c++) {
        const u = c / cols;
        const a = a0 + (a1 - a0) * u;
        const corner = Math.pow(Math.abs(Math.cos(Math.PI * u)), 5.0);
        const lift = eaveLift * Math.pow(t, 6.0) * corner;
        const ext = 1 + cornerExtend * Math.pow(t, 5.0) * corner;
        positions.push(Math.cos(a) * rad * ext, y + lift, Math.sin(a) * rad * ext);
        uvs.push((s + u) / segments, 1 - t);
      }
    }

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const i0 = base + r * (cols + 1) + c;
        const i1 = i0 + 1;
        const i2 = i0 + cols + 1;
        const i3 = i2 + 1;
        indices.push(i0, i1, i2, i1, i3, i2);
      }
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function eavePoint(angle, radius, eaveLift, segments) {
  const step = (Math.PI * 2) / segments;
  const a = ((angle % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
  const s = Math.floor(a / step);
  const u = (a - s * step) / step;
  const corner = Math.pow(Math.abs(Math.cos(Math.PI * u)), 5);
  return V3(
    Math.cos(a) * radius * (1 + 0.04 * corner),
    eaveLift * corner,
    Math.sin(a) * radius * (1 + 0.04 * corner)
  );
}

function addRoofRidges(group, { radius, height, eaveLift, segments, innerRadius = 0.09 }) {
  // Fascia around the entire eave.
  const eavePts = [];
  const total = segments * 18;
  for (let i = 0; i <= total; i++) {
    const a = (i / total) * Math.PI * 2;
    const p = eavePoint(a, radius, eaveLift, segments);
    eavePts.push(V3(p.x, p.y - 0.045, p.z));
  }
  addMesh(
    group,
    new THREE.TubeGeometry(new THREE.CatmullRomCurve3(eavePts, true, 'catmullrom', 0.3), total, 0.058, 5, true),
    MAT.roofDark
  );

  // Eight hips climbing to the apex, plus a sharp upturned eave tip at each
  // corner. These small silhouettes do a lot of the "Chinese roof" reading.
  for (let s = 0; s < segments; s++) {
    const a = (s / segments) * Math.PI * 2;
    const pts = [];
    for (let r = 0; r <= 8; r++) {
      const t = r / 8;
      const y = height * Math.pow(1 - t, 1.48) + eaveLift * Math.pow(t, 6) + 0.04;
      const rad = innerRadius + (radius - innerRadius) * Math.pow(t, 0.9);
      pts.push(V3(Math.cos(a) * (rad + 0.015), y, Math.sin(a) * (rad + 0.015)));
    }
    addMesh(
      group,
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 14, 0.047, 5, false),
      MAT.roofDark
    );

    const hornPts = [
      V3(Math.cos(a) * radius * 0.94, eaveLift * 0.86 + 0.02, Math.sin(a) * radius * 0.94),
      V3(Math.cos(a) * (radius + 0.1), eaveLift + 0.09, Math.sin(a) * (radius + 0.1)),
      V3(Math.cos(a) * (radius + 0.19), eaveLift + 0.25, Math.sin(a) * (radius + 0.19)),
      V3(Math.cos(a) * (radius + 0.22), eaveLift + 0.42, Math.sin(a) * (radius + 0.22)),
    ];
    addMesh(
      group,
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(hornPts), 10, 0.045, 5, false),
      MAT.roofDark
    );
    addMesh(group, new THREE.SphereGeometry(0.065, 7, 5), MAT.gold, {
      x: Math.cos(a) * (radius + 0.22),
      y: eaveLift + 0.46,
      z: Math.sin(a) * (radius + 0.22),
    });
  }
}

function addLongRoof(parent, width, depth, rise, { y = 0, z = 0, material = MAT.roof } = {}) {
  const group = new THREE.Group();
  group.position.set(0, y, z);
  parent.add(group);

  const half = depth / 2;
  const angle = Math.atan2(rise, half);
  const slopeLength = Math.hypot(half, rise);

  for (const side of [-1, 1]) {
    const panel = addBox(
      group,
      width,
      0.09,
      slopeLength,
      material,
      0,
      -rise / 2 + 0.02,
      (side * half) / 2,
      side * angle,
      0,
      0
    );
    panel.castShadow = true;

    // Physical tile courses. They read as crisp toon lines even at a distance.
    for (let row = 1; row <= 7; row++) {
      const t = row / 8;
      addBox(
        group,
        width - 0.04,
        0.028,
        0.028,
        MAT.roofLine,
        0,
        -rise * t + 0.042,
        side * half * t
      );
    }
  }

  addBox(group, width + 0.1, 0.14, 0.25, MAT.roofDark, 0, 0.045, 0);
  addBox(group, width + 0.12, 0.14, 0.16, MAT.roofDark, 0, -rise - 0.015, half - 0.02);
  addBox(group, width + 0.12, 0.14, 0.16, MAT.roofDark, 0, -rise - 0.015, -half + 0.02);

  // Upward ridge-end scrolls.
  for (const sx of [-1, 1]) {
    addMesh(group, new THREE.SphereGeometry(0.085, 7, 5), MAT.roofDark, {
      x: sx * (width / 2 + 0.03),
      y: 0.12,
      z: 0,
    });
    addMesh(group, new THREE.ConeGeometry(0.055, 0.24, 5), MAT.roofDark, {
      x: sx * (width / 2 + 0.1),
      y: 0.23,
      z: 0,
      rz: -sx * 0.62,
    });
  }

  return group;
}

// ---------------------------------------------------------------------------
// The covered zig-zag walk along the left bank
// ---------------------------------------------------------------------------

function makeSegmentedBeam(parent, x1, z1, x2, z2, y, thickness, depth, material) {
  const dx = x2 - x1;
  const dz = z2 - z1;
  const len = Math.hypot(dx, dz);
  const midX = (x1 + x2) / 2;
  const midZ = (z1 + z2) / 2;
  const angle = Math.atan2(dx, dz);
  return addBox(parent, thickness, depth, len, material, midX, y, midZ, 0, angle, 0);
}

function buildCorridorSegment(parent, x1, z1, x2, z2, index) {
  const dx = x2 - x1;
  const dz = z2 - z1;
  const len = Math.hypot(dx, dz);
  const group = new THREE.Group();
  group.position.set((x1 + x2) / 2, 0, (z1 + z2) / 2);
  group.rotation.y = -Math.atan2(dz, dx);
  parent.add(group);

  // Stone piles under the timber deck.
  for (const lx of [-len * 0.34, 0, len * 0.34]) {
    addBox(group, 0.62, 0.52, 1.86, MAT.slabDark, lx, 0.56, 0);
    addBox(group, 0.74, 0.1, 2.0, MAT.slab, lx, 0.85, 0);
  }

  // Deck.
  addBox(group, len + 0.35, 0.16, 2.12, MAT.wood, 0, 0.94, 0);
  addBox(group, len + 0.5, 0.08, 2.28, MAT.woodDark, 0, 0.85, 0);

  // Columns and their stone feet.
  const columnXs = [-len / 2 + 0.28, 0, len / 2 - 0.28];
  for (const lx of columnXs) {
    for (const sz of [-1, 1]) {
      addCylinder(group, 0.16, 0.18, 0.14, 8, MAT.slab, lx, 1.06, sz * 0.91);
      addCylinder(group, 0.105, 0.12, 2.58, 8, MAT.wood, lx, 2.38, sz * 0.91);
    }
  }

  // Top beams.
  for (const sz of [-1, 1]) {
    addBox(group, len + 0.15, 0.16, 0.15, MAT.woodDark, 0, 3.62, sz * 0.91);
    addBox(group, len + 0.08, 0.1, 0.13, MAT.wood, 0, 3.46, sz * 0.91);
  }

  // Railings with fine balusters.
  for (const sz of [-1, 1]) {
    addBox(group, len + 0.08, 0.09, 0.09, MAT.woodDark, 0, 1.58, sz * 1.01);
    addBox(group, len + 0.08, 0.045, 0.06, MAT.wood, 0, 1.12, sz * 1.01);
    const count = Math.max(4, Math.round(len / 0.52));
    for (let i = 0; i <= count; i++) {
      const lx = -len / 2 + (i / count) * len;
      addBox(group, 0.045, 0.54, 0.045, MAT.woodDark, lx, 1.34, sz * 1.01);
    }
  }

  // Hanging lattice frieze under the eaves.
  for (const sz of [-1, 1]) {
    addBox(group, len + 0.05, 0.055, 0.06, MAT.woodDark, 0, 3.38, sz * 0.99);
    addBox(group, len + 0.05, 0.055, 0.06, MAT.woodDark, 0, 2.95, sz * 0.99);
    const count = Math.max(5, Math.round(len / 0.46));
    for (let i = 0; i <= count; i++) {
      const lx = -len / 2 + (i / count) * len;
      addBox(group, 0.035, 0.48, 0.035, MAT.woodDark, lx, 3.16, sz * 0.99);
    }
  }

  // Curved eave roof.
  addLongRoof(group, len + 0.8, 2.55, 0.52, { y: 4.33, z: 0 });

  // A hair of moss at the stone feet.
  for (const lx of [-len * 0.34, 0, len * 0.34]) {
    addMesh(group, new THREE.SphereGeometry(0.24, 6, 4), MAT.moss, {
      x: lx + rand(-0.2, 0.2),
      y: 0.93,
      z: rand(-0.8, 0.8),
      sx: rand(0.8, 1.4),
      sy: 0.3,
      sz: rand(0.7, 1.2),
    });
  }

  group.userData.index = index;
}

function buildCorridor() {
  const root = new THREE.Group();
  root.name = 'covered-walk';
  staticRoot.add(root);
  // A continuous covered walk starts at the lower-left and folds around the
  // garden to the octagonal pavilion at the upper-right.
  const points = [
    V2(-8.8, 9.7),
    V2(-9.5, 6.0),
    V2(-8.5, 2.4),
    V2(-9.3, -1.5),
    V2(-8.7, -5.2),
    V2(-8.7, -7.0),
    V2(4.9, -7.0),
  ];
  for (let i = 0; i < points.length - 1; i++) {
    buildCorridorSegment(root, points[i].x, points[i].y, points[i + 1].x, points[i + 1].y, i);
  }

  // Entry steps at the near end.
  const entry = new THREE.Group();
  entry.position.set(-8.8, 0, 10.15);
  root.add(entry);
  addBox(entry, 2.3, 0.24, 0.8, MAT.slab, 0, 0.18, 0.2);
  addBox(entry, 2.1, 0.24, 0.7, MAT.slab, 0, 0.41, -0.28);
  addBox(entry, 1.9, 0.24, 0.62, MAT.slab, 0, 0.63, -0.74);
}

buildCorridor();

// ---------------------------------------------------------------------------
// White wall, dark tiled coping and a moon gate
// ---------------------------------------------------------------------------

function makeTextTexture(text, { width = 512, height = 256, bg = '#304a40', fg = '#e7ca84' } = {}) {
  const c = document.createElement('canvas');
  c.width = width;
  c.height = height;
  const ctx = c.getContext('2d');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);
  const grad = ctx.createLinearGradient(0, 0, width, height);
  grad.addColorStop(0, 'rgba(255,255,255,0.09)');
  grad.addColorStop(0.55, 'rgba(255,255,255,0)');
  grad.addColorStop(1, 'rgba(0,0,0,0.16)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = 'rgba(221, 193, 128, 0.38)';
  ctx.lineWidth = Math.max(2, width * 0.012);
  ctx.strokeRect(width * 0.055, height * 0.11, width * 0.89, height * 0.78);
  ctx.fillStyle = fg;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `600 ${Math.round(height * 0.47)}px "STKaiti", "KaiTi", "FangSong", "Songti SC", serif`;
  ctx.fillText(text, width / 2, height / 2 + height * 0.015);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  return tex;
}

const plaqueTexture = makeTextTexture('荷風清夏');
const plaqueMaterial = lit(0xffffff, { map: plaqueTexture });

// ---------------------------------------------------------------------------
// Enclosing courtyard walls with real moon gates and leak windows
// ---------------------------------------------------------------------------

function makeHolePath(spec) {
  const p = new THREE.Path();
  if (spec.type === 'moon') {
    p.absarc(spec.x, spec.y, spec.r, 0, Math.PI * 2, true);
    return p;
  }
  if (spec.type === 'hex') {
    const rx = spec.w * 0.5;
    const ry = spec.h * 0.5;
    for (let i = 0; i <= 6; i++) {
      const a = Math.PI / 2 - (i / 6) * Math.PI * 2;
      const x = spec.x + Math.cos(a) * rx;
      const y = spec.y + Math.sin(a) * ry;
      if (i === 0) p.moveTo(x, y);
      else p.lineTo(x, y);
    }
    p.closePath();
    return p;
  }
  if (spec.type === 'fan') {
    const apexY = spec.y - spec.h * 0.44;
    const rx = spec.w * 0.5;
    const ry = spec.h * 0.94;
    p.moveTo(spec.x, apexY);
    for (let i = 0; i <= 20; i++) {
      const a = THREE.MathUtils.degToRad(160 - (i / 20) * 140);
      p.lineTo(spec.x + Math.cos(a) * rx, apexY + Math.sin(a) * ry);
    }
    p.closePath();
    return p;
  }
  if (spec.type === 'begonia') {
    const steps = 56;
    for (let i = 0; i <= steps; i++) {
      const a = -(i / steps) * Math.PI * 2;
      const lobe = 1 + 0.24 * Math.cos(a * 4);
      const x = spec.x + Math.cos(a) * spec.w * 0.5 * lobe;
      const y = spec.y + Math.sin(a) * spec.h * 0.5 * lobe;
      if (i === 0) p.moveTo(x, y);
      else p.lineTo(x, y);
    }
    p.closePath();
    return p;
  }
  return p;
}

function addBar(parent, x1, y1, x2, y2, z, thickness = 0.045, material = MAT.lattice) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy);
  const angle = Math.atan2(dy, dx);
  return addBox(parent, len, thickness, 0.055, material, (x1 + x2) / 2, (y1 + y2) / 2, z, 0, 0, angle);
}

function addWindowFrame(parent, spec, z) {
  const path = makeHolePath(spec);
  const count = spec.type === 'hex' ? 18 : spec.type === 'fan' ? 24 : 36;
  const points = path.getPoints(count);
  for (let i = 0; i < points.length - 1; i++) {
    addBar(
      parent,
      points[i].x,
      points[i].y,
      points[i + 1].x,
      points[i + 1].y,
      z,
      0.075,
      MAT.lattice
    );
  }
}

function addWindowLattice(parent, spec) {
  const z = 0;
  if (spec.type === 'hex') {
    for (const t of [-0.22, 0.22]) {
      addBar(parent, spec.x - spec.w * 0.42, spec.y + spec.h * t, spec.x + spec.w * 0.42, spec.y + spec.h * t, z);
    }
    addBar(parent, spec.x, spec.y - spec.h * 0.38, spec.x, spec.y + spec.h * 0.38, z);
  } else if (spec.type === 'fan') {
    const apexY = spec.y - spec.h * 0.44;
    const rx = spec.w * 0.46;
    const ry = spec.h * 0.82;
    for (const angle of [128, 90, 52]) {
      const a = THREE.MathUtils.degToRad(angle);
      addBar(
        parent,
        spec.x,
        apexY,
        spec.x + Math.cos(a) * rx,
        apexY + Math.sin(a) * ry + spec.h * 0.05,
        z,
        0.04
      );
    }
    addBar(parent, spec.x - spec.w * 0.36, apexY + spec.h * 0.2, spec.x + spec.w * 0.36, apexY + spec.h * 0.2, z, 0.04);
  } else if (spec.type === 'begonia') {
    addBar(parent, spec.x, spec.y - spec.h * 0.38, spec.x, spec.y + spec.h * 0.38, z);
    addBar(parent, spec.x - spec.w * 0.38, spec.y, spec.x + spec.w * 0.38, spec.y, z);
    addBar(parent, spec.x - spec.w * 0.22, spec.y - spec.h * 0.22, spec.x + spec.w * 0.22, spec.y + spec.h * 0.22, z, 0.035);
    addBar(parent, spec.x - spec.w * 0.22, spec.y + spec.h * 0.22, spec.x + spec.w * 0.22, spec.y - spec.h * 0.22, z, 0.035);
  }
}

function buildWallPanel({
  name,
  length,
  height,
  x,
  z,
  rotationY,
  holes,
  plaque = false,
  thickness = 0.55,
}) {
  const root = new THREE.Group();
  root.name = name;
  root.position.set(x, 0, z);
  root.rotation.y = rotationY;
  staticRoot.add(root);

  const shape = new THREE.Shape();
  shape.moveTo(-length / 2, 0.28);
  shape.lineTo(length / 2, 0.28);
  shape.lineTo(length / 2, height);
  shape.lineTo(-length / 2, height);
  shape.closePath();

  for (const spec of holes) {
    shape.holes.push(makeHolePath(spec));
  }

  const wallGeo = new THREE.ExtrudeGeometry(shape, {
    depth: thickness,
    bevelEnabled: false,
    curveSegments: 32,
  });
  wallGeo.translate(0, 0, -thickness / 2);
  addMesh(root, wallGeo, MAT.plaster);

  // Stone foot, top trim and a tiled coping.
  addBox(root, length, 0.34, thickness + 0.24, MAT.slabDark, 0, 0.34, 0);
  addBox(root, length + 0.06, 0.12, thickness + 0.26, MAT.baseTrim, 0, height - 0.02, 0);
  addBox(root, length, 0.08, thickness + 0.22, MAT.slab, 0, height + 0.09, 0);
  addLongRoof(root, length + 0.42, 1.55, 0.55, { y: height + 0.82, z: 0 });

  // Squared posts close the joints where walls meet.
  for (const sx of [-1, 1]) {
    addBox(root, 0.38, height - 0.28, 0.8, MAT.slabDark, sx * (length / 2 - 0.15), height / 2 + 0.2, 0);
    addBox(root, 0.5, 0.12, 0.92, MAT.baseTrim, sx * (length / 2 - 0.15), height + 0.16, 0);
  }

  for (const spec of holes) {
    const frontZ = thickness / 2 + 0.028;
    const backZ = -thickness / 2 - 0.028;

    if (spec.type === 'moon') {
      addMesh(root, new THREE.TorusGeometry(spec.r + 0.045, 0.075, 7, 56), MAT.slabDark, {
        x: spec.x, y: spec.y, z: frontZ,
      });
      addMesh(root, new THREE.TorusGeometry(spec.r + 0.045, 0.075, 7, 56), MAT.slabDark, {
        x: spec.x, y: spec.y, z: backZ,
      });
      addMesh(root, new THREE.TorusGeometry(spec.r + 0.14, 0.03, 5, 56), MAT.gold, {
        x: spec.x, y: spec.y, z: frontZ - 0.012,
      });
      addBox(root, spec.r * 1.62, 0.11, thickness + 0.16, MAT.slabDark, spec.x, 0.42, 0);
      addBox(root, spec.r * 1.42, 0.08, thickness + 0.1, MAT.slab, spec.x, 0.5, 0);
    } else {
      addWindowFrame(root, spec, frontZ);
      addWindowFrame(root, spec, backZ);
      addWindowLattice(root, spec);
      addBox(root, spec.w * 0.85, 0.1, thickness + 0.12, MAT.slabDark, spec.x, spec.y - spec.h * 0.5 - 0.04, 0);
    }
  }

  if (plaque) {
    for (const side of [-1, 1]) {
      const plaqueGroup = new THREE.Group();
      plaqueGroup.position.set(0, 4.08, side * (thickness / 2 + 0.055));
      if (side < 0) plaqueGroup.rotation.y = Math.PI;
      root.add(plaqueGroup);
      addBox(plaqueGroup, 1.9, 0.72, 0.07, MAT.woodDark, 0, 0, 0);
      addMesh(plaqueGroup, new THREE.PlaneGeometry(1.68, 0.54), plaqueMaterial, { z: 0.045 });
    }
  }

  return root;
}

function buildWallCorner(x, z, flip = 1) {
  const root = new THREE.Group();
  root.name = 'wall-corner-pier';
  root.position.set(x, 0, z);
  staticRoot.add(root);

  // A white corner pier closes the joint and lets the rear coping run into
  // both side walls as one continuous U.
  addBox(root, 1.5, 4.7, 1.5, MAT.plaster, 0, 2.58, 0);
  addBox(root, 1.8, 0.34, 1.8, MAT.slabDark, 0, 0.34, 0);
  addBox(root, 1.62, 0.12, 1.62, MAT.baseTrim, 0, 4.66, 0);
  addBox(root, 1.9, 0.1, 1.9, MAT.slab, 0, 4.77, 0);

  // A broad hipped tile cap bridges the two wall roofs at the turn and hides
  // the triangular roof intersection underneath.
  addBox(root, 3.0, 0.14, 3.0, MAT.roof, 0, 4.64, 0);
  const eave = addBox(root, 3.2, 0.12, 3.2, MAT.roofDark, 0, 4.82, 0);
  eave.castShadow = true;
  const cap = addMesh(root, new THREE.ConeGeometry(2.3, 0.96, 4, 1), MAT.roof, {
    y: 5.12,
    ry: Math.PI / 4,
  });
  cap.castShadow = true;
  cap.receiveShadow = true;
  addCylinder(root, 0.055, 0.075, 0.26, 6, MAT.roofDark, 0, 5.7, 0);
  addMesh(root, new THREE.SphereGeometry(0.09, 8, 6), MAT.gold, { y: 5.86 });

  // A subtle wooden corner brace visually ties the two wall faces together.
  for (const sx of [-1, 1]) {
    addBox(root, 0.1, 0.16, 1.1, MAT.woodDark, sx * 0.64, 4.55, 0, 0, 0, flip * 0.22);
  }
}

function buildWalls() {
  buildWallPanel({
    name: 'rear-wall',
    length: 26.0,
    height: 4.7,
    x: 0,
    z: -11.38,
    rotationY: 0,
    plaque: true,
    holes: [
      { type: 'moon', x: -2.05, y: 2.18, r: 1.52 },
      { type: 'hex', x: 4.8, y: 2.58, w: 1.35, h: 1.5 },
      { type: 'fan', x: -7.1, y: 2.55, w: 1.25, h: 1.4 },
    ],
  });

  buildWallPanel({
    name: 'left-wall',
    length: 24.35,
    height: 4.35,
    x: -12.88,
    z: 0.6,
    rotationY: Math.PI / 2,
    holes: [
      { type: 'moon', x: -3.2, y: 2.08, r: 1.3 },
      { type: 'fan', x: 4.9, y: 2.55, w: 1.25, h: 1.5 },
    ],
  });

  buildWallPanel({
    name: 'right-wall',
    length: 24.35,
    height: 4.35,
    x: 12.88,
    z: 0.6,
    rotationY: -Math.PI / 2,
    holes: [
      { type: 'moon', x: 5.1, y: 2.06, r: 1.32 },
      { type: 'begonia', x: -5.3, y: 2.52, w: 1.42, h: 1.55 },
    ],
  });

  // The front is intentionally open, leaving a U-shaped three-wall garden.
  // The two back corners are capped so the three wall panels read as one
  // continuous U-shaped enclosure under a single tile language.
  buildWallCorner(-12.88, -11.38, 1);
  buildWallCorner(12.88, -11.38, -1);

  // A bench against the rear wall, under the tiled coping.
  addBox(staticRoot, 2.65, 0.18, 0.65, MAT.slab, 4.7, 0.74, -10.05);
  for (const sx of [-1, 1]) {
    addBox(staticRoot, 0.3, 0.42, 0.55, MAT.slabDark, 4.7 + sx * 1.05, 0.51, -10.05);
  }
}

buildWalls();

// ---------------------------------------------------------------------------
// Octagonal pavilion
// ---------------------------------------------------------------------------

function buildPavilion() {
  const root = new THREE.Group();
  root.name = 'octagonal-pavilion';
  root.position.set(8.48, PAVE_TOP, -7.0);
  root.rotation.y = -Math.PI / 2;
  staticRoot.add(root);

  const R = 2.58;
  const columns = [];
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2 + Math.PI / 8;
    columns.push({ angle, x: Math.cos(angle) * R, z: Math.sin(angle) * R });
  }

  // Stone platform and wooden floor.
  addCylinder(root, 3.12, 3.3, 0.58, 8, MAT.slab, 0, 0.29, 0);
  addCylinder(root, 2.86, 2.86, 0.13, 8, MAT.woodDark, 0, 0.64, 0);
  addCylinder(root, 2.55, 2.55, 0.07, 8, MAT.wood, 0, 0.73, 0);

  // Triple steps at the front.
  for (let i = 0; i < 3; i++) {
    const depth = 2.2;
    addBox(root, 1.95, 0.17, 0.52, MAT.slab, 0, 0.12 + i * 0.17, 3.24 + (2 - i) * 0.35);
  }

  // Columns with lotus-bud stone feet.
  for (const c of columns) {
    addCylinder(root, 0.19, 0.24, 0.18, 8, MAT.slab, c.x, 0.87, c.z);
    addCylinder(root, 0.12, 0.145, 2.7, 8, MAT.wood, c.x, 2.3, c.z);
    addCylinder(root, 0.18, 0.2, 0.15, 8, MAT.woodDark, c.x, 3.66, c.z);
  }

  // Beams and openwork friezes between the columns.
  for (let i = 0; i < 8; i++) {
    const a = columns[i];
    const b = columns[(i + 1) % 8];
    makeSegmentedBeam(root, a.x, a.z, b.x, b.z, 3.61, 0.17, 0.2, MAT.woodDark);
    makeSegmentedBeam(root, a.x, a.z, b.x, b.z, 3.29, 0.07, 0.08, MAT.jade);

    const mx = (a.x + b.x) / 2;
    const mz = (a.z + b.z) / 2;
    const angle = Math.atan2(a.x - b.x, a.z - b.z);
    const tangentX = (b.x - a.x) / Math.hypot(b.x - a.x, b.z - a.z);
    const tangentZ = (b.z - a.z) / Math.hypot(b.x - a.x, b.z - a.z);
    for (let k = -2; k <= 2; k++) {
      if (k === 0) continue;
      addBox(root, 0.035, 0.4, 0.035, MAT.woodDark, mx + tangentX * k * 0.28, 3.42, mz + tangentZ * k * 0.28, 0, angle, 0);
    }
  }

  // Railing; leave the central front bay open.
  for (let i = 0; i < 8; i++) {
    const a = columns[i];
    const b = columns[(i + 1) % 8];
    const midAngle = (a.angle + b.angle) / 2;
    const front = Math.abs(Math.atan2(Math.sin(midAngle - Math.PI / 2), Math.cos(midAngle - Math.PI / 2)));
    if (front < 0.5) continue;
    const mx = (a.x + b.x) / 2;
    const mz = (a.z + b.z) / 2;
    const len = Math.hypot(b.x - a.x, b.z - a.z);
    const angle = Math.atan2(a.x - b.x, a.z - b.z);
    addBox(root, 0.09, 0.11, len - 0.24, MAT.woodDark, mx, 1.62, mz, 0, angle, 0);
    addBox(root, 0.06, 0.05, len - 0.3, MAT.jade, mx, 1.25, mz, 0, angle, 0);
    const n = 3;
    for (let k = 1; k <= n; k++) {
      const t = k / (n + 1) - 0.5;
      addBox(root, 0.04, 0.43, 0.04, MAT.woodDark, mx + (b.x - a.x) * t, 1.45, mz + (b.z - a.z) * t, 0, angle, 0);
    }
  }

  // A low stone table and drum stools.
  addCylinder(root, 0.72, 0.78, 0.15, 12, MAT.slab, 0, 1.16, 0);
  addCylinder(root, 0.2, 0.3, 0.55, 10, MAT.slabDark, 0, 0.88, 0);
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    addCylinder(root, 0.28, 0.31, 0.42, 10, MAT.slab, Math.cos(a) * 1.32, 0.94, Math.sin(a) * 1.32);
    addCylinder(root, 0.31, 0.31, 0.06, 10, MAT.woodDark, Math.cos(a) * 1.32, 1.16, Math.sin(a) * 1.32);
  }

  // Roof structure.
  const lowerRoof = new THREE.Group();
  lowerRoof.position.y = 3.82;
  root.add(lowerRoof);
  addMesh(lowerRoof, makeRoofGeometry({
    radius: 3.46,
    height: 1.34,
    eaveLift: 0.31,
    segments: 8,
    rows: 12,
    cols: 5,
    topRadius: 0.065,
  }), MAT.roof);
  addRoofRidges(lowerRoof, {
    radius: 3.46,
    height: 1.34,
    eaveLift: 0.31,
    segments: 8,
    innerRadius: 0.065,
  });

  // Pale rafters and a dark inner ceiling.
  addCylinder(lowerRoof, 2.65, 2.8, 0.12, 8, MAT.woodDark, 0, -0.05, 0);
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
    const x = Math.cos(a) * 1.55;
    const z = Math.sin(a) * 1.55;
    addBox(lowerRoof, 0.09, 0.12, 2.7, MAT.wood, x, -0.14, z, 0, -a + Math.PI / 2, 0);
  }

  // Finial on the single, generous octagonal roof.
  addCylinder(root, 0.1, 0.2, 0.24, 8, MAT.gold, 0, 5.33, 0);
  addMesh(root, new THREE.SphereGeometry(0.19, 10, 7), MAT.gold, { y: 5.53 });
  addCylinder(root, 0.02, 0.055, 0.62, 6, MAT.gold, 0, 5.88, 0);
  addMesh(root, new THREE.SphereGeometry(0.07, 8, 6), MAT.gold, { y: 6.23 });

  // A small hanging bell under the upper eave.
  addTube(root, [V3(0, 4.35, 0), V3(0.05, 3.94, 0), V3(0.02, 3.7, 0)], 0.014, MAT.metalDark, 6, 4);
  addMesh(root, new THREE.ConeGeometry(0.12, 0.22, 8), MAT.gold, { x: 0.02, y: 3.57, z: 0 });

  // Plaque facing the pond / camera.
  const plaque = new THREE.Group();
  plaque.position.set(0, 3.18, 2.42);
  root.add(plaque);
  addBox(plaque, 1.32, 0.48, 0.08, MAT.woodDark, 0, 0, 0);
  addMesh(plaque, new THREE.PlaneGeometry(1.15, 0.34), plaqueMaterial, { z: 0.052 });

  // A small paper lantern warms the shaded interior.
  addTube(root, [V3(0, 3.78, 0), V3(0, 3.43, 0), V3(0, 3.18, 0)], 0.012, MAT.metalDark, 4, 4);
  addCylinder(root, 0.2, 0.24, 0.38, 10, MAT.paperLantern, 0, 2.96, 0);
  addCylinder(root, 0.24, 0.25, 0.06, 10, MAT.woodDark, 0, 3.17, 0);
  addCylinder(root, 0.25, 0.23, 0.06, 10, MAT.woodDark, 0, 2.75, 0);
  addCylinder(root, 0.025, 0.035, 0.2, 5, MAT.gold, 0, 2.64, 0);
  const pavilionLight = new THREE.PointLight(0xffca7d, 16, 7.5, 2);
  pavilionLight.position.set(0, 2.95, 0);
  pavilionLight.castShadow = false;
  root.add(pavilionLight);

  // Moss at the foot of the platform.
  for (let i = 0; i < 8; i++) {
    const a = rand(0, Math.PI * 2);
    addMesh(root, new THREE.SphereGeometry(rand(0.18, 0.34), 6, 4), i % 2 ? MAT.moss : MAT.mossDark, {
      x: Math.cos(a) * rand(2.8, 3.25),
      y: 0.34,
      z: Math.sin(a) * rand(2.8, 3.25),
      sx: rand(0.8, 1.5),
      sy: 0.26,
      sz: rand(0.8, 1.5),
    });
  }
}

buildPavilion();

// ---------------------------------------------------------------------------
// Stone arch bridge and its little tree island
// ---------------------------------------------------------------------------

const ISLAND = V2(-2.4, 4.8);

function buildIsland() {
  const root = new THREE.Group();
  root.name = 'willow-islet';
  root.position.set(ISLAND.x, 0, ISLAND.y);
  staticRoot.add(root);

  addCylinder(root, 1.18, 1.38, 0.3, 9, MAT.rock, 0, 0.44, 0);
  addCylinder(root, 1.02, 1.08, 0.09, 12, MAT.moss, 0, 0.61, 0);

  for (let i = 0; i < 13; i++) {
    const a = (i / 13) * Math.PI * 2 + rand(-0.12, 0.12);
    addMesh(root, new THREE.DodecahedronGeometry(rand(0.18, 0.38), 0), MAT.rock, {
      x: Math.cos(a) * rand(0.9, 1.25),
      y: rand(0.35, 0.55),
      z: Math.sin(a) * rand(0.9, 1.25),
      rx: rand(0, 2),
      ry: rand(0, 3),
      rz: rand(0, 2),
      sx: rand(1, 1.6),
      sy: rand(0.6, 1.1),
      sz: rand(0.8, 1.4),
    });
  }

  // A reachable little landing for the bridge.
  addBox(root, 0.88, 0.13, 1.3, MAT.slab, -0.92, 0.63, 0);

  // Mossy planting pockets.
  for (let i = 0; i < 7; i++) {
    const a = rand(0, Math.PI * 2);
    addMesh(root, new THREE.SphereGeometry(rand(0.15, 0.28), 6, 4), i % 2 ? MAT.moss : MAT.mossDark, {
      x: Math.cos(a) * rand(0.45, 0.88),
      y: 0.65,
      z: Math.sin(a) * rand(0.45, 0.88),
      sx: rand(0.8, 1.4),
      sy: 0.24,
      sz: rand(0.8, 1.4),
    });
  }
}

buildIsland();

function buildBridge() {
  const root = new THREE.Group();
  root.name = 'stone-arch-bridge';
  root.position.set(-5.2, 0, 4.8);
  staticRoot.add(root);

  const length = 3.4;
  const width = 1.62;
  const arch = 0.62;
  const endHeight = 0.55;
  const segments = 18;

  const pos = [];
  const uv = [];
  const idx = [];
  const topAt = (t) => endHeight + Math.sin(Math.PI * t) * arch;

  // Top walking surface.
  const baseTop = 0;
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const x = -length / 2 + t * length;
    const y = topAt(t);
    pos.push(x, y, -width / 2, x, y, width / 2);
    uv.push(t * 2, 0, t * 2, 1);
  }
  for (let i = 0; i < segments; i++) {
    const a = baseTop + i * 2;
    idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
  }

  // Bottom surface, tucked beneath the arch.
  const baseBottom = pos.length / 3;
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const x = -length / 2 + t * length;
    const y = topAt(t) - 0.25;
    pos.push(x, y, -width / 2, x, y, width / 2);
    uv.push(t * 2, 0, t * 2, 1);
  }
  for (let i = 0; i < segments; i++) {
    const a = baseBottom + i * 2;
    idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
  }

  // Side fascia.
  const baseSide = pos.length / 3;
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const x = -length / 2 + t * length;
    const y = topAt(t);
    pos.push(x, y, -width / 2, x, y, width / 2, x, y - 0.25, -width / 2, x, y - 0.25, width / 2);
    uv.push(t * 2, 0, t * 2, 1, t * 2, 0, t * 2, 1);
  }
  for (let i = 0; i < segments; i++) {
    const a = baseSide + i * 4;
    idx.push(a, a + 2, a + 1, a + 2, a + 3, a + 1);
    idx.push(a + 1, a + 3, a, a + 3, a + 2, a);
  }

  const deckGeo = new THREE.BufferGeometry();
  deckGeo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  deckGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  deckGeo.setIndex(idx);
  deckGeo.computeVertexNormals();
  addMesh(root, deckGeo, MAT.slab);

  // Low stone parapets and posts.
  const postTs = [0.08, 0.31, 0.53, 0.75, 0.94];
  for (const sz of [-1, 1]) {
    for (const t of postTs) {
      const x = -length / 2 + t * length;
      const y = topAt(t);
      addBox(root, 0.17, 0.58, 0.17, MAT.slab, x, y + 0.27, sz * (width / 2 - 0.08));
      addMesh(root, new THREE.SphereGeometry(0.085, 6, 4), MAT.slabDark, {
        x, y: y + 0.59, z: sz * (width / 2 - 0.08),
      });
    }

    const railPts = [];
    for (let i = 0; i <= 16; i++) {
      const t = i / 16;
      railPts.push(V3(-length / 2 + t * length, topAt(t) + 0.54, sz * (width / 2 - 0.08)));
    }
    addMesh(
      root,
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(railPts), 28, 0.06, 5, false),
      MAT.slabDark
    );
    addBox(root, length, 0.1, 0.08, MAT.slabDark, 0, 0.35, sz * (width / 2 - 0.04));
  }

  // Stone steps at each end.
  addBox(root, 0.45, 0.16, 1.35, MAT.slabDark, -length / 2 - 0.2, 0.46, 0);
  addBox(root, 0.45, 0.16, 1.35, MAT.slabDark, length / 2 + 0.2, 0.46, 0);

  // Submerged arch ribs, so the bridge reads as an arch from the side.
  for (const sz of [-1, 1]) {
    const pts = [];
    for (let i = 0; i <= 18; i++) {
      const t = i / 18;
      const x = -length / 2 + 0.1 + t * (length - 0.2);
      const y = 0.18 + Math.sin(Math.PI * t) * 0.32;
      pts.push(V3(x, y, sz * (width / 2 - 0.04)));
    }
    addMesh(root, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 20, 0.09, 5, false), MAT.slabDark);
  }
}

buildBridge();

// ---------------------------------------------------------------------------
// Stone lantern
// ---------------------------------------------------------------------------

function buildStoneLantern(x, z, scale = 1, baseY = PAVE_TOP) {
  const root = new THREE.Group();
  root.name = 'stone-lantern';
  root.position.set(x, baseY, z);
  root.scale.setScalar(scale);
  staticRoot.add(root);

  addCylinder(root, 0.36, 0.46, 0.18, 8, MAT.slabDark, 0, 0.09, 0);
  addCylinder(root, 0.13, 0.2, 0.62, 8, MAT.slab, 0, 0.48, 0);
  addCylinder(root, 0.38, 0.24, 0.12, 8, MAT.slabDark, 0, 0.84, 0);
  addCylinder(root, 0.34, 0.34, 0.22, 8, MAT.slab, 0, 0.98, 0);

  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    addBox(root, 0.27, 0.33, 0.36, MAT.slab, Math.cos(a) * 0.22, 1.21, Math.sin(a) * 0.22, 0, -a, 0);
    addBox(root, 0.16, 0.2, 0.01, MAT.metalDark, Math.cos(a) * 0.38, 1.21, Math.sin(a) * 0.38, 0, -a, 0);
  }
  addCylinder(root, 0.48, 0.56, 0.13, 8, MAT.slabDark, 0, 1.44, 0);
  addCylinder(root, 0.06, 0.47, 0.34, 8, MAT.slab, 0, 1.64, 0);
  addMesh(root, new THREE.SphereGeometry(0.1, 8, 6), MAT.gold, { y: 1.84 });
  addCylinder(root, 0.02, 0.04, 0.18, 6, MAT.gold, 0, 1.97, 1);

  // Mossy feet.
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + 0.2;
    addMesh(root, new THREE.SphereGeometry(rand(0.12, 0.2), 6, 4), MAT.moss, {
      x: Math.cos(a) * 0.36,
      y: 0.04,
      z: Math.sin(a) * 0.36,
      sx: 1.3,
      sy: 0.28,
      sz: 1.1,
    });
  }
}

buildStoneLantern(4.75, 8.45, 0.8);
buildStoneLantern(-8.35, 10.9, 0.64);

// ---------------------------------------------------------------------------
// Informal garden paths in the foreground
// ---------------------------------------------------------------------------

function buildGardenPaths() {
  const root = new THREE.Group();
  root.name = 'garden-paths';
  staticRoot.add(root);
  const mats = [MAT.flagA, MAT.flagB, MAT.flagC];

  function makePath(points, { count, width }) {
    const curve = new THREE.CatmullRomCurve3(points);
    for (let i = 0; i < count; i++) {
      const t = (i + 0.5) / count;
      const p = curve.getPoint(t);
      const tangent = curve.getTangent(t);
      const yaw = Math.atan2(tangent.x, tangent.z);
      const sides = 5 + Math.floor(rand(0, 4));
      const rx = width * rand(0.36, 0.56);
      const rz = rand(0.36, 0.62);
      const shape = new THREE.Shape();
      for (let s = 0; s < sides; s++) {
        const a = (s / sides) * Math.PI * 2 + rand(-0.18, 0.18);
        const rr = rand(0.84, 1.06);
        const px = Math.cos(a) * rx * rr;
        const py = Math.sin(a) * rz * rr;
        if (s === 0) shape.moveTo(px, py);
        else shape.lineTo(px, py);
      }
      shape.closePath();
      const geo = new THREE.ExtrudeGeometry(shape, {
        depth: 0.055,
        bevelEnabled: true,
        bevelSize: 0.025,
        bevelThickness: 0.012,
        bevelSegments: 1,
        curveSegments: 4,
      });
      geo.rotateX(-Math.PI / 2);
      addMesh(root, geo, mats[i % mats.length], {
        x: p.x + rand(-0.16, 0.16),
        y: PAVE_TOP + 0.058,
        z: p.z + rand(-0.16, 0.16),
        ry: yaw + rand(-0.22, 0.22),
      });
      if (i % 2 === 0) {
        addMesh(root, new THREE.SphereGeometry(rand(0.12, 0.22), 6, 4), i % 4 ? MAT.moss : MAT.mossDark, {
          x: p.x + Math.cos(yaw) * rand(-0.8, 0.8),
          y: PAVE_TOP + 0.015,
          z: p.z + Math.sin(yaw) * rand(-0.8, 0.8),
          sx: rand(0.8, 1.7),
          sy: 0.2,
          sz: rand(0.7, 1.3),
        });
      }
    }
  }

  // Two quiet irregular-stone approaches from the open foreground.
  makePath(
    [V3(-4.7, 0, 12.25), V3(-5.9, 0, 11.4), V3(-7.2, 0, 10.7), V3(-8.4, 0, 10.15)],
    { count: 6, width: 1.35 }
  );
  makePath(
    [V3(0.5, 0, 12.35), V3(1.2, 0, 11.0), V3(0.8, 0, 9.4), V3(0.1, 0, 8.1)],
    { count: 8, width: 1.05 }
  );
}

buildGardenPaths();

// ---------------------------------------------------------------------------
// Weeping willows, bamboo and Taihu rocks
// ---------------------------------------------------------------------------

function makeLeafGeometry(width, length, curl = 0.08) {
  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  shape.quadraticCurveTo(width, length * 0.36, 0, length);
  shape.quadraticCurveTo(-width, length * 0.36, 0, 0);
  const geo = new THREE.ShapeGeometry(shape, 5);
  const position = geo.attributes.position;
  for (let i = 0; i < position.count; i++) {
    const y = position.getY(i);
    const x = position.getX(i);
    const k = y / length;
    position.setZ(i, curl * k * k + Math.abs(x) * 0.16);
  }
  geo.computeVertexNormals();
  return geo;
}

const bambooLeafGeometry = makeLeafGeometry(0.05, 0.48, 0.06);

const bambooLeafMaterial = lit(0xffffff, {
  side: THREE.DoubleSide,
  castShadow: true,
  receiveShadow: true,
});

const bambooLeaves = [];

function pushLeaf(target, position, quaternion, scale, color) {
  target.push({ position: position.clone(), quaternion: quaternion.clone(), scale, color: color.clone() });
}

const BAMBOO_GREENS = [0x86a56d, 0x96b27e, 0x789766, 0xa4bd8a, 0x6d8c5f];

function buildBambooCluster(x, z, baseY, count, height, spread, seed) {
  const local = new THREE.Group();
  local.position.set(x, baseY, z);
  local.rotation.y = seed * 2.31;
  staticRoot.add(local);
  local.updateMatrixWorld(true);

  for (let i = 0; i < count; i++) {
    const offsetAngle = rand(0, Math.PI * 2);
    const offsetR = Math.sqrt(rand(0.02, 1)) * spread;
    const sx = Math.cos(offsetAngle) * offsetR;
    const sz = Math.sin(offsetAngle) * offsetR;
    const h = height * rand(0.72, 1.08);
    const lean = rand(-0.22, 0.22);
    const leanZ = rand(-0.18, 0.18);
    const curve = new THREE.CatmullRomCurve3([
      V3(sx, 0, sz),
      V3(sx + lean * 0.25, h * 0.38, sz + leanZ * 0.25),
      V3(sx + lean * 0.62, h * 0.72, sz + leanZ * 0.72),
      V3(sx + lean, h, sz + leanZ),
    ]);
    addMesh(
      local,
      new THREE.TubeGeometry(curve, 13, 0.052, 5, false),
      MAT.bamboo
    );

    // Bamboo nodes.
    for (let k = 0.28; k < 0.96; k += 0.18) {
      const p = curve.getPoint(k);
      addMesh(local, new THREE.TorusGeometry(0.055, 0.012, 4, 7), MAT.bambooDark, {
        x: p.x,
        y: p.y,
        z: p.z,
        rx: Math.PI / 2,
      });
    }
    const tip = curve.getPoint(1);
    addMesh(local, new THREE.ConeGeometry(0.04, 0.24, 5), MAT.bambooDark, {
      x: tip.x,
      y: tip.y + 0.08,
      z: tip.z,
    });

    // Side twigs and leaves.
    for (let b = 0; b < 4; b++) {
      const hb = h * rand(0.48, 0.9);
      const p = curve.getPoint(hb / h);
      const a = rand(0, Math.PI * 2);
      const branchLen = rand(0.22, 0.5);
      const tip2 = V3(p.x + Math.cos(a) * branchLen, p.y + rand(0.08, 0.35), p.z + Math.sin(a) * branchLen);
      const twig = new THREE.CatmullRomCurve3([
        V3(p.x, p.y, p.z),
        V3((p.x + tip2.x) * 0.5, p.y + 0.16, (p.z + tip2.z) * 0.5),
        tip2,
      ]);
      addMesh(local, new THREE.TubeGeometry(twig, 5, 0.012, 4, false), MAT.bambooDark);

      const leafCount = 9;
      for (let l = 0; l < leafCount; l++) {
        const t = rand(0.28, 1);
        const pp = twig.getPoint(t);
        const q = new THREE.Quaternion().setFromEuler(
          new THREE.Euler(rand(0.6, 1.65), rand(0, Math.PI * 2), rand(-0.5, 0.5), 'YXZ')
        );
        const wp = pp.clone().applyMatrix4(local.matrixWorld);
        wp.x += rand(-0.08, 0.08);
        wp.z += rand(-0.08, 0.08);
        pushLeaf(
          bambooLeaves,
          wp,
          q.premultiply(new THREE.Quaternion().setFromEuler(local.rotation)),
          rand(0.78, 1.28),
          new THREE.Color(choose(BAMBOO_GREENS))
        );
      }
    }

    // Extra leaves toward the top so the cluster feels dense.
    for (let l = 0; l < 16; l++) {
      const t = rand(0.55, 1);
      const p = curve.getPoint(t);
      const q = new THREE.Quaternion().setFromEuler(
        new THREE.Euler(rand(0.7, 1.75), rand(0, Math.PI * 2), rand(-0.45, 0.45), 'YXZ')
      );
      const wp = p.clone().add(V3(rand(-0.42, 0.42), rand(-0.08, 0.25), rand(-0.42, 0.42)));
      wp.applyMatrix4(local.matrixWorld);
      pushLeaf(
        bambooLeaves,
        wp,
        q.premultiply(new THREE.Quaternion().setFromEuler(local.rotation)),
        rand(0.82, 1.3),
        new THREE.Color(choose(BAMBOO_GREENS))
      );
    }
  }

  // A couple of mossy stones at the roots.
  for (let i = 0; i < 4; i++) {
    addMesh(local, new THREE.DodecahedronGeometry(rand(0.1, 0.2), 0), MAT.rockDark, {
      x: rand(-spread, spread),
      y: 0.08,
      z: rand(-spread, spread),
      sx: rand(1, 1.6),
      sy: rand(0.4, 0.8),
      sz: rand(0.9, 1.3),
    });
  }
}

function buildBamboo() {
  buildBambooCluster(-11.0, -8.45, PAVE_TOP, 7, 4.4, 0.8, 0.5);
  buildBambooCluster(-6.25, -9.35, PAVE_TOP, 5, 4.0, 0.62, 1.2);
  buildBambooCluster(3.15, -9.32, PAVE_TOP, 7, 4.8, 0.78, 2.1);
  buildBambooCluster(10.8, -10.1, PAVE_TOP, 5, 4.2, 0.58, 3.3);
  buildBambooCluster(-2.0, -12.0, PAVE_TOP, 4, 3.8, 0.44, 4.7);
  buildBambooCluster(11.6, 3.6, PAVE_TOP, 4, 3.7, 0.42, 5.8);
}

buildBamboo();

function makeRockGeometry(seed = 1, detail = 2) {
  const geo = new THREE.IcosahedronGeometry(1, detail);
  const position = geo.attributes.position;
  const v = new THREE.Vector3();
  for (let i = 0; i < position.count; i++) {
    v.fromBufferAttribute(position, i);
    const n =
      1 +
      Math.sin(v.x * 4.1 + seed * 3.2) * 0.1 +
      Math.cos(v.y * 5.3 - seed * 1.9) * 0.08 +
      Math.sin(v.z * 6.7 + seed * 2.7) * 0.07;
    v.x *= n * 0.94;
    v.y *= n * 1.13;
    v.z *= n;
    v.x += Math.sin(v.y * 5.0 + seed) * 0.035;
    v.z += Math.cos(v.y * 4.2 - seed) * 0.035;
    position.setXYZ(i, v.x, v.y, v.z);
  }
  geo.computeVertexNormals();
  return geo;
}

const CAVITY_MATERIAL = lit(0x394c43, {
  color: 0x394c43,
  castShadow: false,
  receiveShadow: false,
});

function addRockCavity(parent, x, y, z, sx, sy, ry = 0) {
  addMesh(parent, new THREE.SphereGeometry(1, 10, 8), CAVITY_MATERIAL, {
    x,
    y,
    z,
    ry,
    sx: sx,
    sy: sy,
    sz: 0.045,
  });
}

function buildRockCluster(x, z, baseY, scale, seed, opts = {}) {
  const root = new THREE.Group();
  root.name = 'taihu-rock';
  root.position.set(x, baseY, z);
  root.rotation.y = rand(0, Math.PI * 2);
  root.scale.setScalar(scale);
  staticRoot.add(root);

  const lobes = opts.lobes ?? 5;
  for (let i = 0; i < lobes; i++) {
    const rx = rand(-0.23, 0.23);
    const rz = rand(-0.17, 0.17);
    const ry = i * 0.3;
    const geo = makeRockGeometry(seed + i * 1.77, 2);
    addMesh(root, geo, i % 3 === 0 ? MAT.rockDark : MAT.rock, {
      x: rx,
      y: 0.38 + ry,
      z: rz,
      rx: rand(-0.2, 0.2),
      ry: rand(0, 3),
      rz: rand(-0.18, 0.18),
      sx: rand(0.2, 0.37),
      sy: rand(0.4, 0.72),
      sz: rand(0.17, 0.31),
    });
  }
  // One taller finger gives the eroded mass its vertical Taihu-stone gesture.
  addMesh(root, makeRockGeometry(seed + 9.3, 2), MAT.rock, {
    x: rand(-0.16, 0.16),
    y: 1.52,
    z: rand(-0.12, 0.12),
    rx: rand(-0.25, 0.25),
    ry: rand(0, 3),
    rz: rand(-0.22, 0.22),
    sx: rand(0.18, 0.29),
    sy: rand(0.58, 0.88),
    sz: rand(0.16, 0.25),
  });

  // Vertical "eyes" and cave mouths. They read as holes in the toon silhouette.
  addRockCavity(root, 0.0, 0.78, 0.33, 0.27, 0.48, 0);
  addRockCavity(root, 0.19, 1.45, 0.22, 0.16, 0.29, 0.2);
  addRockCavity(root, -0.32, 1.1, 0.06, 0.18, 0.34, -1.2);
  addRockCavity(root, 0.28, 0.54, -0.22, 0.15, 0.22, 1.8);
  addRockCavity(root, -0.08, 1.95, 0.05, 0.11, 0.22, 0.65);
  addRockCavity(root, 0.35, 1.48, -0.06, 0.1, 0.16, 1.55);

  // Base stones and moss.
  for (let i = 0; i < 4; i++) {
    const a = rand(0, Math.PI * 2);
    addMesh(root, new THREE.DodecahedronGeometry(rand(0.16, 0.28), 0), MAT.rockDark, {
      x: Math.cos(a) * rand(0.3, 0.7),
      y: rand(0.06, 0.18),
      z: Math.sin(a) * rand(0.3, 0.7),
      sx: rand(1, 1.7),
      sy: rand(0.4, 0.7),
      sz: rand(0.8, 1.3),
    });
  }
  for (let i = 0; i < 5; i++) {
    const a = rand(0, Math.PI * 2);
    addMesh(root, new THREE.SphereGeometry(rand(0.18, 0.34), 6, 4), i % 2 ? MAT.moss : MAT.mossDark, {
      x: Math.cos(a) * rand(0.25, 0.75),
      y: 0.09,
      z: Math.sin(a) * rand(0.25, 0.75),
      sx: rand(1.0, 1.8),
      sy: 0.22,
      sz: rand(0.8, 1.5),
    });
  }
}

function buildRocks() {
  buildRockCluster(-6.4, 4.62, PAVE_TOP, 1.05, 1.1, { lobes: 6 });
  buildRockCluster(-5.05, -4.35, PAVE_TOP, 1.25, 2.2, { lobes: 7 });
  buildRockCluster(2.15, -4.4, PAVE_TOP, 0.86, 3.4, { lobes: 5 });
  buildRockCluster(-11.1, 2.6, PAVE_TOP, 0.78, 4.2, { lobes: 4 });
  buildRockCluster(-2.95, 5.42, 0.64, 0.58, 5.3, { lobes: 4 });
  buildRockCluster(-2.05, -11.84, PAVE_TOP, 0.7, 6.7, { lobes: 4 });
  buildRockCluster(7.05, 8.7, PAVE_TOP, 0.72, 7.1, { lobes: 5 });
}

buildRocks();

// ---------------------------------------------------------------------------
// Layered rockeries and the low hedge rows tucked against the walls
// ---------------------------------------------------------------------------

function buildRockery(x, z, baseY, scale, seed) {
  const root = new THREE.Group();
  root.name = 'layered-rockery';
  root.position.set(x, baseY, z);
  root.rotation.y = seed * 0.7;
  staticRoot.add(root);

  const layers = [
    { count: 3, y: 0.38, spread: 0.65, size: [0.8, 1.0] },
    { count: 3, y: 0.95, spread: 0.5, size: [0.55, 0.8] },
    { count: 2, y: 1.4, spread: 0.35, size: [0.35, 0.6] },
  ];
  for (let layer = 0; layer < layers.length; layer++) {
    const l = layers[layer];
    for (let i = 0; i < l.count; i++) {
      const a = (i / l.count) * Math.PI * 2 + seed + layer * 0.8;
      const sx = scale * rand(l.size[0], l.size[1]);
      const sy = scale * rand(l.size[0], l.size[1]) * rand(0.6, 1.05);
      const sz = scale * rand(l.size[0], l.size[1]) * rand(0.7, 1.1);
      addMesh(
        root,
        new THREE.DodecahedronGeometry(1, 0),
        (i + layer) % 3 ? MAT.rockery : MAT.rockeryDark,
        {
          x: Math.cos(a) * l.spread * scale + rand(-0.15, 0.15),
          y: l.y * scale + rand(-0.08, 0.08),
          z: Math.sin(a) * l.spread * scale + rand(-0.15, 0.15),
          sx,
          sy,
          sz,
          rx: rand(-0.6, 0.6),
          ry: rand(0, Math.PI * 2),
          rz: rand(-0.45, 0.45),
        }
      );
    }
  }

  // Angular slabs break up the boulder silhouette.
  for (let i = 0; i < 2; i++) {
    addMesh(root, new THREE.BoxGeometry(1, 1, 1), MAT.rockeryDark, {
      x: rand(-0.32, 0.32) * scale,
      y: rand(0.9, 1.35) * scale,
      z: rand(-0.28, 0.28) * scale,
      sx: rand(0.45, 0.75) * scale,
      sy: rand(0.18, 0.34) * scale,
      sz: rand(0.55, 0.9) * scale,
      rx: rand(-0.6, 0.6),
      ry: rand(0, Math.PI),
      rz: rand(-0.5, 0.5),
    });
  }

  for (let i = 0; i < 3; i++) {
    addMesh(root, new THREE.SphereGeometry(rand(0.16, 0.28), 7, 5), i % 2 ? MAT.moss : MAT.mossDark, {
      x: rand(-0.35, 0.35) * scale,
      y: rand(1.0, 1.5) * scale,
      z: rand(-0.35, 0.35) * scale,
      sx: rand(1.0, 1.8),
      sy: 0.18,
      sz: rand(0.8, 1.4),
    });
  }
}

buildRockery(-7.8, 6.5, PAVE_TOP, 1.0, 11);
buildRockery(7.0, 6.1, PAVE_TOP, 0.9, 12);
buildRockery(-7.35, -2.9, PAVE_TOP, 0.8, 13);
buildRockery(4.7, -4.55, PAVE_TOP, 0.72, 14);

function buildHedges() {
  const geo = new THREE.IcosahedronGeometry(1, 0);
  const rows = [
    { axis: 'z', fixed: -11.82, from: -7.4, to: 9.2, step: 0.52 },
    { axis: 'z', fixed: 11.82, from: -3.2, to: 5.3, step: 0.52 },
    { axis: 'x', fixed: -10.45, from: -10.2, to: 4.5, step: 0.55 },
    { axis: 'x', fixed: -8.55, from: -7.2, to: 4.6, step: 0.58 },
  ];
  for (const row of rows) {
    for (let v = row.from; v <= row.to; v += row.step) {
      const x = row.axis === 'z' ? row.fixed : v + rand(-0.1, 0.1);
      const z = row.axis === 'z' ? v + rand(-0.1, 0.1) : row.fixed;
      const sx = rand(0.27, 0.48);
      const sy = rand(0.2, 0.38);
      const sz = rand(0.27, 0.46);
      addMesh(staticRoot, geo, rng() < 0.5 ? MAT.hedge : MAT.hedgeLight, {
        x: x + rand(-0.12, 0.12),
        y: PAVE_TOP + sy * 0.86,
        z: z + rand(-0.12, 0.12),
        sx,
        sy,
        sz,
        ry: rand(0, Math.PI * 2),
      });
      if (rng() < 0.32) {
        addMesh(staticRoot, geo, MAT.hedgeLight, {
          x: x + rand(-0.3, 0.3),
          y: PAVE_TOP + 0.12,
          z: z + rand(-0.3, 0.3),
          sx: sx * 0.7,
          sy: sy * 0.65,
          sz: sz * 0.7,
          ry: rand(0, Math.PI * 2),
        });
      }
    }
  }
}

buildHedges();

// A second, looser ring of shrubs fills the wider gaps between the walls and
// the corridor / pavilion, plus both cheeks of the open front. Sizes are
// deliberately mixed from ankle-high tufts to large rounded bushes.
function buildShrubClusters() {
  const clusterCenters = [
    [-11.25, 7.4], [-11.35, 4.3], [-11.2, 0.8], [-11.4, -3.0], [-11.25, -6.5],
    [-9.7, -10.05], [-6.8, -10.1], [-3.8, -10.05], [-0.8, -10.1], [2.1, -10.0], [4.5, -9.9],
    [11.3, 4.6], [11.35, 2.2], [11.2, -0.8],
    [-11.0, 10.8], [-10.2, 12.0], [-4.6, 12.1], [5.0, 11.9], [7.3, 11.6], [9.3, 11.25],
  ];
  const lampPositions = [
    [-10.3, 11.15], [10.3, 11.15], [-9.0, 1.75], [2.2, -7.85],
    [7.45, -5.95], [9.45, -8.05],
  ];
  const roundGeo = new THREE.IcosahedronGeometry(1, 0);
  const angularGeo = new THREE.DodecahedronGeometry(1, 0);
  const shrubMaterials = [MAT.hedge, MAT.hedgeLight, MAT.shrubDeep, MAT.shrubOlive];

  for (const [cx, cz] of clusterCenters) {
    const count = 4 + Math.floor(rng() * 5);
    for (let i = 0; i < count; i++) {
      const a = rand(0, Math.PI * 2);
      const radius = Math.sqrt(rng()) * 1.05;
      const x = cx + Math.cos(a) * radius;
      const z = cz + Math.sin(a) * radius;
      if (pointInPond(x, z, 0.1)) continue;
      if (Math.hypot(x - 8.48, z + 7.0) < 3.6) continue;
      let tooCloseToLamp = false;
      for (const [lx, lz] of lampPositions) {
        if (Math.hypot(x - lx, z - lz) < 0.72) {
          tooCloseToLamp = true;
          break;
        }
      }
      if (tooCloseToLamp) continue;

      const large = rng() < 0.24;
      const size = large ? rand(0.5, 0.86) : rand(0.16, 0.5);
      const sx = size * rand(0.85, 1.25);
      const sy = size * rand(0.55, 0.95);
      const sz = size * rand(0.85, 1.25);
      const mat = shrubMaterials[Math.floor(rng() * shrubMaterials.length)];
      addMesh(staticRoot, large && rng() < 0.24 ? angularGeo : roundGeo, mat, {
        x: x + rand(-0.08, 0.08),
        y: PAVE_TOP + sy * 0.83,
        z: z + rand(-0.08, 0.08),
        sx,
        sy,
        sz,
        rx: rand(-0.12, 0.12),
        ry: rand(0, Math.PI * 2),
        rz: rand(-0.12, 0.12),
      });

      // Small satellite tufts make the clusters less like a row of balls.
      if (rng() < 0.45) {
        addMesh(staticRoot, roundGeo, mat, {
          x: x + rand(-0.45, 0.45),
          y: PAVE_TOP + sy * 0.4,
          z: z + rand(-0.45, 0.45),
          sx: sx * 0.55,
          sy: sy * 0.52,
          sz: sz * 0.55,
          ry: rand(0, Math.PI * 2),
        });
      }
    }
  }
}

buildShrubClusters();

function makeWillowFrondGeometry() {
  const positions = [];
  const indices = [];

  // Each instance is a small bunch of three sibling strands. This keeps the
  // silhouette fine and leaf-like while giving every leaf group enough body
  // to read as a dense hanging spray instead of a single wire.
  for (let strand = 0; strand < 3; strand++) {
    const lateral = (strand - 1) * 0.075;
    const zOffset = (strand - 1) * 0.03;
    const phase = strand * 1.7;
    const curveAt = (t) => V3(
      Math.sin(t * 3.1 + phase) * 0.055 + lateral,
      -t,
      Math.cos(t * 2.2 + phase) * 0.025 + zOffset
    );

    // A barely visible central stem ribbon.
    const stemBase = positions.length / 3;
    for (let i = 0; i <= 14; i++) {
      const t = i / 14;
      const p = curveAt(t);
      const w = 0.006 * (1 - t * 0.4);
      positions.push(p.x - w, p.y, p.z, p.x + w, p.y, p.z);
      if (i < 14) {
        const a = stemBase + i * 2;
        indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
      }
    }

    // Long, narrow leaflets alternating down each strand.
    const leafCount = 18;
    for (let i = 0; i < leafCount; i++) {
      const t = 0.07 + (i / leafCount) * 0.87;
      const p = curveAt(t);
      const side = i % 2 ? 1 : -1;
      const length = 0.15 * (1 - t * 0.18);
      const dir = V3(side * 0.55, -0.82, Math.sin(i * 1.9 + phase) * 0.22).normalize();
      const widthDir = V3(-dir.z, 0, dir.x).normalize();
      const half = 0.04 * (1 - t * 0.18);
      const base = p.clone().addScaledVector(widthDir, side * 0.005);
      const mid = base.clone().addScaledVector(dir, length * 0.46);
      const tip = base.clone().addScaledVector(dir, length);
      const w1 = mid.clone().addScaledVector(widthDir, half);
      const w2 = mid.clone().addScaledVector(widthDir, -half);
      const baseIndex = positions.length / 3;
      positions.push(
        base.x, base.y, base.z,
        w1.x, w1.y, w1.z,
        tip.x, tip.y, tip.z,
        w2.x, w2.y, w2.z
      );
      indices.push(baseIndex, baseIndex + 1, baseIndex + 2, baseIndex, baseIndex + 2, baseIndex + 3);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

const willowFrondGeometry = makeWillowFrondGeometry();
const willowFrondMaterial = lit(0xffffff, {
  side: THREE.DoubleSide,
  roughness: 0.9,
});
const willowTuftGeometry = (() => {
  const positions = [];
  const indices = [];
  const leafCount = 20;
  for (let i = 0; i < leafCount; i++) {
    const a = (i / leafCount) * Math.PI * 2 + rand(-0.2, 0.2);
    const radial = rand(0.35, 0.8);
    const dir = V3(
      Math.cos(a) * radial,
      rand(-1.15, -0.25),
      Math.sin(a) * radial
    ).normalize();
    const widthDir = V3(-Math.sin(a), 0, Math.cos(a)).normalize();
    const base = V3(
      Math.cos(a) * rand(0.04, 0.22),
      rand(-0.18, 0.22),
      Math.sin(a) * rand(0.04, 0.22)
    );
    const length = rand(0.42, 0.82);
    const half = rand(0.045, 0.085);
    const mid = base.clone().addScaledVector(dir, length * 0.48);
    const tip = base.clone().addScaledVector(dir, length);
    const w1 = mid.clone().addScaledVector(widthDir, half);
    const w2 = mid.clone().addScaledVector(widthDir, -half);
    const baseIndex = positions.length / 3;
    positions.push(
      base.x, base.y, base.z,
      w1.x, w1.y, w1.z,
      tip.x, tip.y, tip.z,
      w2.x, w2.y, w2.z
    );
    indices.push(baseIndex, baseIndex + 1, baseIndex + 2, baseIndex, baseIndex + 2, baseIndex + 3);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
})();
const WILLOW_TUFT_A = lit(0x7e9c62, { flatShading: true, roughness: 0.94 });
const WILLOW_TUFT_B = lit(0x9ab277, { flatShading: true, roughness: 0.94 });
const willowFronds = [];
const WILLOW_GREENS = [0x8fae70, 0xa3bc7f, 0x7c9e63, 0xb0c78b, 0x6e9258];

function buildWillow(x, z, baseY, scale, seed) {
  const root = new THREE.Group();
  root.name = 'weeping-willow';
  root.position.set(x, baseY, z);
  root.rotation.y = seed * 1.7;
  root.scale.setScalar(scale);
  staticRoot.add(root);

  // Trunk plus a small set of real, forking limbs. The lower trunk stays
  // visible; the upper half is where the grouped leaning branches live.
  addCylinder(root, 0.065, 0.14, 2.7, 8, MAT.bark, 0, 1.35, 0);

  const branchCurves = [];
  const branchCount = 6;
  for (let b = 0; b < branchCount; b++) {
    const a = (b / branchCount) * Math.PI * 2 + seed * 0.55 + rand(-0.2, 0.2);
    const reach = rand(1.1, 1.75);
    const startY = rand(2.05, 2.3);
    const endY = rand(2.9, 3.65);
    const start = V3(0, startY, 0);
    const mid = V3(
      Math.cos(a) * reach * 0.52,
      startY + (endY - startY) * 0.55,
      Math.sin(a) * reach * 0.52
    );
    const end = V3(Math.cos(a) * reach, endY, Math.sin(a) * reach);
    const curve = new THREE.CatmullRomCurve3([start, mid, end], false, 'catmullrom', 0.38);
    addMesh(root, new THREE.TubeGeometry(curve, 9, rand(0.026, 0.04), 5, false), MAT.bark);
    branchCurves.push({ curve, a, central: false });
  }

  // A central leader fills the crown top so the canopy is round rather than
  // a flat ring of hanging strands.
  const centerCurve = new THREE.CatmullRomCurve3([
    V3(0, 2.35, 0),
    V3(rand(-0.16, 0.16), 3.05, rand(-0.16, 0.16)),
    V3(rand(-0.22, 0.22), 3.8, rand(-0.22, 0.22)),
  ], false, 'catmullrom', 0.38);
  addMesh(root, new THREE.TubeGeometry(centerCurve, 9, 0.028, 5, false), MAT.bark);
  branchCurves.push({ curve: centerCurve, a: seed * 2.1, central: true });

  root.updateMatrixWorld(true);
  const rootQuat = new THREE.Quaternion().setFromEuler(root.rotation);

  // Each limb carries three distinct leaf groups along its outer half. The
  // tops of each group gather around one branch point, then fan out and hang,
  // giving the crown the bunched, layered silhouette of a real weeping willow.
  for (let b = 0; b < branchCurves.length; b++) {
    const branch = branchCurves[b];
    const groupTs = branch.central ? [0.2, 0.45, 0.72, 1.0] : [0.22, 0.48, 0.72, 0.96];
    const perGroup = branch.central ? 14 : 16;
    for (let g = 0; g < groupTs.length; g++) {
      const hub = branch.curve.getPoint(groupTs[g]);
      for (let i = 0; i < perGroup; i++) {
        const spread = branch.central ? 0.5 : 0.4;
        const local = V3(
          hub.x + rand(-spread, spread),
          hub.y + rand(-0.22, 0.14),
          hub.z + rand(-spread, spread)
        );
        const world = local.clone().applyMatrix4(root.matrixWorld);
        const outward = branch.central ? rand(0.02, 0.09) : rand(0.1, 0.28);
        const q = new THREE.Quaternion().setFromEuler(
          new THREE.Euler(
            -Math.sin(branch.a) * outward + rand(-0.04, 0.04),
            rand(0, Math.PI * 2),
            Math.cos(branch.a) * outward + rand(-0.04, 0.04),
            'YXZ'
          )
        ).premultiply(rootQuat);
        const length = scale * rand(0.8, 2.65) * (0.72 + groupTs[g] * 0.34);
        const width = scale * rand(0.8, 1.34);
        willowFronds.push({
          position: world,
          quaternion: q,
          scale: V3(width, length, width),
          color: new THREE.Color(choose(WILLOW_GREENS)),
          phase: seed * 4.1 + b * 0.7 + g * 0.18 + i * 0.014 + rand(-0.08, 0.08),
          sway: rand(0.016, 0.04),
          swaySpeed: rand(0.2, 0.38),
        });
      }

      // Short leaf tufts around the same branch point build a soft, clustered
      // crown above the longer weeping strands.
      for (let i = 0; i < 8; i++) {
        const local = V3(
          hub.x + rand(-0.42, 0.42),
          hub.y + rand(-0.12, 0.28),
          hub.z + rand(-0.42, 0.42)
        );
        const world = local.clone().applyMatrix4(root.matrixWorld);
        const q = new THREE.Quaternion().setFromEuler(
          new THREE.Euler(rand(-0.22, 0.22), rand(0, Math.PI * 2), rand(-0.22, 0.22), 'YXZ')
        ).premultiply(rootQuat);
        const length = scale * rand(0.32, 0.82);
        const width = scale * rand(0.9, 1.4);
        willowFronds.push({
          position: world,
          quaternion: q,
          scale: V3(width, length, width),
          color: new THREE.Color(choose(WILLOW_GREENS)),
          phase: seed * 4.1 + b * 0.7 + g * 0.2 + i * 0.09 + rand(-0.12, 0.12),
          sway: rand(0.012, 0.03),
          swaySpeed: rand(0.18, 0.34),
        });
      }

      // Small irregular leaf masses sit inside each branch group. They fill
      // the crown gaps and read as bunched foliage between the hanging strands.
      const hubWorld = hub.clone().applyMatrix4(root.matrixWorld);
      for (let i = 0; i < 4; i++) {
        addMesh(
          staticRoot,
          willowTuftGeometry,
          i % 2 ? WILLOW_TUFT_A : WILLOW_TUFT_B,
          {
            x: hubWorld.x + rand(-0.36, 0.36) * scale,
            y: hubWorld.y + rand(-0.12, 0.25) * scale,
            z: hubWorld.z + rand(-0.36, 0.36) * scale,
            sx: scale * rand(0.4, 0.7),
            sy: scale * rand(0.34, 0.62),
            sz: scale * rand(0.4, 0.7),
            ry: rand(0, Math.PI * 2),
            rz: rand(-0.24, 0.24),
          }
        );
      }
    }
  }

  for (let i = 0; i < 5; i++) {
    addMesh(root, new THREE.SphereGeometry(rand(0.12, 0.22), 7, 5), MAT.moss, {
      x: rand(-0.35, 0.35),
      y: 0.03,
      z: rand(-0.35, 0.35),
      sx: 1.4,
      sy: 0.22,
      sz: 1.1,
    });
  }
}

buildWillow(-6.8, 9.55, PAVE_TOP, 1.12, 0.4);
buildWillow(8.8, 9.4, PAVE_TOP, 1.02, 2.3);
buildWillow(-1.78, 5.25, 0.64, 0.78, 4.1);

const willowMesh = new THREE.InstancedMesh(
  willowFrondGeometry,
  willowFrondMaterial,
  willowFronds.length
);
{
  const matrix = new THREE.Matrix4();
  for (let i = 0; i < willowFronds.length; i++) {
    const f = willowFronds[i];
    matrix.compose(f.position, f.quaternion, f.scale);
    willowMesh.setMatrixAt(i, matrix);
    willowMesh.setColorAt(i, f.color);
  }
  willowMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  willowMesh.instanceMatrix.needsUpdate = true;
  if (willowMesh.instanceColor) willowMesh.instanceColor.needsUpdate = true;
  willowMesh.castShadow = true;
  willowMesh.receiveShadow = true;
  willowMesh.frustumCulled = false;
  scene.add(willowMesh);
}

// A few soft grasses in crevices and at the pond edge.
function makeGrassTuftGeometry() {
  const blades = [];
  for (let i = 0; i < 5; i++) {
    const blade = new THREE.PlaneGeometry(0.055, rand(0.28, 0.52), 1, 2);
    const position = blade.attributes.position;
    for (let j = 0; j < position.count; j++) {
      const y = position.getY(j);
      position.setZ(j, Math.pow((y + 0.26) / 0.52, 2) * 0.09);
    }
    blade.rotateX(rand(-0.22, 0.22));
    blade.rotateY((i / 5) * Math.PI * 2 + rand(-0.3, 0.3));
    blade.translate(rand(-0.05, 0.05), 0.2, rand(-0.05, 0.05));
    blades.push(blade);
  }
  const merged = mergeGeometries(blades.map((b) => (b.index ? b.toNonIndexed() : b)), false);
  merged.computeVertexNormals();
  return merged;
}

const grassMaterial = lit(0x7da65e, {
  side: THREE.DoubleSide,
  castShadow: false,
  receiveShadow: true,
});
const grassTuftGeometry = makeGrassTuftGeometry();
const grassMesh = new THREE.InstancedMesh(grassTuftGeometry, grassMaterial, 46);
grassMesh.castShadow = false;
grassMesh.receiveShadow = true;
grassMesh.frustumCulled = false;
{
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const s = new THREE.Vector3();
  let i = 0;
  for (; i < 46; i++) {
    const p = pondSamples[Math.floor(rand(0, pondSamples.length))];
    const len = Math.hypot(p.x, p.z) || 1;
    const offset = rand(0.2, 0.78);
    const x = p.x + (p.x / len) * offset;
    const z = p.z + (p.z / len) * offset;
    s.setScalar(rand(0.5, 0.98));
    q.setFromEuler(new THREE.Euler(0, rand(0, Math.PI * 2), 0));
    m.compose(V3(x, PAVE_TOP + 0.01, z), q, s);
    grassMesh.setMatrixAt(i, m);
    grassMesh.setColorAt(i, new THREE.Color(choose([0x628e49, 0x789f55, 0x527f42, 0x88aa61])));
  }
  grassMesh.instanceMatrix.needsUpdate = true;
  if (grassMesh.instanceColor) grassMesh.instanceColor.needsUpdate = true;
}
scene.add(grassMesh);

// Build the single instanced bamboo foliage mesh.
function makeLeafInstances(data, material) {
  const mesh = new THREE.InstancedMesh(bambooLeafGeometry, material, data.length);
  const matrix = new THREE.Matrix4();
  for (let i = 0; i < data.length; i++) {
    const d = data[i];
    matrix.compose(d.position, d.quaternion, V3(d.scale, d.scale, d.scale));
    mesh.setMatrixAt(i, matrix);
    mesh.setColorAt(i, d.color);
  }
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.frustumCulled = false;
  scene.add(mesh);
  return mesh;
}

makeLeafInstances(bambooLeaves, bambooLeafMaterial);

// ---------------------------------------------------------------------------
// Lotus pond: leaves, flowers, buds, floating petals
// ---------------------------------------------------------------------------

const lotusLeafMaterial = lit(0xffffff, {
  map: leafTexture,
  side: THREE.DoubleSide,
  castShadow: true,
  receiveShadow: true,
});
const lotusLeafGeometry = (() => {
  const radius = 0.86;
  const rings = 5;
  const segments = 40;
  const notch = 0.4;
  const positions = [];
  const uvs = [];
  const indices = [];

  positions.push(0, 0, 0);
  uvs.push(0.5, 0.5);
  const ringStart = [];
  for (let r = 1; r <= rings; r++) {
    const t = r / rings;
    ringStart.push(positions.length / 3);
    for (let s = 0; s < segments; s++) {
      const u = s / (segments - 1);
      const a = notch * 0.5 + u * (Math.PI * 2 - notch);
      const ruff = 1
        + 0.045 * Math.sin(a * 7 + 0.9) * Math.pow(t, 2.4)
        + 0.02 * Math.sin(a * 13 + 2.1) * Math.pow(t, 3.6);
      const rr = radius * t * ruff;
      const edgeWave = (
        0.032 * Math.sin(a * 7 + 0.8)
        + 0.014 * Math.sin(a * 13 + 2.4)
      ) * Math.pow(t, 3.0);
      const y = 0.13 * Math.pow(t, 2.2) + 0.06 * Math.pow(t, 6) + edgeWave;
      positions.push(Math.cos(a) * rr, y, Math.sin(a) * rr);
      uvs.push(Math.cos(a) * 0.5 * t + 0.5, Math.sin(a) * 0.5 * t + 0.5);
    }
  }

  for (let s = 0; s < segments - 1; s++) {
    indices.push(0, ringStart[0] + s, ringStart[0] + s + 1);
  }
  for (let r = 0; r < rings - 1; r++) {
    const a0 = ringStart[r];
    const a1 = ringStart[r + 1];
    for (let s = 0; s < segments - 1; s++) {
      indices.push(a0 + s, a0 + s + 1, a1 + s, a0 + s + 1, a1 + s + 1, a1 + s);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
})();

function makePetalGeometry() {
  const cols = 6;
  const rows = 11;
  const positions = [];
  const colors = [];
  const uvs = [];
  const indices = [];
  const baseColor = new THREE.Color(0xfffdf9);
  const tipColor = new THREE.Color(0xf0d3d8);
  const midColor = new THREE.Color(0xfaf0ef);
  const c = new THREE.Color();

  for (let r = 0; r <= rows; r++) {
    const v = r / rows;
    const y = v * 1.02;
    const width = 0.02 + 0.42 * Math.pow(Math.sin(Math.PI * Math.pow(v, 0.86)), 0.76);
    for (let cIdx = 0; cIdx <= cols; cIdx++) {
      const u = cIdx / cols;
      const x = (u * 2 - 1) * width;
      const z = 0.055 * Math.sin(Math.PI * v) * (1 - Math.pow(u * 2 - 1, 2)) + 0.012 * v;
      positions.push(x, y, z);
      uvs.push(u, v);

      const t = clamp(v * 1.08, 0, 1);
      if (t < 0.6) c.copy(baseColor).lerp(midColor, t / 0.6);
      else c.copy(midColor).lerp(tipColor, (t - 0.6) / 0.4);
      // A pale, nearly white edge for a clean cel-shaded petal.
      const edge = Math.pow(Math.abs(u * 2 - 1), 2);
      c.lerp(new THREE.Color(0xfff7ec), edge * 0.22);
      colors.push(c.r, c.g, c.b);
    }
  }
  for (let r = 0; r < rows; r++) {
    for (let cIdx = 0; cIdx < cols; cIdx++) {
      const i0 = r * (cols + 1) + cIdx;
      const i1 = i0 + 1;
      const i2 = i0 + cols + 1;
      const i3 = i2 + 1;
      indices.push(i0, i1, i2, i1, i3, i2);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

const petalGeometry = makePetalGeometry();
const petalMeshMaterial = lit(0xffffff, {
  vertexColors: true,
  side: THREE.DoubleSide,
  castShadow: false,
  receiveShadow: true,
});
const flowerHeartGeometry = new THREE.CylinderGeometry(0.16, 0.13, 0.13, 12);
const flowerHeartRingGeometry = new THREE.TorusGeometry(0.145, 0.03, 5, 12);
const stemGeometry = new THREE.CylinderGeometry(1, 1, 1, 6);
const lotusStemMaterial = lit(0x5d9559, { castShadow: true, receiveShadow: true });

const leafData = [];
const leafMatrices = [];
const leafPhases = [];
const stemMatrices = [];
const flowerPetalData = [];
const flowerHearts = [];
const flowerHeartRings = [];
const flowerStems = [];
const flowerCalyxes = [];
const budStems = [];

const UP_AXIS = V3(0, 1, 0);

function stemMatrixBetween(start, end, radius = 0.028) {
  const delta = end.clone().sub(start);
  const length = delta.length();
  const q = new THREE.Quaternion().setFromUnitVectors(UP_AXIS, delta.normalize());
  return new THREE.Matrix4().compose(
    start.clone().add(end).multiplyScalar(0.5),
    q,
    V3(radius, length, radius)
  );
}

function makeFlowerMatrix(basePos, angle, tilt, scale, headQuat) {
  const qY = new THREE.Quaternion().setFromAxisAngle(V3(0, 1, 0), angle);
  const qX = new THREE.Quaternion().setFromAxisAngle(V3(1, 0, 0), tilt);
  const q = headQuat.clone().multiply(qY).multiply(qX);
  return new THREE.Matrix4().compose(basePos, q, V3(scale, scale, scale));
}

const OPEN_RINGS = [
  { count: 9, tilt: 0.98, scale: 1.0 },
  { count: 8, tilt: 0.58, scale: 0.79 },
  { count: 6, tilt: 0.28, scale: 0.54 },
];
const HALF_OPEN_RINGS = [
  { count: 8, tilt: 0.7, scale: 1.0 },
  { count: 7, tilt: 0.38, scale: 0.8 },
  { count: 5, tilt: 0.16, scale: 0.56 },
];

function addFlowerAt(x, z, pose = 'upright') {
  if (!pointInPond(x, z, 0.55)) return false;
  if (Math.hypot(x - ISLAND.x, z - ISLAND.y) < 1.75) return false;
  if (Math.abs(z - 4.8) < 1.0 && x < -3.0 && x > -7.3) return false;

  let stemHeight;
  let bend;
  let lean;
  let flowerScale;
  let rings;
  if (pose === 'bent') {
    stemHeight = rand(0.72, 1.08);
    bend = rand(0.24, 0.42);
    lean = rand(0.36, 0.64);
    flowerScale = rand(0.52, 0.68);
    rings = OPEN_RINGS;
  } else if (pose === 'drooping') {
    stemHeight = rand(0.86, 1.22);
    bend = rand(0.35, 0.57);
    lean = rand(0.86, 1.15);
    flowerScale = rand(0.5, 0.66);
    rings = OPEN_RINGS;
  } else if (pose === 'halfOpen') {
    stemHeight = rand(0.58, 0.98);
    bend = rand(0.06, 0.2);
    lean = rand(0.06, 0.24);
    flowerScale = rand(0.46, 0.6);
    rings = HALF_OPEN_RINGS;
  } else {
    stemHeight = rand(0.54, 1.06);
    bend = rand(0.03, 0.13);
    lean = rand(0.02, 0.16);
    flowerScale = rand(0.54, 0.7);
    rings = OPEN_RINGS;
  }

  const a = rand(0, Math.PI * 2);
  const bendX = Math.cos(a) * bend;
  const bendZ = Math.sin(a) * bend;
  const stemTop = V3(x + bendX, WATER_Y + stemHeight, z + bendZ);
  const stemStart = V3(x, WATER_Y, z);
  const stemMid = V3(
    x + bendX * 0.38,
    WATER_Y + stemHeight * 0.55,
    z + bendZ * 0.38
  );
  const tiltAxis = V3(Math.sin(a), 0, -Math.cos(a));
  const headQuat = new THREE.Quaternion()
    .setFromAxisAngle(tiltAxis, lean)
    .multiply(new THREE.Quaternion().setFromAxisAngle(UP_AXIS, rand(0, Math.PI * 2)));
  const headUp = V3(0, 1, 0).applyQuaternion(headQuat);
  const headBase = stemTop.clone();

  const color = new THREE.Color().setHSL(rand(0.975, 1.0), rand(0.035, 0.1), rand(0.95, 0.985));
  for (const ring of rings) {
    for (let i = 0; i < ring.count; i++) {
      const angle = (i / ring.count) * Math.PI * 2 + rand(-0.12, 0.12);
      const m = makeFlowerMatrix(
        headBase,
        angle,
        ring.tilt + rand(-0.08, 0.08),
        flowerScale * ring.scale * rand(0.9, 1.08),
        headQuat
      );
      flowerPetalData.push({ matrix: m, color: color.clone() });
    }
  }

  flowerHearts.push({
    matrix: new THREE.Matrix4().compose(
      headBase.clone().add(headUp.clone().multiplyScalar(0.29 * flowerScale + 0.08)),
      headQuat.clone(),
      new THREE.Vector3(flowerScale * 1.4, flowerScale * 1.2, flowerScale * 1.4)
    ),
  });
  flowerHeartRings.push({
    matrix: new THREE.Matrix4().compose(
      headBase.clone().add(headUp.clone().multiplyScalar(0.23 * flowerScale + 0.06)),
      headQuat.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2, 0, 0))),
      new THREE.Vector3(flowerScale * 1.45, flowerScale * 1.45, flowerScale * 1.45)
    ),
  });

  flowerStems.push({ matrix: stemMatrixBetween(stemStart, stemMid, 0.028) });
  flowerStems.push({ matrix: stemMatrixBetween(stemMid, stemTop, 0.025) });

  flowerCalyxes.push({
    matrix: new THREE.Matrix4().compose(
      headBase.clone().add(headUp.clone().multiplyScalar(-0.04)),
      headQuat.clone().multiply(new THREE.Quaternion().setFromAxisAngle(UP_AXIS, rand(0, 6.28))),
      new THREE.Vector3(flowerScale, flowerScale, flowerScale)
    ),
  });
  return true;
}

function addBudAt(x, z) {
  if (!pointInPond(x, z, 0.5)) return false;
  if (Math.hypot(x - ISLAND.x, z - ISLAND.y) < 1.7) return false;
  if (Math.abs(z - 4.8) < 1.0 && x < -3.0 && x > -7.3) return false;

  const stemHeight = rand(0.46, 0.95);
  const a = rand(0, Math.PI * 2);
  const bend = rand(0.04, 0.16);
  const bendX = Math.cos(a) * bend;
  const bendZ = Math.sin(a) * bend;
  const top = V3(x + bendX, WATER_Y + stemHeight, z + bendZ);
  const start = V3(x, WATER_Y, z);
  const mid = V3(x + bendX * 0.35, WATER_Y + stemHeight * 0.55, z + bendZ * 0.35);
  const budScale = rand(0.28, 0.42);
  const budColor = new THREE.Color().setHSL(rand(0.975, 1.0), rand(0.06, 0.13), rand(0.93, 0.97));
  const headQuat = new THREE.Quaternion().setFromAxisAngle(
    V3(Math.sin(a), 0, -Math.cos(a)),
    rand(0.04, 0.3)
  );

  for (let i = 0; i < 7; i++) {
    const angle = (i / 7) * Math.PI * 2 + rand(-0.1, 0.1);
    const m = makeFlowerMatrix(
      top,
      angle,
      rand(0.04, 0.17),
      budScale * rand(0.9, 1.08),
      headQuat
    );
    flowerPetalData.push({ matrix: m, color: budColor.clone() });
  }
  budStems.push({ matrix: stemMatrixBetween(start, mid, 0.022) });
  budStems.push({ matrix: stemMatrixBetween(mid, top, 0.02) });
  return true;
}

function buildLotus() {
  // Leaves and flowers are deliberately left-weighted: roughly 70% of the
  // planting sits in the left half of the pond, 30% in the right.
  const leftLeafClusters = [
    V2(-5.35, 0.15), V2(-3.2, -2.3), V2(-1.3, 3.75), V2(-3.25, 5.0),
    V2(-5.2, 4.2), V2(-6.2, -2.2), V2(-1.8, 5.8), V2(-4.2, -3.8),
  ];
  const rightLeafClusters = [
    V2(3.05, -1.85), V2(5.25, 1.2), V2(2.2, 3.65), V2(4.3, 4.2),
    V2(1.7, 6.05), V2(6.0, 3.8),
  ];

  function addLeafAt(x, z) {
    if (!pointInPond(x, z, 0.52)) return false;
    if (Math.hypot(x - ISLAND.x, z - ISLAND.y) < 1.9) return false;
    if (Math.abs(z - 4.8) < 1.12 && x < -3.0 && x > -7.3) return false;
    const raised = rng() < 0.43;
    const leafY = raised ? WATER_Y + rand(0.24, 0.92) : WATER_Y + 0.015;
    const s = raised ? rand(0.56, 0.98) : rand(0.55, 1.15);
    const m = new THREE.Matrix4().compose(
      V3(x, leafY, z),
      new THREE.Quaternion().setFromEuler(
        new THREE.Euler(rand(-0.16, 0.16), rand(0, Math.PI * 2), rand(-0.16, 0.16), 'YXZ')
      ),
      V3(s, s * rand(0.88, 1.12), s)
    );
    leafData.push({
      matrix: m.clone(),
      color: new THREE.Color(choose([0x92b58f, 0xa4c09e, 0x7fa17c, 0xb0cba7, 0xbfd5b4, 0x89aa86, 0xc8dcbc])),
    });
    leafMatrices.push(m);
    leafPhases.push(rand(0, Math.PI * 2));
    if (raised) {
      stemMatrices.push(new THREE.Matrix4().compose(
        V3(x, WATER_Y + (leafY - WATER_Y) / 2, z),
        new THREE.Quaternion(),
        V3(0.021, leafY - WATER_Y, 0.021)
      ));
    }
    return true;
  }

  function fillLeaves(side, target) {
    const clusters = side < 0 ? leftLeafClusters : rightLeafClusters;
    let placed = 0;
    let tries = 0;
    while (placed < target && tries < 1600) {
      const c = choose(clusters);
      let x = c.x + rand(-1.45, 1.45);
      x = side < 0 ? Math.min(-0.2, x) : Math.max(0.2, x);
      const z = c.y + rand(-1.2, 1.2);
      if (addLeafAt(x, z)) placed++;
      tries++;
    }
  }

  fillLeaves(-1, 105);
  fillLeaves(1, 45);

  const leftFlowerClusters = [
    V2(-6.1, 0.3), V2(-4.7, 1.1), V2(-3.0, -2.2), V2(-5.5, -2.6),
    V2(-2.0, 3.6), V2(-4.7, 3.8), V2(-5.4, 5.5), V2(-1.4, -4.1),
    V2(-3.5, 5.7), V2(-6.4, 3.0), V2(-1.1, 1.2),
  ];
  const rightFlowerClusters = [
    V2(3.5, -2.2), V2(5.5, 0.6), V2(3.6, 3.6), V2(5.9, 3.7),
    V2(1.5, -3.4), V2(6.2, -1.3),
  ];
  const poses = ['upright', 'bent', 'upright', 'drooping', 'halfOpen', 'bent', 'upright', 'drooping'];
  function fillFlowers(side, target, poseOffset) {
    const clusters = side < 0 ? leftFlowerClusters : rightFlowerClusters;
    let placed = 0;
    let tries = 0;
    while (placed < target && tries < 1800) {
      const c = choose(clusters);
      let x = c.x + rand(-1.25, 1.25);
      x = side < 0 ? Math.min(-0.18, x) : Math.max(0.18, x);
      const z = c.y + rand(-1.15, 1.15);
      if (addFlowerAt(x, z, poses[(placed + poseOffset) % poses.length])) placed++;
      tries++;
    }
  }
  fillFlowers(-1, 58, 0);
  fillFlowers(1, 24, 3);

  // A few clearly readable bent/drooping blossoms near the open front.
  addFlowerAt(-0.15, 5.45, 'drooping');
  addFlowerAt(-3.15, 5.35, 'bent');
  addFlowerAt(4.2, 4.9, 'halfOpen');
  addFlowerAt(5.6, 3.5, 'drooping');

  const leftBudClusters = [
    V2(-5.8, 0.2), V2(-3.0, -2.6), V2(-2.2, 3.1), V2(-5.0, 4.4),
    V2(-4.5, -3.7), V2(-6.2, 2.1), V2(-1.3, 5.2),
  ];
  const rightBudClusters = [
    V2(4.6, -1.7), V2(5.7, 2.3), V2(2.6, 4.7), V2(1.3, -0.8),
  ];
  function fillBuds(side, target) {
    const clusters = side < 0 ? leftBudClusters : rightBudClusters;
    let placed = 0;
    let tries = 0;
    while (placed < target && tries < 1000) {
      const c = choose(clusters);
      let x = c.x + rand(-1.1, 1.1);
      x = side < 0 ? Math.min(-0.15, x) : Math.max(0.15, x);
      const z = c.y + rand(-1.0, 1.0);
      if (addBudAt(x, z)) placed++;
      tries++;
    }
  }
  fillBuds(-1, 24);
  fillBuds(1, 10);

  // Instanced leaves. Volume comes from the cupped geometry and lighting.
  const leafMesh = new THREE.InstancedMesh(lotusLeafGeometry, lotusLeafMaterial, leafData.length);
  leafMesh.castShadow = true;
  leafMesh.receiveShadow = true;
  leafMesh.frustumCulled = false;
  for (let i = 0; i < leafData.length; i++) {
    leafMesh.setMatrixAt(i, leafData[i].matrix);
    leafMesh.setColorAt(i, leafData[i].color);
  }
  leafMesh.instanceMatrix.needsUpdate = true;
  if (leafMesh.instanceColor) leafMesh.instanceColor.needsUpdate = true;
  scene.add(leafMesh);

  const stemMesh = new THREE.InstancedMesh(stemGeometry, lotusStemMaterial, stemMatrices.length);
  stemMesh.castShadow = true;
  stemMesh.receiveShadow = true;
  stemMesh.frustumCulled = false;
  for (let i = 0; i < stemMatrices.length; i++) stemMesh.setMatrixAt(i, stemMatrices[i]);
  stemMesh.instanceMatrix.needsUpdate = true;
  scene.add(stemMesh);

  // Petals.
  const petalMesh = new THREE.InstancedMesh(petalGeometry, petalMeshMaterial, flowerPetalData.length);
  petalMesh.castShadow = false;
  petalMesh.receiveShadow = true;
  petalMesh.frustumCulled = false;
  for (let i = 0; i < flowerPetalData.length; i++) {
    petalMesh.setMatrixAt(i, flowerPetalData[i].matrix);
    petalMesh.setColorAt(i, flowerPetalData[i].color);
  }
  petalMesh.instanceMatrix.needsUpdate = true;
  if (petalMesh.instanceColor) petalMesh.instanceColor.needsUpdate = true;
  scene.add(petalMesh);

  const heartMesh = new THREE.InstancedMesh(flowerHeartGeometry, MAT.lotusHeart, flowerHearts.length);
  const heartRingMesh = new THREE.InstancedMesh(flowerHeartRingGeometry, MAT.lotusHeartDark, flowerHeartRings.length);
  heartMesh.castShadow = false;
  heartRingMesh.castShadow = false;
  heartMesh.frustumCulled = false;
  heartRingMesh.frustumCulled = false;
  for (let i = 0; i < flowerHearts.length; i++) {
    heartMesh.setMatrixAt(i, flowerHearts[i].matrix);
    heartRingMesh.setMatrixAt(i, flowerHeartRings[i].matrix);
  }
  heartMesh.instanceMatrix.needsUpdate = true;
  heartRingMesh.instanceMatrix.needsUpdate = true;
  scene.add(heartMesh);
  scene.add(heartRingMesh);

  const flowerStemMesh = new THREE.InstancedMesh(stemGeometry, lotusStemMaterial, flowerStems.length);
  flowerStemMesh.castShadow = true;
  flowerStemMesh.frustumCulled = false;
  for (let i = 0; i < flowerStems.length; i++) flowerStemMesh.setMatrixAt(i, flowerStems[i].matrix);
  flowerStemMesh.instanceMatrix.needsUpdate = true;
  scene.add(flowerStemMesh);

  const calyxGeometry = new THREE.ConeGeometry(0.32, 0.16, 7);
  calyxGeometry.translate(0, -0.015, 0);
  const calyxMesh = new THREE.InstancedMesh(calyxGeometry, lotusStemMaterial, flowerCalyxes.length);
  calyxMesh.frustumCulled = false;
  calyxMesh.castShadow = false;
  for (let i = 0; i < flowerCalyxes.length; i++) calyxMesh.setMatrixAt(i, flowerCalyxes[i].matrix);
  calyxMesh.instanceMatrix.needsUpdate = true;
  scene.add(calyxMesh);

  const budStemMesh = new THREE.InstancedMesh(stemGeometry, lotusStemMaterial, budStems.length);
  budStemMesh.frustumCulled = false;
  for (let i = 0; i < budStems.length; i++) budStemMesh.setMatrixAt(i, budStems[i].matrix);
  budStemMesh.instanceMatrix.needsUpdate = true;
  scene.add(budStemMesh);

  // A few petals floating on the water.
  const floatingGeometry = new THREE.CircleGeometry(0.09, 7);
  floatingGeometry.scale(1, 0.45, 1);
  const floatingData = [];
  for (let i = 0; i < 22; i++) {
    let x;
    let z;
    let ok = false;
    for (let tries = 0; tries < 30 && !ok; tries++) {
      x = rand(-6.5, 6.8);
      z = rand(-4.2, 4.6);
      ok = pointInPond(x, z, 0.6);
    }
    if (!ok) continue;
    floatingData.push({
      x, z,
      ry: rand(0, Math.PI * 2),
      s: rand(0.6, 1.2),
    });
  }
  const floatingMesh = new THREE.InstancedMesh(floatingGeometry, MAT.petalFloat, floatingData.length);
  const m = new THREE.Matrix4();
  for (let i = 0; i < floatingData.length; i++) {
    const d = floatingData[i];
    m.compose(
      V3(d.x, WATER_Y + 0.025, d.z),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(-Math.PI / 2, 0, d.ry)),
      V3(d.s, d.s, d.s)
    );
    floatingMesh.setMatrixAt(i, m);
  }
  floatingMesh.instanceMatrix.needsUpdate = true;
  floatingMesh.frustumCulled = false;
  floatingMesh.renderOrder = 3;
  scene.add(floatingMesh);

  return {
    leafMesh,
    flowerMeshes: [
      petalMesh,
      heartMesh,
      heartRingMesh,
      flowerStemMesh,
      calyxMesh,
      budStemMesh,
    ],
  };
}

const lotus = buildLotus();

// Gentle expanding rings make the water read as a surface, not a painted plane.
const rippleRings = [];
{
  const ringRoot = new THREE.Group();
  ringRoot.name = 'water-ripples';
  scene.add(ringRoot);
  const rippleCenters = [
    V2(-2.2, 1.1), V2(3.1, -1.4), V2(0.1, 3.6), V2(-4.7, 3.4),
    V2(5.0, 1.4), V2(-1.1, -2.4), V2(1.7, 4.8), V2(4.6, 4.4),
    V2(-5.4, 0.2), V2(2.6, 5.7),
  ];
  for (let i = 0; i < rippleCenters.length; i++) {
    const p = rippleCenters[i];
    if (!pointInPond(p.x, p.y, 0.4)) continue;
    const material = new THREE.MeshBasicMaterial({
      color: 0xd9f4e6,
      transparent: true,
      opacity: 0.2,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const geo = new THREE.RingGeometry(0.74, 0.8, 56);
    geo.rotateX(-Math.PI / 2);
    const mesh = new THREE.Mesh(geo, material);
    mesh.position.set(p.x, WATER_Y + 0.018, p.y);
    mesh.renderOrder = 3;
    mesh.userData.phase = i * 0.17 + rand(0, 0.2);
    mesh.userData.rate = rand(0.12, 0.2);
    mesh.userData.strength = rand(0.25, 0.42);
    ringRoot.add(mesh);
    rippleRings.push(mesh);
  }
}

// The static architecture, rocks and trunks are now merged by material.
// ---------------------------------------------------------------------------
// Classical floor lanterns (geometry baked, lights kept dynamic)
// ---------------------------------------------------------------------------

const floorLampLights = [];

function buildFloorLamp(x, z, baseY, scale = 1, withLight = true) {
  const group = new THREE.Group();
  group.name = 'classical-floor-lamp';
  group.position.set(x, baseY, z);
  group.scale.setScalar(scale);
  staticRoot.add(group);

  addCylinder(group, 0.25, 0.3, 0.13, 8, MAT.slabDark, 0, 0.065, 0);
  addCylinder(group, 0.055, 0.07, 0.88, 8, MAT.woodDark, 0, 0.58, 0);
  addCylinder(group, 0.2, 0.23, 0.075, 6, MAT.woodDark, 0, 1.02, 0);
  addCylinder(group, 0.155, 0.185, 0.45, 6, MAT.lampGlow, 0, 1.27, 0);
  addCylinder(group, 0.21, 0.23, 0.075, 6, MAT.woodDark, 0, 1.52, 0);
  addMesh(group, new THREE.ConeGeometry(0.27, 0.2, 6), MAT.roofDark, { y: 1.64 });
  addMesh(group, new THREE.SphereGeometry(0.045, 7, 5), MAT.gold, { y: 1.78 });

  // Thin wooden cage bars around the glowing paper.
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    addBox(
      group,
      0.016,
      0.43,
      0.016,
      MAT.woodDark,
      Math.cos(a) * 0.17,
      1.27,
      Math.sin(a) * 0.17,
      0,
      -a,
      0
    );
  }

  if (withLight) {
    floorLampLights.push({
      x,
      y: baseY + 1.28 * scale,
      z,
      color: 0xffb15a,
      intensity: 1.8,
      distance: 4.6,
    });
  }
  return group;
}

buildFloorLamp(7.45, -5.95, 1.05, 1.0);
buildFloorLamp(9.45, -8.05, 1.05, 1.0);
buildFloorLamp(-9.0, 1.75, 1.02, 0.92);
buildFloorLamp(2.2, -7.85, 1.02, 0.9);
buildFloorLamp(-10.3, 11.15, PAVE_TOP, 1.0);
buildFloorLamp(10.3, 11.15, PAVE_TOP, 1.0);

bakeStatic(staticRoot);

// The lamps are static geometry, but their warm light pools remain live.
const lampPointLights = [];
for (const spec of floorLampLights) {
  const light = new THREE.PointLight(spec.color, spec.intensity, spec.distance, 2);
  light.position.set(spec.x, spec.y, spec.z);
  light.castShadow = false;
  scene.add(light);
  lampPointLights.push(light);
}

// ---------------------------------------------------------------------------
// Koi and dragonflies — small moving details in the still garden
// ---------------------------------------------------------------------------

const faunaRoot = new THREE.Group();
faunaRoot.name = 'fauna';
scene.add(faunaRoot);

function makeKoi({ color, patch, scale = 1 }) {
  const group = new THREE.Group();
  const bodyMat = lit(color, {
    castShadow: false,
    receiveShadow: false,
    emissive: 0x3a1004,
    emissiveIntensity: 0.18,
  });
  const patchMat = lit(patch, { castShadow: false, receiveShadow: false });
  const finMat = lit(color, {
    side: THREE.DoubleSide,
    castShadow: false,
    receiveShadow: false,
    emissive: 0x2f0c02,
    emissiveIntensity: 0.16,
  });

  const body = addMesh(group, new THREE.SphereGeometry(1, 12, 8), bodyMat, {
    sx: 0.38, sy: 0.12, sz: 0.16,
  });
  body.scale.multiplyScalar(1);
  addMesh(group, new THREE.SphereGeometry(1, 10, 7), patchMat, {
    x: 0.06, y: 0.04, z: 0,
    sx: 0.24, sy: 0.09, sz: 0.14,
  });
  addMesh(group, new THREE.SphereGeometry(1, 8, 6), patchMat, {
    x: -0.18, y: 0.02, z: 0.04,
    sx: 0.12, sy: 0.08, sz: 0.12,
  });

  const tail = new THREE.Group();
  tail.position.x = -0.37;
  group.add(tail);
  addMesh(tail, new THREE.ConeGeometry(0.14, 0.36, 4), finMat, {
    x: -0.12,
    rz: Math.PI / 2,
    sz: 0.65,
  });
  addMesh(tail, new THREE.ConeGeometry(0.08, 0.22, 4), finMat, {
    x: -0.06, y: 0.04, rz: Math.PI / 2, sy: 0.6,
  });

  // Side and dorsal fins.
  for (const sz of [-1, 1]) {
    addMesh(group, new THREE.ConeGeometry(0.07, 0.22, 3), finMat, {
      x: 0.12,
      y: -0.02,
      z: sz * 0.16,
      rx: Math.PI / 2,
      rz: -Math.PI / 2,
      sy: 0.6,
    });
  }
  addMesh(group, new THREE.ConeGeometry(0.055, 0.18, 3), finMat, {
    x: 0.08, y: 0.11, rz: Math.PI, sz: 0.7,
  });

  // Eyes.
  for (const sz of [-1, 1]) {
    addMesh(group, new THREE.SphereGeometry(0.018, 6, 4), MAT.koiBlack, {
      x: 0.25, y: 0.035, z: sz * 0.1,
    });
  }

  group.scale.setScalar(scale);
  group.rotation.order = 'YXZ';
  faunaRoot.add(group);
  return { group, tail, bodyMat, baseColor: color };
}

function buildKoi() {
  const palettes = [
    { color: 0xe95634, patch: 0xffb36b, scale: 0.42 },
    { color: 0xf06a33, patch: 0xffd08c, scale: 0.38 },
    { color: 0xd9482b, patch: 0xffc477, scale: 0.4 },
    { color: 0xf28640, patch: 0xffe0a8, scale: 0.35 },
    { color: 0xe8a23e, patch: 0xffefc4, scale: 0.36 },
    { color: 0xcf4b28, patch: 0xffd7a5, scale: 0.33 },
    { color: 0xf05a32, patch: 0xffe6b8, scale: 0.34 },
  ];
  const paths = [
    { cx: -2.3, cz: 1.4, rx: 1.9, rz: 1.15, speed: 0.16, phase: 0.2, depth: 0.105 },
    { cx: 2.9, cz: -1.0, rx: 1.55, rz: 0.9, speed: -0.21, phase: 2.1, depth: 0.12 },
    { cx: -4.0, cz: -1.4, rx: 1.2, rz: 0.9, speed: 0.18, phase: 4.0, depth: 0.115 },
    { cx: 0.9, cz: 3.4, rx: 1.25, rz: 0.72, speed: -0.14, phase: 1.0, depth: 0.125 },
    { cx: -1.3, cz: -2.0, rx: 1.55, rz: 0.95, speed: 0.22, phase: 3.2, depth: 0.1 },
    { cx: 4.5, cz: 1.8, rx: 1.0, rz: 0.8, speed: -0.17, phase: 5.2, depth: 0.12 },
    { cx: 0.2, cz: -2.8, rx: 1.65, rz: 0.65, speed: 0.2, phase: 2.6, depth: 0.11 },
  ];

  const koi = [];
  for (let i = 0; i < palettes.length; i++) {
    const fish = makeKoi(palettes[i]);
    const p = paths[i];
    fish.path = p;
    fish.phase = p.phase;
    fish.group.position.y = WATER_Y - p.depth;
    koi.push(fish);
  }
  return koi;
}

const koiFish = buildKoi();

function makeDragonfly(scale = 1) {
  const group = new THREE.Group();
  addMesh(group, new THREE.CylinderGeometry(0.012, 0.021, 0.31, 6), MAT.dragonBody, {
    rx: Math.PI / 2,
  });
  addMesh(group, new THREE.SphereGeometry(0.035, 7, 5), MAT.dragonBody, {
    z: 0.17, sx: 1.2, sy: 0.8, sz: 1.1,
  });
  addMesh(group, new THREE.CylinderGeometry(0.006, 0.012, 0.24, 5), MAT.dragonBody, {
    z: -0.25, rx: Math.PI / 2,
  });

  const wings = [];
  for (const sz of [-1, 1]) {
    for (let i = 0; i < 2; i++) {
      const pivot = new THREE.Group();
      pivot.position.set(0, 0.015, i === 0 ? 0.08 : -0.02);
      pivot.rotation.y = sz * (0.55 + i * 0.16);
      group.add(pivot);
      const wing = addMesh(
        pivot,
        new THREE.PlaneGeometry(0.29, 0.075),
        MAT.dragonWing,
        { x: sz * 0.145, rx: -Math.PI / 2, z: 0.0 }
      );
      wing.renderOrder = 4;
      wings.push({ pivot, side: sz });
    }
  }
  group.scale.setScalar(scale);
  group.rotation.order = 'YXZ';
  faunaRoot.add(group);
  return { group, wings };
}

const dragonflies = [
  { ...makeDragonfly(0.9), center: V3(0.5, 1.55, 1.0), radius: 0.85, h: 1.15, speed: 0.62, phase: 0 },
  { ...makeDragonfly(0.72), center: V3(-4.65, 1.0, 2.9), radius: 0.55, h: 0.9, speed: 0.83, phase: 2.2 },
  { ...makeDragonfly(0.8), center: V3(4.05, 1.32, 3.1), radius: 0.7, h: 1.05, speed: 0.48, phase: 4.4 },
];

// Capture the finished courtyard once into a cube map. The physical water
// material uses this for soft, real reflections of the wall, roof and lotus.
function captureWaterEnvironment() {
  if (!waterMesh) return;
  const cubeTarget = new THREE.WebGLCubeRenderTarget(256, {
    generateMipmaps: true,
    minFilter: THREE.LinearMipmapLinearFilter,
  });
  const cubeCamera = new THREE.CubeCamera(0.25, 90, cubeTarget);
  cubeCamera.position.set(0, 1.7, 0.4);
  scene.add(cubeCamera);

  const waterVisible = waterMesh.visible;
  const reflectorVisible = waterReflector ? waterReflector.visible : false;
  const ringVisibility = rippleRings.map((r) => r.visible);
  waterMesh.visible = false;
  if (waterReflector) waterReflector.visible = false;
  for (const r of rippleRings) r.visible = false;
  cubeCamera.update(renderer, scene);
  waterMesh.visible = waterVisible;
  if (waterReflector) waterReflector.visible = reflectorVisible;
  for (let i = 0; i < rippleRings.length; i++) rippleRings[i].visible = ringVisibility[i];

  waterMaterial.envMap = cubeTarget.texture;
  waterMaterial.envMapIntensity = 0.95;
  waterMaterial.needsUpdate = true;
  MAT.gold.envMap = cubeTarget.texture;
  MAT.gold.envMapIntensity = 0.65;
  MAT.gold.needsUpdate = true;
  scene.remove(cubeCamera);
}

captureWaterEnvironment();

const leafBaseX = leafMatrices.map((m) => m.elements[12]);
const leafBaseY = leafMatrices.map((m) => m.elements[13]);
const leafBaseZ = leafMatrices.map((m) => m.elements[14]);
const leavesMesh = lotus.leafMesh;
const flowerSwayMeshes = lotus.flowerMeshes;

// ---------------------------------------------------------------------------
// Render loop
// ---------------------------------------------------------------------------

const clock = new THREE.Clock();
let elapsed = 0;
let frame = 0;
let weatherTarget = 0;
let weatherMix = 0;

const windEuler = new THREE.Euler();
const windQuat = new THREE.Quaternion();
const willowSwayQuat = new THREE.Quaternion();
const willowMatrix = new THREE.Matrix4();

function updateWillowSway(time) {
  const weatherBoost = 1 + weatherMix * 1.45;
  const weatherSpeed = 1 + weatherMix * 0.55;
  for (let i = 0; i < willowFronds.length; i++) {
    const f = willowFronds[i];
    const speed = f.swaySpeed * weatherSpeed;
    const sway = Math.sin(time * speed + f.phase) * f.sway * weatherBoost
      + Math.sin(time * speed * 1.33 + f.phase * 1.2) * f.sway * 0.26 * weatherBoost;
    windEuler.set(sway * 0.18, 0, sway, 'XYZ');
    windQuat.setFromEuler(windEuler);
    // World-space wind: all fronds lean and sway roughly the same way.
    willowSwayQuat.copy(windQuat).multiply(f.quaternion);
    willowMatrix.compose(f.position, willowSwayQuat, f.scale);
    willowMesh.setMatrixAt(i, willowMatrix);
  }
  willowMesh.instanceMatrix.needsUpdate = true;
}

// ---------------------------------------------------------------------------
// Rain, weather transition and the two umbrella walkers
// ---------------------------------------------------------------------------

const RAIN_COUNT = 700;
const RAIN_TOP = 19;
const RAIN_FLOOR = PAVE_TOP + 0.04;
const rainX = new Float32Array(RAIN_COUNT);
const rainY = new Float32Array(RAIN_COUNT);
const rainZ = new Float32Array(RAIN_COUNT);
const rainLengths = new Float32Array(RAIN_COUNT);
const rainSpeeds = new Float32Array(RAIN_COUNT);
const rainDriftX = new Float32Array(RAIN_COUNT);
const rainDriftZ = new Float32Array(RAIN_COUNT);
const rainPositions = new Float32Array(RAIN_COUNT * 6);
const rainGeometry = new THREE.BufferGeometry();
rainGeometry.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
const rainMaterial = new THREE.LineBasicMaterial({
  color: 0xd2dde4,
  transparent: true,
  opacity: 0,
  depthWrite: false,
});
rainMaterial.userData.castShadow = false;
const rainSystem = new THREE.LineSegments(rainGeometry, rainMaterial);
rainSystem.name = 'drizzle';
rainSystem.frustumCulled = false;
rainSystem.renderOrder = 4;
rainSystem.visible = false;
scene.add(rainSystem);

function seedRainDrop(i, high = false) {
  rainX[i] = rand(-12.6, 12.6);
  rainY[i] = high ? rand(9, RAIN_TOP) : rand(RAIN_FLOOR + 1, RAIN_TOP);
  rainZ[i] = rand(-12.6, 12.6);
  rainLengths[i] = rand(0.1, 0.27);
  rainSpeeds[i] = rand(14, 23);
  rainDriftX[i] = rand(0.7, 1.6);
  rainDriftZ[i] = rand(0.12, 0.4);
}

for (let i = 0; i < RAIN_COUNT; i++) seedRainDrop(i);

function updateRain(dt) {
  for (let i = 0; i < RAIN_COUNT; i++) {
    rainX[i] += rainDriftX[i] * dt;
    rainY[i] -= rainSpeeds[i] * dt;
    rainZ[i] += rainDriftZ[i] * dt;
    if (rainY[i] < RAIN_FLOOR + rainLengths[i]) {
      rainX[i] = rand(-12.6, 12.6);
      rainY[i] = rand(9, RAIN_TOP);
      rainZ[i] = rand(-12.6, 12.6);
    }
    if (rainX[i] > 12.9) rainX[i] -= 25.8;
    if (rainX[i] < -12.9) rainX[i] += 25.8;
    if (rainZ[i] > 12.9) rainZ[i] -= 25.8;
    if (rainZ[i] < -12.9) rainZ[i] += 25.8;

    const j = i * 6;
    rainPositions[j] = rainX[i];
    rainPositions[j + 1] = rainY[i];
    rainPositions[j + 2] = rainZ[i];
    rainPositions[j + 3] = rainX[i] - rainDriftX[i] * 0.027;
    rainPositions[j + 4] = rainY[i] - rainLengths[i];
    rainPositions[j + 5] = rainZ[i] - rainDriftZ[i] * 0.027;
  }
  rainGeometry.attributes.position.needsUpdate = true;
}

const CLEAR_SUN = new THREE.Color(0xffb366);
const RAIN_SUN = new THREE.Color(0x8296a8);
const CLEAR_AMBIENT = new THREE.Color(0xffd7ac);
const RAIN_AMBIENT = new THREE.Color(0x9db1c2);
const CLEAR_HEMI = new THREE.Color(0xffd5b2);
const RAIN_HEMI = new THREE.Color(0x9eafc0);
const CLEAR_GROUND = new THREE.Color(0x6f685a);
const RAIN_GROUND = new THREE.Color(0x647078);
const CLEAR_FOG = new THREE.Color(0xb28a82);
const RAIN_FOG = new THREE.Color(0x8797a2);
const CLEAR_FILL = new THREE.Color(0xaab9cd);
const RAIN_FILL = new THREE.Color(0x8ea2b3);

function updateWeather(dt) {
  const approach = 1 - Math.exp(-dt * 1.9);
  weatherMix += (weatherTarget - weatherMix) * approach;
  if (Math.abs(weatherTarget - weatherMix) < 0.0015) weatherMix = weatherTarget;
  const ease = weatherMix * weatherMix * (3 - 2 * weatherMix);

  sun.color.copy(CLEAR_SUN).lerp(RAIN_SUN, ease);
  sun.intensity = 3.35 + (1.35 - 3.35) * ease;
  ambient.color.copy(CLEAR_AMBIENT).lerp(RAIN_AMBIENT, ease);
  ambient.intensity = 0.46 + (0.25 - 0.46) * ease;
  hemi.color.copy(CLEAR_HEMI).lerp(RAIN_HEMI, ease);
  hemi.groundColor.copy(CLEAR_GROUND).lerp(RAIN_GROUND, ease);
  hemi.intensity = 0.3 + (0.22 - 0.3) * ease;
  fillLight.color.copy(CLEAR_FILL).lerp(RAIN_FILL, ease);
  fillLight.intensity = 0.15 + (0.22 - 0.15) * ease;
  scene.fog.color.copy(CLEAR_FOG).lerp(RAIN_FOG, ease);
  renderer.toneMappingExposure = 1.1 + (0.9 - 1.1) * ease;

  MAT.lampGlow.emissiveIntensity = 2.1 + 4.2 * ease;
  for (const light of lampPointLights) {
    light.intensity = 1.8 + 4.8 * ease;
  }
  bloomPass.strength = 0.56 + 0.2 * ease;

  rainMaterial.opacity = 0.22 * ease;
  rainSystem.visible = ease > 0.008;
  if (rainSystem.visible) updateRain(dt);
  scene.backgroundIntensity = 1 - 0.55 * ease;
  cloudDome.material.color.setScalar(1 - 0.3 * ease);
}

// ---------------------------------------------------------------------------
// Two tiny ladies with oil-paper umbrellas
// ---------------------------------------------------------------------------

const walkPath = new THREE.CatmullRomCurve3([
  V3(-8.85, 1.02, 9.8),
  V3(-8.55, 0.9, 10.15),
  V3(-7.95, 0.34, 10.45),
  V3(-6.8, 0.34, 10.55),
  V3(-5.4, 0.34, 10.5),
  V3(-4.0, 0.34, 10.45),
  V3(-2.4, 0.34, 10.4),
  V3(-0.8, 0.34, 10.3),
  V3(0.9, 0.34, 10.2),
], false, 'catmullrom', 0.36);

function makeLady(dressColor, accentColor, umbrellaColor) {
  const group = new THREE.Group();
  group.name = 'umbrella-lady';
  group.visible = false;

  const dressMat = lit(dressColor, { roughness: 0.9, castShadow: false, receiveShadow: true });
  const accentMat = lit(accentColor, { roughness: 0.88, castShadow: false, receiveShadow: true });
  const skinMat = lit(0xe7c8ad, { roughness: 0.9, castShadow: false, receiveShadow: true });
  const hairMat = lit(0x332625, { roughness: 0.94, castShadow: false, receiveShadow: true });

  addMesh(group, new THREE.ConeGeometry(0.27, 0.58, 10), dressMat, { y: 0.29 });
  addCylinder(group, 0.1, 0.14, 0.4, 8, dressMat, 0, 0.76, 0);
  addCylinder(group, 0.145, 0.16, 0.07, 8, accentMat, 0, 0.64, 0);
  addMesh(group, new THREE.SphereGeometry(0.105, 12, 8), skinMat, { y: 1.06 });
  addMesh(group, new THREE.SphereGeometry(0.118, 10, 7), hairMat, {
    y: 1.1, z: -0.018, sx: 1.02, sy: 0.9, sz: 1.02,
  });
  addMesh(group, new THREE.SphereGeometry(0.055, 8, 6), hairMat, { y: 1.19, z: -0.06 });
  for (const sx of [-1, 1]) {
    addCylinder(group, 0.028, 0.034, 0.33, 6, dressMat, sx * 0.15, 0.8, 0.01, 0, 0, sx * 0.2);
  }

  const umbrella = new THREE.Group();
  group.add(umbrella);
  const canopyMat = lit(umbrellaColor, {
    transparent: true,
    opacity: 0.56,
    side: THREE.DoubleSide,
    depthWrite: false,
    roughness: 0.76,
    castShadow: false,
    receiveShadow: false,
  });
  addMesh(umbrella, new THREE.ConeGeometry(0.52, 0.16, 16, 1, false), canopyMat, { y: 1.78 });
  addMesh(umbrella, new THREE.TorusGeometry(0.5, 0.012, 5, 24), accentMat, {
    y: 1.7, rx: Math.PI / 2,
  });
  addCylinder(umbrella, 0.011, 0.011, 0.9, 5, MAT.woodDark, 0, 1.27, 0);
  addMesh(umbrella, new THREE.SphereGeometry(0.04, 7, 5), MAT.gold, { y: 1.93 });

  const shadow = addMesh(group, new THREE.CircleGeometry(0.26, 16), new THREE.MeshBasicMaterial({
    color: 0x2b201c,
    transparent: true,
    opacity: 0.16,
    depthWrite: false,
  }), { y: 0.012, rx: -Math.PI / 2 });
  shadow.renderOrder = 1;

  return { group, umbrella, shadow };
}

const walkers = [
  { ...makeLady(0x7ba4b8, 0xe0cba7, 0xefd3a4), lane: -0.28, speed: 0.055, phase: 0.0 },
  { ...makeLady(0xd6a1a3, 0xecd8b6, 0xf0d9ad), lane: 0.28, speed: 0.04, phase: 1.4 },
];
for (const w of walkers) {
  w.u = 0;
  scene.add(w.group);
}
let walkActive = false;

function startWalk() {
  walkActive = true;
  for (const w of walkers) {
    w.u = 0;
    w.group.visible = true;
  }
}

function updateWalkers(dt, time) {
  if (!walkActive) return;
  let moving = false;
  for (const w of walkers) {
    if (w.u < 1) {
      w.u = Math.min(1, w.u + dt * w.speed);
      moving = true;
    }
    const p = walkPath.getPointAt(w.u);
    const tangent = walkPath.getTangentAt(w.u);
    p.x += -tangent.z * w.lane;
    p.z += tangent.x * w.lane;
    const bob = Math.sin(time * 6.2 + w.phase) * 0.028;
    w.group.position.set(p.x, p.y + bob, p.z);
    w.group.rotation.y = Math.atan2(tangent.x, tangent.z);
    w.group.rotation.z = Math.sin(time * 1.8 + w.phase) * 0.015;
    w.umbrella.rotation.z = Math.sin(time * 1.4 + w.phase) * 0.025;
    w.umbrella.rotation.x = Math.sin(time * 1.1 + w.phase) * 0.018;
  }
  if (!moving) walkActive = false;
}

const rainButton = document.getElementById('btn-rain');
const walkButton = document.getElementById('btn-walk');
const rainTint = document.getElementById('rain-tint');

function setWeather(on) {
  weatherTarget = on ? 1 : 0;
  if (rainButton) {
    rainButton.classList.toggle('is-active', on);
    rainButton.setAttribute('aria-pressed', on ? 'true' : 'false');
  }
  if (rainTint) rainTint.classList.toggle('is-rainy', on);
}

if (rainButton) {
  rainButton.addEventListener('click', () => setWeather(weatherTarget < 0.5));
}
if (walkButton) {
  walkButton.addEventListener('click', () => startWalk());
}

function animate() {
  const dt = Math.min(clock.getDelta(), 0.05);
  elapsed += dt;

  updateWeather(dt);

  waterNormalTexture.offset.x = elapsed * 0.016;
  waterNormalTexture.offset.y = elapsed * 0.009;
  cloudDome.rotation.y = 0.45 + elapsed * 0.006;

  for (const ring of rippleRings) {
    const cycle = (elapsed * ring.userData.rate + ring.userData.phase) % 1;
    ring.scale.setScalar(0.32 + cycle * 2.3);
    ring.material.opacity = Math.pow(1 - cycle, 1.8) * ring.userData.strength;
  }

  // Leaves breathe with the water; the rain increases both amplitude and tempo.
  const leafBoost = 1 + weatherMix * 2.1;
  const leafSpeed = 1 + weatherMix * 0.85;
  for (let i = 0; i < leafMatrices.length; i++) {
    const bob = Math.sin(elapsed * 0.9 * leafSpeed + leafPhases[i]) * 0.009 * leafBoost
      + Math.sin(elapsed * 1.7 * leafSpeed + leafPhases[i] * 1.8) * 0.003 * leafBoost;
    const xSway = Math.sin(elapsed * 1.05 * leafSpeed + leafPhases[i] * 1.3) * 0.004 * leafBoost;
    leafMatrices[i].elements[12] = leafBaseX[i] + xSway;
    leafMatrices[i].elements[13] = leafBaseY[i] + bob;
    leafMatrices[i].elements[14] = leafBaseZ[i] + xSway * 0.55;
    leavesMesh.setMatrixAt(i, leafMatrices[i]);
  }
  leavesMesh.instanceMatrix.needsUpdate = true;

  // Flower heads drift together on the same breeze, more strongly in rain.
  const flowerTime = elapsed * (1 + weatherMix * 0.6) * 1.15;
  const flowerAmp = 0.006 + weatherMix * 0.018;
  const flowerSway = Math.sin(flowerTime) * flowerAmp
    + Math.sin(flowerTime * 2.2 + 0.7) * flowerAmp * 0.35;
  for (const mesh of flowerSwayMeshes) {
    mesh.position.x = flowerSway;
    mesh.position.z = flowerSway * 0.42;
  }

  // Wind moves each willow frond independently, with its own phase and speed.
  updateWillowSway(elapsed);

  // Koi swim slow ellipses beneath the surface.
  for (const fish of koiFish) {
    const p = fish.path;
    const a = elapsed * p.speed + fish.phase;
    const x = p.cx + Math.cos(a) * p.rx;
    const z = p.cz + Math.sin(a) * p.rz;
    const dx = -Math.sin(a) * p.rx * p.speed;
    const dz = Math.cos(a) * p.rz * p.speed;
    fish.group.position.set(
      x,
      WATER_Y - p.depth + Math.sin(a * 2.4) * 0.012,
      z
    );
    fish.group.rotation.y = -Math.atan2(dz, dx);
    fish.group.rotation.z = Math.sin(a * 2 + fish.phase) * 0.035;
    fish.tail.rotation.y = Math.sin(elapsed * 4.2 + fish.phase) * 0.24;
  }

  for (const d of dragonflies) {
    const a = elapsed * d.speed + d.phase;
    const x = d.center.x + Math.cos(a) * d.radius;
    const z = d.center.z + Math.sin(a * 1.35) * d.radius;
    d.group.position.set(
      x,
      d.center.y + Math.sin(a * 2.2 + 0.8) * 0.14,
      z
    );
    d.group.rotation.y = -Math.atan2(
      -Math.sin(a) * d.radius * d.speed,
      Math.cos(a * 1.35) * 1.35 * d.radius * d.speed
    );
    d.group.rotation.z = Math.sin(elapsed * 2.6 + d.phase) * 0.05;
    for (const wing of d.wings) {
      wing.pivot.rotation.z = wing.side * (0.08 + Math.sin(elapsed * 22 + d.phase) * 0.13);
    }
  }

  updateWalkers(dt, elapsed);

  controls.update();
  composer.render();
  frame++;
  if (frame === 3) {
    // The garden itself is static; freezing the shadow map keeps the frame
    // budget low while preserving all of the directional-light layering.
    renderer.shadowMap.autoUpdate = false;
    document.documentElement.dataset.sceneReady = '1';
  }
}

renderer.setAnimationLoop(animate);

function onResize() {
  const aspect = window.innerWidth / window.innerHeight;
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  renderer.setPixelRatio(dpr);
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = aspect;
  camera.fov = aspect < 0.92 ? 48 : 42;
  camera.updateProjectionMatrix();
  composer.setPixelRatio(dpr);
  composer.setSize(window.innerWidth, window.innerHeight);
  bloomPass.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.needsUpdate = true;
}

window.addEventListener('resize', onResize, { passive: true });
window.addEventListener('orientationchange', onResize, { passive: true });
