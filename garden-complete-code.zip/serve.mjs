// Minimal development server for the editable module version.
// Usage: node serve.mjs  ->  http://127.0.0.1:8123
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';

const root = resolve('.');
const port = Number(process.env.PORT || 8123);
const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.css': 'text/css; charset=utf-8',
};

createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host}`);
    let path = decodeURIComponent(url.pathname);
    if (path === '/' || path === '') path = '/index.html';
    const absolute = normalize(join(root, path));
    if (!absolute.startsWith(root)) throw new Error('Forbidden');
    const info = await stat(absolute);
    if (!info.isFile()) throw new Error('Not a file');
    const body = await readFile(absolute);
    res.writeHead(200, {
      'Content-Type': mime[extname(absolute).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-store',
      'Content-Length': body.byteLength,
    });
    res.end(body);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }
}).listen(port, '127.0.0.1', () => {
  console.log(`Shangyuan lantern fair: http://127.0.0.1:${port}`);
});
