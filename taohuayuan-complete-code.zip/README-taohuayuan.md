# 桃花源 · PBR 微缩春日山水

一个纯 Three.js 的国风微缩场景：方形木石地台、青翠群山、左侧飞瀑、蜿蜒溪流、桃花林、石板路、半山古亭、暖黄石灯笼，以及右侧一株巨大的主桃树和垂落的红绸。画面使用 PBR 材质、程序化环境光照、ACES 色调映射、EffectComposer 柔焦景深与 UnrealBloom 柔光；页面底部提供【落英缤纷】与【雨后初霁】两个古风交互按钮。

![桃花源预览](taohuayuan-preview.png)

竖屏取景见 [taohuayuan-mobile.png](taohuayuan-mobile.png)，雨后彩虹效果见 [taohuayuan-rain.png](taohuayuan-rain.png)。

## 直接观看

双击打开 **[`taohuayuan.html`](taohuayuan.html)** 即可。

这是单文件版本：Three.js r169、OrbitControls、全部场景代码与程序化贴图都内嵌其中，不需要联网，也不需要本地服务器。

- 左键拖拽：旋转
- 滚轮 / 双指：缩放
- 右键 / 平移：已关闭
- 页面底部按钮：【落英缤纷】风起花落；【雨后初霁】太阳雨与彩虹（再次点击关闭）

## 本次调整

- **从 Toon 转 PBR**：主体材质改为 `MeshStandardMaterial` / `MeshPhysicalMaterial`，加入程序化 PMREM 环境光、ACES 色调映射、粗糙度与凹凸细节，取消描边和硬色阶。
- **构图重排**：瀑布整体左移到 `FALL_X = -2.35`，溪流源头同步左摆；右侧由一棵超大型主桃树压住画面重心，瀑布与主树之间保留呼吸空间。
- **主树与红绸**：主树高约 5.9、冠幅约 3.5，12 根主枝、3 级细枝；6 条姻缘红绸从枝桠垂落，使用 **21×46 顶点网格（20×45 个四边形）** 实时更新布料波浪、边缘褶皱与扭转，`MeshPhysicalMaterial` 的 sheen 近似绒面织物高光，`DoubleSide` 保证翻面不黑，象征姻缘。
- **树冠细分**：不再使用圆柱/大球体做树冠。每棵树由中央大裂片、六片环向裂片、下层外扩裂片和顶部侧裂片组成多裂片圆顶；再叠加小尺度花团、主花瓣卡片、枝干花套、垂落花枝、顶部散花和独立叶片。主树约 8,000 张基础花瓣卡片、1,900 片叶卡，小型树约 1,100 张花卡、290 片叶卡；冠幅加宽约 6%，轮廓连续、没有方顶，上半部枝条基本被花云遮住。
- **多尺寸变体**：1 棵超大型主树、4 棵大型、7 棵中型、14 棵小型，共 26 棵；右侧 17 棵、左侧 9 棵。每棵树的裂片、枝干数、冠幅、花色族、倾斜与枝序都由独立种子生成，避免同款复制堆叠。小型树减少到 4 根主枝、1 级细枝，避免小树过于杂乱。
- **成团布局**：26 棵树不再沿地台边缘均匀散点，而是收成三组——右侧围绕主树的浓密花林、左侧围绕古亭的花林、后山脚下的小花簇；中央水面、石板路与前景草地保留为空白，形成更明确的疏密关系。
- **枝干弯折**：主枝和细枝都改为 3–6 段 Catmull-Rom 曲线折段，带侧向 S 弯、端部下垂和由粗到细的锥度；枝基重新落在弯曲主干上，避免枝干与主干脱节。主干也增加了横向扭折，整体枝态更接近参考图的虬曲桃树。
- **粉色层次**：花色族扩充为深玫瑰、亮粉、柔粉、浅粉、洋红和近白六族；大多数中小型树偏向深粉/亮粉，少量浅粉树保留呼吸感。主树固定为亮粉色族，粉色比上一版更显著。
- **强烈冷暖光比**：主光提高到 6.0，并移到方形地台**正后上方**（沿相机视线对齐地台中心：光源 `x=-24, y=26, z=-22`，视觉太阳 `x=-24, y=12.5, z=-55.5`），使用饱和暖黄 `0xffd34f`；环境/背光改为冷蓝 `0xa0c0ff`，半球光 0.3、蓝色补光 0.6、冷蓝环境填充 0.45、环境光 0.012。树冠受光面偏暖黄粉，背光面落下冷蓝暗粉，投影朝前。
- **柔和阴影**：`sunLight.castShadow = true`，2048 PCFSoft 阴影贴图、shadow radius 2.0；静态阴影在前 8 帧后冻结，树影明显但不死黑。
- **自然粉蓝天空**：天空球与 IBL 同步换色——顶部雾蓝 `#679fd4`、中段浅蓝 `#9fcbe9`、地平线蜜桃粉 `#ffc6c9`、低空玫瑰粉 `#f9bec7`、最底部奶油暖橙 `#ffd3b8`；厚白云降低不透明度，新增 8 条横向薄云丝，把蓝天空与粉橙地平线柔化融合。背景色与雾色也同步偏蓝粉。
- **无断层过渡**：五段天空色改用相互重叠的 `smootherstep` 混合，并在最终调色 Pass 加入 1/255 级抖动，消除大面积渐变的色带。
- **色调映射**：`renderer.toneMapping = THREE.ACESFilmicToneMapping`，场景在线性 HDR RenderTarget 中保持线性，最后由 `OutputPass` 统一做 ACES + sRGB，避免二次色调映射。
- **电影感后处理**：`EffectComposer` 依次执行 `RenderPass → DofPass → UnrealBloomPass → OutputPass → ShaderPass`。Bloom 参数为强度 0.8、半径 0.8、阈值 0.85，让阳光、瀑布水花与浅色花瓣出现明显但柔和的泛光；最后一道 ShaderPass 做对比、饱和和暗角。
- **景深**：`DofPass` 读取 RenderTarget 的深度纹理，12 采样按 CoC 柔焦；对焦距离跟随相机到 Orbit 目标的距离，横屏和竖屏都不会把主体整体虚化。
- **丁达尔光**：在阳光斜角方向布置 3 片极低透明度的暖白 Plane，始终朝向相机，模拟阳光穿过桃林的光束；材质不写深度，不会遮住场景。
- **水景**：瀑布与溪流各自使用独立 Shader；溪水增加程序化焦散亮网、折射错位色边、高频闪点、岸缘泡沫与落花倒影；另叠 260 个水面星芒 Points、42 片浮光，瀑底有 140 个水花粒子、扩散水环和水雾。
- **落花与飘花**：地面落花从 6,200 片增至 12,000 片，空中花瓣雨从 920 片增至 2,600 片，水面浮花从 110 片增至 180 片；花瓣颜色加入暖白、浅粉和深粉层次。
- **【落英缤纷】风起花落**：点击后风场强度平滑升至 1。树冠在顶点着色器中按实例世界坐标取相位，以低频 `sin` 波轻微左右摆动，树干保持不动；红绸以 21×46 顶点逐帧更新：顶部金环固定，越往下越向右倾斜，同时叠加低频 S 形长波、两组布面褶皱和边缘小幅翻卷，最后重新计算法线；整体仍是缓慢向右舒展再回摆。花瓣雨为 2,600 片，风起时下落加快并叠加 +X / 轻微 -Z 风位移。
- **【雨后初霁】太阳雨与彩虹**：点击后淡入 750 条极淡灰白雨丝与 4 道半圆彩虹；雨丝用动态 `LineSegments` 更新，长度缩短、整体透明度约 0.3；彩虹用 `TorusGeometry(..., Math.PI)` 构造红、黄、绿、蓝四层细圆环，颜色抬到 HDR 亮度并保留普通混合。彩虹在 2.6s 内只做 opacity 0 → 0.6 的渐显，保持固定大小，不放大缩小；雨天空色通过 `skyMaterial.uniforms.uRain` 做更明显的压暗与偏蓝，但主光完全不改暗，仍是暖黄太阳雨。再次点击时雨丝、彩虹与蓝色天色一起平滑淡出。

## 场景内容

- **方形地台**：深胡桃木底座、浅米色石壁、金色嵌线、四角包铜，顶部由木框收住土地边缘，地台外是低垂云海。
- **地形**：后方两座主峰、左侧配峰与半山平台；山体表面有细碎起伏和顶点色花瓣斑块，坡面、池塘、溪岸分别做了地形压低。
- **瀑布与溪流**：左侧山坳有三级水练、湿黑崖壁、瀑底深潭、白色水环与水雾；溪流从潭口蜿蜒到正面，水面有流动波纹、焦散、浮光、岸缘泡沫与落花倒影。
- **桃林**：26 棵分层桃树，主树在右，其余大、中、小树错落分布在坡地、路旁与后山；树冠由多裂片花团、花瓣卡片和叶片卡片组成，近看是细碎花瓣，远看是完整树冠。
- **姻缘红绸**：主树 6 条红绸从不同高度的枝桠垂落，金色环扣固定，风场使绸面产生 S 形摆动、扭转和布料褶皱；红绸不冻结阴影，不投射静态脏影。
- **地面**：嫩绿草坡、草丛、野花、青灰岸石、苔藓、灌木，以及约 12,000 片实例化落花和地形顶点色中的粉色花瓣斑块。
- **石板路与古亭**：不规则石板沿山坡抬升，尽头是半山石台与四柱攒尖古亭；屋顶沿四坡排布 468 根圆柱瓦垄，青灰瓦面带微弱高光。
- **石灯笼**：沿路 5 座，暖黄自发光与 PointLight 有呼吸变化。
- **动态**：三层瀑布水幕、溪水流光、瀑底水环、2,600 片半透明花瓣雨、180 片水面浮花、水雾缓移、灯笼呼吸、红绸风动；点击按钮后追加树冠风摆、花瓣风舞、太阳雨与彩虹。
- **天空**：雾蓝顶部过渡到浅蓝、蜜桃粉与奶油暖橙，厚白云降低不透明度，并叠加横向薄云丝；暖日位于地台正后上方并落在画面上方中央。下雨时天空单独压暗、偏蓝，主光与太阳 Sprite 保持原亮度。

## 渲染与性能

- **PBR 与环境光**：`MeshStandardMaterial` / `MeshPhysicalMaterial`；程序化 equirectangular 画布经 PMREM 生成 IBL；木材、石材、花瓣、树叶、树皮凹凸与地面凹凸均为运行时 Canvas 纹理，没有外部图片。
- **光照**：太阳 `DirectionalLight` 6.0（饱和暖黄 0xffd34f），位于方形地台正后方上方，并按相机视线对齐中心；半球光 0.3（冷蓝天空 / 暖粉地面），蓝色背光 0.6、冷蓝前补 0.45、环境光 0.012，环境贴图强度 0.28，曝光 0.86；暖主光与冷补光形成明显的受光/背光分离。
- **阴影**：2048 PCFSoft，shadow radius 2.0、`normalBias` 0.026 控制细枝/花瓣自阴影；静态阴影在前 8 帧后冻结，避免每帧重绘。
- **后处理**：`EffectComposer` + `RenderPass` + `UnrealBloomPass` + `OutputPass` + 调色 ShaderPass。Bloom 强度 0.8、半径 0.8、阈值 0.85；场景先写入带 DepthTexture 的 HalfFloat HDR 目标，最后统一 ACES + sRGB，避免双重色调映射。
- **景深**：`DofPass` 读取深度纹理，12 采样按 CoC 柔焦；对焦距离跟随相机到 Orbit 目标的距离。
- **合批**：树冠花团、花瓣卡片、叶片卡片、落花、花瓣雨、瓦垄、草丛、石块等均使用 `InstancedMesh`；红绸为 6 个独立布料网格（每条 21×46 顶点），逐帧更新顶点、法线和双面材质。
- **实测**：晴天场景通道约 **443 个 draw call / 1.12M 个三角面 / 400 个点精灵**；开启雨后追加 1 个雨丝 draw 与 4 个彩虹 draw，花瓣雨为 2,600 个实例。后处理链约增加十余个全屏 draw，并复用同一张深度纹理。
- **像素比**：`min(max(devicePixelRatio, 1.15), 1.25)`，兼顾高分屏清晰度和泛光/景深的填充率。
- **UI**：底部两个按钮位于固定层 `z-index: 20`；容器 `pointer-events: none`，按钮自身 `pointer-events: auto`，因此只拦截按钮区域，不会挡住画布的拖拽和缩放。后处理只在 WebGL 内发生，DOM 按钮始终显示在画面之上；按钮带 `aria-pressed` 与激活态。
- **交互更新位置**：`updatePetalRain()`、`updateSilkRibbons()`、`updateRain()`、`updateRainbow()` 都在主 `animate()` 循环里；风场强度与雨量通过 `fxState` 平滑插值。
- **相机**：横屏为低机位第三人称，窄竖屏抬高机位并拉远视距，保持方形地台完整入画；相机参数可在 `fitCamera()` 中按宽高比调整。

## 文件

- [`taohuayuan.html`](taohuayuan.html) — 单文件成品
- [`taohuayuan-scene.js`](taohuayuan-scene.js) — 全部场景逻辑、材质、Shader、动画
- [`taohuayuan.dev.html`](taohuayuan.dev.html) — 模块化本地预览入口
- [`build-taohuayuan.mjs`](build-taohuayuan.mjs) — 零依赖单文件打包脚本
- [`serve.mjs`](serve.mjs) — 本地静态服务器
- [`vendor/`](vendor/) — Three.js r169、OrbitControls 与 EffectComposer / UnrealBloomPass / OutputPass 后处理源码

本地预览：

```bash
node serve.mjs
# http://127.0.0.1:8123/taohuayuan.dev.html
```

修改 `taohuayuan-scene.js` 后重新打包：

```bash
node build-taohuayuan.mjs
```

## 可调参数

- 树量与位置：`TREE_TYPES`、`treePlacements`、`addTreePlacement()` 的坡地/水边/路径校验
- 每棵树的树冠密度：`TREE_TYPES` 中的 `clusters`、`cards`、`leaves`
- 树冠裂片形状：`buildTrees()` 中的 `crownLobes`、`ringCount`、下层/上层裂片与 `sampleCrown()`
- 枝干弯折：`addBentBranch()` 的 `segments`、`strength`，以及主干 `p1`–`p3` 的横向扭折
- 花色族：`flowerFamilies` 与 `pinkFamilyPool`
- 瀑布位置与溪流曲线：`FALL_X`、`riverCenter()`、地形中的 `poolD`
- 主树位置与红绸：`treePlacements` 第一项、`buildSilkRibbons()`、`updateSilkRibbons()`
- 景深强度与对焦：`post.dofPass.material.uniforms.uMaxBlur`，以及 `animate()` 中对 `uFocus` 的更新
- 泛光：`post.bloomPass.strength`、`.radius`、`.threshold`
- 后处理调色：`post.gradePass.uniforms.uContrast`、`.uSaturation`
- 丁达尔光束：`buildGodRays()` 中的 `opacity`、平面位置与数量
- 光照与曝光：`sunLight`、`hemi`、`fillLight`、`frontFill`、`renderer.toneMappingExposure`
- 花瓣雨与落花：`PETAL_RAIN_COUNT`、`buildFallenPetals()` 中的 12000 次循环
- 竖屏相机：`fitCamera()` 的 `aspect < 0.82` 分支
