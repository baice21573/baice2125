// Rebuilds the self-contained taohuayuan.html from the editable source.
// No bundler dependency: the Three.js module, OrbitControls and the scene source
// are wrapped into one IIFE so the result can be opened directly from disk.
import { readFileSync, writeFileSync } from 'node:fs';

const threePath = 'vendor/three.module.js';
const orbitPath = 'vendor/examples/jsm/controls/OrbitControls.js';
const addonPaths = [
  'vendor/examples/jsm/shaders/CopyShader.js',
  'vendor/examples/jsm/shaders/LuminosityHighPassShader.js',
  'vendor/examples/jsm/postprocessing/Pass.js',
  'vendor/examples/jsm/postprocessing/ShaderPass.js',
  'vendor/examples/jsm/postprocessing/MaskPass.js',
  'vendor/examples/jsm/postprocessing/EffectComposer.js',
  'vendor/examples/jsm/postprocessing/RenderPass.js',
  'vendor/examples/jsm/postprocessing/UnrealBloomPass.js',
  'vendor/examples/jsm/shaders/OutputShader.js',
  'vendor/examples/jsm/postprocessing/OutputPass.js',
];

let threeSource = readFileSync(threePath, 'utf8');
const exportMatch = threeSource.match(/export \{([\s\S]*?)\};?\s*$/);
if (!exportMatch) throw new Error('Could not find Three.js export list');

const exportNames = exportMatch[1]
  .split(',')
  .map((name) => name.trim())
  .filter(Boolean);

if (exportNames.some((name) => name.includes(' as '))) {
  throw new Error('Aliased Three.js exports are not supported by this build script');
}

threeSource = threeSource.slice(0, exportMatch.index);

let orbitSource = readFileSync(orbitPath, 'utf8');
orbitSource = orbitSource
  .replace(/^import[\s\S]*?from 'three';\s*/, '')
  .replace(/export \{ OrbitControls \};?\s*$/, '');

function bundleAddon(path) {
  let source = readFileSync(path, 'utf8');
  source = source
    .replace(/^import\s+[\s\S]*?from\s+['"][^'"]+['"];\s*/gm, '')
    .replace(/^export\s*\{[^}]*\};?\s*$/gm, '');
  return source.trim();
}

const addonSource = addonPaths.map(bundleAddon).join('\n\n');
const addonBundle = `const PostAddons = (function () {
${addonSource}
return { EffectComposer, RenderPass, UnrealBloomPass, OutputPass, ShaderPass, Pass, FullScreenQuad };
})();
const { EffectComposer, RenderPass, UnrealBloomPass, OutputPass, ShaderPass, Pass, FullScreenQuad } = PostAddons;`;

let sceneSource = readFileSync('taohuayuan-scene.js', 'utf8');
sceneSource = sceneSource.replace(/^import[^\n]*\n/gm, '');

const bundled = `(function () {
'use strict';

${threeSource}

const THREE = { ${exportNames.join(', ')} };

const OrbitControls = (function () {
${orbitSource}
return OrbitControls;
})();

${addonBundle}

(function (THREE, OrbitControls) {
${sceneSource}
})(THREE, OrbitControls);
})();`;

const safeBundle = bundled.replace(/<\/script/gi, '<\\/script');
const template = readFileSync('taohuayuan.dev.html', 'utf8');

const standalone = template
  .replace(/[ \t]*<script type="importmap">[\s\S]*?<\/script>\s*\n/, '')
  .replace(
    /[ \t]*<script type="module" src="\.\/taohuayuan-scene\.js[^"]*"><\/script>/,
    () => `<script>\n${safeBundle}\n</script>`
  );

writeFileSync('taohuayuan.html', standalone, 'utf8');
console.log(`Wrote taohuayuan.html (${(Buffer.byteLength(standalone) / 1024 / 1024).toFixed(2)} MB)`);
