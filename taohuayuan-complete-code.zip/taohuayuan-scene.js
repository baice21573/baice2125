import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { Pass, FullScreenQuad } from 'three/addons/postprocessing/Pass.js';

// ---------------------------------------------------------------------------
// 桃花源 · 微缩三维春日山水
// 方形地台、青翠群山、飞瀑溪流、漫山桃林、半山古亭与暖黄石灯笼。
// 全程序化 PBR 场景，无外部贴图；横屏与竖屏分别取景。
// ---------------------------------------------------------------------------

const canvas = document.getElementById('scene');
const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: true,
  alpha: false,
  powerPreference: 'high-performance',
  stencil: false,
});
renderer.setPixelRatio(Math.min(Math.max(window.devicePixelRatio || 1, 1.15), 1.25));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.86;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xbcd9eb);
scene.fog = new THREE.Fog(0xe3d1da, 44, 118);

const TARGET = new THREE.Vector3(1.6, 2.3, 0.55);
const camera = new THREE.PerspectiveCamera(41, window.innerWidth / window.innerHeight, 0.4, 220);

function fitCamera() {
  const aspect = window.innerWidth / window.innerHeight;
  if (aspect < 0.82) {
    camera.position.copy(TARGET).add(new THREE.Vector3(13.0, 27.0, 34.0));
    camera.fov = 56;
  } else if (aspect < 1.08) {
    camera.position.copy(TARGET).add(new THREE.Vector3(14.0, 16.0, 30.5));
    camera.fov = 46;
  } else {
    camera.position.copy(TARGET).add(new THREE.Vector3(12.2, 9.2, 29.2));
    camera.fov = 41;
  }
  camera.updateProjectionMatrix();
}
fitCamera();

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.copy(TARGET);
controls.enableDamping = true;
controls.dampingFactor = 0.06;
controls.enablePan = false;
controls.rotateSpeed = 0.58;
controls.zoomSpeed = 0.78;
controls.minDistance = 15;
controls.maxDistance = 68;
controls.minPolarAngle = 0.2;
controls.maxPolarAngle = 1.38;
controls.update();

// ---------------------------------------------------------------------------
// 电影感后处理：RenderPass -> 景深 -> UnrealBloom -> sRGB 输出
// 场景先渲染到带 DepthTexture 的 HDR 目标，保留原来的真实景深，
// 再叠加柔和泛光；最后只做一次 sRGB 转换，避免双重色调映射。
// ---------------------------------------------------------------------------

const post = (() => {
  const size = new THREE.Vector2();
  renderer.getDrawingBufferSize(size);

  function makePostTarget(width, height) {
    const depthTexture = new THREE.DepthTexture(width, height);
    depthTexture.format = THREE.DepthFormat;
    depthTexture.type = THREE.UnsignedIntType;
    depthTexture.minFilter = THREE.NearestFilter;
    depthTexture.magFilter = THREE.NearestFilter;
    const target = new THREE.WebGLRenderTarget(width, height, {
      type: THREE.HalfFloatType,
      format: THREE.RGBAFormat,
      depthTexture,
      depthBuffer: true,
      stencilBuffer: false,
      samples: 0,
    });
    target.texture.minFilter = THREE.LinearFilter;
    target.texture.magFilter = THREE.LinearFilter;
    target.texture.generateMipmaps = false;
    target.texture.colorSpace = THREE.LinearSRGBColorSpace;
    return target;
  }

  class DofPass extends Pass {
    constructor(cameraRef) {
      super();
      this.needsSwap = true;
      this.clear = true;
      this.material = new THREE.ShaderMaterial({
        uniforms: {
          tDiffuse: { value: null },
          tDepth: { value: null },
          uTexel: { value: new THREE.Vector2(1 / size.x, 1 / size.y) },
          uNear: { value: cameraRef.near },
          uFar: { value: cameraRef.far },
          uFocus: { value: 29.0 },
          uMaxBlur: { value: 4.6 },
        },
        depthTest: false,
        depthWrite: false,
        toneMapped: false,
        vertexShader: /* glsl */ `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = vec4(position.xy, 0.0, 1.0);
          }
        `,
        fragmentShader: /* glsl */ `
          #include <packing>
          uniform sampler2D tDiffuse;
          uniform sampler2D tDepth;
          uniform vec2 uTexel;
          uniform float uNear;
          uniform float uFar;
          uniform float uFocus;
          uniform float uMaxBlur;
          varying vec2 vUv;

          void main() {
            float depth = texture2D(tDepth, vUv).x;
            float viewZ = perspectiveDepthToViewZ(depth, uNear, uFar);
            float dist = -viewZ;

            float nearBlur = 1.0 - smoothstep(uFocus - 13.0, uFocus - 2.0, dist);
            float farBlur = smoothstep(uFocus + 2.0, uFocus + 19.0, dist);
            float dof = max(nearBlur * 0.62, farBlur * 0.9);

            vec3 color = texture2D(tDiffuse, vUv).rgb;
            if (dof > 0.001) {
              vec3 accum = color;
              float total = 1.0;
              const int SAMPLES = 12;
              for (int i = 0; i < SAMPLES; i++) {
                float fi = float(i) + 1.0;
                float r = sqrt(fi / float(SAMPLES)) * uMaxBlur * dof;
                float a = fi * 2.39996323;
                vec2 off = vec2(cos(a), sin(a)) * uTexel * r;
                accum += texture2D(tDiffuse, vUv + off).rgb;
                total += 1.0;
              }
              color = accum / total;
            }

            vec2 q = vUv - vec2(0.5);
            color *= 1.0 - 0.06 * dot(q, q);
            gl_FragColor = vec4(color, 1.0);
          }
        `,
      });
      this.fsQuad = new FullScreenQuad(this.material);
    }

    setSize(width, height) {
      this.material.uniforms.uTexel.value.set(1 / width, 1 / height);
    }

    render(rendererRef, writeBuffer, readBuffer) {
      const uniforms = this.material.uniforms;
      uniforms.tDiffuse.value = readBuffer.texture;
      uniforms.tDepth.value = readBuffer.depthTexture;
      uniforms.uTexel.value.set(1 / readBuffer.width, 1 / readBuffer.height);
      this.fsQuad.material = this.material;
      if (this.renderToScreen) {
        rendererRef.setRenderTarget(null);
        this.fsQuad.render(rendererRef);
      } else {
        rendererRef.setRenderTarget(writeBuffer);
        if (this.clear) rendererRef.clear();
        this.fsQuad.render(rendererRef);
      }
    }

    dispose() {
      this.material.dispose();
      this.fsQuad.dispose();
    }
  }

  const composer = new EffectComposer(renderer);
  // EffectComposer 默认目标没有深度纹理；替换成带 DepthTexture 的 HDR 目标，
  // 供景深 Pass 读取真实场景深度。
  composer.renderTarget1.dispose();
  composer.renderTarget2.dispose();
  const target1 = makePostTarget(size.x, size.y);
  const target2 = makePostTarget(size.x, size.y);
  target1.texture.name = 'Taohuayuan.rt1';
  target2.texture.name = 'Taohuayuan.rt2';
  composer.renderTarget1 = target1;
  composer.renderTarget2 = target2;
  composer.writeBuffer = target1;
  composer.readBuffer = target2;

  const renderPass = new RenderPass(scene, camera);
  const dofPass = new DofPass(camera);
  const bloomPass = new UnrealBloomPass(
    new THREE.Vector2(size.x, size.y),
    0.8,
    0.8,
    0.85
  );
  bloomPass.name = 'SoftBloom';
  // 让泛光略微偏暖，和夕阳/暖白日光统一。
  for (let i = 0; i < bloomPass.bloomTintColors.length; i++) {
    bloomPass.bloomTintColors[i].set(1.0, 0.95, 0.86);
  }

  // 场景在 RenderTarget 中保持线性 HDR（Three 会自动关闭 RT 内的色调映射），
  // 因此最后由 OutputPass 统一执行 ACES 与 sRGB，避免二次转换和泛光过曝。
  const outputPass = new OutputPass();

  // OutputPass 输出 sRGB 后，再做一次很轻的胶片式调色：对比、饱和与暗角。
  const gradePass = new ShaderPass({
    uniforms: {
      tDiffuse: { value: null },
      uContrast: { value: 1.12 },
      uSaturation: { value: 1.14 },
    },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D tDiffuse;
      uniform float uContrast;
      uniform float uSaturation;
      varying vec2 vUv;
      void main() {
        vec3 color = texture2D(tDiffuse, vUv).rgb;
        float luma = dot(color, vec3(0.299, 0.587, 0.114));
        color = mix(vec3(luma), color, uSaturation);
        color = (color - 0.5) * uContrast + 0.5;
        color *= mix(vec3(0.985, 0.995, 1.015), vec3(1.015, 1.0, 0.975), smoothstep(0.15, 0.85, luma));
        vec2 q = vUv - vec2(0.5);
        color *= 1.0 - 0.045 * dot(q, q);
        // 1/255 级抖动，专门消除大面积天空渐变的色带。
        float dither = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
        color += dither / 255.0;
        gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
      }
    `,
  });
  gradePass.material.depthTest = false;
  gradePass.material.depthWrite = false;
  gradePass.material.toneMapped = false;

  composer.addPass(renderPass);
  composer.addPass(dofPass);
  composer.addPass(bloomPass);
  composer.addPass(outputPass);
  composer.addPass(gradePass);

  function resize() {
    composer.setPixelRatio(renderer.getPixelRatio());
    composer.setSize(window.innerWidth, window.innerHeight);
    dofPass.material.uniforms.uNear.value = camera.near;
    dofPass.material.uniforms.uFar.value = camera.far;
  }

  return {
    composer,
    renderPass,
    dofPass,
    bloomPass,
    outputPass,
    gradePass,
    resize,
  };
})();

// ---------------------------------------------------------------------------
// 基础工具
// ---------------------------------------------------------------------------

function mulberry32(seed) {
  let a = seed >>> 0;
  return function random() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rng = mulberry32(0x7a0c93e1);
const rand = (a = 0, b = 1) => a + (b - a) * rng();
const clamp = THREE.MathUtils.clamp;
const V2 = (x = 0, y = 0) => new THREE.Vector2(x, y);
const V3 = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
const UP = V3(0, 1, 0);
const WHITE = new THREE.Color(0xffffff);
const TMP_OBJ = new THREE.Object3D();
const TMP_V = new THREE.Vector3();
const TMP_Q = new THREE.Quaternion();
const TMP_M = new THREE.Matrix4();

function smoothstep(a, b, x) {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
}
function lerp(a, b, t) {
  return a + (b - a) * t;
}
function pick(list) {
  return list[Math.floor(rng() * list.length)];
}
function angleLerp(a, b, t) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

function flatGeometry(geometry) {
  const geo = geometry.index ? geometry.toNonIndexed() : geometry.clone();
  geo.computeVertexNormals();
  return geo;
}

function canvasTexture(canvas, { repeat = false, repeatX = 1, repeatY = 1 } = {}) {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  if (repeat) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(repeatX, repeatY);
  }
  tex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  tex.needsUpdate = true;
  return tex;
}

function makeCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return [c, c.getContext('2d')];
}

function addMesh(parent, geometry, material, x = 0, y = 0, z = 0, cast = true, receive = true) {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(x, y, z);
  mesh.castShadow = cast;
  mesh.receiveShadow = receive;
  parent.add(mesh);
  return mesh;
}

function boxMesh(parent, w, h, d, material, x, y, z, cast = true, receive = true) {
  return addMesh(parent, new THREE.BoxGeometry(w, h, d), material, x, y, z, cast, receive);
}

function cylMesh(parent, rt, rb, h, seg, material, x, y, z, cast = true, receive = true) {
  return addMesh(parent, new THREE.CylinderGeometry(rt, rb, h, seg), material, x, y, z, cast, receive);
}

// ---------------------------------------------------------------------------
// Toon 材质与色阶
// ---------------------------------------------------------------------------

const toonGradient = new THREE.DataTexture(
  new Uint8Array([78, 136, 198, 255]),
  4,
  1,
  THREE.RedFormat
);
toonGradient.minFilter = THREE.NearestFilter;
toonGradient.magFilter = THREE.NearestFilter;
toonGradient.generateMipmaps = false;
toonGradient.needsUpdate = true;

// 物理渲染主体：仍然沿用原来的材质表结构，只把 Toon 材质替换为 PBR。
// roughness / metalness 可以通过第二个参数覆盖。
function pbr(color, extra = {}) {
  const {
    roughness = 0.82,
    metalness = 0.0,
    ...rest
  } = extra;
  return new THREE.MeshStandardMaterial({
    color,
    roughness,
    metalness,
    envMapIntensity: 0.8,
    ...rest,
  });
}
const toon = pbr;

// 用程序化天空生成 IBL 环境贴图，给 PBR 石头、瓦片、绸带与水面柔和反射。
function installEnvironment() {
  const [c, ctx] = makeCanvas(1024, 512);
  const sky = ctx.createLinearGradient(0, 0, 0, 512);
  sky.addColorStop(0, '#6fa9dc');
  sky.addColorStop(0.4, '#bfdcef');
  sky.addColorStop(0.7, '#ffc3c6');
  sky.addColorStop(1, '#ffd3b8');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, 1024, 512);

  const sun = ctx.createRadialGradient(430, 128, 8, 430, 128, 180);
  sun.addColorStop(0, 'rgba(255,252,233,0.95)');
  sun.addColorStop(0.16, 'rgba(255,237,206,0.58)');
  sun.addColorStop(0.52, 'rgba(255,221,205,0.16)');
  sun.addColorStop(1, 'rgba(255,220,210,0)');
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, 1024, 512);

  // 日轮在环境贴图里同样保持正后上方，给 PBR 高光一致的方向。

  ctx.filter = 'blur(18px)';
  for (let i = 0; i < 16; i++) {
    const x = 60 + ((i * 167) % 920);
    const y = 140 + ((i * 73) % 210);
    ctx.fillStyle = `rgba(255,255,255,${0.2 + (i % 4) * 0.055})`;
    ctx.beginPath();
    ctx.ellipse(x, y, 90 + (i % 5) * 28, 17 + (i % 3) * 8, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.filter = 'none';

  const tex = new THREE.CanvasTexture(c);
  tex.mapping = THREE.EquirectangularReflectionMapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();
  const envRT = pmrem.fromEquirectangular(tex);
  scene.environment = envRT.texture;
  scene.environmentIntensity = 0.28;
  tex.dispose();
  pmrem.dispose();
}
installEnvironment();

// ---------------------------------------------------------------------------
// 天空、太阳与云
// ---------------------------------------------------------------------------

let skyMaterial = null;

function buildSky() {
  const geo = new THREE.SphereGeometry(165, 40, 24);
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      uTop: { value: new THREE.Color(0x679fd4) },
      uMid: { value: new THREE.Color(0x9fcbe9) },
      uHorizon: { value: new THREE.Color(0xffc6c9) },
      uBottom: { value: new THREE.Color(0xf9bec7) },
      uLow: { value: new THREE.Color(0xffd3b8) },
      uSunColor: { value: new THREE.Color(0xfff1c9) },
      uSunDir: { value: V3(-24, 12.5, -55).normalize() },
      uRain: { value: 0 },
    },
    vertexShader: /* glsl */ `
      varying vec3 vDir;
      void main() {
        vDir = position;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uTop;
      uniform vec3 uMid;
      uniform vec3 uHorizon;
      uniform vec3 uBottom;
      uniform vec3 uLow;
      uniform vec3 uSunColor;
      uniform vec3 uSunDir;
      uniform float uRain;
      varying vec3 vDir;

      float smootherstep(float a, float b, float x) {
        float t = clamp((x - a) / (b - a), 0.0, 1.0);
        return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
      }

      void main() {
        vec3 d = normalize(vDir);
        float h = d.y;

        // 五段颜色使用重叠的 smootherstep，而不是首尾相接的硬分段。
        vec3 col = uLow;
        col = mix(col, uBottom, smootherstep(-0.5, -0.2, h));
        col = mix(col, uHorizon, smootherstep(-0.24, -0.02, h));
        col = mix(col, uMid, smootherstep(-0.08, 0.14, h));
        col = mix(col, uTop, smootherstep(0.02, 0.42, h));

        // 地平线附近加一层很淡的暖白雾，让蓝、粉、橙互相渗透。
        float haze = exp(-pow((h + 0.03) * 4.2, 2.0));
        col = mix(col, vec3(1.0, 0.86, 0.82), haze * 0.04);

        // 下雨时仅把天空压暗并偏蓝，主光与太阳 Sprite 不变。
        float wet = clamp(uRain, 0.0, 1.0);
        col = mix(col, col * vec3(0.52, 0.68, 0.94), wet * 0.62);
        col = mix(col, vec3(0.16, 0.28, 0.44), wet * 0.18);

        // 太阳本体由世界空间 Sprite 负责，天空球不再重复画一个日轮，
        // 避免相机离原点时出现两个错位的太阳。
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
  skyMaterial = mat;
  const sky = new THREE.Mesh(geo, mat);
  sky.renderOrder = -100;
  sky.frustumCulled = false;
  scene.add(sky);
}

function makeSunTexture() {
  const [c, ctx] = makeCanvas(256, 256);
  const g = ctx.createRadialGradient(128, 128, 2, 128, 128, 126);
  g.addColorStop(0, 'rgba(255,255,247,1)');
  g.addColorStop(0.1, 'rgba(255,247,206,0.98)');
  g.addColorStop(0.25, 'rgba(255,224,165,0.52)');
  g.addColorStop(0.55, 'rgba(255,203,177,0.16)');
  g.addColorStop(1, 'rgba(255,210,190,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  return canvasTexture(c);
}

function makeSunDiscTexture() {
  const [c, ctx] = makeCanvas(256, 256);
  const g = ctx.createRadialGradient(128, 128, 0, 128, 128, 76);
  g.addColorStop(0, 'rgba(255,255,251,1)');
  g.addColorStop(0.52, 'rgba(255,253,236,1)');
  g.addColorStop(0.8, 'rgba(255,241,198,0.9)');
  g.addColorStop(1, 'rgba(255,231,187,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(128, 128, 76, 0, Math.PI * 2);
  ctx.fill();
  return canvasTexture(c);
}

function makeGlowTexture(inner = 'rgba(255,236,183,1)', outer = 'rgba(255,183,108,0)') {
  const [c, ctx] = makeCanvas(128, 128);
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 62);
  g.addColorStop(0, inner);
  g.addColorStop(0.18, 'rgba(255,220,150,0.72)');
  g.addColorStop(0.48, 'rgba(255,184,113,0.24)');
  g.addColorStop(1, outer);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  return canvasTexture(c);
}

function makeMistTexture() {
  const [c, ctx] = makeCanvas(256, 256);
  const g = ctx.createRadialGradient(128, 138, 4, 128, 128, 124);
  g.addColorStop(0, 'rgba(255,255,255,0.75)');
  g.addColorStop(0.28, 'rgba(255,245,246,0.42)');
  g.addColorStop(0.64, 'rgba(248,232,236,0.16)');
  g.addColorStop(1, 'rgba(245,230,234,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  return canvasTexture(c);
}

function makeCloudTexture() {
  const [c, ctx] = makeCanvas(768, 384);
  const crng = mulberry32(0x1e8a44);
  ctx.clearRect(0, 0, 768, 384);
  ctx.filter = 'blur(20px)';
  for (let i = 0; i < 30; i++) {
    const rx = 46 + crng() * 76;
    const ry = 18 + crng() * 28;
    const x = 92 + rx + crng() * (768 - 184 - rx * 2);
    const y = 82 + ry + crng() * (384 - 164 - ry * 2);
    const alpha = 0.55 + crng() * 0.32;
    ctx.fillStyle = `rgba(255, 249, 249, ${alpha})`;
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = `rgba(225, 239, 255, ${alpha * 0.58})`;
    ctx.beginPath();
    ctx.ellipse(x + 8, y + 14, rx * 0.9, ry * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.filter = 'none';
  return canvasTexture(c);
}

function makeWispTexture() {
  const [c, ctx] = makeCanvas(1024, 256);
  const wrng = mulberry32(0x6b2d91);
  ctx.clearRect(0, 0, 1024, 256);
  ctx.filter = 'blur(15px)';
  for (let i = 0; i < 26; i++) {
    const rx = 65 + wrng() * 170;
    const ry = 3 + wrng() * 8;
    const x = 90 + rx + wrng() * (1024 - 180 - rx * 2);
    const y = 60 + ry + wrng() * (256 - 120 - ry * 2);
    const alpha = 0.24 + wrng() * 0.26;
    ctx.fillStyle = `rgba(255, 250, 251, ${alpha})`;
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.filter = 'none';
  return canvasTexture(c);
}

function buildClouds() {
  const cloudTex = makeCloudTexture();
  const crng = mulberry32(0x59a2e8);
  const clouds = [];
  for (let i = 0; i < 18; i++) {
    const mat = new THREE.SpriteMaterial({
      map: cloudTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.4 + crng() * 0.24,
      color: i % 4 === 0 ? 0xfff0f2 : 0xffffff,
      fog: true,
    });
    const s = new THREE.Sprite(mat);
    const angle = (i / 18) * Math.PI * 2 + crng() * 0.4;
    const radius = 38 + crng() * 24;
    s.position.set(
      Math.cos(angle) * radius,
      3.0 + crng() * 10,
      Math.sin(angle) * radius
    );
    const size = 19 + crng() * 27;
    s.scale.set(size, size * (0.36 + crng() * 0.2), 1);
    s.renderOrder = -20;
    scene.add(s);
    clouds.push({ sprite: s, phase: crng() * 8, baseY: s.position.y, x: s.position.x });
  }

  // 画面背后的几片大云，给留白天空一点层次。
  const backdropClouds = [
    [-27, 15, -34, 26, 0.44],
    [-13, 18, -38, 22, 0.38],
    [4, 20, -40, 28, 0.4],
    [24, 16, -34, 24, 0.42],
    [35, 12, -20, 21, 0.34],
    [-35, 11, -22, 23, 0.36],
    [18, 10, -31, 18, 0.3],
    [-18, 9, -28, 19, 0.28],
  ];
  for (let i = 0; i < backdropClouds.length; i++) {
    const b = backdropClouds[i];
    const mat = new THREE.SpriteMaterial({
      map: cloudTex,
      transparent: true,
      depthWrite: false,
      opacity: Math.max(0.08, b[4] * 0.42),
      color: i % 2 ? 0xf4f9ff : 0xffffff,
      fog: false,
    });
    const s = new THREE.Sprite(mat);
    s.position.set(b[0], b[1], b[2]);
    s.scale.set(b[3], b[3] * (0.38 + (i % 3) * 0.04), 1);
    s.renderOrder = -19;
    scene.add(s);
  }

  // 云海：让方形地台像一座漂浮的春日孤岛。
  for (let i = 0; i < 16; i++) {
    const mat = new THREE.SpriteMaterial({
      map: cloudTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.42 + crng() * 0.28,
      color: i % 2 ? 0xfff8f5 : 0xffeef0,
      fog: true,
    });
    const s = new THREE.Sprite(mat);
    const angle = (i / 16) * Math.PI * 2 + crng() * 0.25;
    const radius = 9 + crng() * 19;
    s.position.set(Math.cos(angle) * radius, -4.1 - crng() * 2.2, Math.sin(angle) * radius);
    const size = 12 + crng() * 16;
    s.scale.set(size, size * 0.36, 1);
    s.renderOrder = -15;
    scene.add(s);
  }

  // 横向薄云：参考图里的细长云带，用来把蓝天空与粉橙地平线揉在一起。
  const wispTex = makeWispTexture();
  const wispSpots = [
    [-48, 7.2, -44, 40, 6.5, 0.24, 0xfff8f5],
    [-27, 10.2, -56, 44, 7.0, 0.27, 0xffffff],
    [-6, 5.8, -50, 38, 6.0, 0.22, 0xffeef1],
    [17, 9.1, -52, 35, 6.2, 0.2, 0xfff5f6],
    [38, 12.0, -45, 32, 5.2, 0.18, 0xffffff],
    [-56, 12.4, -52, 36, 5.4, 0.16, 0xfff2f4],
    [54, 8.0, -58, 34, 5.0, 0.15, 0xfff5f5],
    [2, 14.2, -62, 30, 4.6, 0.14, 0xffffff],
  ];
  for (let i = 0; i < wispSpots.length; i++) {
    const w = wispSpots[i];
    const mat = new THREE.SpriteMaterial({
      map: wispTex,
      transparent: true,
      depthWrite: false,
      opacity: w[5],
      color: w[6],
      fog: false,
    });
    const s = new THREE.Sprite(mat);
    s.position.set(w[0], w[1], w[2]);
    s.scale.set(w[3], w[4], 1);
    s.renderOrder = -19.2;
    scene.add(s);
  }

  const sun = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: makeSunDiscTexture(),
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: false,
      opacity: 0.92,
    })
  );
  sun.position.set(-24, 12.5, -55.5);
  sun.scale.set(7.2, 7.2, 1);
  sun.renderOrder = -18;
  scene.add(sun);

  const sunHalo = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: makeSunTexture(),
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: false,
      opacity: 0.1,
    })
  );
  sunHalo.position.copy(sun.position);
  sunHalo.scale.set(30, 30, 1);
  sunHalo.renderOrder = -17;
  scene.add(sunHalo);

  // 初始镜头中的画意云团与淡日，让天空有远景层次。
  const skyClouds = [
    [-41.1, 4.15, -35.4, 22, 0.11, 0xf4f9ff],
    [-18.2, 7.9, -55.5, 20, 0.1, 0xffffff],
    [2.3, 2.95, -50.5, 20, 0.09, 0xf8fbff],
    [-33.1, 8.8, -59.7, 19, 0.08, 0xeef7ff],
    [-58.0, 7.2, -44.0, 18, 0.08, 0xf3f8ff],
    [27.0, 8.1, -44.0, 17, 0.08, 0xf7fbff],
  ];
  for (let i = 0; i < skyClouds.length; i++) {
    const c = skyClouds[i];
    const mat = new THREE.SpriteMaterial({
      map: cloudTex,
      transparent: true,
      depthWrite: false,
      opacity: c[4],
      color: c[5],
      fog: false,
    });
    const s = new THREE.Sprite(mat);
    s.position.set(c[0], c[1], c[2]);
    s.scale.set(c[3], c[3] * 0.34, 1);
    s.renderOrder = -18;
    scene.add(s);
  }

  return clouds;
}

buildSky();
const driftingClouds = buildClouds();

// ---------------------------------------------------------------------------
// 丁达尔光：3 片极低透明度的暖白光束，始终朝向相机，随镜头轻轻保持斜向。
// ---------------------------------------------------------------------------

const godRays = [];
function buildGodRays() {
  const [c, ctx] = makeCanvas(256, 512);
  ctx.clearRect(0, 0, 256, 512);
  ctx.filter = 'blur(13px)';
  for (let i = 0; i < 9; i++) {
    const x = 10 + i * 28 + rand(-7, 7);
    const w = 8 + rand(0, 24);
    const g = ctx.createLinearGradient(0, 0, 0, 512);
    g.addColorStop(0, 'rgba(255,244,218,0)');
    g.addColorStop(0.16, `rgba(255,244,218,${0.07 + rand(0, 0.1)})`);
    g.addColorStop(0.54, `rgba(255,249,229,${0.035 + rand(0, 0.06)})`);
    g.addColorStop(1, 'rgba(255,244,218,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x, 0, w, 512);
  }
  ctx.filter = 'none';
  const tex = canvasTexture(c);
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;

  const mat = new THREE.MeshBasicMaterial({
    map: tex,
    color: 0xfff3d8,
    transparent: true,
    opacity: 0.028,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    depthTest: true,
    side: THREE.DoubleSide,
    toneMapped: false,
    fog: false,
  });
  const geo = new THREE.PlaneGeometry(1, 1);
  const spots = [
    [-2.8, 5.7, 1.2, 4.8, 12.5, -0.34],
    [1.7, 6.3, -1.0, 5.4, 13.5, -0.5],
    [5.2, 5.4, 2.7, 4.2, 11.5, -0.26],
  ];
  for (let i = 0; i < spots.length; i++) {
    const [x, y, z, w, h, tilt] = spots[i];
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    mesh.scale.set(w, h, 1);
    mesh.userData.tilt = tilt;
    mesh.renderOrder = 6;
    mesh.castShadow = false;
    mesh.receiveShadow = false;
    mesh.frustumCulled = false;
    scene.add(mesh);
    godRays.push(mesh);
  }
}
buildGodRays();

function updateGodRays() {
  for (let i = 0; i < godRays.length; i++) {
    const ray = godRays[i];
    ray.quaternion.copy(camera.quaternion);
    ray.rotateZ(ray.userData.tilt);
  }
}

// ---------------------------------------------------------------------------
// 光照
// ---------------------------------------------------------------------------

const hemi = new THREE.HemisphereLight(0xa0c0ff, 0xf2c9ce, 0.3);
scene.add(hemi);

const sunLight = new THREE.DirectionalLight(0xffd34f, 6.0);
sunLight.position.set(-24, 26, -22);
sunLight.target.position.set(0, 0.6, 0);
sunLight.castShadow = true;
sunLight.shadow.mapSize.set(2048, 2048);
sunLight.shadow.camera.left = -15.5;
sunLight.shadow.camera.right = 15.5;
sunLight.shadow.camera.top = 15.5;
sunLight.shadow.camera.bottom = -15.5;
sunLight.shadow.camera.near = 1;
sunLight.shadow.camera.far = 62;
sunLight.shadow.bias = -0.0003;
sunLight.shadow.normalBias = 0.026;
sunLight.shadow.radius = 2.0;
scene.add(sunLight, sunLight.target);

// 逆光花瓣的透光感与阴影补光，保持春日白昼的亮度与层次。
const fillLight = new THREE.DirectionalLight(0xa0c0ff, 0.6);
fillLight.position.set(12, 9, -13);
scene.add(fillLight);

const frontFill = new THREE.DirectionalLight(0xa0c0ff, 0.45);
frontFill.position.set(13, 8, 19);
scene.add(frontFill);

const ambient = new THREE.AmbientLight(0xa0c0ff, 0.012);
scene.add(ambient);

// ---------------------------------------------------------------------------
// 程序化底座贴图
// ---------------------------------------------------------------------------

function makeWoodTexture() {
  const [c, ctx] = makeCanvas(512, 512);
  const wrng = mulberry32(0x320e11);
  const base = ctx.createLinearGradient(0, 0, 0, 512);
  base.addColorStop(0, '#916a51');
  base.addColorStop(0.45, '#795440');
  base.addColorStop(1, '#5f4234');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 95; i++) {
    const y = wrng() * 512;
    const alpha = 0.04 + wrng() * 0.09;
    ctx.strokeStyle = wrng() > 0.55
      ? `rgba(212,166,126,${alpha})`
      : `rgba(24,13,12,${alpha * 1.2})`;
    ctx.lineWidth = 0.5 + wrng() * 2.2;
    ctx.beginPath();
    for (let x = -20; x <= 532; x += 18) {
      const yy = y + Math.sin(x * 0.03 + i * 1.7) * (1.5 + wrng() * 4);
      if (x < 0) ctx.moveTo(x, yy);
      else ctx.lineTo(x, yy);
    }
    ctx.stroke();
  }
  for (let i = 0; i < 9; i++) {
    const x = wrng() * 512;
    const y = wrng() * 512;
    ctx.strokeStyle = 'rgba(28,15,13,0.16)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(x, y, 5 + wrng() * 15, 2 + wrng() * 5, wrng() * 3, 0, Math.PI * 2);
    ctx.stroke();
  }
  return canvasTexture(c, { repeat: true, repeatX: 3.5, repeatY: 1.2 });
}

function makeStoneTexture() {
  const [c, ctx] = makeCanvas(512, 320);
  const srng = mulberry32(0x4a49b1);
  ctx.fillStyle = '#cdc8b8';
  ctx.fillRect(0, 0, 512, 320);
  for (let i = 0; i < 1600; i++) {
    ctx.fillStyle = `rgba(${80 + srng() * 70},${78 + srng() * 65},${68 + srng() * 60},${0.018 + srng() * 0.05})`;
    const x = srng() * 512;
    const y = srng() * 320;
    const r = 0.5 + srng() * 4;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  const course = 64;
  for (let row = 0; row < 5; row++) {
    const y = row * course;
    ctx.strokeStyle = 'rgba(92,89,78,0.32)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
    const offset = row % 2 ? 45 : 0;
    for (let x = offset; x < 512; x += 134) {
      ctx.strokeStyle = 'rgba(95,91,80,0.25)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x, y + course);
      ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(248,243,226,0.25)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, y + 2);
    ctx.lineTo(512, y + 2);
    ctx.stroke();
  }
  return canvasTexture(c, { repeat: true, repeatX: 4.5, repeatY: 1.2 });
}

function makeBlossomTexture() {
  const [c, ctx] = makeCanvas(256, 256);
  const brng = mulberry32(0x9b34d1);
  ctx.clearRect(0, 0, 256, 256);
  // 一朵柔和的粉色花簇底云，再压上许多独立五瓣花，保证卡片本身有足够覆盖。
  const haze = ctx.createRadialGradient(128, 128, 8, 128, 128, 122);
  haze.addColorStop(0, 'rgba(255,255,255,0.20)');
  haze.addColorStop(0.56, 'rgba(255,255,255,0.13)');
  haze.addColorStop(0.84, 'rgba(255,255,255,0.045)');
  haze.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = haze;
  ctx.fillRect(0, 0, 256, 256);

  for (let flower = 0; flower < 92; flower++) {
    const ang = brng() * Math.PI * 2;
    const rad = Math.sqrt(brng()) * 112;
    const cx = 128 + Math.cos(ang) * rad;
    const cy = 128 + Math.sin(ang) * rad;
    const scale = 0.58 + brng() * 0.5;
    const rot = brng() * Math.PI * 2;
    for (let petal = 0; petal < 5; petal++) {
      const a = rot + (petal / 5) * Math.PI * 2;
      ctx.save();
      ctx.translate(cx + Math.cos(a) * 5.6 * scale, cy + Math.sin(a) * 5.6 * scale);
      ctx.rotate(a);
      ctx.fillStyle = `rgba(255,255,255,${0.84 + brng() * 0.16})`;
      ctx.beginPath();
      ctx.ellipse(0, 0, 6.4 * scale, 3.1 * scale, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.beginPath();
    ctx.arc(cx, cy, 1.15 * scale, 0, Math.PI * 2);
    ctx.fill();
  }
  const tex = canvasTexture(c);
  tex.anisotropy = Math.min(4, renderer.capabilities.getMaxAnisotropy());
  return tex;
}

function makeLeafTexture() {
  const [c, ctx] = makeCanvas(128, 128);
  const lrng = mulberry32(0x7182ab);
  ctx.clearRect(0, 0, 128, 128);
  for (let i = 0; i < 7; i++) {
    const cx = 20 + lrng() * 88;
    const cy = 20 + lrng() * 88;
    const size = 0.7 + lrng() * 0.8;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(lrng() * Math.PI * 2);
    ctx.fillStyle = `rgba(255,255,255,${0.58 + lrng() * 0.4})`;
    ctx.beginPath();
    ctx.ellipse(0, 0, 3.5 * size, 9.5 * size, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(120,120,120,0.18)';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.moveTo(0, -8 * size);
    ctx.lineTo(0, 8 * size);
    ctx.stroke();
    ctx.restore();
  }
  return canvasTexture(c);
}

function makeBarkBumpTexture() {
  const [c, ctx] = makeCanvas(256, 512);
  const brng = mulberry32(0x18fa2c);
  ctx.fillStyle = '#777';
  ctx.fillRect(0, 0, 256, 512);
  for (let i = 0; i < 180; i++) {
    const x = brng() * 256;
    const shade = 38 + brng() * 120;
    ctx.strokeStyle = `rgba(${shade},${shade},${shade},${0.16 + brng() * 0.35})`;
    ctx.lineWidth = 0.5 + brng() * 3;
    ctx.beginPath();
    for (let y = -10; y <= 522; y += 18) {
      const xx = x + Math.sin(y * 0.035 + i) * 4 + Math.sin(y * 0.1 + i * 1.7) * 1.5;
      if (y < 0) ctx.moveTo(xx, y);
      else ctx.lineTo(xx, y);
    }
    ctx.stroke();
  }
  const tex = canvasTexture(c, { repeat: true, repeatX: 1.4, repeatY: 2.2 });
  tex.colorSpace = THREE.NoColorSpace;
  return tex;
}

function makeGroundBumpTexture() {
  const [c, ctx] = makeCanvas(256, 256);
  const nrng = mulberry32(0x4d2a91);
  ctx.fillStyle = '#777';
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2200; i++) {
    const x = nrng() * 256;
    const y = nrng() * 256;
    const v = 42 + nrng() * 130;
    ctx.fillStyle = `rgba(${v},${v},${v},${0.06 + nrng() * 0.18})`;
    ctx.beginPath();
    ctx.arc(x, y, 0.4 + nrng() * 2.4, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let i = 0; i < 120; i++) {
    const x = nrng() * 256;
    const y = nrng() * 256;
    ctx.strokeStyle = `rgba(38,38,38,${0.08 + nrng() * 0.18})`;
    ctx.lineWidth = 0.5 + nrng() * 1.4;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + nrng() * 25 - 12, y + nrng() * 25 - 12);
    ctx.stroke();
  }
  const tex = canvasTexture(c, { repeat: true, repeatX: 7, repeatY: 7 });
  tex.colorSpace = THREE.NoColorSpace;
  return tex;
}

const woodTexture = makeWoodTexture();
const stoneTexture = makeStoneTexture();
const blossomTexture = makeBlossomTexture();
const leafTexture = makeLeafTexture();
const barkBumpTexture = makeBarkBumpTexture();
const groundBumpTexture = makeGroundBumpTexture();

const MAT = {
  wood: pbr(0xffffff, { map: woodTexture, roughness: 0.78 }),
  woodDark: pbr(0xd8c0b0, { map: woodTexture, roughness: 0.84 }),
  stone: pbr(0xffffff, { map: stoneTexture, bumpMap: stoneTexture, bumpScale: 0.018, roughness: 0.9 }),
  stoneLight: pbr(0xeee7d8, { roughness: 0.88 }),
  gold: pbr(0xd6ae68, {
    metalness: 0.62,
    roughness: 0.34,
    emissive: 0x2d1808,
    emissiveIntensity: 0.12,
  }),
  trunk: pbr(0xffffff, {
    roughness: 0.9,
    bumpMap: barkBumpTexture,
    bumpScale: 0.035,
  }),
  canopy: pbr(0xffffff, {
    roughness: 0.72,
    emissive: 0x2c0b13,
    emissiveIntensity: 0.1,
    transparent: true,
    opacity: 0.93,
  }),

  blossom: new THREE.MeshStandardMaterial({
    map: blossomTexture,
    color: 0xffffff,
    roughness: 0.8,
    metalness: 0.0,
    transparent: true,
    alphaTest: 0.12,
    depthWrite: true,
    side: THREE.DoubleSide,
    opacity: 0.98,
    emissive: 0x2a0a12,
    emissiveIntensity: 0.12,
    envMapIntensity: 0.7,
  }),
  leaf: new THREE.MeshStandardMaterial({
    map: leafTexture,
    color: 0xffffff,
    roughness: 0.95,
    metalness: 0.0,
    transparent: true,
    alphaTest: 0.2,
    depthWrite: true,
    side: THREE.DoubleSide,
  }),
  silk: new THREE.MeshPhysicalMaterial({
    color: 0xa60f2d,
    roughness: 0.36,
    metalness: 0.02,
    sheen: 1.0,
    sheenColor: 0xff6d86,
    sheenRoughness: 0.45,
    clearcoat: 0.16,
    clearcoatRoughness: 0.55,
    emissive: 0x2b0209,
    emissiveIntensity: 0.14,
    side: THREE.DoubleSide,
    envMapIntensity: 0.8,
  }),
  roofTile: new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.35,
    metalness: 0.14,
    side: THREE.FrontSide,
  }),
  rock: pbr(0xffffff, {
    roughness: 0.94,
    bumpMap: groundBumpTexture,
    bumpScale: 0.055,
  }),
  fallRock: pbr(0x536763, {
    roughness: 0.92,
    bumpMap: groundBumpTexture,
    bumpScale: 0.05,
  }),
  moss: pbr(0xffffff, { roughness: 0.96 }),
  grass: pbr(0xffffff, {
    side: THREE.DoubleSide,
    roughness: 0.92,
  }),
  flower: new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.65,
    metalness: 0.0,
    side: THREE.DoubleSide,
  }),
  petal: new THREE.MeshStandardMaterial({
    color: 0xffcdd8,
    roughness: 0.78,
    metalness: 0.0,
    side: THREE.DoubleSide,
  }),
  path: pbr(0x7f8b84, { roughness: 0.94 }),
  pathSlab: pbr(0xffffff, { roughness: 0.9 }),
  pavilionWood: pbr(0x8f483a, { roughness: 0.68 }),
  pavilionWoodDark: pbr(0x63342e, { roughness: 0.72 }),
  pavilionRoof: pbr(0x5d8b97, { side: THREE.DoubleSide, roughness: 0.56, metalness: 0.04 }),
  pavilionRoofDark: pbr(0x3f626e, { roughness: 0.5, metalness: 0.08 }),
  pavilionRoofUnder: pbr(0x36525b, { roughness: 0.7 }),
  paper: new THREE.MeshStandardMaterial({
    color: 0xffc678,
    emissive: 0xff9e42,
    emissiveIntensity: 1.1,
    roughness: 0.52,
  }),
  lanternStone: pbr(0x88958b, { roughness: 0.9 }),
};

// 树冠风场：只改 canopy / blossom / leaf 的顶点，树干保持不动。
// 每个实例按自己的世界位置取相位，因此 26 棵树不会整齐划一地一起摆。
const windUniforms = {
  uWindTime: { value: 0 },
  uWindStrength: { value: 0 },
};

function enableCanopyWind(material) {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uWindTime = windUniforms.uWindTime;
    shader.uniforms.uWindStrength = windUniforms.uWindStrength;
    shader.vertexShader = `uniform float uWindTime;
uniform float uWindStrength;
${shader.vertexShader}`;
    shader.vertexShader = shader.vertexShader.replace(
      '#include <project_vertex>',
      /* glsl */ `
        vec4 mvPosition = vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          mvPosition = instanceMatrix * mvPosition;
          float windPhase = mvPosition.x * 0.73 + mvPosition.z * 0.51;
          float windWave = sin(uWindTime * 0.55 + windPhase) * 0.72
            + sin(uWindTime * 1.25 + windPhase * 1.7) * 0.28;
          float windHeight = smoothstep(0.15, 1.1, mvPosition.y);
          mvPosition.x += windWave * uWindStrength * 0.095 * windHeight;
          mvPosition.z += windWave * uWindStrength * 0.034 * windHeight;
        #endif
        mvPosition = modelViewMatrix * mvPosition;
        gl_Position = projectionMatrix * mvPosition;
      `
    );
  };
  material.needsUpdate = true;
}
enableCanopyWind(MAT.canopy);
enableCanopyWind(MAT.blossom);
enableCanopyWind(MAT.leaf);

// ---------------------------------------------------------------------------
// 方形地台
// ---------------------------------------------------------------------------

const baseGroup = new THREE.Group();
scene.add(baseGroup);

(function buildBase() {
  boxMesh(baseGroup, 21.0, 0.74, 21.0, MAT.wood, 0, -1.57, 0);
  boxMesh(baseGroup, 20.72, 0.075, 20.72, MAT.gold, 0, -1.18, 0);
  boxMesh(baseGroup, 20.38, 0.86, 20.38, MAT.stone, 0, -0.71, 0);
  boxMesh(baseGroup, 20.58, 0.065, 20.58, MAT.gold, 0, -0.235, 0);
  boxMesh(baseGroup, 20.72, 0.25, 20.72, MAT.woodDark, 0, -0.075, 0);

  // 四周木框，略高于土地，遮住地形边缘。
  const rim = 0.66;
  const half = 10.36;
  for (const s of [-1, 1]) {
    boxMesh(baseGroup, 21.02, 0.24, rim, MAT.woodDark, 0, 0.075, s * (half - rim * 0.5));
    boxMesh(baseGroup, rim, 0.24, 20.72, MAT.woodDark, s * (half - rim * 0.5), 0.075, 0);
    // 内圈细金线
    boxMesh(
      baseGroup,
      19.74,
      0.025,
      0.035,
      MAT.gold,
      0,
      0.198,
      s * (half - rim - 0.025),
      false,
      false
    );
    boxMesh(
      baseGroup,
      0.035,
      0.025,
      19.74,
      MAT.gold,
      s * (half - rim - 0.025),
      0.198,
      0,
      false,
      false
    );
  }

  // 四角包铜
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const corner = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.5), MAT.gold);
      corner.position.set(sx * 9.96, 0.19, sz * 9.96);
      corner.rotation.y = Math.PI * 0.25;
      corner.castShadow = true;
      corner.receiveShadow = true;
      baseGroup.add(corner);
    }
  }
})();

// ---------------------------------------------------------------------------
// 地形参数
// ---------------------------------------------------------------------------

const PEAKS = [
  { x: -4.25, z: -5.25, h: 5.7, rx: 3.75, rz: 3.55 },
  { x: 4.55, z: -5.65, h: 5.15, rx: 3.7, rz: 3.45 },
  { x: -8.05, z: 0.4, h: 3.3, rx: 2.75, rz: 2.75 },
  { x: 8.35, z: -1.0, h: 2.75, rx: 2.45, rz: 2.65 },
  { x: -6.6, z: -6.35, h: 3.55, rx: 2.3, rz: 2.05 },
  { x: -7.75, z: 3.95, h: 1.35, rx: 2.15, rz: 2.35 },
  { x: 7.7, z: 3.7, h: 1.1, rx: 2.05, rz: 2.2 },
];

const PAVILION = {
  x: -5.88,
  z: 0.52,
  y: 2.18,
  flatR: 1.52,
  blendR: 2.88,
};

const WATER_LEVEL = 0.18;

const FALL_X = -2.35;

function riverCenter(z) {
  const base = 0.74 * Math.sin((z + 2.3) * 0.34) + 0.28 * Math.sin((z - 1.0) * 0.78) - 0.08;
  // 瀑布整体左移后，溪流源头也向左摆，再逐渐回到画面中央。
  const sourceShift = -2.2 * (1 - smoothstep(-2.4, 2.8, z));
  return base + sourceShift;
}

function riverWidth(z) {
  let w = 1.35 + 0.18 * Math.sin(z * 0.8 + 0.2) + 0.07 * Math.sin(z * 2.1);
  w += 0.45 * smoothstep(6.0, 9.3, z);
  w *= 0.84 + 0.16 * smoothstep(-2.9, -1.2, z);
  return w;
}

function peakHeight(x, z, p) {
  const dx = (x - p.x) / p.rx;
  const dz = (z - p.z) / p.rz;
  return p.h * Math.exp(-(dx * dx + dz * dz) * 1.16);
}

function terrainHeight(x, z) {
  let h = 0.16;
  h += 0.11 * Math.sin(x * 0.43 + 0.7) * Math.cos(z * 0.37 - 0.2);
  h += 0.055 * Math.sin(x * 1.23 + z * 0.71 + 2.1);
  h += 0.03 * Math.sin(x * 2.6 - z * 1.9);

  for (let i = 0; i < PEAKS.length; i++) {
    h = Math.max(h, peakHeight(x, z, PEAKS[i]));
  }

  // 山脊细碎的起伏，避免成为完美圆锥。
  const ridgeMask = smoothstep(1.0, 3.0, h);
  h += (
    Math.sin(x * 0.9 + z * 1.05 + 0.6) * 0.18 +
    Math.sin(x * 1.9 - z * 1.4 + 1.7) * 0.09
  ) * ridgeMask;

  h += 0.52 * smoothstep(-2.0, -7.2, z);

  // 古亭所在的半山平台
  const pd = Math.hypot(x - PAVILION.x, z - PAVILION.z);
  const plateau = 1 - smoothstep(PAVILION.flatR, PAVILION.blendR, pd);
  h = lerp(h, PAVILION.y, plateau * 0.975);

  // 瀑底深潭：把山脚挖出一个清水潭，让瀑布与溪流真正相接。
  const poolD = Math.hypot(x + 2.4, z + 2.68);
  const poolMask = 1 - smoothstep(0.52, 2.35, poolD);
  if (h > 0.06) h = lerp(h, 0.06, poolMask * 0.96);

  // 方形地台边缘缓慢收平，避免山体被生硬切断。
  const edge = 1 - smoothstep(8.1, 9.55, Math.max(Math.abs(x), Math.abs(z)));
  h = 0.03 + (h - 0.03) * edge;

  // 蜿蜒河道与瀑底水潭
  const reach = smoothstep(-3.2, -2.25, z);
  const riverD = Math.abs(x - riverCenter(z));
  const channel = (1 - smoothstep(0.58, 1.28, riverD)) * 0.235 * reach;
  h -= channel;

  return Math.max(h, 0.008);
}

const terrainNormal = (x, z, eps = 0.12) => {
  const hx = terrainHeight(x + eps, z) - terrainHeight(x - eps, z);
  const hz = terrainHeight(x, z + eps) - terrainHeight(x, z - eps);
  return V3(-hx / (2 * eps), 1, -hz / (2 * eps)).normalize();
};
const terrainSlope = (x, z, eps = 0.17) => {
  const hx = (terrainHeight(x + eps, z) - terrainHeight(x - eps, z)) / (2 * eps);
  const hz = (terrainHeight(x, z + eps) - terrainHeight(x, z - eps)) / (2 * eps);
  return Math.hypot(hx, hz);
};

// ---------------------------------------------------------------------------
// 石板路：先确定路径，供地形配色与树木避让使用
// ---------------------------------------------------------------------------

const PATH_CONTROLS = [
  [-2.55, 9.35],
  [-2.08, 8.25],
  [-3.14, 7.2],
  [-4.3, 6.2],
  [-3.86, 5.15],
  [-4.62, 4.15],
  [-5.52, 3.4],
  [-6.28, 2.76],
  [-6.08, 2.25],
];

const pathCurve = new THREE.CatmullRomCurve3(
  PATH_CONTROLS.map(([x, z]) => V3(x, 0, z)),
  false,
  'catmullrom',
  0.46
);

const PATH_SAMPLE_COUNT = 240;
const pathSamples = [];
for (let i = 0; i <= PATH_SAMPLE_COUNT; i++) {
  const t = i / PATH_SAMPLE_COUNT;
  const p = pathCurve.getPoint(t);
  const tangent = pathCurve.getTangent(t).normalize();
  const y = terrainHeight(p.x, p.z);
  pathSamples.push({
    x: p.x,
    z: p.z,
    y,
    tx: tangent.x,
    tz: tangent.z,
    t,
  });
}

function distanceToPath(x, z) {
  let best = 99;
  for (let i = 0; i < pathSamples.length; i += 2) {
    const s = pathSamples[i];
    const dx = x - s.x;
    const dz = z - s.z;
    const d = dx * dx + dz * dz;
    if (d < best) best = d;
  }
  return Math.sqrt(best);
}

// ---------------------------------------------------------------------------
// 桃树布局（先生成，供地面落花与地形染色参考）
// ---------------------------------------------------------------------------

const treeRandom = mulberry32(0x51f0c3a9);
const trand = (a = 0, b = 1) => a + (b - a) * treeRandom();

// 三种明确规格 + 每棵独立随机骨架，避免同款复制。
const TREE_TYPES = {
  xl: {
    height: 5.9, crown: 3.5, trunk: 0.38,
    branches: 12, twigs: 3, clusters: 550, cards: 8000, leaves: 1900,
  },
  large: {
    height: 3.95, crown: 2.2, trunk: 0.25,
    branches: 9, twigs: 2, clusters: 270, cards: 3800, leaves: 930,
  },
  medium: {
    height: 2.8, crown: 1.5, trunk: 0.16,
    branches: 7, twigs: 2, clusters: 150, cards: 2100, leaves: 520,
  },
  small: {
    height: 2.0, crown: 1.05, trunk: 0.11,
    branches: 4, twigs: 1, clusters: 85, cards: 1100, leaves: 290,
  },
};

function makeTreeSpec(x, z, type, seed, opts = {}) {
  const info = TREE_TYPES[type];
  const height = info.height * trand(0.92, 1.08);
  const crown = info.crown * trand(0.9, 1.1);
  return {
    x,
    z,
    baseY: terrainHeight(x, z),
    category: type,
    hero: type === 'xl',
    mainHero: !!opts.mainHero,
    seed,
    height,
    crown,
    crownW: crown * trand(1.02, 1.26),
    crownD: crown * trand(0.96, 1.2),
    crownH: crown * trand(0.74, 0.92),
    trunkRadius: info.trunk * trand(0.9, 1.12),
    branchCount: info.branches + (trand() < 0.5 ? 1 : 0),
    twigCount: info.twigs,
    clusterCount: info.clusters + Math.floor(trand(-4, 9)),
    cardCount: info.cards + Math.floor(trand(-25, 50)),
    leafCount: info.leaves + Math.floor(trand(-15, 35)),
    leanX: trand(-0.18, 0.18),
    leanZ: trand(-0.15, 0.15),
    ribbonAnchors: [],
  };
}

const treeSpecs = [];

function addTreePlacement(x, z, type, mainHero = false, seed = 1) {
  const spec = makeTreeSpec(x, z, type, seed, { mainHero });
  if (spec.baseY < 0.1 || spec.baseY > 5.45) return false;
  if (terrainSlope(x, z) > 1.8) return false;
  if (Math.hypot(x - (FALL_X - 0.18), z + 3.0) < 2.55) return false;
  if (distanceToPath(x, z) < 0.58 + spec.crown * 0.15) return false;
  if (Math.hypot(x - PAVILION.x, z - PAVILION.z) < 1.45 + spec.crown * 0.18) return false;
  if (z > -3.1 && Math.abs(x - riverCenter(z)) < 1.3 + spec.crown * 0.3) return false;
  for (let i = 0; i < treeSpecs.length; i++) {
    const other = treeSpecs[i];
    const minDist = (spec.crown + other.crown) * 0.19;
    if (Math.hypot(x - other.x, z - other.z) < minDist) return false;
  }
  treeSpecs.push(spec);
  return true;
}

// 右主树、左瀑布、后山与左疏林的排布。列表是经过测算的构图点位；
// 个别位于陡坡或水边的点会被上面的校验自动舍弃。
const treePlacements = [
  // 右主树花林：围绕主树收紧，形成一团浓密的主景。
  [7.1, 3.6, 'xl', true],
  [8.2, -2.0, 'large'],
  [8.7, 1.8, 'medium'],
  [7.5, -4.1, 'medium'],
  [5.7, 7.0, 'medium'],
  [5.8, 1.2, 'small'],
  [8.6, 6.9, 'small'],
  [8.5, 3.4, 'small'],
  [6.4, 6.6, 'small'],
  [5.3, 4.9, 'small'],
  [6.4, -5.1, 'small'],
  [6.6, -4.4, 'small'],
  [7.0, -5.5, 'small'],
  // 左侧古亭花林：在亭子前后收紧成一团。
  [-7.9, 6.3, 'large'],
  [-8.0, -2.3, 'large'],
  [-5.6, 7.4, 'medium'],
  [-6.4, -3.8, 'medium'],
  [-7.1, 4.4, 'small'],
  [-5.4, 8.1, 'small'],
  [-7.4, 7.5, 'small'],
  [-7.5, -1.7, 'small'],
  // 后山花林：只保留主峰脚下的一小簇，中央留出水面和草地。
  [3.0, -6.1, 'large'],
  [2.6, -5.2, 'medium'],
  [1.2, -6.5, 'medium'],
  [0.5, -6.3, 'small'],
  [-2.1, -6.3, 'small'],
];
for (let i = 0; i < treePlacements.length; i++) {
  const [x, z, type, mainHero] = treePlacements[i];
  addTreePlacement(x, z, type, !!mainHero, 0x8a000 + i * 173);
}

// ---------------------------------------------------------------------------
// 地形网格与顶点配色
// ---------------------------------------------------------------------------

const TERRAIN_SIZE = 19.4;
const TERRAIN_SEGMENTS = 132;
const terrainGeometry = new THREE.PlaneGeometry(
  TERRAIN_SIZE,
  TERRAIN_SIZE,
  TERRAIN_SEGMENTS,
  TERRAIN_SEGMENTS
);
terrainGeometry.rotateX(-Math.PI / 2);

(function paintTerrain() {
  const pos = terrainGeometry.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const grassLight = new THREE.Color(0x6fb456);
  const grassDeep = new THREE.Color(0x3f743c);
  const grassHigh = new THREE.Color(0x5a9849);
  const mossBank = new THREE.Color(0x6f9f5a);
  const riverBed = new THREE.Color(0x5b9182);
  const rockTint = new THREE.Color(0x99a08f);
  const petalTint = new THREE.Color(0xdcaec0);
  const forestTint = new THREE.Color(0x356c3b);
  const tmp = new THREE.Color();

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const y = terrainHeight(x, z);
    pos.setY(i, y);

    const slope = terrainSlope(x, z, 0.18);
    const wave = 0.5 + 0.5 * Math.sin(x * 0.89 + z * 1.31) * Math.cos(x * 0.36 - z * 0.73);
    const fine = 0.5 + 0.5 * Math.sin(x * 3.4 - z * 2.1 + 1.7);

    const patch = 0.5 + 0.5 * Math.sin(x * 1.15 + z * 0.73 + 1.2) * Math.cos(z * 0.51 - x * 0.61);
    tmp.copy(grassLight).lerp(grassDeep, clamp(wave * 0.56 + slope * 0.28, 0, 1));
    tmp.lerp(grassHigh, clamp((y - 2.8) / 4.4, 0, 1) * 0.42);
    tmp.lerp(forestTint, smoothstep(0.5, 0.9, patch) * 0.16 + smoothstep(2.4, 5.2, y) * 0.08);
    tmp.lerp(rockTint, smoothstep(0.82, 1.55, slope) * 0.32);

    if (z > -3.0) {
      const d = Math.abs(x - riverCenter(z));
      if (d < 1.45) {
        tmp.lerp(mossBank, (1 - smoothstep(0.55, 1.45, d)) * 0.55);
      }
      if (d < riverWidth(z) * 0.64) {
        tmp.lerp(riverBed, 0.72);
      }
    }

    // 树冠下方落英形成的粉色地衣。
    let nearTree = 0;
    for (let k = 0; k < treeSpecs.length; k++) {
      const tr = treeSpecs[k];
      const dx = x - tr.x;
      const dz = z - tr.z;
      const rr = tr.crown * 1.28;
      const d2 = dx * dx + dz * dz;
      if (d2 < rr * rr) {
        nearTree = Math.max(nearTree, 1 - Math.sqrt(d2) / rr);
      }
    }
    if (nearTree > 0) {
      tmp.lerp(petalTint, nearTree * nearTree * 0.32 * (0.7 + fine * 0.3));
    }

    // 草坡上直接烘焙细碎的粉色花瓣色块，和实例化落花形成双层效果。
    const inRiver = z > -3.0 && Math.abs(x - riverCenter(z)) < riverWidth(z) * 0.64;
    if (!inRiver) {
      const petalHash = Math.abs(Math.sin(x * 12.9898 + z * 78.233 + 0.37) * 43758.5453) % 1;
      const patchHash = Math.abs(Math.sin(x * 3.71 - z * 5.17 + 1.3) * 2137.17) % 1;
      if (nearTree > 0.02 && petalHash > 0.48) {
        tmp.lerp(petalTint, 0.22 + nearTree * 0.34);
      } else if (patchHash > 0.81) {
        tmp.lerp(petalTint, 0.16 + fine * 0.08);
      }
    }

    tmp.offsetHSL(0, 0, (fine - 0.5) * 0.022);
    colors[i * 3] = tmp.r;
    colors[i * 3 + 1] = tmp.g;
    colors[i * 3 + 2] = tmp.b;
  }
  terrainGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  terrainGeometry.computeVertexNormals();
})();

const terrainMaterial = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  vertexColors: true,
  roughness: 0.94,
  metalness: 0.0,
  bumpMap: groundBumpTexture,
  bumpScale: 0.018,
});
const terrainMesh = new THREE.Mesh(terrainGeometry, terrainMaterial);
terrainMesh.castShadow = true;
terrainMesh.receiveShadow = true;
scene.add(terrainMesh);

// ---------------------------------------------------------------------------
// 石板路
// ---------------------------------------------------------------------------

function ribbonGeometry(samples, width, yAt, uvVScale = 1) {
  const verts = [];
  const uvs = [];
  const indices = [];
  for (let i = 0; i < samples.length; i++) {
    const s = samples[i];
    let tx = s.tx;
    let tz = s.tz;
    const len = Math.hypot(tx, tz) || 1;
    tx /= len;
    tz /= len;
    const sx = -tz;
    const sz = tx;
    const w = typeof width === 'function' ? width(s, i) : width;
    const y = typeof yAt === 'function' ? yAt(s, i) : yAt;
    verts.push(s.x + sx * w, y, s.z + sz * w);
    verts.push(s.x - sx * w, y, s.z - sz * w);
    uvs.push(1, s.t * uvVScale, 0, s.t * uvVScale);
    if (i > 0) {
      const a = (i - 1) * 2;
      const b = a + 1;
      const c = i * 2;
      const d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

(function buildStonePath() {
  const pathGroup = new THREE.Group();
  scene.add(pathGroup);

  const pathRibbon = new THREE.Mesh(
    ribbonGeometry(pathSamples, 0.72, (s) => s.y + 0.025, 10),
    MAT.path
  );
  pathRibbon.receiveShadow = true;
  pathRibbon.castShadow = false;
  pathGroup.add(pathRibbon);

  const slabGeo = new THREE.BoxGeometry(1, 1, 1);
  const slabMats = [MAT.pathSlab];
  const slabData = [];
  const prng = mulberry32(0x90ae32);

  let carry = 0;
  for (let i = 2; i < pathSamples.length - 2; i++) {
    const s = pathSamples[i];
    const prev = pathSamples[i - 1];
    const dx = s.x - prev.x;
    const dz = s.z - prev.z;
    const stepLen = Math.hypot(dx, dz);
    carry += stepLen;
    if (carry < 0.29) continue;
    carry = 0;

    const len = Math.hypot(s.tx, s.tz) || 1;
    const tx = s.tx / len;
    const tz = s.tz / len;
    const sx = -tz;
    const sz = tx;
    const yaw = Math.atan2(tx, tz);

    for (let col = -1; col <= 1; col += 2) {
      const lateral = col * 0.28 + (prng() - 0.5) * 0.11;
      const px = s.x + sx * lateral;
      const pz = s.z + sz * lateral;
      const n = terrainNormal(px, pz);
      const qAlign = new THREE.Quaternion().setFromUnitVectors(UP, n);
      const qYaw = new THREE.Quaternion().setFromAxisAngle(UP, yaw + (prng() - 0.5) * 0.17);
      const q = qAlign.multiply(qYaw);
      const sc = V3(0.34 + prng() * 0.13, 0.055 + prng() * 0.035, 0.24 + prng() * 0.12);
      TMP_M.compose(V3(px, terrainHeight(px, pz) + 0.09, pz), q, sc);
      const tone = new THREE.Color(prng() > 0.45 ? 0x88958d : 0x6f7c75);
      tone.offsetHSL(0, 0, (prng() - 0.5) * 0.07);
      slabData.push({ matrix: TMP_M.clone(), color: tone });
    }
  }

  const slabs = new THREE.InstancedMesh(slabGeo, MAT.pathSlab, slabData.length);
  for (let i = 0; i < slabData.length; i++) {
    slabs.setMatrixAt(i, slabData[i].matrix);
    slabs.setColorAt(i, slabData[i].color);
  }
  slabs.instanceMatrix.needsUpdate = true;
  if (slabs.instanceColor) slabs.instanceColor.needsUpdate = true;
  slabs.castShadow = true;
  slabs.receiveShadow = true;
  pathGroup.add(slabs);

  // 路缘碎石
  const edgeGeo = new THREE.DodecahedronGeometry(1, 0);
  const edgeData = [];
  for (let i = 8; i < pathSamples.length - 6; i += 7) {
    const s = pathSamples[i];
    const len = Math.hypot(s.tx, s.tz) || 1;
    const sx = -s.tz / len;
    const sz = s.tx / len;
    for (const side of [-1, 1]) {
      if (prng() < 0.3) continue;
      const px = s.x + sx * side * (0.76 + prng() * 0.18);
      const pz = s.z + sz * side * (0.76 + prng() * 0.18);
      const gy = terrainHeight(px, pz);
      const scale = 0.09 + prng() * 0.13;
      TMP_OBJ.position.set(px, gy + scale * 0.4, pz);
      TMP_OBJ.rotation.set(prng() * 3, prng() * 6, prng() * 3);
      TMP_OBJ.scale.set(scale * (0.8 + prng() * 0.5), scale * 0.6, scale);
      TMP_OBJ.updateMatrix();
      edgeData.push({ matrix: TMP_OBJ.matrix.clone(), color: new THREE.Color().setHSL(0.27, 0.07, 0.42 + prng() * 0.16) });
    }
  }
  const edgeStones = new THREE.InstancedMesh(edgeGeo, MAT.rock, edgeData.length);
  for (let i = 0; i < edgeData.length; i++) {
    edgeStones.setMatrixAt(i, edgeData[i].matrix);
    edgeStones.setColorAt(i, edgeData[i].color);
  }
  edgeStones.instanceMatrix.needsUpdate = true;
  if (edgeStones.instanceColor) edgeStones.instanceColor.needsUpdate = true;
  edgeStones.castShadow = true;
  edgeStones.receiveShadow = true;
  pathGroup.add(edgeStones);

  // 古亭前的三级石阶
  const stepY = terrainHeight(PAVILION.x, 2.18);
  for (let i = 0; i < 3; i++) {
    const step = boxMesh(
      pathGroup,
      1.28 - i * 0.06,
      0.1 + i * 0.06,
      0.34,
      MAT.path,
      PAVILION.x + 0.02,
      stepY + 0.04 + i * 0.055,
      2.34 - i * 0.27,
      true,
      true
    );
    step.rotation.y = -0.03;
  }
})();

// ---------------------------------------------------------------------------
// 河流与瀑布
// ---------------------------------------------------------------------------

const riverUniforms = {
  uTime: { value: 0 },
  uDeep: { value: new THREE.Color(0x0f5574) },
  uShallow: { value: new THREE.Color(0x2fa3b8) },
  uSky: { value: new THREE.Color(0xbce8ef) },
  uFoam: { value: new THREE.Color(0xffffff) },
  uSunDir: { value: V3(-0.45, 0.75, 0.5).normalize() },
  uSunColor: { value: new THREE.Color(0xfff4cf) },
};

const riverMaterial = new THREE.ShaderMaterial({
  uniforms: riverUniforms,
  transparent: false,
  depthWrite: true,
  side: THREE.DoubleSide,
  vertexShader: /* glsl */ `
    uniform float uTime;
    varying vec2 vUv;
    varying vec3 vWorld;
    void main() {
      vec3 p = position;
      float edge = smoothstep(0.0, 0.14, uv.x) * (1.0 - smoothstep(0.86, 1.0, uv.x));
      float wave = sin(uv.y * 42.0 - uTime * 2.15 + uv.x * 7.0) * 0.011
                 + sin(uv.y * 76.0 + uTime * 1.35 + uv.x * 13.0) * 0.0045;
      p.y += wave * edge;
      vec4 world = modelMatrix * vec4(p, 1.0);
      vWorld = world.xyz;
      vUv = uv;
      gl_Position = projectionMatrix * viewMatrix * world;
    }
  `,
  fragmentShader: /* glsl */ `
    uniform float uTime;
    uniform vec3 uDeep;
    uniform vec3 uShallow;
    uniform vec3 uSky;
    uniform vec3 uFoam;
    uniform vec3 uSunDir;
    uniform vec3 uSunColor;
    varying vec2 vUv;
    varying vec3 vWorld;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
    }
    float vnoise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      f = f * f * (3.0 - 2.0 * f);
      float a = hash(i);
      float b = hash(i + vec2(1.0, 0.0));
      float c = hash(i + vec2(0.0, 1.0));
      float d = hash(i + vec2(1.0, 1.0));
      return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
    }

    void main() {
      float edge = smoothstep(0.0, 0.16, vUv.x) * (1.0 - smoothstep(0.84, 1.0, vUv.x));
      vec2 flow = vec2(vUv.x * 6.0, vUv.y * 18.0 - uTime * 0.95);
      float n = vnoise(flow * 1.25) + 0.5 * vnoise(flow * 2.8 + 3.0);
      vec3 normal = normalize(vec3(
        (n - 0.75) * 0.36,
        1.0,
        (vnoise(flow * 1.7 + 8.0) - 0.5) * 0.36
      ));
      vec3 viewDir = normalize(cameraPosition - vWorld);
      float fresnel = pow(1.0 - clamp(dot(viewDir, normal), 0.0, 1.0), 2.2);

      vec3 col = mix(uDeep, uShallow, clamp(0.15 + n * 0.4 + (1.0 - edge) * 0.06, 0.0, 1.0));
      col = mix(col, uSky, 0.08 + 0.16 * fresnel);

      // 水底的深色暗流与岸边落花的倒影。
      float current = vnoise(vec2(vUv.y * 3.4 - uTime * 0.28, vUv.x * 2.6 + 2.0));
      col = mix(col, uDeep * 0.75, smoothstep(0.54, 0.9, current) * 0.44);
      float petalRef = smoothstep(0.68, 0.95, vnoise(vec2(vUv.y * 8.0 - uTime * 0.32, vUv.x * 13.0 + 4.0)));
      col = mix(col, vec3(0.96, 0.59, 0.7), petalRef * 0.09);

      float streak = sin(vUv.y * 88.0 - uTime * 3.35 + sin(vUv.x * 10.0 + uTime) * 2.0) * 0.5 + 0.5;
      float streak2 = sin(vUv.y * 143.0 - uTime * 4.9 + vUv.x * 8.0) * 0.5 + 0.5;
      col += vec3(0.18, 0.25, 0.23) * pow(streak * streak2, 7.0) * 0.8;

      // 溪底折射焦散：两层错位波纹在浅水中形成游动的亮网。
      vec2 c1 = vec2(vUv.x * 14.0 + uTime * 0.25, vUv.y * 18.0 - uTime * 0.95);
      vec2 c2 = vec2(vUv.x * 21.0 - uTime * 0.17, vUv.y * 29.0 + uTime * 1.35);
      float causticA = sin(c1.x + vnoise(c1 * 0.7) * 5.0) * sin(c1.y + vnoise(c1 * 0.9 + 2.0) * 4.0);
      float causticB = sin(c2.x + vnoise(c2 * 0.65 + 9.0) * 5.0) * sin(c2.y + vnoise(c2 * 1.1) * 4.0);
      float caustic = smoothstep(0.46, 0.94, abs(causticA + causticB * 0.62));
      col += vec3(0.18, 0.23, 0.2) * caustic * 0.5;

      vec3 halfDir = normalize(uSunDir + viewDir);
      float spec = pow(max(dot(normal, halfDir), 0.0), 110.0);
      col += uSunColor * spec * 0.85;

      // 高光碎钻：在逆光下形成一层波光粼粼的白色闪点。
      float glitterA = vnoise(vec2(vUv.y * 58.0 - uTime * 2.8, vUv.x * 124.0 + uTime * 1.2));
      float glitterB = vnoise(vec2(vUv.y * 91.0 + uTime * 1.7, vUv.x * 47.0 - uTime * 0.9));
      float glitter = smoothstep(0.8, 0.97, glitterA * 0.7 + glitterB * 0.45);
      col += vec3(1.0, 0.98, 0.9) * glitter * (0.25 + 0.55 * fresnel) * 0.55;

      float foamDist = min(vUv.x, 1.0 - vUv.x);
      float foamBand = 1.0 - smoothstep(0.0, 0.058, foamDist);
      float foamNoise = vnoise(vec2(vUv.y * 21.0 - uTime * 1.25, vUv.x * 9.0));
      float foam = foamBand * (0.32 + 0.68 * foamNoise);
      float line = smoothstep(0.92, 1.0, sin(vUv.y * 51.0 - uTime * 2.5 + n * 6.0) * 0.5 + 0.5);
      foam += line * 0.09 * (0.3 + 0.7 * edge);
      col = mix(col, uFoam, clamp(foam, 0.0, 0.72));

      float alpha = 1.0;
      gl_FragColor = vec4(col, alpha);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `,
});

let waterSparkleMaterial = null;
const riverSamples = [];
(function buildRiver() {
  const riverGroup = new THREE.Group();
  scene.add(riverGroup);
  for (let i = 0; i <= 190; i++) {
    const t = i / 190;
    const z = lerp(-3.08, 9.42, t);
    const x = riverCenter(z);
    const w = riverWidth(z);
    const y = WATER_LEVEL - t * 0.022;
    riverSamples.push({ x, z, y, w, t });
    const s0 = { ...riverSamples[i], tx: 0, tz: -1 };
    if (i > 0) {
      s0.tx = x - riverSamples[i - 1].x;
      s0.tz = z - riverSamples[i - 1].z;
    }
    riverSamples[i].tx = s0.tx;
    riverSamples[i].tz = s0.tz;
  }
  const geo = ribbonGeometry(
    riverSamples,
    (s) => s.w * 0.5,
    (s) => s.y,
    12
  );
  const river = new THREE.Mesh(geo, riverMaterial);
  river.renderOrder = 2;
  river.receiveShadow = false;
  riverGroup.add(river);

  // 水面上的浅色浮光片，让溪流在逆光下仍有波光。
  const glintMat = new THREE.MeshBasicMaterial({
    color: 0xf5ffff,
    transparent: true,
    opacity: 0.36,
    depthWrite: false,
    side: THREE.DoubleSide,
    toneMapped: true,
  });
  const glintGeo = new THREE.PlaneGeometry(0.24, 0.055);
  const glints = [];
  for (let i = 0; i < 42; i++) {
    const z = lerp(-1.9, 8.8, rng());
    const x = riverCenter(z) + (rng() - 0.5) * riverWidth(z) * 0.58;
    const m = new THREE.Mesh(glintGeo, glintMat);
    m.position.set(x, WATER_LEVEL + 0.006, z);
    m.rotation.x = -Math.PI / 2;
    m.rotation.z = rand(0, Math.PI);
    const s = rand(0.5, 1.35);
    m.scale.set(s, s, 1);
    m.renderOrder = 3;
    riverGroup.add(m);
    glints.push({ mesh: m, phase: rand(0, 8) });
  }
  riverGroup.userData.glints = glints;

  // 水面星芒：用单个 Points 画 240 个闪烁光点，既亮又不增加 draw call。
  const sparkleCount = 260;
  const sparklePositions = new Float32Array(sparkleCount * 3);
  const sparklePhases = new Float32Array(sparkleCount);
  const sparkleSizes = new Float32Array(sparkleCount);
  for (let i = 0; i < sparkleCount; i++) {
    let x;
    let z;
    if (i < 205) {
      z = lerp(-2.9, 9.15, rng());
      x = riverCenter(z) + (rng() - 0.5) * riverWidth(z) * 0.74;
    } else {
      const a = rng() * Math.PI * 2;
      const r = Math.sqrt(rng()) * 1.55;
      x = -2.4 + Math.cos(a) * r;
      z = -2.68 + Math.sin(a) * r;
    }
    sparklePositions[i * 3] = x;
    sparklePositions[i * 3 + 1] = WATER_LEVEL + 0.028 + rng() * 0.014;
    sparklePositions[i * 3 + 2] = z;
    sparklePhases[i] = rand(0, 10);
    sparkleSizes[i] = rand(0.7, 2.0);
  }
  const sparkleGeo = new THREE.BufferGeometry();
  sparkleGeo.setAttribute('position', new THREE.BufferAttribute(sparklePositions, 3));
  sparkleGeo.setAttribute('aPhase', new THREE.BufferAttribute(sparklePhases, 1));
  sparkleGeo.setAttribute('aSize', new THREE.BufferAttribute(sparkleSizes, 1));
  waterSparkleMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uPixelRatio: { value: renderer.getPixelRatio() },
    },
    transparent: true,
    depthWrite: false,
    depthTest: true,
    blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */ `
      uniform float uTime;
      uniform float uPixelRatio;
      attribute float aPhase;
      attribute float aSize;
      varying float vTwinkle;
      void main() {
        float blink = pow(0.5 + 0.5 * sin(uTime * 2.9 + aPhase), 4.0);
        vTwinkle = blink;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = aSize * uPixelRatio * (88.0 / max(1.0, -mv.z)) * (0.55 + blink * 0.9);
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      varying float vTwinkle;
      void main() {
        vec2 q = gl_PointCoord - 0.5;
        float d = length(q);
        if (d > 0.5) discard;
        float core = 1.0 - smoothstep(0.0, 0.48, d);
        float cross = max(0.0, 1.0 - abs(q.x) * 8.0) * max(0.0, 1.0 - abs(q.y) * 8.0);
        float alpha = (core * 0.55 + cross * 0.68) * vTwinkle;
        gl_FragColor = vec4(1.0, 0.98, 0.9, alpha * 0.82);
      }
    `,
  });
  const sparkles = new THREE.Points(sparkleGeo, waterSparkleMaterial);
  sparkles.frustumCulled = false;
  sparkles.renderOrder = 4;
  riverGroup.add(sparkles);
})();

// 把 glint 引用留给动画
const riverGroup = scene.children.find((o) => o.userData && o.userData.glints);

// ---------------------------------------------------------------------------
// 瀑布
// ---------------------------------------------------------------------------

const FALL_TOP = V3(-0.18, 3.58, -3.92);
const FALL_BOTTOM = V3(0.06, WATER_LEVEL + 0.03, -2.78);
const fallCurve = new THREE.CatmullRomCurve3([
  V3(FALL_TOP.x, 3.64, -3.96),
  V3(FALL_TOP.x + 0.02, 3.16, -3.82),
  V3(FALL_TOP.x + 0.09, 2.38, -3.56),
  V3(FALL_TOP.x + 0.14, 1.6, -3.3),
  V3(FALL_TOP.x + 0.16, 0.84, -3.05),
  V3(FALL_BOTTOM.x, 0.18, -2.84),
]);

function makeFallStreakTexture() {
  const [c, ctx] = makeCanvas(256, 1024);
  const srng = mulberry32(0x5f17aa);
  ctx.clearRect(0, 0, 256, 1024);
  for (let i = 0; i < 230; i++) {
    const x = srng() * 256;
    const w = 0.35 + srng() * 2.6;
    const alpha = 0.06 + srng() * 0.32;
    const drift = (srng() - 0.5) * 10;
    ctx.strokeStyle = `rgba(255,255,255,${alpha})`;
    ctx.lineWidth = w;
    ctx.beginPath();
    for (let y = -20; y <= 1044; y += 24) {
      const xx = x + drift * Math.sin(y * 0.012 + i) + Math.sin(y * 0.037 + i * 0.7) * 1.8;
      if (y < 0) ctx.moveTo(xx, y);
      else ctx.lineTo(xx, y);
    }
    ctx.stroke();
  }
  for (let i = 0; i < 130; i++) {
    const x = srng() * 256;
    const y = srng() * 1024;
    ctx.fillStyle = `rgba(255,255,255,${0.1 + srng() * 0.35})`;
    ctx.beginPath();
    ctx.ellipse(x, y, 0.6 + srng() * 2.2, 2 + srng() * 9, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.NoColorSpace;
  tex.anisotropy = Math.min(4, renderer.capabilities.getMaxAnisotropy());
  tex.needsUpdate = true;
  return tex;
}

const fallStreakTexture = makeFallStreakTexture();

function makeFallMaterial(speed, widthScale = 1) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uSpeed: { value: speed },
      uWater: { value: new THREE.Color(0x9edce6) },
      uDeep: { value: new THREE.Color(0x4a9fb5) },
      uFoam: { value: new THREE.Color(0xffffff) },
      uWidth: { value: widthScale },
      uStreakTex: { value: fallStreakTexture },
    },
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    vertexShader: /* glsl */ `
      uniform float uTime;
      varying vec2 vUv;
      void main() {
        vec3 p = position;
        float sway = sin(uv.y * 28.0 - uTime * 4.6 + uv.x * 8.0) * 0.018 * (0.4 + uv.y);
        p.x += sway;
        p.z += sin(uv.y * 19.0 - uTime * 3.1) * 0.012;
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform float uTime;
      uniform float uSpeed;
      uniform vec3 uWater;
      uniform vec3 uDeep;
      uniform vec3 uFoam;
      uniform float uWidth;
      uniform sampler2D uStreakTex;
      varying vec2 vUv;

      float hash(vec2 p) {
        return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453);
      }

      void main() {
        float edge = smoothstep(0.0, 0.18, vUv.x) * (1.0 - smoothstep(0.82, 1.0, vUv.x));
        float flow = vUv.y * 2.2 - uTime * uSpeed;
        float veil = sin(vUv.x * 24.0 + flow * 9.0) * 0.5 + 0.5;
        float veil2 = sin(vUv.x * 51.0 - flow * 14.0 + 1.7) * 0.5 + 0.5;
        float bands = smoothstep(0.2, 0.9, veil * 0.7 + veil2 * 0.42);
        vec3 col = mix(uDeep, uWater, 0.26 + bands * 0.58);
        float bright = smoothstep(0.55, 1.0, sin(vUv.y * 34.0 - uTime * uSpeed * 1.15 + vUv.x * 9.0) * 0.5 + 0.5);
        col = mix(col, uFoam, 0.2 + bright * 0.28);

        // 两层不同速度的纵向拉丝纹理：粗细与断裂同时出现。
        vec2 streakA = vec2(vUv.x * 1.15 + 0.08, vUv.y * 2.2 - uTime * uSpeed * 0.34);
        vec2 streakB = vec2(vUv.x * 2.05 + 0.31, vUv.y * 3.6 - uTime * uSpeed * 0.57);
        float threadA = texture2D(uStreakTex, streakA).a;
        float threadB = texture2D(uStreakTex, streakB).a;
        float threads = smoothstep(0.08, 0.9, threadA * 0.72 + threadB * 0.55);
        col = mix(col, uFoam, threads * 0.3);

        // 水膜的折射错位与焦散亮边。
        float refrA = sin(vUv.x * 34.0 - uTime * 2.3 + vUv.y * 9.0);
        float refrB = sin(vUv.y * 27.0 + uTime * 3.1 + vUv.x * 5.0);
        float refr = smoothstep(0.72, 1.0, abs(refrA * refrB));
        col += vec3(0.06, 0.12, 0.14) * refr * 0.5;
        col.r += refr * 0.018;
        col.b += refr * 0.026;

        float bottomFoam = (1.0 - smoothstep(0.0, 0.22, vUv.y)) * (0.45 + 0.55 * hash(vec2(vUv.x * 11.0, floor(uTime * 3.0))));
        col = mix(col, uFoam, bottomFoam * 0.95);

        float alpha = (0.64 + 0.3 * bands + threads * 0.08) * edge;
        alpha = max(alpha, bottomFoam * 0.8);
        gl_FragColor = vec4(col, alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
}

const fallMaterials = [];
const fallMistSprites = [];
(function buildWaterfall() {
  const fallGroup = new THREE.Group();
  fallGroup.position.x = FALL_X;
  scene.add(fallGroup);

  function buildFallRibbon(curve, halfWidth, material, lateralOffset = 0) {
    const N = 44;
    const verts = [];
    const uvs = [];
    const indices = [];
    const p = new THREE.Vector3();
    const tan = new THREE.Vector3();
    for (let i = 0; i <= N; i++) {
      const t = i / N;
      curve.getPoint(t, p);
      curve.getTangent(t, tan);
      const w = halfWidth * (0.72 + t * 0.5);
      verts.push(p.x - w + lateralOffset, p.y, p.z);
      verts.push(p.x + w + lateralOffset, p.y, p.z);
      uvs.push(0, t, 1, t);
      if (i > 0) {
        const a = (i - 1) * 2;
        const b = a + 1;
        const c = i * 2;
        const d = c + 1;
        indices.push(a, c, b, b, c, d);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, material);
    mesh.renderOrder = 4;
    fallGroup.add(mesh);
    return mesh;
  }

  const mainMat = makeFallMaterial(1.55, 1);
  const sideMat = makeFallMaterial(1.15, 0.65);
  fallMaterials.push(mainMat, sideMat);
  const accentMat = makeFallMaterial(1.9, 0.5);
  fallMaterials.push(accentMat);
  buildFallRibbon(fallCurve, 0.78, mainMat, 0);
  buildFallRibbon(fallCurve, 0.36, sideMat, -0.7);
  buildFallRibbon(fallCurve, 0.2, accentMat, 0.66);

  // 瀑布两侧的湿黑巨石
  const fallRockGeo = flatGeometry(new THREE.DodecahedronGeometry(1, 0));
  const fallRockData = [
    [-2.12, 1.0, -3.5, 0.94, 1.48, 0.84],
    [1.93, 1.14, -3.54, 0.98, 1.62, 0.86],
    [-1.66, 2.72, -3.8, 0.62, 1.16, 0.6],
    [1.5, 2.62, -3.82, 0.66, 1.2, 0.63],
    [-1.55, 0.3, -2.94, 0.42, 0.32, 0.38],
    [1.45, 0.27, -2.9, 0.46, 0.3, 0.36],
    [-2.05, 0.28, -2.98, 0.48, 0.34, 0.42],
    [1.95, 0.4, -2.85, 0.5, 0.38, 0.44],
  ];
  for (let i = 0; i < fallRockData.length; i++) {
    const r = fallRockData[i];
    TMP_OBJ.position.set(r[0] + FALL_TOP.x, r[1], r[2]);
    TMP_OBJ.rotation.set(rand(0, 3), rand(0, 6), rand(0, 3));
    TMP_OBJ.scale.set(r[3], r[4], r[5]);
    TMP_OBJ.updateMatrix();
    const rock = new THREE.Mesh(fallRockGeo, MAT.fallRock);
    rock.matrix.copy(TMP_OBJ.matrix);
    rock.matrix.decompose(rock.position, rock.quaternion, rock.scale);
    rock.castShadow = true;
    rock.receiveShadow = true;
    fallGroup.add(rock);
    if (i < 6) {
      const moss = new THREE.Mesh(flatGeometry(new THREE.IcosahedronGeometry(1, 0)), MAT.moss);
      moss.position.set(r[0] + FALL_TOP.x + 0.1, r[1] + r[4] * 0.52, r[2] + 0.06);
      moss.scale.set(r[3] * 0.54, 0.16, r[5] * 0.52);
      moss.rotation.y = rand(0, 6);
      moss.castShadow = false;
      moss.receiveShadow = true;
      moss.material = toon(new THREE.Color(0x5c8f51));
      fallGroup.add(moss);
    }
  }

  // 瀑后崖壁不再使用一整块盒子，而是由多颗不规则多面体堆叠成参差岩壁。
  const backRockData = [
    [-1.5, 1.15, -4.28, 1.02, 1.6, 0.42],
    [-0.35, 1.3, -4.36, 1.15, 1.85, 0.45],
    [0.95, 1.1, -4.27, 0.95, 1.55, 0.42],
    [-1.0, 2.6, -4.22, 0.82, 0.72, 0.42],
    [0.85, 2.7, -4.24, 0.86, 0.78, 0.44],
    [-0.05, 3.22, -4.3, 0.7, 0.55, 0.4],
    [-1.75, 2.1, -4.12, 0.48, 0.8, 0.36],
    [1.7, 2.25, -4.15, 0.5, 0.85, 0.37],
    [0.15, 2.2, -4.48, 1.0, 0.9, 0.35],
  ];
  for (let i = 0; i < backRockData.length; i++) {
    const r = backRockData[i];
    const rock = new THREE.Mesh(fallRockGeo, MAT.fallRock);
    rock.position.set(r[0] + FALL_TOP.x, r[1], r[2]);
    rock.scale.set(r[3], r[4], r[5]);
    rock.rotation.set(rand(0, 3), rand(0, 6), rand(0, 3));
    rock.castShadow = true;
    rock.receiveShadow = true;
    fallGroup.add(rock);
  }

  // 崖顶覆苔，遮住岩块边缘。
  const shelfMossMat = toon(0x5b8c50);
  const shelfMoss = [
    [-1.34, 3.55, -4.0, 0.58, 0.15, 0.42],
    [-0.62, 3.60, -4.22, 0.45, 0.13, 0.38],
    [0.38, 3.59, -4.24, 0.52, 0.13, 0.4],
    [1.2, 3.54, -4.04, 0.55, 0.15, 0.38],
  ];
  for (let i = 0; i < shelfMoss.length; i++) {
    const m = shelfMoss[i];
    const moss = new THREE.Mesh(flatGeometry(new THREE.IcosahedronGeometry(1, 0)), shelfMossMat);
    moss.position.set(m[0], m[1], m[2]);
    moss.scale.set(m[3], m[4], m[5]);
    moss.rotation.y = rand(0, 6);
    moss.castShadow = true;
    moss.receiveShadow = true;
    fallGroup.add(moss);
  }
  // 崖顶碎石，让岩壁顶端不再平直。
  const capRocks = [
    [-1.22, 3.58, -4.16, 0.48, 0.32, 0.4],
    [-0.45, 3.64, -4.28, 0.38, 0.28, 0.35],
    [0.58, 3.63, -4.27, 0.42, 0.3, 0.36],
    [1.28, 3.55, -4.15, 0.45, 0.3, 0.38],
  ];
  for (let i = 0; i < capRocks.length; i++) {
    const r = capRocks[i];
    const rock = new THREE.Mesh(flatGeometry(new THREE.DodecahedronGeometry(1, 0)), MAT.fallRock);
    rock.position.set(r[0], r[1], r[2]);
    rock.scale.set(r[3], r[4], r[5]);
    rock.rotation.set(rand(0, 3), rand(0, 6), rand(0, 3));
    rock.castShadow = true;
    rock.receiveShadow = true;
    fallGroup.add(rock);
  }

  // 瀑布下方的水雾
  const mistTex = makeMistTexture();
  for (let i = 0; i < 5; i++) {
    const mat = new THREE.SpriteMaterial({
      map: mistTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.24 + i * 0.03,
      color: 0xf7ffff,
      fog: true,
    });
    const mist = new THREE.Sprite(mat);
    mist.position.set(
      FALL_BOTTOM.x + rand(-0.65, 0.55),
      0.26 + rand(0.0, 0.24),
      FALL_BOTTOM.z + rand(-0.35, 0.45)
    );
    const s = 2.8 + rand(0, 2.3);
    mist.scale.set(s, s * 0.72, 1);
    mist.renderOrder = 8;
    fallGroup.add(mist);
    mist.userData.baseX = mist.position.x;
    mist.userData.baseY = mist.position.y;
    mist.userData.phase = rand(0, 8);
    fallMistSprites.push(mist);
  }

  // 水花粒子
  const splashTex = makeMistTexture();
  const SPLASH_COUNT = 140;
  const splashPositions = new Float32Array(SPLASH_COUNT * 3);
  const splashState = [];
  for (let i = 0; i < SPLASH_COUNT; i++) {
    splashState.push({
      x: FALL_BOTTOM.x + rand(-0.55, 0.55),
      y: 0.18 + rand(0, 0.15),
      z: FALL_BOTTOM.z + rand(-0.3, 0.3),
      vy: rand(0.35, 1.15),
      vx: rand(-0.35, 0.35),
      vz: rand(-0.25, 0.25),
      life: rand(0, 1),
      speed: rand(0.45, 1.0),
    });
  }
  const splashGeo = new THREE.BufferGeometry();
  splashGeo.setAttribute('position', new THREE.BufferAttribute(splashPositions, 3));
  const splashMat = new THREE.PointsMaterial({
    size: 0.12,
    map: splashTex,
    transparent: true,
    opacity: 0.82,
    depthWrite: false,
    color: 0xf2ffff,
    blending: THREE.AdditiveBlending,
    sizeAttenuation: true,
    toneMapped: false,
  });
  const splashPoints = new THREE.Points(splashGeo, splashMat);
  splashPoints.renderOrder = 9;
  fallGroup.add(splashPoints);
  fallGroup.userData.splash = { state: splashState, geo: splashGeo };
})();

// 瀑底荡开的白色水环
const fallRings = [];
(function buildFallRings() {
  const ringGeo = new THREE.RingGeometry(0.3, 0.42, 36);
  ringGeo.rotateX(-Math.PI / 2);
  const prng = mulberry32(0x2adf18);
  for (let i = 0; i < 7; i++) {
    const mat = new THREE.MeshBasicMaterial({
      color: 0xf8ffff,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
      side: THREE.DoubleSide,
      toneMapped: false,
    });
    const ring = new THREE.Mesh(ringGeo, mat);
    ring.position.set(
      FALL_BOTTOM.x + FALL_X + (prng() - 0.5) * 0.85,
      WATER_LEVEL + 0.014,
      FALL_BOTTOM.z + (prng() - 0.5) * 0.5
    );
    ring.renderOrder = 6;
    scene.add(ring);
    fallRings.push({ mesh: ring, phase: prng(), rate: 0.16 + prng() * 0.12 });
  }
})();

// 山谷里缓慢漂移的薄雾
const valleyMists = [];
(function buildValleyMist() {
  const mistTex = makeMistTexture();
  const spots = [
    [-4.7, 1.15, 0.2, 7.0],
    [3.3, 1.05, -1.4, 6.2],
    [-1.2, 0.8, 2.4, 5.6],
    [0.7, 1.6, -4.1, 5.2],
    [-5.5, 2.55, -4.2, 5.4],
    [5.1, 2.35, -4.6, 5.2],
    [0.3, 0.72, 5.9, 4.2],
    [-3.2, 1.0, 6.8, 4.4],
  ];
  for (let i = 0; i < spots.length; i++) {
    const [x, y, z, size] = spots[i];
    const mat = new THREE.SpriteMaterial({
      map: mistTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.12 + (i % 3) * 0.025,
      color: 0xfff3f2,
      fog: true,
    });
    const mist = new THREE.Sprite(mat);
    mist.position.set(x, y, z);
    mist.scale.set(size, size * 0.3, 1);
    mist.renderOrder = 7;
    scene.add(mist);
    valleyMists.push({ sprite: mist, baseX: x, baseY: y, phase: i * 0.9 });
  }
})();

// ---------------------------------------------------------------------------
// 桃树：枝干与花冠实例化
// ---------------------------------------------------------------------------

const treeGroup = new THREE.Group();
scene.add(treeGroup);
const trunkBuckets = [];
const canopyBuckets = [];
const accentBuckets = [];

function composeSegment(a, b, radius) {
  const dir = TMP_V.copy(b).sub(a);
  const len = dir.length();
  if (len < 0.0001) return null;
  const mid = V3((a.x + b.x) * 0.5, (a.y + b.y) * 0.5, (a.z + b.z) * 0.5);
  const q = new THREE.Quaternion().setFromUnitVectors(UP, dir.normalize());
  const m = new THREE.Matrix4();
  m.compose(mid, q, V3(radius, len, radius));
  return m;
}

function buildTrees(specs) {
  const trunkMatrices = [];
  const trunkColors = [];
  const canopyMatrices = [];
  const canopyColors = [];
  const blossomMatrices = [];
  const blossomColors = [];
  const leafMatrices = [];
  const leafColors = [];
  const canopyGeometry = new THREE.SphereGeometry(1, 6, 4);
  const trunkGeometry = new THREE.CylinderGeometry(0.55, 1, 1, 6, 1);
  // 两片交叉的透明花瓣面片，给小球花冠补充细碎的边缘与空气感。
  const blossomGeometry = (() => {
    const positions = [];
    const uvs = [];
    const indices = [];
    for (let q = 0; q < 2; q++) {
      const a = q * Math.PI * 0.5;
      const dx = Math.cos(a);
      const dz = Math.sin(a);
      const base = positions.length / 3;
      const w = 0.52;
      const h = 0.48;
      positions.push(
        -dx * w, -h, -dz * w,
        dx * w, -h, dz * w,
        dx * w, h, dz * w,
        -dx * w, h, -dz * w
      );
      uvs.push(0, 0, 1, 0, 1, 1, 0, 1);
      indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    return geo;
  })();
  // 每棵树有自己的一族花色：深粉、柔粉、浅粉或近白，
  // 比所有树随机混色更接近真实桃林的层次。
  const flowerFamilies = [
    [new THREE.Color(0xcf3f72), new THREE.Color(0xdf5583), new THREE.Color(0xee6d97)],
    [new THREE.Color(0xe05b88), new THREE.Color(0xee739b), new THREE.Color(0xfb8daf)],
    [new THREE.Color(0xef8aa8), new THREE.Color(0xf7a3bc), new THREE.Color(0xffbdd0)],
    [new THREE.Color(0xf7b8ca), new THREE.Color(0xffcfdb), new THREE.Color(0xffe5eb)],
    [new THREE.Color(0xc94a82), new THREE.Color(0xdb5d94), new THREE.Color(0xeb73a3)],
    [new THREE.Color(0xffb6c9), new THREE.Color(0xffcbd8), new THREE.Color(0xffe8ee)],
  ];
  const barkPalette = [
    new THREE.Color(0x5d4034),
    new THREE.Color(0x6b493b),
    new THREE.Color(0x4e352f),
    new THREE.Color(0x725040),
  ];
  const leafPalette = [
    new THREE.Color(0x4b6b3e),
    new THREE.Color(0x5d7b49),
    new THREE.Color(0x6d8a55),
    new THREE.Color(0x3f5e37),
  ];

  function addTrunkSegment(a, b, radius, color) {
    const m = composeSegment(a, b, radius);
    if (!m) return;
    trunkMatrices.push(m);
    trunkColors.push(color.clone().offsetHSL(0, 0, trand(-0.018, 0.02)));
  }

  // 把一条直枝拆成 4~5 段带 S 弯与端部下垂的曲线，参考桃树的虬曲枝态。
  function addBentBranch(a, b, baseRadius, color, bendRng, segments = 4, strength = 1) {
    const dir = TMP_V.copy(b).sub(a);
    const len = dir.length();
    if (len < 0.001) return null;
    const horizontal = V3(dir.x, 0, dir.z);
    if (horizontal.lengthSq() < 0.0001) horizontal.set(1, 0, 0);
    horizontal.normalize();
    const side = V3(-horizontal.z, 0, horizontal.x);
    const br = (lo = 0, hi = 1) => lo + (hi - lo) * bendRng();
    const phase = br(0, Math.PI * 2);
    const amp = len * br(0.045, 0.11) * strength;
    const arch = len * br(0.03, 0.095) * strength;
    const p1 = a.clone().lerp(b, 0.35);
    p1.y += arch;
    p1.addScaledVector(side, Math.sin(phase) * amp);
    const p2 = a.clone().lerp(b, 0.7);
    p2.y += arch * 0.52;
    p2.addScaledVector(side, Math.cos(phase * 1.35) * amp * 0.9);
    const tip = b.clone();
    tip.y -= len * br(0.02, 0.075) * strength;
    tip.addScaledVector(side, Math.sin(phase * 0.7) * amp * 0.35);
    const curve = new THREE.CatmullRomCurve3(
      [a.clone(), p1, p2, tip],
      false,
      'catmullrom',
      0.46
    );
    const pts = curve.getPoints(Math.max(3, segments));
    for (let i = 0; i < pts.length - 1; i++) {
      const t = i / (pts.length - 1);
      const rad = baseRadius * lerp(1, 0.52, t);
      addTrunkSegment(pts[i], pts[i + 1], rad, color);
    }
    return { curve, tip: pts[pts.length - 1] };
  }

  for (let si = 0; si < specs.length; si++) {
    const spec = specs[si];
    const tr = mulberry32(spec.seed);
    const rr = (a = 0, b = 1) => a + (b - a) * tr();
    const bendRng = mulberry32((spec.seed ^ 0x6d2b79f5) >>> 0);
    const base = V3(spec.x, spec.baseY - 0.04, spec.z);
    const leanTop = V3(
      spec.x + spec.leanX + rr(-0.24, 0.24) * spec.crown,
      spec.baseY + spec.height,
      spec.z + spec.leanZ + rr(-0.24, 0.24) * spec.crown
    );
    const bark = barkPalette[Math.floor(rr(0, barkPalette.length))];
    const pinkFamilyPool = [0, 1, 0, 4, 2];
    const familyIndex = spec.mainHero
      ? 1
      : (rr() < 0.82
        ? pinkFamilyPool[Math.floor(rr(0, pinkFamilyPool.length))]
        : Math.floor(rr(0, flowerFamilies.length)));
    const family = flowerFamilies[familyIndex];

    // 四段微微扭折的主干，枝干比上一版更密，让花冠后面有可读的黑色枝网。
    const p0 = base;
    const p1 = base.clone().lerp(leanTop, 0.28);
    const p2 = base.clone().lerp(leanTop, 0.55);
    const p3 = base.clone().lerp(leanTop, 0.8);
    const p4 = leanTop;
    const trunkBend = spec.hero ? 1.25 : 1;
    p1.x += rr(-0.1, 0.1) * spec.crown * trunkBend;
    p1.z += rr(-0.1, 0.1) * spec.crown * trunkBend;
    p2.x += rr(-0.2, 0.2) * spec.crown * trunkBend;
    p2.z += rr(-0.2, 0.2) * spec.crown * trunkBend;
    p3.x += rr(-0.25, 0.25) * spec.crown * trunkBend;
    p3.z += rr(-0.25, 0.25) * spec.crown * trunkBend;
    addTrunkSegment(p0, p1, spec.trunkRadius, bark);
    addTrunkSegment(p1, p2, spec.trunkRadius * 0.82, bark);
    addTrunkSegment(p2, p3, spec.trunkRadius * 0.64, bark);
    addTrunkSegment(p3, p4, spec.trunkRadius * 0.44, bark);
    const trunkPoints = [p0, p1, p2, p3, p4];
    const pointOnTrunk = (t) => {
      const seg = Math.min(3, Math.floor(t * 4));
      return trunkPoints[seg].clone().lerp(trunkPoints[seg + 1], t * 4 - seg);
    };

    const rootCount = spec.hero ? 5 : 2 + Math.floor(rr(0, 2));
    for (let r = 0; r < rootCount; r++) {
      const ang = r * 1.7 + rr(-0.35, 0.35);
      const rootEnd = V3(
        base.x + Math.cos(ang) * spec.crownW * rr(0.24, 0.4),
        base.y - 0.01,
        base.z + Math.sin(ang) * spec.crownD * rr(0.24, 0.4)
      );
      const rootStart = V3(base.x, base.y + spec.height * rr(0.1, 0.2), base.z);
      addTrunkSegment(rootStart, rootEnd, spec.trunkRadius * rr(0.3, 0.48), bark);
    }

    const tips = [];
    const branchSegments = [];
    const branchCount = spec.branchCount;
    for (let bi = 0; bi < branchCount; bi++) {
      const startT = 0.34 + rr(0, 0.34);
      const start = pointOnTrunk(startT);
      const angle = bi * 2.399 + rr(-0.28, 0.28);
      const reachX = spec.crownW * (0.5 + rr(0, 0.58));
      const reachZ = spec.crownD * (0.5 + rr(0, 0.58));
      const end = V3(
        start.x + Math.cos(angle) * reachX,
        start.y + spec.crownH * (0.2 + rr(0, 0.48)),
        start.z + Math.sin(angle) * reachZ
      );
      const branchRadius = spec.trunkRadius * (0.3 + rr(0, 0.14));
      const bent = addBentBranch(
        start,
        end,
        branchRadius,
        bark,
        bendRng,
        spec.hero ? 6 : 4,
        spec.hero ? 1.4 : 1.12
      );
      const branchTip = bent ? bent.tip : end;
      tips.push(branchTip);
      branchSegments.push(bent
        ? [bent.curve.getPoint(0.24), bent.curve.getPoint(0.96)]
        : [start, end]);

      if (spec.mainHero && bi < 6) {
        const tAnchor = rr(0.7, 0.92);
        const anchor = bent ? bent.curve.getPoint(tAnchor) : end;
        spec.ribbonAnchors.push(V3(
          anchor.x,
          anchor.y + rr(-0.06, 0.08),
          anchor.z
        ));
      }

      const twigCount = spec.twigCount;
      for (let tw = 0; tw < twigCount; tw++) {
        const t0 = 0.48 + rr(0, 0.34);
        const twigStart = bent
          ? bent.curve.getPoint(t0)
          : start.clone().lerp(end, t0);
        const twigAngle = angle + rr(-1.35, 1.35);
        const twigEnd = V3(
          twigStart.x + Math.cos(twigAngle) * spec.crownW * rr(0.2, 0.44),
          twigStart.y + spec.crownH * rr(0.12, 0.34),
          twigStart.z + Math.sin(twigAngle) * spec.crownD * rr(0.2, 0.44)
        );
        const bentTwig = addBentBranch(
          twigStart,
          twigEnd,
          spec.trunkRadius * rr(0.1, 0.19),
          bark,
          bendRng,
          3,
          1.32
        );
        const twigTip = bentTwig ? bentTwig.tip : twigEnd;
        tips.push(twigTip);
        branchSegments.push(bentTwig
          ? [bentTwig.curve.getPoint(0.2), bentTwig.tip]
          : [twigStart, twigEnd]);
      }
    }

    const crownCenter = V3(
      lerp(p0.x, p4.x, 0.86),
      p4.y + spec.crownH * 0.14,
      lerp(p0.z, p4.z, 0.86)
    );

    // 树冠不是一个大圆柱，而是由中央大裂片 + 六个偏斜裂片组成的
    // 不规则圆顶。这样外轮廓会像真实桃树一样向四周溢出，不会出现方顶。
    const crownLobes = [{
      x: crownCenter.x,
      y: crownCenter.y + spec.crownH * 0.03,
      z: crownCenter.z,
      rx: spec.crownW * 0.59,
      ry: spec.crownH * 0.52,
      rz: spec.crownD * 0.59,
    }];
    const ringCount = 6;
    for (let li = 0; li < ringCount; li++) {
      const angle = (li / ringCount) * Math.PI * 2 + rr(-0.38, 0.38);
      const ringR = rr(0.28, 0.52);
      crownLobes.push({
        x: crownCenter.x + Math.cos(angle) * spec.crownW * ringR,
        y: crownCenter.y + rr(-0.14, 0.2) * spec.crownH,
        z: crownCenter.z + Math.sin(angle) * spec.crownD * ringR,
        rx: spec.crownW * rr(0.42, 0.6),
        ry: spec.crownH * rr(0.36, 0.52),
        rz: spec.crownD * rr(0.42, 0.6),
      });
    }
    // 下层外扩裂片：让花冠向下包住枝桠，而不是只顶着一个平底蘑菇盖。
    for (let li = 0; li < 3; li++) {
      const angle = li * (Math.PI * 2 / 3) + rr(-0.5, 0.5);
      const ringR = rr(0.3, 0.5);
      crownLobes.push({
        x: crownCenter.x + Math.cos(angle) * spec.crownW * ringR,
        y: crownCenter.y - spec.crownH * rr(0.24, 0.38),
        z: crownCenter.z + Math.sin(angle) * spec.crownD * ringR,
        rx: spec.crownW * rr(0.38, 0.54),
        ry: spec.crownH * rr(0.3, 0.44),
        rz: spec.crownD * rr(0.38, 0.54),
      });
    }
    // 上层侧裂片把圆弧顶打碎，形成参考图里不规则的桃花云团。
    for (let li = 0; li < 2; li++) {
      const angle = li * Math.PI + 0.8 + rr(-0.5, 0.5);
      const ringR = rr(0.18, 0.34);
      crownLobes.push({
        x: crownCenter.x + Math.cos(angle) * spec.crownW * ringR,
        y: crownCenter.y + spec.crownH * rr(0.22, 0.34),
        z: crownCenter.z + Math.sin(angle) * spec.crownD * ringR,
        rx: spec.crownW * rr(0.34, 0.48),
        ry: spec.crownH * rr(0.28, 0.4),
        rz: spec.crownD * rr(0.34, 0.48),
      });
    }
    const crownLobeWeights = [];
    let crownLobeVolume = 0;
    for (let li = 0; li < crownLobes.length; li++) {
      const lobe = crownLobes[li];
      crownLobeVolume += lobe.rx * lobe.ry * lobe.rz;
      crownLobeWeights.push(crownLobeVolume);
    }
    const sampleCrown = (spread = 1) => {
      const pick = rr(0, crownLobeVolume);
      let lobe = crownLobes[crownLobes.length - 1];
      for (let li = 0; li < crownLobeWeights.length; li++) {
        if (pick <= crownLobeWeights[li]) {
          lobe = crownLobes[li];
          break;
        }
      }
      const theta = rr(0, Math.PI * 2);
      const vz = rr(-1, 1);
      const sinV = Math.sqrt(1 - vz * vz);
      const edge = 0.91
        + 0.13 * Math.sin(theta * 5.0 + spec.seed * 0.0017)
        + 0.04 * Math.sin(theta * 11.0 + spec.seed * 0.0009);
      const rad = Math.pow(rr(0, 1), 0.43) * spread * edge;
      return V3(
        lobe.x + Math.cos(theta) * sinV * rad * lobe.rx,
        lobe.y + vz * rad * lobe.ry,
        lobe.z + Math.sin(theta) * sinV * rad * lobe.rz
      );
    };

    const pickFamilyColor = () => {
      const color = family[Math.floor(rr(0, family.length))].clone();
      color.lerp(WHITE, rr(0, 0.02));
      return color;
    };
    const addCluster = (px, py, pz, sc, color) => {
      const q = new THREE.Quaternion().setFromEuler(
        new THREE.Euler(rr(-0.45, 0.45), rr(0, Math.PI * 2), rr(-0.35, 0.35))
      );
      TMP_M.compose(
        V3(px, py, pz),
        q,
        V3(sc * rr(1.0, 1.35), sc * rr(0.55, 0.9), sc * rr(1.0, 1.35))
      );
      canopyMatrices.push(TMP_M.clone());
      canopyColors.push(color);
    };
    const addBlossom = (px, py, pz, size, color) => {
      TMP_OBJ.position.set(px, py, pz);
      TMP_OBJ.rotation.set(rr(-0.6, 0.6), rr(0, Math.PI * 2), rr(-0.6, 0.6));
      TMP_OBJ.scale.set(size * rr(0.8, 1.3), size * rr(0.75, 1.15), size);
      TMP_OBJ.updateMatrix();
      blossomMatrices.push(TMP_OBJ.matrix.clone());
      blossomColors.push(color);
    };
    const addLeaf = (px, py, pz, size, color) => {
      TMP_OBJ.position.set(px, py, pz);
      TMP_OBJ.rotation.set(rr(-0.8, 0.8), rr(0, Math.PI * 2), rr(-0.9, 0.9));
      TMP_OBJ.scale.set(size * rr(0.8, 1.25), size * rr(0.8, 1.2), size);
      TMP_OBJ.updateMatrix();
      leafMatrices.push(TMP_OBJ.matrix.clone());
      leafColors.push(color);
    };

    // 枝干中段的小花团，让每一条枝都带花生长的连续性。
    for (let bi = 0; bi < branchSegments.length; bi++) {
      const [segStart, segEnd] = branchSegments[bi];
      const count = 4 + (rr() < 0.58 ? 1 : 0);
      for (let bc = 0; bc < count; bc++) {
        const t = rr(0.16, 0.9);
        const sc = spec.crown * rr(0.012, 0.028);
        const px = lerp(segStart.x, segEnd.x, t) + rr(-0.06, 0.06) * spec.crown;
        const py = lerp(segStart.y, segEnd.y, t) + rr(-0.03, 0.08) * spec.crown;
        const pz = lerp(segStart.z, segEnd.z, t) + rr(-0.06, 0.06) * spec.crown;
        addCluster(px, py, pz, sc, pickFamilyColor());
        if (rr() < 0.9) {
          addBlossom(px, py, pz, spec.crown * rr(0.055, 0.108), pickFamilyColor());
          addBlossom(
            px + rr(-0.12, 0.12) * spec.crown,
            py + rr(-0.04, 0.1) * spec.crown,
            pz + rr(-0.12, 0.12) * spec.crown,
            spec.crown * rr(0.052, 0.098),
            pickFamilyColor()
          );
        }
      }
    }

    // 花冠主体：从多裂片圆顶中采样，避免圆柱形/方形树冠。
    for (let ci = 0; ci < spec.clusterCount; ci++) {
      const p = sampleCrown(0.94);
      const sc = spec.crown * rr(0.012, 0.03);
      addCluster(p.x, p.y, p.z, sc, pickFamilyColor());
    }

    // 枝梢的小花簇，勾勒完整的树冠外轮廓。
    for (let ti = 0; ti < tips.length; ti++) {
      const tip = tips[ti];
      const tipCount = 2 + (rr() < 0.45 ? 1 : 0);
      for (let tc = 0; tc < tipCount; tc++) {
        const sc = spec.crown * rr(0.01, 0.025);
        addCluster(
          tip.x + rr(-0.1, 0.1) * spec.crown,
          tip.y + rr(-0.05, 0.11) * spec.crown,
          tip.z + rr(-0.1, 0.1) * spec.crown,
          sc,
          pickFamilyColor()
        );
      }
    }

    // 独立细碎的花瓣卡片：从同一组裂片中采样，外轮廓自然、没有方顶。
    const cardCount = spec.cardCount;
    for (let ci = 0; ci < cardCount; ci++) {
      const p = sampleCrown(1.0);
      if (rr() < 0.3) p.y += spec.crownH * rr(0.03, 0.15);
      addBlossom(
        p.x,
        p.y,
        p.z,
        spec.crown * rr(0.06, 0.11),
        pickFamilyColor()
      );
    }
    // 少数垂落花枝与顶部散花，打碎圆顶轮廓的规则边线。
    const drapeCards = Math.floor(spec.cardCount * 0.045);
    for (let ci = 0; ci < drapeCards; ci++) {
      const ang = rr(0, Math.PI * 2);
      const radial = rr(0.68, 1.02);
      addBlossom(
        crownCenter.x + Math.cos(ang) * radial * spec.crownW,
        crownCenter.y - spec.crownH * rr(0.26, 0.48),
        crownCenter.z + Math.sin(ang) * radial * spec.crownD,
        spec.crown * rr(0.05, 0.09),
        pickFamilyColor()
      );
    }
    const topAccentCards = Math.floor(spec.cardCount * 0.028);
    for (let ci = 0; ci < topAccentCards; ci++) {
      const ang = rr(0, Math.PI * 2);
      const radial = rr(0.45, 0.88);
      addBlossom(
        crownCenter.x + Math.cos(ang) * radial * spec.crownW,
        crownCenter.y + spec.crownH * rr(0.32, 0.56),
        crownCenter.z + Math.sin(ang) * radial * spec.crownD,
        spec.crown * rr(0.05, 0.095),
        pickFamilyColor()
      );
    }
    for (let ti = 0; ti < tips.length; ti++) {
      const tip = tips[ti];
      const tipCards = 3 + (rr() < 0.4 ? 1 : 0);
      for (let tc = 0; tc < tipCards; tc++) {
        addBlossom(
          tip.x + rr(-0.12, 0.12) * spec.crown,
          tip.y + rr(-0.02, 0.12) * spec.crown,
          tip.z + rr(-0.12, 0.12) * spec.crown,
          spec.crown * rr(0.055, 0.1),
          pickFamilyColor()
        );
      }
    }

    // 哑光叶片独立散布在花簇之间，增加真实桃树的体积与色彩层次。
    for (let li = 0; li < spec.leafCount; li++) {
      const p = sampleCrown(1.01);
      const leafColor = leafPalette[Math.floor(rr(0, leafPalette.length))].clone();
      leafColor.offsetHSL((rr() - 0.5) * 0.02, (rr() - 0.5) * 0.06, (rr() - 0.5) * 0.08);
      addLeaf(p.x, p.y, p.z, spec.crown * rr(0.045, 0.086), leafColor);
    }
    for (let ti = 0; ti < tips.length; ti++) {
      if (rr() < 0.42) continue;
      const tip = tips[ti];
      const leafColor = leafPalette[Math.floor(rr(0, leafPalette.length))].clone();
      leafColor.offsetHSL(0, 0, (rr() - 0.5) * 0.08);
      addLeaf(
        tip.x + rr(-0.1, 0.1) * spec.crown,
        tip.y + rr(-0.02, 0.09) * spec.crown,
        tip.z + rr(-0.1, 0.1) * spec.crown,
        spec.crown * rr(0.035, 0.07),
        leafColor
      );
    }
    // 外缘深绿叶簇，让粉色花云之间能透出一点真实桃叶的层次。
    const edgeLeafAccents = Math.floor(spec.leafCount * 0.16);
    for (let li = 0; li < edgeLeafAccents; li++) {
      const ang = rr(0, Math.PI * 2);
      const radial = rr(0.72, 1.02);
      const leafColor = leafPalette[Math.floor(rr(0, leafPalette.length))].clone();
      leafColor.offsetHSL(0, 0.04, -0.02 + (rr() - 0.5) * 0.06);
      addLeaf(
        crownCenter.x + Math.cos(ang) * radial * spec.crownW,
        crownCenter.y + rr(-0.34, 0.2) * spec.crownH,
        crownCenter.z + Math.sin(ang) * radial * spec.crownD,
        spec.crown * rr(0.065, 0.1),
        leafColor
      );
    }
  }

  const trunks = new THREE.InstancedMesh(trunkGeometry, MAT.trunk, trunkMatrices.length);
  for (let i = 0; i < trunkMatrices.length; i++) {
    trunks.setMatrixAt(i, trunkMatrices[i]);
    trunks.setColorAt(i, trunkColors[i]);
  }
  trunks.instanceMatrix.needsUpdate = true;
  if (trunks.instanceColor) trunks.instanceColor.needsUpdate = true;
  trunks.castShadow = true;
  trunks.receiveShadow = true;
  treeGroup.add(trunks);

  const canopies = new THREE.InstancedMesh(canopyGeometry, MAT.canopy, canopyMatrices.length);
  for (let i = 0; i < canopyMatrices.length; i++) {
    canopies.setMatrixAt(i, canopyMatrices[i]);
    canopies.setColorAt(i, canopyColors[i]);
  }
  canopies.instanceMatrix.needsUpdate = true;
  if (canopies.instanceColor) canopies.instanceColor.needsUpdate = true;
  // 小片花团只负责投射细碎树影，不再作为可见的大块树冠。
  canopies.castShadow = true;
  canopies.receiveShadow = true;
  treeGroup.add(canopies);

  const blossoms = new THREE.InstancedMesh(blossomGeometry, MAT.blossom, blossomMatrices.length);
  for (let i = 0; i < blossomMatrices.length; i++) {
    blossoms.setMatrixAt(i, blossomMatrices[i]);
    blossoms.setColorAt(i, blossomColors[i]);
  }
  blossoms.instanceMatrix.needsUpdate = true;
  if (blossoms.instanceColor) blossoms.instanceColor.needsUpdate = true;
  blossoms.castShadow = true;
  blossoms.receiveShadow = true;
  treeGroup.add(blossoms);

  const leaves = new THREE.InstancedMesh(blossomGeometry, MAT.leaf, leafMatrices.length);
  for (let i = 0; i < leafMatrices.length; i++) {
    leaves.setMatrixAt(i, leafMatrices[i]);
    leaves.setColorAt(i, leafColors[i]);
  }
  leaves.instanceMatrix.needsUpdate = true;
  if (leaves.instanceColor) leaves.instanceColor.needsUpdate = true;
  leaves.castShadow = true;
  leaves.receiveShadow = true;
  treeGroup.add(leaves);
}

buildTrees(treeSpecs);

// ---------------------------------------------------------------------------
// 姻缘红绸：从主桃树枝桠垂落，带布料褶皱与独立风场
// ---------------------------------------------------------------------------

const silkRibbons = [];

function buildSilkRibbons() {
  const mainTree = treeSpecs.find((tree) => tree.mainHero);
  if (!mainTree) return [];
  const ribRng = mulberry32(0x6f2b18);
  const rr = (a = 0, b = 1) => a + (b - a) * ribRng();
  const anchors = mainTree.ribbonAnchors
    .slice()
    .sort((a, b) => b.y - a.y)
    .slice(0, 6);
  // 20×45 个布面网格，足够让边缘、褶皱和波形连续，而不是一块平板。
  const cols = 21;
  const rows = 46;

  for (let ri = 0; ri < anchors.length; ri++) {
    const anchor = anchors[ri].clone();
    anchor.x += rr(-0.18, 0.18);
    anchor.z += rr(-0.18, 0.18);
    const length = clamp(anchor.y - 0.7 + rr(0.4, 1.4), 2.2, 4.6);
    const width = 0.3 + rr(0, 0.16);
    const phase = rr(0, Math.PI * 2);
    const twistBase = rr(-0.7, 0.7);
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array((rows + 1) * cols * 3);
    const uvs = new Float32Array((rows + 1) * cols * 2);
    const indices = [];
    for (let y = 0; y <= rows; y++) {
      for (let x = 0; x < cols; x++) {
        const p = (y * cols + x) * 3;
        positions[p] = anchor.x;
        positions[p + 1] = anchor.y;
        positions[p + 2] = anchor.z;
        const uv = (y * cols + x) * 2;
        uvs[uv] = x / (cols - 1);
        uvs[uv + 1] = y / rows;
      }
    }
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols - 1; x++) {
        const a = y * cols + x;
        const b = a + 1;
        const c = a + cols;
        const d = c + 1;
        indices.push(a, c, b, b, c, d);
      }
    }
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();

    const mesh = new THREE.Mesh(geometry, MAT.silk);
    mesh.frustumCulled = false;
    mesh.castShadow = false;
    mesh.receiveShadow = true;
    scene.add(mesh);

    const knot = new THREE.Mesh(
      new THREE.TorusGeometry(0.058, 0.013, 6, 12),
      MAT.gold
    );
    knot.position.copy(anchor);
    knot.rotation.set(Math.PI / 2, rr(0, Math.PI), 0);
    knot.castShadow = false;
    scene.add(knot);

    silkRibbons.push({
      mesh,
      geometry,
      positions,
      anchor,
      length,
      width,
      phase,
      twistBase,
      cols,
      rows,
      indexCount: indices.length,
    });
  }
  return silkRibbons;
}
buildSilkRibbons();

function updateSilkRibbons(time, breeze = 0) {
  const gust = clamp(breeze, 0, 1);
  for (let ri = 0; ri < silkRibbons.length; ri++) {
    const ribbon = silkRibbons[ri];
    const {
      positions, anchor, length, width, phase, twistBase, cols, rows,
    } = ribbon;
    for (let y = 0; y <= rows; y++) {
      const u = y / rows;
      const fall = u * u;
      // 整体向右倾斜：顶部保持在金环处，越往下越向右展开。
      const leanX = u * (0.3 + 0.22 * u) + gust * u * (0.06 + 0.1 * u);
      // 以向右为正基线，再缓慢来回摆动；频率很低，避免硬板式抖振。
      const slowSwing = Math.sin(time * 0.16 + phase * 0.45 + u * 0.82)
        * (0.03 + 0.15 * u) * u * (1 + gust * 0.45);
      const slowWaveX = Math.sin(time * 0.09 + phase + u * 0.58)
        * (0.008 + 0.028 * u) * u;
      // 沿整条绸面传播的长波，让中轴线本身弯成柔软的 S 形。
      const bodyWaveX = Math.sin(u * 3.5 + time * 0.32 + phase) * (0.08 + 0.22 * u) * u;
      const bodyWaveX2 = Math.sin(u * 6.2 - time * 0.21 + phase * 1.7) * (0.03 + 0.09 * u) * u;
      const bodyWaveZ = Math.cos(u * 4.1 + time * 0.27 + phase * 1.2)
        * (0.04 + 0.16 * u) * u;
      const swayZ = Math.cos(time * 0.12 + phase * 1.1 + u * 0.8) * (0.012 + 0.05 * u)
        + Math.cos(time * 0.06 + phase + u * 1.6) * (0.008 + 0.02 * u);
      const centerX = anchor.x + leanX + slowSwing + slowWaveX + bodyWaveX + bodyWaveX2;
      const centerY = anchor.y - length * u
        + Math.sin(time * 0.3 + phase + u * 2.0) * 0.014 * u;
      const centerZ = anchor.z + bodyWaveZ + swayZ + Math.sin(phase) * u * 0.08 + gust * 0.025 * u;
      // 缓慢的布料扭转；不再做整块刚性旋转。
      const twist = twistBase + u * 0.95 + Math.sin(time * 0.13 + phase) * 0.06;
      const wdX = Math.cos(twist);
      const wdZ = Math.sin(twist);
      const ndX = -wdZ;
      const ndZ = wdX;
      const halfW = width * (0.5 - 0.12 * fall);
      for (let x = 0; x < cols; x++) {
        const t = x / (cols - 1) - 0.5;
        const edge = 0.3 + Math.abs(t) * 1.35;
        // 两组不同波长/相位的慢波叠加，让布面产生柔软的 S 形起伏。
        const foldA = Math.sin(u * 7.2 - time * 0.38 + phase + t * 2.2)
          * (0.026 + 0.1 * u) * edge;
        const foldB = Math.sin(u * 12.0 - time * 0.24 + phase * 1.6 - t * 2.8)
          * (0.012 + 0.045 * u) * edge;
        const ripple = Math.sin(u * 8.5 - time * 0.3 + phase + t * 1.7)
          * (0.008 + 0.025 * u) * (0.4 + Math.abs(t) * 1.1);
        // 横向微拱让布面有体积，不再像一条平面硬带。
        const curl = Math.sin(t * Math.PI) * (0.03 + 0.07 * u) * (1 + gust * 0.25);
        const fold = foldA + foldB + curl;
        const px = centerX + wdX * (t * 2 * halfW) + ndX * fold + wdX * ripple;
        const pz = centerZ + wdZ * (t * 2 * halfW) + ndZ * fold + wdZ * ripple;
        const py = centerY
          + Math.sin(u * 7.0 + time * 0.28 + t * 2.2) * (0.01 + 0.025 * u) * edge;
        const p = (y * cols + x) * 3;
        positions[p] = px;
        positions[p + 1] = py;
        positions[p + 2] = pz;
      }
    }
    ribbon.geometry.attributes.position.needsUpdate = true;
    ribbon.geometry.computeVertexNormals();
  }
}

// ---------------------------------------------------------------------------
// 草丛、野花、灌木、石头
// ---------------------------------------------------------------------------

function makeGrassGeometry() {
  const positions = [];
  const indices = [];
  for (let b = 0; b < 3; b++) {
    const ang = (b / 3) * Math.PI * 2 + 0.4;
    const dx = Math.cos(ang);
    const dz = Math.sin(ang);
    const sideX = -dz * 0.075;
    const sideZ = dx * 0.075;
    const base = positions.length / 3;
    positions.push(-sideX, 0, -sideZ);
    positions.push(sideX, 0, sideZ);
    positions.push(dx * 0.22, 0.82 + (b % 2) * 0.18, dz * 0.22);
    indices.push(base, base + 1, base + 2);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

(function buildGroundCover() {
  const grassRng = mulberry32(0x7ac882);
  const grassGeo = makeGrassGeometry();
  const grassData = [];
  const flowerData = [];
  const shrubData = [];
  const shrubFlowerData = [];

  // 草丛：在河岸、路旁和林下最密。
  for (let i = 0; i < 7200; i++) {
    const x = lerp(-9.25, 9.25, grassRng());
    const z = lerp(-9.15, 9.3, grassRng());
    const y = terrainHeight(x, z);
    if (y < 0.04) continue;
    if (z > -3.05 && Math.abs(x - riverCenter(z)) < riverWidth(z) * 0.56 + 0.1) continue;
    if (distanceToPath(x, z) < 0.72) continue;
    if (Math.hypot(x - PAVILION.x, z - PAVILION.z) < 1.38) continue;
    const slope = terrainSlope(x, z);
    if (slope > 1.72) continue;
    const nearWater = z > -3.2 ? 1 - smoothstep(1.0, 3.3, Math.abs(x - riverCenter(z))) : 0;
    const prob = 0.42 + nearWater * 0.3;
    if (grassRng() > prob) continue;
    const s = 0.15 + grassRng() * 0.22;
    TMP_OBJ.position.set(x, y + 0.015, z);
    TMP_OBJ.rotation.set(0, grassRng() * Math.PI * 2, (grassRng() - 0.5) * 0.15);
    TMP_OBJ.scale.set(s * (0.8 + grassRng() * 0.6), s, s * (0.8 + grassRng() * 0.6));
    TMP_OBJ.updateMatrix();
    const color = new THREE.Color().setHSL(
      0.245 + grassRng() * 0.055,
      0.42 + grassRng() * 0.23,
      0.34 + grassRng() * 0.2
    );
    grassData.push({ matrix: TMP_OBJ.matrix.clone(), color });
  }

  const grass = new THREE.InstancedMesh(grassGeo, MAT.grass, grassData.length);
  for (let i = 0; i < grassData.length; i++) {
    grass.setMatrixAt(i, grassData[i].matrix);
    grass.setColorAt(i, grassData[i].color);
  }
  grass.instanceMatrix.needsUpdate = true;
  if (grass.instanceColor) grass.instanceColor.needsUpdate = true;
  grass.castShadow = false;
  grass.receiveShadow = true;
  scene.add(grass);

  // 野花小点
  const flowerGeo = new THREE.IcosahedronGeometry(1, 0);
  for (let i = 0; i < 900; i++) {
    const x = lerp(-9.2, 9.2, grassRng());
    const z = lerp(-9.1, 9.25, grassRng());
    const y = terrainHeight(x, z);
    if (y < 0.05) continue;
    if (z > -3.0 && Math.abs(x - riverCenter(z)) < riverWidth(z) * 0.58) continue;
    if (distanceToPath(x, z) < 0.65) continue;
    if (Math.hypot(x - PAVILION.x, z - PAVILION.z) < 1.35) continue;
    if (grassRng() > 0.68) continue;
    const s = 0.035 + grassRng() * 0.055;
    TMP_OBJ.position.set(x, y + s * 0.5, z);
    TMP_OBJ.rotation.set(0, grassRng() * 6, 0);
    TMP_OBJ.scale.set(s * 1.3, s, s * 1.3);
    TMP_OBJ.updateMatrix();
    const palette = [0xffe8d5, 0xf7a9c0, 0xf28faa, 0xffcf7a, 0xe7d5ff];
    const color = new THREE.Color(palette[Math.floor(grassRng() * palette.length)]);
    flowerData.push({ matrix: TMP_OBJ.matrix.clone(), color });
  }

  // 灌木：岸线、路缘和古亭周围。
  const shrubSpots = [];
  for (let z = -1.7; z < 8.9; z += 0.9) {
    for (const side of [-1, 1]) {
      if (grassRng() < 0.35) continue;
      const offset = riverWidth(z) * 0.5 + 0.55 + grassRng() * 0.85;
      shrubSpots.push([riverCenter(z) + side * offset, z + (grassRng() - 0.5) * 0.4]);
    }
  }
  for (let i = 0; i < 24; i++) {
    const s = pathSamples[Math.floor(8 + grassRng() * (pathSamples.length - 16))];
    const side = grassRng() > 0.5 ? 1 : -1;
    shrubSpots.push([s.x + side * (0.9 + grassRng() * 0.7), s.z + (grassRng() - 0.5) * 0.5]);
  }
  for (let i = 0; i < 20; i++) {
    const ang = grassRng() * Math.PI * 2;
    const rad = 1.7 + grassRng() * 1.5;
    shrubSpots.push([PAVILION.x + Math.cos(ang) * rad, PAVILION.z + Math.sin(ang) * rad]);
  }

  for (let i = 0; i < shrubSpots.length; i++) {
    const [x, z] = shrubSpots[i];
    const y = terrainHeight(x, z);
    if (z > -3.0 && Math.abs(x - riverCenter(z)) < riverWidth(z) * 0.58) continue;
    if (distanceToPath(x, z) < 0.65) continue;
    const count = 2 + Math.floor(grassRng() * 3);
    const baseR = 0.19 + grassRng() * 0.2;
    for (let j = 0; j < count; j++) {
      const ang = grassRng() * Math.PI * 2;
      const rr = j === 0 ? 0 : grassRng() * baseR * 0.9;
      const s = baseR * (0.65 + grassRng() * 0.55);
      TMP_OBJ.position.set(
        x + Math.cos(ang) * rr,
        y + s * (0.34 + grassRng() * 0.18),
        z + Math.sin(ang) * rr
      );
      TMP_OBJ.rotation.set(0, grassRng() * 6, 0);
      TMP_OBJ.scale.set(s * 1.15, s * 0.72, s * 1.15);
      TMP_OBJ.updateMatrix();
      const color = new THREE.Color().setHSL(
        0.245 + grassRng() * 0.045,
        0.38 + grassRng() * 0.2,
        0.31 + grassRng() * 0.16
      );
      shrubData.push({ matrix: TMP_OBJ.matrix.clone(), color });
    }
    // 灌木上的粉色花点
    if (grassRng() > 0.38) {
      for (let f = 0; f < 4; f++) {
        const ang = grassRng() * Math.PI * 2;
        const rr = grassRng() * baseR * 1.2;
        const fs = 0.045 + grassRng() * 0.045;
        TMP_OBJ.position.set(
          x + Math.cos(ang) * rr,
          y + baseR * (0.55 + grassRng() * 0.45),
          z + Math.sin(ang) * rr
        );
        TMP_OBJ.rotation.set(0, 0, 0);
        TMP_OBJ.scale.setScalar(fs);
        TMP_OBJ.updateMatrix();
        const c = new THREE.Color(grassRng() > 0.3 ? 0xffbed0 : 0xfff4f5);
        shrubFlowerData.push({ matrix: TMP_OBJ.matrix.clone(), color: c });
      }
    }
  }

  const shrubs = new THREE.InstancedMesh(flatGeometry(new THREE.IcosahedronGeometry(1, 0)), MAT.moss, shrubData.length);
  for (let i = 0; i < shrubData.length; i++) {
    shrubs.setMatrixAt(i, shrubData[i].matrix);
    shrubs.setColorAt(i, shrubData[i].color);
  }
  shrubs.instanceMatrix.needsUpdate = true;
  if (shrubs.instanceColor) shrubs.instanceColor.needsUpdate = true;
  shrubs.castShadow = true;
  shrubs.receiveShadow = true;
  scene.add(shrubs);

  const allFlowers = flowerData.concat(shrubFlowerData);
  const flowers = new THREE.InstancedMesh(flowerGeo, MAT.flower, allFlowers.length);
  for (let i = 0; i < allFlowers.length; i++) {
    flowers.setMatrixAt(i, allFlowers[i].matrix);
    flowers.setColorAt(i, allFlowers[i].color);
  }
  flowers.instanceMatrix.needsUpdate = true;
  if (flowers.instanceColor) flowers.instanceColor.needsUpdate = true;
  flowers.castShadow = false;
  flowers.receiveShadow = false;
  scene.add(flowers);
})();

// ---------------------------------------------------------------------------
// 石头：河岸、山脚、古亭周围
// ---------------------------------------------------------------------------

(function buildRocks() {
  const rockRng = mulberry32(0x54d9e1);
  const rockData = [];
  const roundRockData = [];
  const mossData = [];
  const rockGeo = flatGeometry(new THREE.DodecahedronGeometry(1, 0));
  const roundRockGeo = flatGeometry(new THREE.SphereGeometry(1, 7, 5));

  function addRock(x, z, sx, sy, sz, tone, moss = false, rounded = false, buried = false) {
    // 瀑底留白，避免岸石挡住水口。
    if (Math.hypot(x - (FALL_BOTTOM.x + FALL_X), z - FALL_BOTTOM.z) < 2.0) return;
    if (distanceToPath(x, z) < 0.52) return;
    const y = terrainHeight(x, z);
    TMP_OBJ.position.set(x, y + sy * (buried ? 0.18 : 0.34), z);
    TMP_OBJ.rotation.set(rockRng() * 3, rockRng() * 6, rockRng() * 3);
    TMP_OBJ.scale.set(sx, sy, sz);
    TMP_OBJ.updateMatrix();
    const color = new THREE.Color(tone);
    color.offsetHSL(0, (rockRng() - 0.5) * 0.06, (rockRng() - 0.5) * 0.09);
    (rounded ? roundRockData : rockData).push({ matrix: TMP_OBJ.matrix.clone(), color });
    if (moss) {
      TMP_OBJ.position.set(x + sx * 0.1, y + sy * 0.68, z + sz * 0.05);
      TMP_OBJ.rotation.set(0, rockRng() * 6, 0);
      TMP_OBJ.scale.set(sx * 0.62, sy * 0.18, sz * 0.58);
      TMP_OBJ.updateMatrix();
      mossData.push({
        matrix: TMP_OBJ.matrix.clone(),
        color: new THREE.Color().setHSL(0.25 + rockRng() * 0.04, 0.3, 0.28 + rockRng() * 0.1),
      });
    }
  }

  // 河岸用三层大小不一的卵石、碎石完全覆盖，打断原本平滑的水岸线。
  const bankTones = [0x596560, 0x6f7c76, 0x87928c, 0x9ba49d, 0x4f5b58];
  for (let z = -2.95; z < 9.15; z += 0.24) {
    for (const side of [-1, 1]) {
      const center = riverCenter(z) + side * riverWidth(z) * 0.5;
      if (rockRng() < 0.9) {
        const s = 0.055 + rockRng() * 0.19;
        addRock(
          center + side * (0.015 + rockRng() * 0.2),
          z + (rockRng() - 0.5) * 0.26,
          s * (0.8 + rockRng() * 0.75),
          s * (0.5 + rockRng() * 0.55),
          s * (0.8 + rockRng() * 0.8),
          bankTones[Math.floor(rockRng() * bankTones.length)],
          rockRng() > 0.82,
          rockRng() < 0.42,
          true
        );
      }
      if (rockRng() < 0.82) {
        const s = 0.11 + rockRng() * 0.28;
        addRock(
          center + side * (0.28 + rockRng() * 0.68),
          z + (rockRng() - 0.5) * 0.38,
          s * (0.75 + rockRng() * 0.8),
          s * (0.5 + rockRng() * 0.65),
          s * (0.7 + rockRng() * 0.8),
          bankTones[Math.floor(rockRng() * bankTones.length)],
          rockRng() > 0.7,
          rockRng() < 0.45,
          rockRng() < 0.36
        );
      }
      if (rockRng() < 0.4) {
        const s = 0.16 + rockRng() * 0.3;
        addRock(
          center + side * (0.8 + rockRng() * 0.95),
          z + (rockRng() - 0.5) * 0.45,
          s * (0.8 + rockRng() * 0.8),
          s * (0.55 + rockRng() * 0.55),
          s * (0.75 + rockRng() * 0.8),
          bankTones[Math.floor(rockRng() * bankTones.length)],
          rockRng() > 0.62,
          rockRng() < 0.5,
          false
        );
      }
    }
  }

  // 较大的岸石与山脚石
  const bigSpots = [
    [-1.65, 0.15, 0.62, 0.48],
    [1.85, 1.15, 0.7, 0.52],
    [-2.2, 4.0, 0.52, 0.4],
    [2.45, 4.85, 0.64, 0.45],
    [-3.35, 6.9, 0.5, 0.38],
    [4.65, 6.1, 0.58, 0.42],
    [-7.0, 2.5, 0.8, 0.62],
    [7.1, 2.4, 0.7, 0.55],
    [-7.4, -1.8, 0.95, 0.72],
    [6.8, -2.6, 0.8, 0.62],
    [-4.8, 8.35, 0.46, 0.38],
    [4.4, 8.2, 0.55, 0.43],
  ];
  for (let i = 0; i < bigSpots.length; i++) {
    const b = bigSpots[i];
    addRock(b[0], b[1], b[2], b[3], b[2] * (0.8 + rockRng() * 0.3), 0x84928b, rockRng() > 0.35);
  }

  // 山坡上零星的青灰岩块，破开大面积草坡。
  for (let i = 0; i < 22; i++) {
    const x = lerp(-8.2, 8.2, rockRng());
    const z = lerp(-8.2, 7.6, rockRng());
    const h = terrainHeight(x, z);
    if (h < 0.8 || h > 4.9) continue;
    if (terrainSlope(x, z) < 0.58) continue;
    if (distanceToPath(x, z) < 1.05) continue;
    if (Math.hypot(x - PAVILION.x, z - PAVILION.z) < 2.4) continue;
    if (z > -2.8 && Math.abs(x - riverCenter(z)) < riverWidth(z) * 0.65 + 0.3) continue;
    const s = 0.18 + rockRng() * 0.3;
    addRock(x, z, s * (0.9 + rockRng() * 0.5), s * 0.7, s, 0x7f8c85, rockRng() > 0.48);
  }

  // 古亭台基边缘
  for (let i = 0; i < 11; i++) {
    const ang = (i / 11) * Math.PI * 2;
    const rad = 1.72 + rockRng() * 0.38;
    const s = 0.13 + rockRng() * 0.12;
    addRock(
      PAVILION.x + Math.cos(ang) * rad,
      PAVILION.z + Math.sin(ang) * rad,
      s,
      s * 0.7,
      s * 0.9,
      0x8d968c,
      rockRng() > 0.5
    );
  }

  const rocks = new THREE.InstancedMesh(rockGeo, MAT.rock, rockData.length);
  for (let i = 0; i < rockData.length; i++) {
    rocks.setMatrixAt(i, rockData[i].matrix);
    rocks.setColorAt(i, rockData[i].color);
  }
  rocks.instanceMatrix.needsUpdate = true;
  if (rocks.instanceColor) rocks.instanceColor.needsUpdate = true;
  rocks.castShadow = true;
  rocks.receiveShadow = true;
  scene.add(rocks);

  const roundRocks = new THREE.InstancedMesh(roundRockGeo, MAT.rock, roundRockData.length);
  for (let i = 0; i < roundRockData.length; i++) {
    roundRocks.setMatrixAt(i, roundRockData[i].matrix);
    roundRocks.setColorAt(i, roundRockData[i].color);
  }
  roundRocks.instanceMatrix.needsUpdate = true;
  if (roundRocks.instanceColor) roundRocks.instanceColor.needsUpdate = true;
  roundRocks.castShadow = true;
  roundRocks.receiveShadow = true;
  scene.add(roundRocks);

  const moss = new THREE.InstancedMesh(flatGeometry(new THREE.IcosahedronGeometry(1, 0)), MAT.moss, mossData.length);
  for (let i = 0; i < mossData.length; i++) {
    moss.setMatrixAt(i, mossData[i].matrix);
    moss.setColorAt(i, mossData[i].color);
  }
  moss.instanceMatrix.needsUpdate = true;
  if (moss.instanceColor) moss.instanceColor.needsUpdate = true;
  moss.castShadow = false;
  moss.receiveShadow = true;
  scene.add(moss);
})();

// ---------------------------------------------------------------------------
// 地面落花
// ---------------------------------------------------------------------------

(function buildFallenPetals() {
  const prng = mulberry32(0x33e1a7);
  const petalGeo = new THREE.CircleGeometry(1, 5);
  petalGeo.rotateX(-Math.PI / 2);
  const data = [];
  const palette = [0xf7a5bb, 0xffc0d0, 0xf48fa9, 0xffdbe4, 0xe97d9e, 0xfff1f4];

  for (let i = 0; i < 12000; i++) {
    let x;
    let z;
    if (prng() < 0.8) {
      const t = treeSpecs[Math.floor(prng() * treeSpecs.length)];
      const ang = prng() * Math.PI * 2;
      const rad = Math.pow(prng(), 0.55) * t.crown * 1.7;
      x = t.x + Math.cos(ang) * rad;
      z = t.z + Math.sin(ang) * rad;
    } else {
      const s = pathSamples[Math.floor(prng() * pathSamples.length)];
      x = s.x + (prng() - 0.5) * 2.8;
      z = s.z + (prng() - 0.5) * 2.4;
    }
    if (Math.abs(x) > 9.3 || Math.abs(z) > 9.35) continue;
    if (z > -2.9 && Math.abs(x - riverCenter(z)) < riverWidth(z) * 0.62) continue;
    const y = terrainHeight(x, z);
    if (y < 0.04) continue;
    const scale = 0.045 + prng() * 0.105;
    TMP_OBJ.position.set(x, y + 0.018, z);
    TMP_OBJ.rotation.set((prng() - 0.5) * 0.32, prng() * Math.PI * 2, (prng() - 0.5) * 0.32);
    TMP_OBJ.scale.set(scale * (0.8 + prng() * 0.6), scale, scale * (0.55 + prng() * 0.4));
    TMP_OBJ.updateMatrix();
    data.push({
      matrix: TMP_OBJ.matrix.clone(),
      color: new THREE.Color(palette[Math.floor(prng() * palette.length)]),
    });
  }

  const petals = new THREE.InstancedMesh(petalGeo, MAT.petal, data.length);
  for (let i = 0; i < data.length; i++) {
    petals.setMatrixAt(i, data[i].matrix);
    petals.setColorAt(i, data[i].color);
  }
  petals.instanceMatrix.needsUpdate = true;
  if (petals.instanceColor) petals.instanceColor.needsUpdate = true;
  petals.castShadow = false;
  petals.receiveShadow = false;
  scene.add(petals);
})();

// ---------------------------------------------------------------------------
// 古亭
// ---------------------------------------------------------------------------

function buildCurvedRoofGeometry(half, height, lift, radialSegments = 10, angularSegments = 10) {
  const positions = [];
  const uvs = [];
  const indices = [];
  const total = 4 * angularSegments;
  for (let r = 0; r <= radialSegments; r++) {
    const rr = r / radialSegments;
    for (let s = 0; s <= total; s++) {
      const theta = (s / total) * Math.PI * 2;
      const c = Math.cos(theta);
      const sn = Math.sin(theta);
      const maxc = Math.max(Math.abs(c), Math.abs(sn));
      const radius = (half * rr) / maxc;
      const corner = Math.pow(Math.abs(Math.sin(2 * theta)), 7);
      const flare = 1 + 0.055 * Math.pow(rr, 5) * corner;
      const x = radius * c * flare;
      const z = radius * sn * flare;
      const y = -height * Math.pow(rr, 0.68) + lift * Math.pow(rr, 5) * corner;
      positions.push(x, y, z);
      uvs.push((x / half + 1) * 0.5, (z / half + 1) * 0.5);
    }
  }
  for (let r = 0; r < radialSegments; r++) {
    for (let s = 0; s < total; s++) {
      const a = r * (total + 1) + s;
      const b = a + 1;
      const c = (r + 1) * (total + 1) + s;
      const d = c + 1;
      // 逆时针朝上，保证屋面从上方可见、檐底壳从下方可见。
      indices.push(a, b, c, b, d, c);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function addRoofTiles(group, half, height, lift) {
  // 沿四坡从檐口到宝顶排布细圆柱瓦垄；整体只有一个 InstancedMesh。
  const tileMatrices = [];
  const tileColors = [];
  const tileRng = mulberry32(0x7a3c91);
  const pointAt = (theta, rr) => {
    const c = Math.cos(theta);
    const sn = Math.sin(theta);
    const maxc = Math.max(Math.abs(c), Math.abs(sn));
    const radius = (half * rr) / maxc;
    const corner = Math.pow(Math.abs(Math.sin(2 * theta)), 7);
    const flare = 1 + 0.055 * Math.pow(rr, 5) * corner;
    const y = -height * Math.pow(rr, 0.68) + lift * Math.pow(rr, 5) * corner;
    return V3(radius * c * flare, y + 0.06, radius * sn * flare);
  };

  const ribs = 13;
  const segments = 9;
  for (let face = 0; face < 4; face++) {
    for (let rib = 0; rib < ribs; rib++) {
      const t = (rib / (ribs - 1) - 0.5) * 0.88;
      const theta = face * Math.PI * 0.5 + t * Math.PI * 0.5;
      for (let s = 0; s < segments; s++) {
        const r0 = 0.075 + (s / segments) * 0.9;
        const r1 = 0.075 + ((s + 1.12) / segments) * 0.9;
        const start = pointAt(theta, r0);
        const end = pointAt(theta, Math.min(r1, 1.02));
        const matrix = composeSegment(start, end, 0.035 + tileRng() * 0.008);
        if (!matrix) continue;
        tileMatrices.push(matrix);
        const tone = new THREE.Color(0x4d7782);
        tone.offsetHSL(0, (tileRng() - 0.5) * 0.02, (tileRng() - 0.5) * 0.07);
        tileColors.push(tone);
      }
    }
  }
  const geometry = new THREE.CylinderGeometry(1, 1, 1, 5, 1);
  const tiles = new THREE.InstancedMesh(geometry, MAT.roofTile, tileMatrices.length);
  for (let i = 0; i < tileMatrices.length; i++) {
    tiles.setMatrixAt(i, tileMatrices[i]);
    tiles.setColorAt(i, tileColors[i]);
  }
  tiles.instanceMatrix.needsUpdate = true;
  if (tiles.instanceColor) tiles.instanceColor.needsUpdate = true;
  tiles.castShadow = true;
  tiles.receiveShadow = true;
  group.add(tiles);
}

function addRoofDetails(group, half, height, lift) {
  const corners = [
    [half, -height + lift, half],
    [-half, -height + lift, half],
    [-half, -height + lift, -half],
    [half, -height + lift, -half],
  ];
  const ridgeMat = MAT.pavilionRoofDark;

  // 四条垂脊
  for (let i = 0; i < 4; i++) {
    const [cx, , cz] = corners[i];
    const pts = [];
    for (let j = 0; j <= 8; j++) {
      const rr = j / 8;
      const y = -height * Math.pow(rr, 0.68) + lift * Math.pow(rr, 5);
      pts.push(V3(cx * rr, y + 0.01, cz * rr));
    }
    const curve = new THREE.CatmullRomCurve3(pts);
    const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 18, 0.026, 4, false), ridgeMat);
    tube.castShadow = true;
    group.add(tube);
  }

  // 檐口一圈
  const eavePts = [];
  for (let i = 0; i < 96; i++) {
    const theta = (i / 96) * Math.PI * 2;
    const c = Math.cos(theta);
    const sn = Math.sin(theta);
    const maxc = Math.max(Math.abs(c), Math.abs(sn));
    const radius = half / maxc;
    const corner = Math.pow(Math.abs(Math.sin(2 * theta)), 7);
    const flare = 1 + 0.055 * corner;
    eavePts.push(V3(radius * c * flare, -height + lift * corner, radius * sn * flare));
  }
  const eaveCurve = new THREE.CatmullRomCurve3(eavePts, true);
  const eave = new THREE.Mesh(new THREE.TubeGeometry(eaveCurve, 128, 0.04, 5, true), ridgeMat);
  eave.castShadow = true;
  group.add(eave);

  // 四角起翘
  for (let i = 0; i < 4; i++) {
    const [cx, cy, cz] = corners[i];
    const out = V3(cx, 0, cz).normalize();
    const hornPts = [
      V3(cx * 0.98, cy, cz * 0.98),
      V3(cx * 1.04 + out.x * 0.08, cy + 0.07, cz * 1.04 + out.z * 0.08),
      V3(cx * 1.08 + out.x * 0.2, cy + 0.23, cz * 1.08 + out.z * 0.2),
    ];
    const horn = new THREE.Mesh(
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(hornPts), 10, 0.025, 4, false),
      MAT.gold
    );
    horn.castShadow = true;
    group.add(horn);
    const tip = new THREE.Mesh(new THREE.IcosahedronGeometry(0.055, 0), MAT.gold);
    tip.position.copy(hornPts[2]);
    tip.castShadow = true;
    group.add(tip);
  }
}

const pavilionGroup = new THREE.Group();
scene.add(pavilionGroup);
const pavilionLanterns = [];
(function buildPavilion() {
  const baseY = terrainHeight(PAVILION.x, PAVILION.z);
  pavilionGroup.position.set(PAVILION.x, baseY, PAVILION.z);
  pavilionGroup.rotation.y = 0.1;

  const stone = MAT.stoneLight;
  const wood = MAT.pavilionWood;
  const woodDark = MAT.pavilionWoodDark;

  // 台基
  boxMesh(pavilionGroup, 3.65, 0.14, 3.65, stone, 0, 0.02, 0);
  boxMesh(pavilionGroup, 3.28, 0.22, 3.28, stone, 0, 0.14, 0);
  boxMesh(pavilionGroup, 2.62, 0.09, 2.62, woodDark, 0, 0.285, 0);
  boxMesh(pavilionGroup, 2.45, 0.055, 2.45, MAT.wood, 0, 0.34, 0);

  // 三级台阶
  for (let i = 0; i < 3; i++) {
    boxMesh(
      pavilionGroup,
      1.03 + i * 0.13,
      0.09,
      0.34,
      stone,
      0,
      0.2 - i * 0.055,
      1.83 + i * 0.26
    );
  }

  // 四根朱红柱与柱础
  const colH = 1.65;
  const colPositions = [
    [-0.98, -0.98],
    [0.98, -0.98],
    [-0.98, 0.98],
    [0.98, 0.98],
  ];
  for (let i = 0; i < 4; i++) {
    const [x, z] = colPositions[i];
    cylMesh(pavilionGroup, 0.075, 0.078, colH, 8, wood, x, 0.36 + colH * 0.5, z);
    cylMesh(pavilionGroup, 0.13, 0.15, 0.12, 8, stone, x, 0.4, z);
    // 柱头
    boxMesh(pavilionGroup, 0.2, 0.08, 0.2, woodDark, x, 0.36 + colH - 0.02, z);
  }

  // 梁枋
  const beamY = 0.36 + colH - 0.1;
  for (const s of [-1, 1]) {
    boxMesh(pavilionGroup, 2.15, 0.12, 0.1, woodDark, 0, beamY, s * 0.98);
    boxMesh(pavilionGroup, 0.1, 0.12, 2.15, woodDark, s * 0.98, beamY, 0);
  }
  // 顶梁压低在屋面之内，不能高过攒尖屋顶的宝顶。
  boxMesh(pavilionGroup, 2.02, 0.08, 2.02, woodDark, 0, beamY - 0.03, 0);

  // 栏杆：后侧与两侧，前面留空
  function railing(x1, z1, x2, z2) {
    const len = Math.hypot(x2 - x1, z2 - z1);
    const mx = (x1 + x2) * 0.5;
    const mz = (z1 + z2) * 0.5;
    const yaw = Math.atan2(x2 - x1, z2 - z1);
    const g = new THREE.Group();
    g.position.set(mx, 0.36, mz);
    g.rotation.y = yaw;
    pavilionGroup.add(g);
    boxMesh(g, 0.05, 0.05, len, wood, 0, 0.34, 0);
    boxMesh(g, 0.04, 0.04, len, wood, 0, 0.58, 0);
    const posts = Math.max(2, Math.round(len / 0.4));
    for (let i = 0; i <= posts; i++) {
      const pz = lerp(-len * 0.5, len * 0.5, i / posts);
      cylMesh(g, 0.025, 0.03, 0.62, 5, wood, 0, 0.31, pz, false, true);
    }
    // 花纹小格
    for (let i = 0; i < posts; i++) {
      const pz = lerp(-len * 0.5, len * 0.5, (i + 0.5) / posts);
      boxMesh(g, 0.026, 0.028, len / posts * 0.55, woodDark, 0, 0.47, pz, false, true);
    }
  }
  railing(-0.98, -0.98, 0.98, -0.98);
  railing(-0.98, -0.98, -0.98, 0.98);
  railing(0.98, -0.98, 0.98, 0.98);

  // 石桌与茶盏
  cylMesh(pavilionGroup, 0.33, 0.37, 0.1, 10, stone, 0, 0.49, -0.05);
  cylMesh(pavilionGroup, 0.11, 0.13, 0.42, 8, stone, 0, 0.72, -0.05);
  cylMesh(pavilionGroup, 0.26, 0.3, 0.07, 10, stone, 0, 0.95, -0.05);
  cylMesh(pavilionGroup, 0.05, 0.05, 0.035, 8, MAT.paper, -0.1, 1.0, -0.03, false, false);
  cylMesh(pavilionGroup, 0.05, 0.05, 0.035, 8, MAT.paper, 0.1, 1.0, -0.08, false, false);

  // 二层小檐与屋顶
  // 檐口落在梁枋之上，避免方形梁穿透屋面。
  const roofY = 0.36 + colH + 0.82;
  const half = 1.96;
  const roofH = 1.08;
  const lift = 0.27;
  const roofGeo = buildCurvedRoofGeometry(half, roofH, lift, 11, 11);
  const roof = new THREE.Mesh(roofGeo, MAT.pavilionRoof);
  roof.position.y = roofY;
  roof.castShadow = true;
  roof.receiveShadow = true;
  pavilionGroup.add(roof);

  const underGeo = roofGeo.clone();
  underGeo.translate(0, -0.03, 0);
  const under = new THREE.Mesh(underGeo, MAT.pavilionRoofUnder);
  under.material = MAT.pavilionRoofUnder;
  under.position.y = roofY;
  under.material.side = THREE.BackSide;
  under.castShadow = false;
  pavilionGroup.add(under);

  const roofDetails = new THREE.Group();
  roofDetails.position.y = roofY;
  pavilionGroup.add(roofDetails);
  addRoofTiles(roofDetails, half, roofH, lift);
  addRoofDetails(roofDetails, half, roofH, lift);

  // 宝顶
  cylMesh(pavilionGroup, 0.035, 0.06, 0.32, 8, MAT.gold, 0, roofY + 0.13, 0);
  const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.09, 1), MAT.gold);
  orb.position.set(0, roofY + 0.34, 0);
  orb.castShadow = true;
  pavilionGroup.add(orb);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.18, 7), MAT.gold);
  tip.position.set(0, roofY + 0.47, 0);
  tip.castShadow = true;
  pavilionGroup.add(tip);

  // 亭内暖灯
  const glowTex = makeGlowTexture();
  for (const side of [-1, 1]) {
    const lantern = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.18, 8), MAT.paper);
    lantern.position.set(side * 0.72, beamY - 0.18, 0.82);
    pavilionGroup.add(lantern);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.04, 8), woodDark);
    cap.position.set(side * 0.72, beamY - 0.08, 0.82);
    pavilionGroup.add(cap);

    const glow = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: glowTex,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        opacity: 0.5,
        color: 0xffbd72,
        fog: false,
      })
    );
    glow.position.set(side * 0.72, beamY - 0.18, 0.84);
    glow.scale.set(0.9, 0.9, 1);
    pavilionGroup.add(glow);
    pavilionLanterns.push({ sprite: glow, phase: side * 2.3 });
  }

  // 亭顶外侧的一圈小瓦当
  for (let i = 0; i < 32; i++) {
    const theta = (i / 32) * Math.PI * 2;
    const c = Math.cos(theta);
    const sn = Math.sin(theta);
    const maxc = Math.max(Math.abs(c), Math.abs(sn));
    const radius = half / maxc * 0.955;
    const corner = Math.pow(Math.abs(Math.sin(2 * theta)), 7);
    const y = -roofH + lift * corner;
    const drop = new THREE.Mesh(new THREE.SphereGeometry(0.028, 5, 4), MAT.pavilionRoofDark);
    drop.position.set(radius * c, roofY + y - 0.03, radius * sn);
    pavilionGroup.add(drop);
  }
})();

// ---------------------------------------------------------------------------
// 古风石灯笼
// ---------------------------------------------------------------------------

const lanternLights = [];
const glowTexture = makeGlowTexture();

function buildStoneLantern(x, z, yaw = 0, scale = 1) {
  const group = new THREE.Group();
  group.position.set(x, terrainHeight(x, z) - 0.02, z);
  group.rotation.y = yaw;
  group.scale.setScalar(scale);
  scene.add(group);

  boxMesh(group, 0.38, 0.1, 0.38, MAT.lanternStone, 0, 0.05, 0);
  cylMesh(group, 0.1, 0.14, 0.5, 8, MAT.lanternStone, 0, 0.35, 0);
  boxMesh(group, 0.27, 0.07, 0.27, MAT.lanternStone, 0, 0.62, 0);
  boxMesh(group, 0.3, 0.26, 0.3, MAT.lanternStone, 0, 0.78, 0);

  // 四面透光小窗
  for (let i = 0; i < 4; i++) {
    const ang = (i / 4) * Math.PI * 2;
    const panel = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 0.16), MAT.paper);
    panel.position.set(Math.cos(ang) * 0.152, 0.78, Math.sin(ang) * 0.152);
    panel.rotation.y = -ang + Math.PI * 0.5;
    group.add(panel);
  }

  const cap = new THREE.Mesh(new THREE.ConeGeometry(0.26, 0.18, 4), MAT.lanternStone);
  cap.position.y = 0.98;
  cap.rotation.y = Math.PI * 0.25;
  cap.castShadow = true;
  group.add(cap);
  const finial = new THREE.Mesh(new THREE.IcosahedronGeometry(0.055, 0), MAT.lanternStone);
  finial.position.y = 1.1;
  finial.castShadow = true;
  group.add(finial);

  const light = new THREE.PointLight(0xffb763, 0.9, 2.4, 2.0);
  light.position.set(0, 0.82, 0);
  group.add(light);
  lanternLights.push({ light, base: 0.9, phase: rand(0, 8) });

  const glow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      opacity: 0.16,
      color: 0xffb65f,
      fog: true,
    })
  );
  glow.position.set(0, 0.82, 0);
  glow.scale.set(1.1, 1.1, 1);
  glow.renderOrder = 7;
  group.add(glow);
  group.userData.glow = glow;

  return group;
}

(function placeLanterns() {
  const spots = [
    [0.18, -1],
    [0.36, 1],
    [0.54, -1],
    [0.72, 1],
    [0.86, -1],
  ];
  for (let i = 0; i < spots.length; i++) {
    const s = pathSamples[Math.floor(spots[i][0] * (pathSamples.length - 1))];
    const len = Math.hypot(s.tx, s.tz) || 1;
    const sx = -s.tz / len;
    const sz = s.tx / len;
    const side = spots[i][1];
    const x = s.x + sx * side * 0.82;
    const z = s.z + sz * side * 0.82;
    buildStoneLantern(x, z, Math.atan2(s.tx, s.tz) + Math.PI, 1.15);
  }
})();

// ---------------------------------------------------------------------------
// 桃花源中的小小游人
// ---------------------------------------------------------------------------

(function buildWanderer() {
  const s = pathSamples[Math.floor(pathSamples.length * 0.24)];
  const group = new THREE.Group();
  group.position.set(s.x + 0.06, terrainHeight(s.x, s.z) + 0.02, s.z);
  group.rotation.y = Math.atan2(s.tx, s.tz) + Math.PI;
  scene.add(group);

  const dress = toon(0xf4c3ca);
  const dressShade = toon(0xd99baa);
  const skin = toon(0xf4d2bc);
  const hair = toon(0x2d2326);
  const white = toon(0xfff4f1);

  // 长裙
  addMesh(group, new THREE.ConeGeometry(0.19, 0.56, 8), dress, 0, 0.3, 0, true, false);
  addMesh(group, new THREE.CylinderGeometry(0.1, 0.14, 0.22, 8), dressShade, 0, 0.58, 0, true, false);
  // 腰带
  addMesh(group, new THREE.TorusGeometry(0.105, 0.018, 5, 12), dressShade, 0, 0.52, 0, true, false).rotation.x = Math.PI / 2;
  // 上衣
  addMesh(group, new THREE.CylinderGeometry(0.09, 0.1, 0.24, 8), white, 0, 0.73, 0, true, false);
  // 头
  addMesh(group, new THREE.SphereGeometry(0.087, 10, 8), skin, 0, 0.9, 0, true, false);
  addMesh(group, new THREE.SphereGeometry(0.092, 10, 8), hair, 0, 0.925, -0.006, true, false);
  const hairCap = addMesh(group, new THREE.SphereGeometry(0.055, 8, 6), hair, 0, 0.85, -0.07, true, false);
  hairCap.scale.set(1.05, 1.2, 1.1);
  // 发髻
  addMesh(group, new THREE.SphereGeometry(0.042, 8, 6), hair, 0, 0.985, -0.005, true, false);
  // 双臂
  const armGeo = new THREE.CylinderGeometry(0.018, 0.022, 0.26, 5);
  for (const side of [-1, 1]) {
    const arm = new THREE.Mesh(armGeo, skin);
    arm.position.set(side * 0.115, 0.7, 0.01);
    arm.rotation.z = side * 0.25;
    arm.rotation.x = 0.2;
    arm.castShadow = true;
    group.add(arm);
  }
  // 裙摆飘带
  const ribbon = new THREE.Mesh(new THREE.PlaneGeometry(0.08, 0.3), dressShade);
  ribbon.position.set(0.12, 0.42, -0.08);
  ribbon.rotation.z = 0.3;
  ribbon.rotation.y = 0.5;
  group.add(ribbon);
  group.userData.ribbon = ribbon;
  group.userData.phase = 2.2;
})();

// ---------------------------------------------------------------------------
// 空中花瓣雨
// ---------------------------------------------------------------------------

const rainPetalGeo = (() => {
  const geo = new THREE.PlaneGeometry(1, 0.68, 2, 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    pos.setZ(i, Math.abs(x) * 0.12 + Math.cos(y * 2.2) * 0.045);
  }
  geo.computeVertexNormals();
  return geo;
})();

const PETAL_RAIN_COUNT = 2600;
const petalRain = [];
const petalRainMaterial = new THREE.MeshBasicMaterial({
  color: 0xffffff,
  side: THREE.DoubleSide,
  transparent: true,
  opacity: 0.9,
  depthWrite: false,
  toneMapped: false,
});
const petalRainMesh = new THREE.InstancedMesh(rainPetalGeo, petalRainMaterial, PETAL_RAIN_COUNT);
petalRainMesh.renderOrder = 4;
petalRainMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
petalRainMesh.castShadow = false;
petalRainMesh.receiveShadow = false;
petalRainMesh.frustumCulled = false;
scene.add(petalRainMesh);

(function initPetalRain() {
  const prng = mulberry32(0xb05a19);
  const palette = [0xf79bb2, 0xffb9c9, 0xffd3de, 0xee86a3, 0xffe5eb, 0xfff2f5];
  for (let i = 0; i < PETAL_RAIN_COUNT; i++) {
    petalRain.push({
      x: lerp(-10.7, 10.7, prng()),
      y: lerp(0.5, 12.2, prng()),
      z: lerp(-10.5, 10.7, prng()),
      speed: 0.22 + prng() * 0.42,
      swaySpeed: 0.5 + prng() * 1.1,
      swayAmp: 0.22 + prng() * 0.38,
      phase: prng() * Math.PI * 2,
      spinX: (prng() - 0.5) * 1.1,
      spinY: (prng() - 0.5) * 1.8,
      spinZ: (prng() - 0.5) * 1.1,
      rotX: prng() * 6,
      rotY: prng() * 6,
      rotZ: prng() * 6,
      scale: 0.045 + prng() * 0.1,
      color: new THREE.Color(palette[Math.floor(prng() * palette.length)]),
    });
    petalRainMesh.setColorAt(i, petalRain[i].color);
  }
  if (petalRainMesh.instanceColor) petalRainMesh.instanceColor.needsUpdate = true;
})();

const petalDummy = new THREE.Object3D();
function updatePetalRain(dt, time, breeze = 0) {
  const gust = clamp(breeze, 0, 1);
  const fallMultiplier = 1 + gust * 2.8;
  const windX = gust * 3.2;
  const windZ = -gust * 0.55;
  for (let i = 0; i < PETAL_RAIN_COUNT; i++) {
    const p = petalRain[i];
    p.y -= p.speed * dt * fallMultiplier;
    p.x += (Math.sin(time * p.swaySpeed + p.phase) * p.swayAmp * (1 + gust * 1.8) + windX) * dt;
    p.z += (Math.cos(time * p.swaySpeed * 0.71 + p.phase) * p.swayAmp * 0.52 * (1 + gust * 1.4) + windZ) * dt;
    p.rotX += p.spinX * dt * (1 + gust * 1.4);
    p.rotY += p.spinY * dt * (1 + gust * 1.4);
    p.rotZ += p.spinZ * dt * (1 + gust * 1.4);

    const ground = Math.max(0.16, terrainHeight(p.x, p.z) + 0.12);
    if (p.y < ground || Math.abs(p.x) > 12.5 || Math.abs(p.z) > 12.5) {
      p.x = rand(-10.7, 10.7);
      p.z = rand(-10.5, 10.7);
      p.y = rand(9.5, 13.8);
    }

    petalDummy.position.set(p.x, p.y, p.z);
    petalDummy.rotation.set(p.rotX, p.rotY, p.rotZ);
    petalDummy.scale.set(p.scale, p.scale * 0.78, p.scale);
    petalDummy.updateMatrix();
    petalRainMesh.setMatrixAt(i, petalDummy.matrix);
  }
  petalRainMaterial.opacity = 0.9 + gust * 0.1;
  petalRainMesh.instanceMatrix.needsUpdate = true;
}

// ---------------------------------------------------------------------------
// 雨后初霁：太阳雨与半圆彩虹
// ---------------------------------------------------------------------------

const RAIN_DROP_COUNT = 750;
const rainDrops = [];
const rainPositions = new Float32Array(RAIN_DROP_COUNT * 6);
const rainGeometry = new THREE.BufferGeometry();
const rainPositionAttr = new THREE.BufferAttribute(rainPositions, 3);
rainPositionAttr.setUsage(THREE.DynamicDrawUsage);
rainGeometry.setAttribute('position', rainPositionAttr);
const rainMaterial = new THREE.LineBasicMaterial({
  color: 0xe8edf1,
  transparent: true,
  opacity: 0,
  linewidth: 0.55,
  depthWrite: false,
  toneMapped: false,
});
const rainSystem = new THREE.LineSegments(rainGeometry, rainMaterial);
rainSystem.frustumCulled = false;
rainSystem.visible = false;
rainSystem.renderOrder = 5;
scene.add(rainSystem);

(function initRain() {
  const rrng = mulberry32(0x7a31c2);
  for (let i = 0; i < RAIN_DROP_COUNT; i++) {
    rainDrops.push({
      x: lerp(-11.2, 11.2, rrng()),
      y: rrng() * 14 + 0.3,
      z: lerp(-10.5, 11.4, rrng()),
      speed: 8.5 + rrng() * 6.2,
      length: 0.12 + rrng() * 0.2,
      phase: rrng() * Math.PI * 2,
    });
  }
})();

function updateRain(dt, time, amount) {
  const a = clamp(amount, 0, 1);
  rainSystem.visible = a > 0.012;
  if (!rainSystem.visible) return;
  rainMaterial.opacity = a * 0.3;
  for (let i = 0; i < RAIN_DROP_COUNT; i++) {
    const d = rainDrops[i];
    d.y -= d.speed * dt;
    d.x += (0.08 + Math.sin(time * 0.8 + d.phase) * 0.03) * dt;
    if (d.y < 0.08) {
      d.x = rand(-11.2, 11.2);
      d.z = rand(-10.5, 11.4);
      d.y = rand(11.5, 15.5);
    }
    const j = i * 6;
    rainPositions[j] = d.x;
    rainPositions[j + 1] = d.y;
    rainPositions[j + 2] = d.z;
    rainPositions[j + 3] = d.x + 0.035;
    rainPositions[j + 4] = d.y - d.length;
    rainPositions[j + 5] = d.z;
  }
  rainPositionAttr.needsUpdate = true;
}

const rainbowGroup = new THREE.Group();
rainbowGroup.position.set(0, 1.4, -17.5);
rainbowGroup.visible = false;
scene.add(rainbowGroup);

const rainbowMaterials = [];
const rainbowColors = [0xff3b3b, 0xffd23f, 0x65e6a2, 0x4aa8ff];
for (let i = 0; i < rainbowColors.length; i++) {
  // 红色在外、蓝色在内，更接近真实彩虹的色序。
  const radius = 10.46 - i * 0.32;
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(radius, 0.042, 6, 96, Math.PI),
    new THREE.MeshBasicMaterial({
      color: new THREE.Color(rainbowColors[i]).multiplyScalar(1.8),
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      blending: THREE.NormalBlending,
      depthWrite: false,
      toneMapped: false,
    })
  );
  ring.frustumCulled = false;
  ring.renderOrder = 3 + i;
  rainbowGroup.add(ring);
  rainbowMaterials.push(ring.material);
}

function updateRainbow(time, reveal) {
  const a = clamp(reveal, 0, 1);
  rainbowGroup.visible = a > 0.001;
  if (!rainbowGroup.visible) return;
  const eased = a * a * (3 - 2 * a);
  rainbowGroup.position.y = 1.4 + Math.sin(time * 0.35) * 0.16;
  rainbowGroup.rotation.y = Math.atan2(
    camera.position.x - rainbowGroup.position.x,
    camera.position.z - rainbowGroup.position.z
  );
  // 只做透明渐显渐隐，保持固定大小。
  rainbowGroup.scale.setScalar(1);
  for (let i = 0; i < rainbowMaterials.length; i++) {
    rainbowMaterials[i].opacity = (0.6 - i * 0.02) * eased;
  }
}

const fxState = {
  breezeActive: false,
  breezeTarget: 0,
  breeze: 0,
  rainActive: false,
  rainTarget: 0,
  rain: 0,
  rainbowReveal: 0,
};

// ---------------------------------------------------------------------------
// 溪面上的花瓣
// ---------------------------------------------------------------------------

const waterPetals = [];
const waterPetalMesh = new THREE.InstancedMesh(new THREE.CircleGeometry(0.055, 5), MAT.petal, 180);
waterPetalMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
waterPetalMesh.castShadow = false;
waterPetalMesh.receiveShadow = false;
waterPetalMesh.renderOrder = 3;
scene.add(waterPetalMesh);
(function initWaterPetals() {
  const prng = mulberry32(0x662b8f);
  const palette = [0xf69cb3, 0xffc2d0, 0xffdae3, 0xed86a3];
  for (let i = 0; i < 180; i++) {
    waterPetals.push({
      z: lerp(-1.65, 8.9, prng()),
      lat: (prng() - 0.5) * 0.8,
      speed: 0.16 + prng() * 0.23,
      phase: prng() * 8,
      rot: prng() * Math.PI * 2,
      spin: (prng() - 0.5) * 0.55,
      scale: 0.65 + prng() * 0.8,
      color: new THREE.Color(palette[Math.floor(prng() * palette.length)]),
    });
    waterPetalMesh.setColorAt(i, waterPetals[i].color);
  }
  if (waterPetalMesh.instanceColor) waterPetalMesh.instanceColor.needsUpdate = true;
})();

function updateWaterPetals(dt, time) {
  for (let i = 0; i < waterPetals.length; i++) {
    const p = waterPetals[i];
    p.z += p.speed * dt;
    if (p.z > 9.25) {
      p.z = -1.8;
      p.lat = (rand(-0.45, 0.45));
    }
    const w = riverWidth(p.z);
    const x = riverCenter(p.z) + p.lat * w;
    const y = WATER_LEVEL + 0.017 + Math.sin(time * 1.8 + p.phase) * 0.004;
    p.rot += p.spin * dt;
    petalDummy.position.set(x, y, p.z);
    petalDummy.rotation.set(-Math.PI / 2, 0, p.rot);
    petalDummy.scale.set(p.scale, p.scale * 0.72, p.scale);
    petalDummy.updateMatrix();
    waterPetalMesh.setMatrixAt(i, petalDummy.matrix);
  }
  waterPetalMesh.instanceMatrix.needsUpdate = true;
}

// ---------------------------------------------------------------------------
// 瀑布水花动画
// ---------------------------------------------------------------------------

const splashSystem = (() => {
  let fallGroup = null;
  scene.traverse((o) => {
    if (!fallGroup && o.userData && o.userData.splash) fallGroup = o;
  });
  return fallGroup ? fallGroup.userData.splash : null;
})();

function updateSplash(dt, time) {
  if (!splashSystem) return;
  const arr = splashSystem.geo.attributes.position.array;
  const state = splashSystem.state;
  for (let i = 0; i < state.length; i++) {
    const s = state[i];
    s.life -= dt * s.speed;
    if (s.life <= 0) {
      s.life = 1;
      s.x = FALL_BOTTOM.x + rand(-0.5, 0.5);
      s.z = FALL_BOTTOM.z + rand(-0.28, 0.3);
      s.y = 0.18 + rand(0, 0.12);
      s.vx = rand(-0.32, 0.32);
      s.vy = rand(0.35, 1.0);
      s.vz = rand(-0.22, 0.22);
    }
    s.vy -= 1.55 * dt;
    s.x += s.vx * dt;
    s.y += s.vy * dt;
    s.z += s.vz * dt;
    if (s.y < 0.16) {
      s.y = 0.16;
      s.vy *= -0.28;
      s.vx *= 0.7;
      s.vz *= 0.7;
    }
    arr[i * 3] = s.x;
    arr[i * 3 + 1] = s.y;
    arr[i * 3 + 2] = s.z;
  }
  splashSystem.geo.attributes.position.needsUpdate = true;
}

// ---------------------------------------------------------------------------
// 古风交互按钮
// ---------------------------------------------------------------------------

const petalButton = document.getElementById('btn-petals');
const rainButton = document.getElementById('btn-rain');

function setButtonActive(button, active) {
  if (!button) return;
  button.classList.toggle('is-active', active);
  button.setAttribute('aria-pressed', active ? 'true' : 'false');
}

if (petalButton) {
  petalButton.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    fxState.breezeActive = !fxState.breezeActive;
    fxState.breezeTarget = fxState.breezeActive ? 1 : 0;
    setButtonActive(petalButton, fxState.breezeActive);
  });
}

if (rainButton) {
  rainButton.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    fxState.rainActive = !fxState.rainActive;
    fxState.rainTarget = fxState.rainActive ? 1 : 0;
    setButtonActive(rainButton, fxState.rainActive);
  });
}

// ---------------------------------------------------------------------------
// 动画
// ---------------------------------------------------------------------------

const clock = new THREE.Clock();
let elapsed = 0;
let frameCount = 0;

function animate() {
  const dt = Math.min(clock.getDelta(), 0.05);
  elapsed += dt;

  riverUniforms.uTime.value = elapsed;
  if (waterSparkleMaterial) waterSparkleMaterial.uniforms.uTime.value = elapsed;
  for (let i = 0; i < fallMaterials.length; i++) {
    fallMaterials[i].uniforms.uTime.value = elapsed;
  }

  fxState.breeze += (fxState.breezeTarget - fxState.breeze) * Math.min(1, dt * 5.0);
  fxState.rain += (fxState.rainTarget - fxState.rain) * Math.min(1, dt * 4.0);
  // 彩虹用固定 2.6s 的线性过渡，和雨丝淡入分离，避免点击时瞬间弹出。
  fxState.rainbowReveal = clamp(
    fxState.rainbowReveal + (fxState.rainActive ? 1 : -1) * (dt / 2.6),
    0,
    1
  );
  windUniforms.uWindTime.value = elapsed;
  windUniforms.uWindStrength.value = fxState.breeze;
  if (skyMaterial) skyMaterial.uniforms.uRain.value = fxState.rain;

  updatePetalRain(dt, elapsed, fxState.breeze);
  updateWaterPetals(dt, elapsed);
  updateSplash(dt, elapsed);
  updateSilkRibbons(elapsed, fxState.breeze);
  updateRain(dt, elapsed, fxState.rain);
  updateRainbow(elapsed, fxState.rainbowReveal);

  // 灯笼的微光呼吸
  for (let i = 0; i < lanternLights.length; i++) {
    const l = lanternLights[i];
    l.light.intensity = l.base * (0.9 + 0.1 * Math.sin(elapsed * 2.1 + l.phase));
  }
  for (let i = 0; i < pavilionLanterns.length; i++) {
    const l = pavilionLanterns[i];
    l.sprite.material.opacity = 0.43 + 0.08 * Math.sin(elapsed * 1.8 + l.phase);
  }

  // 溪面浮光的闪烁
  if (riverGroup && riverGroup.userData.glints) {
    const glints = riverGroup.userData.glints;
    if (glints.length) {
      glints[0].mesh.material.opacity = 0.34 + 0.24 * (0.5 + 0.5 * Math.sin(elapsed * 2.2));
    }
    for (let i = 0; i < glints.length; i++) {
      const g = glints[i];
      g.mesh.position.x += Math.sin(elapsed * 0.4 + g.phase) * 0.0006;
    }
  }

  // 瀑底水环
  for (let i = 0; i < fallRings.length; i++) {
    const ring = fallRings[i];
    const cycle = (elapsed * ring.rate + ring.phase) % 1;
    const s = 0.5 + cycle * 2.8;
    ring.mesh.scale.set(s, s, s);
    ring.mesh.material.opacity = Math.pow(1 - cycle, 1.7) * 0.65;
  }

  // 山谷薄雾缓慢平移
  for (let i = 0; i < valleyMists.length; i++) {
    const m = valleyMists[i];
    m.sprite.position.x = m.baseX + Math.sin(elapsed * 0.09 + m.phase) * 0.55;
    m.sprite.position.y = m.baseY + Math.sin(elapsed * 0.16 + m.phase) * 0.1;
    m.sprite.material.opacity = 0.1 + 0.035 * (0.5 + 0.5 * Math.sin(elapsed * 0.13 + m.phase));
  }

  // 瀑布水雾轻轻漂移
  for (let i = 0; i < fallMistSprites.length; i++) {
    const m = fallMistSprites[i];
    m.position.x = m.userData.baseX + Math.sin(elapsed * 0.35 + m.userData.phase) * 0.16;
    m.position.y = m.userData.baseY + Math.sin(elapsed * 0.5 + m.userData.phase) * 0.06;
  }

  // 远处云影缓慢漂移
  for (let i = 0; i < driftingClouds.length; i++) {
    const c = driftingClouds[i];
    c.sprite.position.x = c.x + Math.sin(elapsed * 0.035 + c.phase) * 1.1;
    c.sprite.position.y = c.baseY + Math.sin(elapsed * 0.05 + c.phase) * 0.18;
  }

  controls.update();
  // 对焦在构图目标附近；竖屏拉远时也保持一致的前景/背景分离。
  post.dofPass.material.uniforms.uFocus.value = Math.max(
    12,
    camera.position.distanceTo(controls.target) - 1.6
  );
  if (typeof updateGodRays === 'function') updateGodRays();
  renderer.info.autoReset = false;
  renderer.info.reset();
  post.composer.render(dt);
  if (window.__TAOHUAYUAN__) {
    window.__TAOHUAYUAN__.sceneStats = {
      calls: renderer.info.render.calls,
      triangles: renderer.info.render.triangles,
      points: renderer.info.render.points,
      lines: renderer.info.render.lines,
    };
  }
  frameCount++;
  if (frameCount === 8) {
    renderer.shadowMap.autoUpdate = false;
    document.documentElement.dataset.sceneReady = '1';
  }
}

renderer.setAnimationLoop(animate);

// ---------------------------------------------------------------------------
// 尺寸
// ---------------------------------------------------------------------------

function onResize() {
  const aspect = window.innerWidth / window.innerHeight;
  const dpr = Math.min(Math.max(window.devicePixelRatio || 1, 1.15), 1.25);
  renderer.setPixelRatio(dpr);
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = aspect;
  camera.fov = aspect < 0.82 ? 56 : aspect < 1.08 ? 46 : 42;
  camera.updateProjectionMatrix();
  post.resize();
  if (waterSparkleMaterial) {
    waterSparkleMaterial.uniforms.uPixelRatio.value = dpr;
  }
  renderer.shadowMap.needsUpdate = true;
}

window.addEventListener('resize', onResize, { passive: true });
window.addEventListener('orientationchange', onResize, { passive: true });

window.__TAOHUAYUAN__ = {
  scene,
  camera,
  renderer,
  controls,
  treeSpecs,
  post,
  fx: fxState,
  rainSystem,
  rainbowGroup,
  buttons: { petals: petalButton, rain: rainButton },
};
